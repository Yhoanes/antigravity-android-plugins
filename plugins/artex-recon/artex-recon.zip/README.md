# ARTEX API & Surface Recon (`v1.0.0`) — Reconocimiento No Destructivo de APIs y Superficie Web en Rust ARM64

Plugin nativo **ARM64 (`aarch64` + `LSE`)** para **Antigravity for Android** que porta los módulos `skills/api-recon`, `skills/scopesentry` y `enrich/` de [`jiwoochris/artex-global`](https://github.com/jiwoochris/artex-global) (`AGPL-3.0`), sincronizando automáticamente cada ruta y servicio descubierto con la base SQLite compartida de ARTEX (`~/.gemini/artex/artex.db`).

> [!TIP]
> **Cero Saturación de Contexto en Bundles Minificados:**
> En lugar de leer archivos `index-*.js` de varios megabytes dentro del prompt, `artex_harvest_static` y `artex_route_perm_map` expanden recursivamente los manifiestos de chunks **Webpack (`__webpack_require__.u`)** y **Vite (`__vite__mapDeps`)** fuera de contexto, devolviendo listas limpias de endpoints, rutas SPA y árboles de permisos RBAC.

---

## Las 6 Herramientas MCP Nativas en Rust

| Herramienta | Categoría | Función Nativa ARM64 |
| :--- | :--- | :--- |
| `artex_recon_status` | Diagnóstico | Verifica Python 3, Node.js, Chromium ARM64 Headless (`runtime/bin/chrome`) y conexión con `artex.db`. |
| `artex_harvest_static` | SPA / Bundles JS | Cosecha recursiva de chunks JS estáticos (URL autorizada o carpeta local `dist/`/`out/`) y sincronización al Asset Graph. |
| `artex_route_perm_map` | Rutas & RBAC | Reconstruye `route_map.json` y árboles de códigos de permisos (`role_permissions_stub.json`) desde módulos frontend. |
| `artex_source_api_scan` | Código Fuente | Escáner nativo en Rust para **Next.js App Router, Express, Fastify, FastAPI, Flask, Go y Spring**, detectando endpoints sin referencias de autenticación. |
| `artex_enrich_target` | Postura HTTP/TLS | Sondeo pasivo de 1 petición sobre objetivos en alcance: `<title>`, stack tecnológico, `CORS` y cabeceras ausentes (`CSP`, `HSTS`, `X-Frame-Options`). |
| `artex_openapi_diff` | Shadow APIs | Compara tu `openapi.json` / `swagger.json` contra los endpoints reales del Asset Graph para descubrir rutas fantasma sin documentar. |

---

## Skills Incluidos

- **`artex-api-recon`:** Flujo estructurado de descubrimiento de superficie API estática y dinámica compatible con `chrome-devtools-plugin` en Android.
- **`artex-surface-sync`:** Inventario y sincronización jerárquica de dominios, servicios y endpoints hacia el Grafo Dual de ARTEX.
