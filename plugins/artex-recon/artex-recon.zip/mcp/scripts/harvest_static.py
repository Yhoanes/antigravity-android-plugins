#!/usr/bin/env python3
"""
harvest_static.py <BASE_URL> <OUTDIR>
Ported from jiwoochris/artex-global/skills/api-recon/scripts/harvest_static.py (AGPL-3.0).
Authorized non-destructive static SPA/MPA JS bundle & chunk-manifest endpoint harvester.
"""
import sys, os, re, ssl, json, urllib.request, urllib.parse
from concurrent.futures import ThreadPoolExecutor

CTX = ssl.create_default_context()
CTX.check_hostname = False
CTX.verify_mode = ssl.CERT_NONE
UA = "Mozilla/5.0 (artex-api-recon-static/1.0)"

def fetch(url, binary=False):
    try:
        req = urllib.request.Request(url, headers={"User-Agent": UA})
        with urllib.request.urlopen(req, context=CTX, timeout=20) as r:
            data = r.read()
            return (data if binary else data.decode("utf-8", "ignore")), r.status
    except Exception as e:
        code = getattr(e, "code", 0)
        return (b"" if binary else ""), code

def origin_of(u):
    p = urllib.parse.urlparse(u)
    return f"{p.scheme}://{p.netloc}"

def matched_block(s, end_brace_idx):
    depth = 0
    j = end_brace_idx
    while j >= 0:
        if s[j] == '}':
            depth += 1
        elif s[j] == '{':
            depth -= 1
            if depth == 0:
                return s[j:end_brace_idx+1]
        j -= 1
    return ""

def parse_chunk_maps(js_text):
    maps = []
    pubs = re.findall(r'(?:\.p|publicPath)\s*=\s*"([^"]*)"', js_text)
    for m in re.finditer(r'\}\[[A-Za-z_$]\]\s*\+\s*"\.js"', js_text):
        body = matched_block(js_text, m.start())
        pairs = re.findall(r'(\d+):"([0-9a-fA-F]{6,16})"', body)
        if pairs:
            maps.append((pubs, dict(pairs)))
    for fn in re.findall(r'"(assets/[^"]+\.js)"', js_text):
        maps.append((["/"], {"__vite__": fn}))
    return maps

def chunk_urls(base, js_text):
    origin = origin_of(base)
    out = set()
    for pubs, idmap in parse_chunk_maps(js_text):
        paths = pubs or ["/assets/", "/"]
        for cid, h in idmap.items():
            if cid == "__vite__":
                for _ in paths:
                    out.add(urllib.parse.urljoin(origin + "/", h))
                continue
            for pp in paths:
                if pp.startswith("http"):
                    bareorigin, prefix = "", pp
                else:
                    bareorigin = origin
                    prefix = pp if pp.startswith("/") else "/" + pp
                if not prefix.endswith("/"):
                    prefix += "/"
                out.add(f"{bareorigin}{prefix}{cid}.{h}.js")
    return out

API_HINT = re.compile(r'/(?:api|rest|service|services|gateway|graphql|v\d|web|admin|backend|open|auth)\b', re.I)
ASSET_EXT = re.compile(r'\.(js|css|png|jpe?g|svg|gif|woff2?|ttf|ico|map|json|mp4|webp)(\?|$)', re.I)

def extract_endpoints(js_text):
    paths = set()
    for m in re.findall(r'''["'`](/[A-Za-z0-9_\-./{}$:]+)["'`]''', js_text):
        paths.add(m)
    for m in re.findall(r'''["'](/[A-Za-z0-9_\-./]+/)["']\s*\+''', js_text):
        paths.add(m)
    api, other = set(), set()
    for p in paths:
        if ASSET_EXT.search(p):
            continue
        if p.count('/') < 2 and not API_HINT.search(p):
            continue
        (api if API_HINT.search(p) else other).add(p)
    return api, other

def extract_routes(js_text):
    r = set()
    for key in ('path', 'to', 'redirect', 'href'):
        for m in re.findall(key + r'''\s*:\s*["'](/[A-Za-z0-9_\-/:]*)["']''', js_text):
            if not ASSET_EXT.search(m) and not API_HINT.search(m):
                r.add(m)
    return r

def harvest_local_dir(local_dir, outdir):
    os.makedirs(outdir, exist_ok=True)
    api, other, routes, js_files = set(), set(), set(), []
    for root, _, files in os.walk(local_dir):
        if "node_modules" in root:
            continue
        for fn in files:
            if fn.endswith((".js", ".mjs", ".jsx", ".ts", ".tsx")):
                fp = os.path.join(root, fn)
                js_files.append(fp)
                try:
                    txt = open(fp, encoding="utf-8", errors="ignore").read()
                    a, o = extract_endpoints(txt)
                    api |= a
                    other |= o
                    routes |= extract_routes(txt)
                except Exception:
                    pass
    open(os.path.join(outdir, "api_static.txt"), "w").write("\n".join(sorted(api)))
    open(os.path.join(outdir, "paths_other.txt"), "w").write("\n".join(sorted(other)))
    open(os.path.join(outdir, "routes.txt"), "w").write("\n".join(sorted(routes)))
    summary = {
        "mode": "local_dir",
        "source": local_dir,
        "js_scanned": len(js_files),
        "api_endpoints": sorted(api),
        "routes": sorted(routes),
        "other_paths_count": len(other),
        "outdir": outdir,
    }
    json.dump(summary, open(os.path.join(outdir, "summary.json"), "w"), indent=2)
    print(json.dumps(summary))

def main():
    if len(sys.argv) < 3:
        print("usage: harvest_static.py <BASE_URL_OR_DIR> <OUTDIR>")
        sys.exit(1)
    target, outdir = sys.argv[1], sys.argv[2]
    if os.path.isdir(target):
        harvest_local_dir(target, outdir)
        return

    base = target if target.startswith("http") else "https://" + target
    jsdir = os.path.join(outdir, "js")
    os.makedirs(jsdir, exist_ok=True)

    html, status = fetch(base)
    open(os.path.join(outdir, "index.html"), "w").write(html)
    srcs = set(re.findall(r'<script[^>]+src=["\']([^"\']+\.js[^"\']*)["\']', html))
    srcs |= set(re.findall(r'(?:src|href)=["\']([^"\']*\.js)["\']', html))
    seed = {s if s.startswith("http") else urllib.parse.urljoin(base, s) for s in srcs}

    have = {}
    def dl(url):
        fn = os.path.basename(urllib.parse.urlparse(url).path)
        if not fn.endswith(".js"):
            return None
        lp = os.path.join(jsdir, fn)
        if url in have:
            return have[url]
        data, st = fetch(url, binary=True)
        if st == 200 and data and not data[:15].lstrip().startswith(b"<"):
            open(lp, "wb").write(data)
            have[url] = lp
            return lp
        return None

    with ThreadPoolExecutor(max_workers=12) as ex:
        list(ex.map(dl, seed))

    seen_urls = set(have.keys())
    frontier = list(have.values())
    rounds = 0
    while frontier and rounds < 5:
        rounds += 1
        new_urls = set()
        for lp in frontier:
            try:
                txt = open(lp, encoding="utf-8", errors="ignore").read()
            except Exception:
                continue
            for cu in chunk_urls(base, txt):
                if cu not in seen_urls:
                    new_urls.add(cu)
        seen_urls |= new_urls
        if not new_urls:
            break
        before = set(have.values())
        with ThreadPoolExecutor(max_workers=16) as ex:
            list(ex.map(dl, new_urls))
        frontier = [p for p in have.values() if p not in before]

    api, other, routes = set(), set(), set()
    for lp in have.values():
        try:
            txt = open(lp, encoding="utf-8", errors="ignore").read()
        except Exception:
            continue
        a, o = extract_endpoints(txt)
        api |= a
        other |= o
        routes |= extract_routes(txt)

    open(os.path.join(outdir, "api_static.txt"), "w").write("\n".join(sorted(api)))
    open(os.path.join(outdir, "paths_other.txt"), "w").write("\n".join(sorted(other)))
    open(os.path.join(outdir, "routes.txt"), "w").write("\n".join(sorted(routes)))
    summary = {
        "mode": "url",
        "source": base,
        "http_status": status,
        "js_downloaded": len(have),
        "api_endpoints": sorted(api),
        "routes": sorted(routes),
        "other_paths_count": len(other),
        "outdir": outdir,
    }
    json.dump(summary, open(os.path.join(outdir, "summary.json"), "w"), indent=2)
    print(json.dumps(summary))

if __name__ == "__main__":
    main()
