#!/usr/bin/env python3
"""
extract_route_map.py & build_perm_tree.py combined helper
Ported from jiwoochris/artex-global/skills/api-recon/scripts/ (AGPL-3.0).
"""
import re, json, os, sys, glob

DEFAULT_ROOTS = [
    'MONITOR', 'THREAT', 'ASSETS_RISK', 'INVESTIGATION', 'MANAGEMENT',
    'AGENT_EVIDENCE', 'MDR', 'PLATFORM', 'ADMIN', 'DASHBOARD', 'SETTINGS'
]

def extract_route_map(jsdir):
    best = {}
    pat1 = re.compile(r'([A-Z_][A-Z0-9_]*)\s*:\s*\{\s*name\s*:\s*["\']([^"\']*)["\']\s*,\s*link\s*:\s*["\']([^"\']+)["\']')
    pat2 = re.compile(r'path\s*:\s*["\'](/[A-Za-z0-9_\-/:]+)["\']\s*,\s*(?:name|meta)\s*:\s*["\'{]([^"\'}]+)')
    for fp in glob.glob(os.path.join(jsdir, '*.js')):
        try:
            txt = open(fp, encoding='utf-8', errors='ignore').read()
        except Exception:
            continue
        hits = pat1.findall(txt)
        if len(hits) > len(best):
            best = {k: {'name': n, 'link': l} for k, n, l in hits}
        for path_v, name_v in pat2.findall(txt):
            key = path_v.strip('/').upper().replace('/', '_').replace('-', '_') or 'ROOT'
            best.setdefault(key, {'name': name_v.strip(), 'link': path_v})
    return best

def extract_perm_codes(jsdir):
    codes = set()
    pat = re.compile(r'''(?:hasPermission|checkPerm|v-permission|permissions\.includes|role_permissions|authCode)\s*\(\s*["']([A-Za-z0-9_:.\-]+)["']''')
    for fp in glob.glob(os.path.join(jsdir, '*.js')):
        try:
            txt = open(fp, encoding='utf-8', errors='ignore').read()
        except Exception:
            continue
        for m in pat.findall(txt):
            codes.add(m)
    return sorted(codes)

def main():
    if len(sys.argv) < 3:
        print("usage: route_perm_helper.py <JSDIR> <OUTDIR>")
        sys.exit(1)
    jsdir, outdir = sys.argv[1], sys.argv[2]
    os.makedirs(outdir, exist_ok=True)
    route_map = extract_route_map(jsdir)
    perm_codes = extract_perm_codes(jsdir)

    json.dump(route_map, open(os.path.join(outdir, 'route_map.json'), 'w'), indent=2, ensure_ascii=False)
    role_stub = {
        'response_code': 0,
        'verbose_msg': 'ok',
        'data': {'role_type': 'AUDIT_VIEWER', 'permissions': perm_codes},
    }
    json.dump(role_stub, open(os.path.join(outdir, 'role_permissions_stub.json'), 'w'), indent=2, ensure_ascii=False)
    res = {
        'ok': True,
        'routes_discovered': len(route_map),
        'permission_codes_discovered': len(perm_codes),
        'route_map': route_map,
        'permission_codes': perm_codes[:100],
        'outdir': outdir,
    }
    print(json.dumps(res, ensure_ascii=False))

if __name__ == '__main__':
    main()
