// main.rs — ARTEX API & Surface Recon (artex-recon v1.0.0)
// Native Android ARM64 Rust MCP Server + SQLite Asset Graph integration
mod json;
mod sqlite;

use json::{make_tool, n_i64, parse_json, prop_bool, prop_int, prop_str, s, JsonVal};
use sqlite::{sqlite_version, Db, SqlParam};
use std::collections::BTreeSet;
use std::env;
use std::fs;
use std::io::{self, BufRead, BufReader, Write};
use std::path::{Path, PathBuf};
use std::process::Command;

const SERVER_NAME: &str = "artex-recon";
const SERVER_VERSION: &str = "1.0.0";

struct EnvPaths {
    home: PathBuf,
    prefix: PathBuf,
    plugin_dir: PathBuf,
    artex_dir: PathBuf,
    db_path: PathBuf,
}

impl EnvPaths {
    fn resolve() -> Self {
        let home = env::var("HOME")
            .map(PathBuf::from)
            .unwrap_or_else(|_| PathBuf::from("/data/user/0/com.agy/files"));
        let prefix = env::var("PREFIX")
            .map(PathBuf::from)
            .unwrap_or_else(|_| home.join("usr"));
        let plugin_dir = home.join(".gemini/config/plugins/artex-recon");
        let artex_dir = env::var("ARTEX_DATA_DIR")
            .map(PathBuf::from)
            .unwrap_or_else(|_| home.join(".gemini/artex"));
        let _ = fs::create_dir_all(&artex_dir);
        let db_path = artex_dir.join("artex.db");
        Self {
            home,
            prefix,
            plugin_dir,
            artex_dir,
            db_path,
        }
    }

    fn python_bin(&self) -> PathBuf {
        let p = self.prefix.join("bin/python3");
        if p.exists() {
            p
        } else {
            PathBuf::from("python3")
        }
    }

    fn chrome_available(&self) -> bool {
        self.home.join("runtime/bin/chrome").exists()
            || self.prefix.join("bin/chromium").exists()
            || self.prefix.join("bin/chromium-browser").exists()
    }
}

fn is_url_in_scope(db: &Db, url_or_host: &str) -> bool {
    let lower = url_or_host.to_lowercase();
    let defaults = ["localhost", "127.0.0.1", "::1", "0.0.0.0", "10.", "192.168.", "172.16."];
    if defaults.iter().any(|d| lower.contains(d)) {
        return true;
    }
    if let Ok(rows) = db.query_rows("SELECT scope_patterns FROM companies;", &[]) {
        for r in rows {
            if let Some(sp) = r.get_str("scope_patterns") {
                for tok in sp.split(',') {
                    let clean = tok.trim().trim_end_matches('*').to_lowercase();
                    if !clean.is_empty() && lower.contains(&clean) {
                        return true;
                    }
                }
            }
        }
    }
    false
}

fn upsert_endpoint_asset(
    db: &Db,
    company_id: i64,
    value: &str,
    host: &str,
    tech: &str,
    status: i64,
    title: &str,
) {
    let dedup = format!("{}:endpoint:{}", company_id, value.trim().to_lowercase());
    let _ = db.exec_params(
        "INSERT INTO assets (company_id, asset_type, value, dedup_key, host, http_status, title, tech_stack)
         VALUES (?1, 'endpoint', ?2, ?3, ?4, ?5, ?6, ?7)
         ON CONFLICT(dedup_key) DO UPDATE SET
           host = CASE WHEN excluded.host != '' THEN excluded.host ELSE assets.host END,
           http_status = CASE WHEN excluded.http_status > 0 THEN excluded.http_status ELSE assets.http_status END,
           title = CASE WHEN excluded.title != '' THEN excluded.title ELSE assets.title END,
           tech_stack = CASE WHEN excluded.tech_stack != '' THEN excluded.tech_stack ELSE assets.tech_stack END;",
        &[
            SqlParam::Int(company_id),
            SqlParam::Text(value.trim()),
            SqlParam::Text(&dedup),
            SqlParam::Text(host),
            SqlParam::Int(status),
            SqlParam::Text(title),
            SqlParam::Text(tech),
        ],
    );
}

fn tool_status(paths: &EnvPaths) -> Result<JsonVal, String> {
    let db = Db::open(&paths.db_path)?;
    let mut res = JsonVal::obj();
    res.insert("ok", JsonVal::Bool(true));
    res.insert("plugin", s(SERVER_NAME));
    res.insert("version", s(SERVER_VERSION));
    res.insert("sqlite_version", s(&sqlite_version()));
    res.insert("python3_ready", JsonVal::Bool(paths.prefix.join("bin/python3").exists()));
    res.insert("node_ready", JsonVal::Bool(paths.prefix.join("bin/node").exists()));
    res.insert("chromium_headless_ready", JsonVal::Bool(paths.chrome_available()));
    res.insert(
        "harvest_script",
        s(&paths.plugin_dir.join("mcp/scripts/harvest_static.py").display().to_string()),
    );
    res.insert(
        "asset_graph_endpoints",
        n_i64(db.query_i64("SELECT COUNT(*) FROM assets WHERE asset_type='endpoint';", &[])),
    );
    Ok(res)
}

fn tool_harvest_static(paths: &EnvPaths, args: &JsonVal) -> Result<JsonVal, String> {
    let db = Db::open(&paths.db_path)?;
    let target = args.get_str("target").ok_or("Missing 'target' (URL or local build/src directory)")?;
    let sync_db = args.get_bool("sync_asset_graph").unwrap_or(true);
    let company_id = args.get_i64("company_id").unwrap_or(1);

    let is_local_dir = Path::new(target).is_dir();
    if !is_local_dir && !is_url_in_scope(&db, target) {
        return Err(format!(
            "Target '{}' is outside configured authorized scope. Register it via artex_scope_configure first.",
            target
        ));
    }

    let out_dir = args
        .get_str("outdir")
        .map(PathBuf::from)
        .unwrap_or_else(|| paths.artex_dir.join("recon_out"));
    let _ = fs::create_dir_all(&out_dir);

    let script = paths.plugin_dir.join("mcp/scripts/harvest_static.py");
    let output = Command::new(paths.python_bin())
        .arg(&script)
        .arg(target)
        .arg(&out_dir)
        .output()
        .map_err(|e| format!("Failed to invoke harvest_static.py: {}", e))?;

    let stdout = String::from_utf8_lossy(&output.stdout).trim().to_string();
    let stderr = String::from_utf8_lossy(&output.stderr).trim().to_string();
    if !output.status.success() {
        return Err(format!("harvest_static.py failed: {} {}", stdout, stderr));
    }

    let mut parsed = parse_json(&stdout).unwrap_or_else(|_| {
        let mut o = JsonVal::obj();
        o.insert("raw", s(&stdout));
        o
    });

    let mut ingested = 0i64;
    if sync_db {
        if let Some(arr) = parsed.get("api_endpoints").and_then(|v| v.as_arr()) {
            for ep in arr {
                if let Some(ep_s) = ep.as_str() {
                    upsert_endpoint_asset(&db, company_id, ep_s, target, "static-js-harvest", 0, "");
                    ingested += 1;
                }
            }
        }
    }
    parsed.insert("ok", JsonVal::Bool(true));
    parsed.insert("ingested_to_asset_graph", n_i64(ingested));
    Ok(parsed)
}

fn tool_route_perm_map(paths: &EnvPaths, args: &JsonVal) -> Result<JsonVal, String> {
    let jsdir = args
        .get_str("jsdir")
        .map(PathBuf::from)
        .unwrap_or_else(|| paths.artex_dir.join("recon_out/js"));
    let outdir = args
        .get_str("outdir")
        .map(PathBuf::from)
        .unwrap_or_else(|| paths.artex_dir.join("recon_out"));

    if !jsdir.exists() {
        return Err(format!(
            "JS directory '{}' does not exist. Run artex_harvest_static first or pass an existing jsdir.",
            jsdir.display()
        ));
    }

    let script = paths.plugin_dir.join("mcp/scripts/route_perm_helper.py");
    let output = Command::new(paths.python_bin())
        .arg(&script)
        .arg(&jsdir)
        .arg(&outdir)
        .output()
        .map_err(|e| format!("Failed to run route_perm_helper.py: {}", e))?;

    let stdout = String::from_utf8_lossy(&output.stdout).trim().to_string();
    if let Ok(jv) = parse_json(&stdout) {
        Ok(jv)
    } else {
        let mut o = JsonVal::obj();
        o.insert("ok", JsonVal::Bool(output.status.success()));
        o.insert("stdout", s(&stdout));
        Ok(o)
    }
}

fn scan_source_files(dir: &Path, out_files: &mut Vec<PathBuf>) {
    if out_files.len() >= 1500 {
        return;
    }
    let entries = match fs::read_dir(dir) {
        Ok(e) => e,
        Err(_) => return,
    };
    for ent in entries.flatten() {
        let p = ent.path();
        let fname = ent.file_name().to_string_lossy().to_string();
        if fname.starts_with('.')
            || fname == "node_modules"
            || fname == "target"
            || fname == "dist"
            || fname == "build"
            || fname == "vendor"
            || fname == "__pycache__"
        {
            continue;
        }
        if p.is_dir() {
            scan_source_files(&p, out_files);
        } else if matches!(
            p.extension().and_then(|x| x.to_str()),
            Some("ts" | "tsx" | "js" | "mjs" | "py" | "go" | "rs" | "java" | "kt")
        ) {
            out_files.push(p);
        }
    }
}

fn extract_quoted_path_after(line: &str, marker: &str) -> Option<String> {
    let idx = line.find(marker)?;
    let rest = &line[idx + marker.len()..];
    for q in ['"', '\'', '`'] {
        if let Some(p1) = rest.find(q) {
            let after = &rest[p1 + 1..];
            if let Some(p2) = after.find(q) {
                let candidate = &after[..p2];
                if candidate.starts_with('/') {
                    return Some(candidate.to_string());
                }
            }
        }
    }
    None
}

fn tool_source_api_scan(paths: &EnvPaths, args: &JsonVal) -> Result<JsonVal, String> {
    let db = Db::open(&paths.db_path)?;
    let root_str = args.get_str("project_dir").ok_or("Missing 'project_dir'")?;
    let root = PathBuf::from(root_str);
    if !root.is_dir() {
        return Err(format!("Directory not found: {}", root_str));
    }
    let sync_db = args.get_bool("sync_asset_graph").unwrap_or(true);
    let company_id = args.get_i64("company_id").unwrap_or(1);

    let mut files = Vec::new();
    scan_source_files(&root, &mut files);

    let mut routes = Vec::new();
    let method_markers: &[(&str, &str, &str)] = &[
        (".get(", "GET", "express/fastify"),
        (".post(", "POST", "express/fastify"),
        (".put(", "PUT", "express/fastify"),
        (".delete(", "DELETE", "express/fastify"),
        (".patch(", "PATCH", "express/fastify"),
        ("@app.get(", "GET", "fastapi/flask"),
        ("@app.post(", "POST", "fastapi/flask"),
        ("@router.get(", "GET", "fastapi"),
        ("@router.post(", "POST", "fastapi"),
        ("@router.put(", "PUT", "fastapi"),
        ("@router.delete(", "DELETE", "fastapi"),
        ("HandleFunc(", "ANY", "go-http"),
        ("@GetMapping(", "GET", "spring"),
        ("@PostMapping(", "POST", "spring"),
    ];

    for fp in &files {
        let rel = fp
            .strip_prefix(&root)
            .unwrap_or(fp)
            .display()
            .to_string();

        let txt = match fs::read_to_string(fp) {
            Ok(t) => t,
            Err(_) => continue,
        };

        let has_auth_hint = txt.contains("Authorization")
            || txt.contains("jwt")
            || txt.contains("session")
            || txt.contains("Depends(")
            || txt.contains("requireAuth")
            || txt.contains("middleware");

        // Next.js App Router: app/api/.../route.ts
        if (rel.ends_with("/route.ts") || rel.ends_with("/route.js")) && rel.contains("api/") {
            if let Some(api_idx) = rel.find("api/") {
                let mut route_p = format!("/{}", &rel[api_idx..]);
                route_p = route_p
                    .trim_end_matches("/route.ts")
                    .trim_end_matches("/route.js")
                    .to_string();
                for m in ["GET", "POST", "PUT", "DELETE", "PATCH"] {
                    if txt.contains(&format!("export async function {}", m))
                        || txt.contains(&format!("export function {}", m))
                    {
                        let mut item = JsonVal::obj();
                        item.insert("method", s(m));
                        item.insert("path", s(&route_p));
                        item.insert("framework", s("nextjs-app-router"));
                        item.insert("file", s(&rel));
                        item.insert("auth_referenced", JsonVal::Bool(has_auth_hint));
                        if sync_db {
                            let val = format!("{} {}", m, route_p);
                            upsert_endpoint_asset(&db, company_id, &val, &rel, "nextjs-app-router", 0, "");
                        }
                        routes.push(item);
                    }
                }
            }
        }

        for (lineno, line) in txt.lines().enumerate() {
            for (marker, meth, fw) in method_markers {
                if line.contains(marker) {
                    if let Some(p_str) = extract_quoted_path_after(line, marker) {
                        let mut item = JsonVal::obj();
                        item.insert("method", s(meth));
                        item.insert("path", s(&p_str));
                        item.insert("framework", s(fw));
                        item.insert("file", s(&format!("{}:{}", rel, lineno + 1)));
                        item.insert("auth_referenced", JsonVal::Bool(has_auth_hint));
                        if sync_db {
                            let val = format!("{} {}", meth, p_str);
                            upsert_endpoint_asset(&db, company_id, &val, &rel, fw, 0, "");
                        }
                        routes.push(item);
                    }
                }
            }
        }
    }

    let mut res = JsonVal::obj();
    res.insert("ok", JsonVal::Bool(true));
    res.insert("files_scanned", n_i64(files.len() as i64));
    res.insert("routes_discovered", n_i64(routes.len() as i64));
    res.insert("routes", JsonVal::Arr(routes));
    Ok(res)
}

fn tool_enrich_target(paths: &EnvPaths, args: &JsonVal) -> Result<JsonVal, String> {
    let db = Db::open(&paths.db_path)?;
    let url = args.get_str("url").ok_or("Missing 'url'")?;
    let company_id = args.get_i64("company_id").unwrap_or(1);

    if !is_url_in_scope(&db, url) {
        return Err(format!(
            "URL '{}' is outside authorized scope. Add it via artex_scope_configure first.",
            url
        ));
    }

    let py_probe = r#"
import sys, ssl, re, json, urllib.request, socket, urllib.parse
u = sys.argv[1]
if not u.startswith("http"): u = "http://" + u
p = urllib.parse.urlparse(u)
host = p.hostname or ""
port = p.port or (443 if p.scheme == "https" else 80)
ips = []
try:
    for info in socket.getaddrinfo(host, port, type=socket.SOCK_STREAM):
        ip = info[4][0]
        if ip not in ips: ips.append(ip)
except Exception:
    pass
ctx = ssl.create_default_context()
ctx.check_hostname = False
ctx.verify_mode = ssl.CERT_NONE
status, hdrs, title = 0, {}, ""
try:
    req = urllib.request.Request(u, headers={"User-Agent": "Mozilla/5.0 (artex-safe-enrich/1.0)"})
    with urllib.request.urlopen(req, context=ctx, timeout=8) as r:
        status = r.status
        hdrs = {k.lower(): v for k, v in r.headers.items()}
        body = r.read(16384).decode("utf-8", "ignore")
        m = re.search(r"<title[^>]*>(.*?)</title>", body, re.I | re.S)
        if m: title = re.sub(r"\s+", " ", m.group(1)).strip()[:140]
except urllib.error.HTTPError as e:
    status = e.code
    hdrs = {k.lower(): v for k, v in e.headers.items()}
except Exception as e:
    hdrs["probe_error"] = str(e)

sec_missing = []
for h in ["content-security-policy", "x-frame-options", "x-content-type-options"]:
    if h not in hdrs: sec_missing.append(h)
if p.scheme == "https" and "strict-transport-security" not in hdrs:
    sec_missing.append("strict-transport-security")

tech = ", ".join(filter(None, [hdrs.get("server",""), hdrs.get("x-powered-by","")]))
print(json.dumps({
    "ok": True,
    "url": u,
    "host": host,
    "port": port,
    "ips": ips,
    "http_status": status,
    "title": title,
    "tech_stack": tech,
    "security_headers_missing": sec_missing,
    "cors_allow_origin": hdrs.get("access-control-allow-origin", ""),
}))
"#;

    let out = Command::new(paths.python_bin())
        .arg("-c")
        .arg(py_probe)
        .arg(url)
        .output()
        .map_err(|e| format!("Failed to run enrich probe: {}", e))?;

    let stdout = String::from_utf8_lossy(&out.stdout).trim().to_string();
    let parsed = parse_json(&stdout)?;
    let host = parsed.get_str("host").unwrap_or("");
    let port = parsed.get_i64("port").unwrap_or(0);
    let status = parsed.get_i64("http_status").unwrap_or(0);
    let title = parsed.get_str("title").unwrap_or("");
    let tech = parsed.get_str("tech_stack").unwrap_or("");

    let dedup = format!("{}:service:{}", company_id, url.trim().to_lowercase());
    let _ = db.exec_params(
        "INSERT INTO assets (company_id, asset_type, value, dedup_key, host, port, http_status, title, tech_stack, metadata_json)
         VALUES (?1, 'service', ?2, ?3, ?4, ?5, ?6, ?7, ?8, ?9)
         ON CONFLICT(dedup_key) DO UPDATE SET http_status=excluded.http_status, title=excluded.title, tech_stack=excluded.tech_stack, metadata_json=excluded.metadata_json;",
        &[
            SqlParam::Int(company_id),
            SqlParam::Text(url),
            SqlParam::Text(&dedup),
            SqlParam::Text(host),
            SqlParam::Int(port),
            SqlParam::Int(status),
            SqlParam::Text(title),
            SqlParam::Text(tech),
            SqlParam::Text(&stdout),
        ],
    );
    Ok(parsed)
}

fn tool_openapi_diff(paths: &EnvPaths, args: &JsonVal) -> Result<JsonVal, String> {
    let db = Db::open(&paths.db_path)?;
    let spec_path = args.get_str("openapi_json_path").ok_or("Missing 'openapi_json_path'")?;
    let spec_raw = fs::read_to_string(spec_path).map_err(|e| format!("Failed to read {}: {}", spec_path, e))?;
    let spec = parse_json(&spec_raw)?;

    let mut documented = BTreeSet::new();
    if let Some(JsonVal::Obj(paths_map)) = spec.get("paths") {
        for (p_key, _) in paths_map {
            documented.insert(p_key.trim().to_string());
        }
    }

    let db_rows = db.query_rows("SELECT value FROM assets WHERE asset_type='endpoint';", &[])?;
    let mut discovered = BTreeSet::new();
    for r in db_rows {
        if let Some(v) = r.get_str("value") {
            let clean = v.split_whitespace().last().unwrap_or(v).trim().to_string();
            if clean.starts_with('/') {
                discovered.insert(clean);
            }
        }
    }

    let undocumented_shadow: Vec<JsonVal> = discovered
        .difference(&documented)
        .map(|x| s(x))
        .collect();
    let documented_only: Vec<JsonVal> = documented
        .difference(&discovered)
        .map(|x| s(x))
        .collect();

    let mut res = JsonVal::obj();
    res.insert("ok", JsonVal::Bool(true));
    res.insert("documented_count", n_i64(documented.len() as i64));
    res.insert("discovered_count", n_i64(discovered.len() as i64));
    res.insert("shadow_undocumented_endpoints", JsonVal::Arr(undocumented_shadow));
    res.insert("unobserved_documented_endpoints", JsonVal::Arr(documented_only));
    Ok(res)
}

fn build_tools_list() -> JsonVal {
    let tools = vec![
        make_tool(
            "artex_recon_status",
            "Check ARTEX API & Surface Recon runtime readiness (Python3, Node.js, Chromium Headless ARM64, static harvesters, and SQLite Asset Graph).",
            vec![],
            &[],
        ),
        make_tool(
            "artex_harvest_static",
            "Non-destructive static SPA/MPA JS bundle & webpack/Vite chunk-manifest harvester (ported from artex-global/skills/api-recon). Accepts an in-scope URL or local directory and syncs endpoints to the Asset Graph.",
            vec![
                ("target", prop_str("Authorized URL (e.g. http://127.0.0.1:3000) or local build/src folder")),
                ("outdir", prop_str("Optional output directory for api_static.txt, routes.txt, and js/")),
                ("sync_asset_graph", prop_bool("Automatically insert discovered API endpoints into artex.db (default true)")),
                ("company_id", prop_int("Owning company ID in artex.db (default 1)")),
            ],
            &["target"],
        ),
        make_tool(
            "artex_route_perm_map",
            "Analyze downloaded JS chunks to reconstruct frontend route maps (route_map.json) and RBAC permission codes/stubs (role_permissions_stub.json).",
            vec![
                ("jsdir", prop_str("Directory containing .js chunks (defaults to ~/.gemini/artex/recon_out/js)")),
                ("outdir", prop_str("Output directory for route_map.json and stubs")),
            ],
            &[],
        ),
        make_tool(
            "artex_source_api_scan",
            "Scan a local project codebase in native Rust (Next.js App Router, Express, FastAPI, Flask, Go, Spring) to inventory backend routes, HTTP methods, and auth middleware references into the Asset Graph.",
            vec![
                ("project_dir", prop_str("Absolute path to local repository/project")),
                ("sync_asset_graph", prop_bool("Upsert discovered routes into artex.db (default true)")),
                ("company_id", prop_int("Company ID (default 1)")),
            ],
            &["project_dir"],
        ),
        make_tool(
            "artex_enrich_target",
            "Safe single-request DNS + HTTP title, tech-stack, CORS, and security-header enrichment (ported from artex-global/enrich) for an authorized target.",
            vec![
                ("url", prop_str("Authorized target URL (e.g. http://127.0.0.1:8080)")),
                ("company_id", prop_int("Company ID (default 1)")),
            ],
            &["url"],
        ),
        make_tool(
            "artex_openapi_diff",
            "Compare an OpenAPI/Swagger JSON specification against endpoints discovered in the ARTEX Asset Graph to detect undocumented shadow APIs.",
            vec![("openapi_json_path", prop_str("Absolute path to openapi.json / swagger.json"))],
            &["openapi_json_path"],
        ),
    ];
    let mut out = JsonVal::obj();
    out.insert("tools", JsonVal::Arr(tools));
    out
}

fn dispatch_tool(paths: &EnvPaths, name: &str, args: &JsonVal) -> Result<JsonVal, String> {
    match name {
        "artex_recon_status" => tool_status(paths),
        "artex_harvest_static" => tool_harvest_static(paths, args),
        "artex_route_perm_map" => tool_route_perm_map(paths, args),
        "artex_source_api_scan" => tool_source_api_scan(paths, args),
        "artex_enrich_target" => tool_enrich_target(paths, args),
        "artex_openapi_diff" => tool_openapi_diff(paths, args),
        _ => Err(format!("Unknown tool: {}", name)),
    }
}

#[derive(Clone, Copy)]
enum Framing {
    Line,
    ContentLength,
}

fn read_rpc_message<R: BufRead>(reader: &mut R) -> io::Result<Option<(String, Framing)>> {
    loop {
        let mut line = String::new();
        let n = reader.read_line(&mut line)?;
        if n == 0 {
            return Ok(None);
        }
        let trimmed = line.trim();
        if trimmed.is_empty() {
            continue;
        }
        if trimmed.starts_with('{') {
            return Ok(Some((trimmed.to_string(), Framing::Line)));
        }
        let lower = trimmed.to_ascii_lowercase();
        if let Some(rest) = lower.strip_prefix("content-length:") {
            let len: usize = rest
                .trim()
                .parse()
                .map_err(|_| io::Error::new(io::ErrorKind::InvalidData, "Bad Content-Length"))?;
            loop {
                let mut hdr = String::new();
                let hn = reader.read_line(&mut hdr)?;
                if hn == 0 || hdr.trim().is_empty() {
                    break;
                }
            }
            let mut buf = vec![0u8; len];
            reader.read_exact(&mut buf)?;
            return Ok(Some((String::from_utf8_lossy(&buf).to_string(), Framing::ContentLength)));
        }
    }
}

fn write_rpc_message<W: Write>(writer: &mut W, payload: &JsonVal, framing: Framing) -> io::Result<()> {
    let serialized = payload.to_json_string();
    match framing {
        Framing::Line => {
            writer.write_all(serialized.as_bytes())?;
            writer.write_all(b"\n")?;
        }
        Framing::ContentLength => {
            let header = format!("Content-Length: {}\r\n\r\n", serialized.len());
            writer.write_all(header.as_bytes())?;
            writer.write_all(serialized.as_bytes())?;
        }
    }
    writer.flush()
}

fn handle_rpc_request(paths: &EnvPaths, req: &JsonVal) -> Option<JsonVal> {
    let method = req.get_str("method").unwrap_or("");
    if method.starts_with("notifications/") {
        return None;
    }
    let id = req.get("id")?.clone();
    let mut resp = JsonVal::obj();
    resp.insert("jsonrpc", s("2.0"));
    resp.insert("id", id);

    match method {
        "initialize" => {
            let mut server_info = JsonVal::obj();
            server_info.insert("name", s(SERVER_NAME));
            server_info.insert("version", s(SERVER_VERSION));
            let mut caps = JsonVal::obj();
            caps.insert("tools", JsonVal::obj());
            let proto = req
                .get("params")
                .and_then(|p| p.get_str("protocolVersion"))
                .unwrap_or("2024-11-05");
            let mut result = JsonVal::obj();
            result.insert("protocolVersion", s(proto));
            result.insert("capabilities", caps);
            result.insert("serverInfo", server_info);
            resp.insert("result", result);
        }
        "ping" => {
            resp.insert("result", JsonVal::obj());
        }
        "tools/list" => {
            resp.insert("result", build_tools_list());
        }
        "tools/call" => {
            let params = req.get("params").cloned().unwrap_or_else(JsonVal::obj);
            let tname = params.get_str("name").unwrap_or("");
            let targs = params.get("arguments").cloned().unwrap_or_else(JsonVal::obj);
            match dispatch_tool(paths, tname, &targs) {
                Ok(val) => {
                    let mut citem = JsonVal::obj();
                    citem.insert("type", s("text"));
                    citem.insert("text", s(&val.to_json_string()));
                    let mut result = JsonVal::obj();
                    result.insert("content", JsonVal::Arr(vec![citem]));
                    resp.insert("result", result);
                }
                Err(e) => {
                    let mut err_obj = JsonVal::obj();
                    err_obj.insert("ok", JsonVal::Bool(false));
                    err_obj.insert("error", s(&e));
                    let mut citem = JsonVal::obj();
                    citem.insert("type", s("text"));
                    citem.insert("text", s(&err_obj.to_json_string()));
                    let mut result = JsonVal::obj();
                    result.insert("content", JsonVal::Arr(vec![citem]));
                    result.insert("isError", JsonVal::Bool(true));
                    resp.insert("result", result);
                }
            }
        }
        _ => {
            let mut err = JsonVal::obj();
            err.insert("code", JsonVal::Num(-32601.0));
            err.insert("message", s(&format!("Method not found: {}", method)));
            resp.insert("error", err);
        }
    }
    Some(resp)
}

fn main() {
    let paths = EnvPaths::resolve();
    let argv: Vec<String> = env::args().collect();
    if argv.len() > 1 {
        if argv[1] == "status" {
            match tool_status(&paths) {
                Ok(v) => println!("{}", v.to_json_string()),
                Err(e) => {
                    eprintln!("{}", e);
                    std::process::exit(1);
                }
            }
        } else {
            println!("Usage: artex-recon [status]");
        }
        return;
    }

    let stdin = io::stdin();
    let stdout = io::stdout();
    let mut reader = BufReader::new(stdin.lock());
    let mut writer = stdout.lock();

    while let Ok(Some((raw, framing))) = read_rpc_message(&mut reader) {
        if let Ok(req) = parse_json(&raw) {
            if let Some(resp) = handle_rpc_request(&paths, &req) {
                if write_rpc_message(&mut writer, &resp, framing).is_err() {
                    break;
                }
            }
        }
    }
}
