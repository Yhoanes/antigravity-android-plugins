// sqlite.rs — Native Android ARM64 FFI wrapper over libsqlite3.so (SQLite 3.54+)
// Implements ARTEX Global's Dual-Graph (Asset Graph + Exploration Graph) & Guard/Intercept schema.
#![allow(dead_code)]

use crate::json::{n_i64, s, JsonVal};
use std::ffi::{CStr, CString};
use std::os::raw::{c_char, c_double, c_int, c_void};
use std::path::Path;
use std::ptr;

const SQLITE_OK: c_int = 0;
const SQLITE_ROW: c_int = 100;
const SQLITE_DONE: c_int = 101;

const SQLITE_INTEGER: c_int = 1;
const SQLITE_FLOAT: c_int = 2;
const SQLITE_TEXT: c_int = 3;
const SQLITE_BLOB: c_int = 4;
const SQLITE_NULL: c_int = 5;

fn sqlite_transient() -> *const c_void {
    usize::MAX as *const c_void
}

#[repr(C)]
pub struct Sqlite3 {
    _priv: [u8; 0],
}

#[repr(C)]
pub struct Sqlite3Stmt {
    _priv: [u8; 0],
}

#[link(name = "sqlite3")]
extern "C" {
    fn sqlite3_libversion() -> *const c_char;
    fn sqlite3_open(filename: *const c_char, pp_db: *mut *mut Sqlite3) -> c_int;
    fn sqlite3_close(db: *mut Sqlite3) -> c_int;
    fn sqlite3_busy_timeout(db: *mut Sqlite3, ms: c_int) -> c_int;
    fn sqlite3_errmsg(db: *mut Sqlite3) -> *const c_char;
    fn sqlite3_exec(
        db: *mut Sqlite3,
        sql: *const c_char,
        callback: Option<extern "C" fn(*mut c_void, c_int, *mut *mut c_char, *mut *mut c_char) -> c_int>,
        arg: *mut c_void,
        errmsg: *mut *mut c_char,
    ) -> c_int;
    fn sqlite3_free(ptr: *mut c_void);
    fn sqlite3_prepare_v2(
        db: *mut Sqlite3,
        z_sql: *const c_char,
        n_byte: c_int,
        pp_stmt: *mut *mut Sqlite3Stmt,
        pz_tail: *mut *const c_char,
    ) -> c_int;
    fn sqlite3_bind_text(
        stmt: *mut Sqlite3Stmt,
        idx: c_int,
        val: *const c_char,
        n_byte: c_int,
        destructor: *const c_void,
    ) -> c_int;
    fn sqlite3_bind_int64(stmt: *mut Sqlite3Stmt, idx: c_int, val: i64) -> c_int;
    fn sqlite3_bind_null(stmt: *mut Sqlite3Stmt, idx: c_int) -> c_int;
    fn sqlite3_step(stmt: *mut Sqlite3Stmt) -> c_int;
    fn sqlite3_finalize(stmt: *mut Sqlite3Stmt) -> c_int;
    fn sqlite3_column_count(stmt: *mut Sqlite3Stmt) -> c_int;
    fn sqlite3_column_name(stmt: *mut Sqlite3Stmt, n: c_int) -> *const c_char;
    fn sqlite3_column_type(stmt: *mut Sqlite3Stmt, i_col: c_int) -> c_int;
    fn sqlite3_column_int64(stmt: *mut Sqlite3Stmt, i_col: c_int) -> i64;
    fn sqlite3_column_double(stmt: *mut Sqlite3Stmt, i_col: c_int) -> c_double;
    fn sqlite3_column_text(stmt: *mut Sqlite3Stmt, i_col: c_int) -> *const u8;
    fn sqlite3_column_bytes(stmt: *mut Sqlite3Stmt, i_col: c_int) -> c_int;
    fn sqlite3_last_insert_rowid(db: *mut Sqlite3) -> i64;
    fn sqlite3_changes(db: *mut Sqlite3) -> c_int;
}

pub enum SqlParam<'a> {
    Text(&'a str),
    Int(i64),
    Null,
}

pub struct Db {
    raw: *mut Sqlite3,
}

impl Drop for Db {
    fn drop(&mut self) {
        if !self.raw.is_null() {
            unsafe {
                let _ = sqlite3_close(self.raw);
            }
            self.raw = ptr::null_mut();
        }
    }
}

pub fn sqlite_version() -> String {
    unsafe {
        let p = sqlite3_libversion();
        if p.is_null() {
            "unknown".into()
        } else {
            CStr::from_ptr(p).to_string_lossy().to_string()
        }
    }
}

impl Db {
    pub fn open(path: &Path) -> Result<Self, String> {
        if let Some(parent) = path.parent() {
            let _ = std::fs::create_dir_all(parent);
        }
        let c_path = CString::new(path.to_string_lossy().as_bytes())
            .map_err(|_| "Invalid DB path (interior NUL)")?;
        let mut raw: *mut Sqlite3 = ptr::null_mut();
        let rc = unsafe { sqlite3_open(c_path.as_ptr(), &mut raw) };
        if rc != SQLITE_OK || raw.is_null() {
            let msg = if !raw.is_null() {
                let err = unsafe { CStr::from_ptr(sqlite3_errmsg(raw)).to_string_lossy().to_string() };
                unsafe { sqlite3_close(raw) };
                err
            } else {
                format!("sqlite3_open error code {}", rc)
            };
            return Err(msg);
        }
        unsafe {
            sqlite3_busy_timeout(raw, 5000);
        }
        let db = Db { raw };
        db.exec_batch("PRAGMA journal_mode=WAL; PRAGMA synchronous=NORMAL; PRAGMA foreign_keys=ON;")?;
        db.init_schema()?;
        Ok(db)
    }

    fn last_err(&self) -> String {
        unsafe {
            let p = sqlite3_errmsg(self.raw);
            if p.is_null() {
                "SQLite error".into()
            } else {
                CStr::from_ptr(p).to_string_lossy().to_string()
            }
        }
    }

    pub fn exec_batch(&self, sql: &str) -> Result<(), String> {
        let c_sql = CString::new(sql).map_err(|_| "NUL in SQL batch")?;
        let mut errmsg: *mut c_char = ptr::null_mut();
        let rc = unsafe { sqlite3_exec(self.raw, c_sql.as_ptr(), None, ptr::null_mut(), &mut errmsg) };
        if rc != SQLITE_OK {
            let msg = if !errmsg.is_null() {
                let s_err = unsafe { CStr::from_ptr(errmsg).to_string_lossy().to_string() };
                unsafe { sqlite3_free(errmsg as *mut c_void) };
                s_err
            } else {
                self.last_err()
            };
            return Err(msg);
        }
        Ok(())
    }

    pub fn exec_params(&self, sql: &str, params: &[SqlParam<'_>]) -> Result<(i64, i32), String> {
        let c_sql = CString::new(sql).map_err(|_| "NUL in SQL")?;
        let mut stmt: *mut Sqlite3Stmt = ptr::null_mut();
        let rc = unsafe {
            sqlite3_prepare_v2(
                self.raw,
                c_sql.as_ptr(),
                c_sql.as_bytes().len() as c_int,
                &mut stmt,
                ptr::null_mut(),
            )
        };
        if rc != SQLITE_OK || stmt.is_null() {
            return Err(format!("prepare error: {} | sql: {}", self.last_err(), sql));
        }

        for (i, param) in params.iter().enumerate() {
            let idx = (i + 1) as c_int;
            let brc = unsafe {
                match param {
                    SqlParam::Text(t) => sqlite3_bind_text(
                        stmt,
                        idx,
                        t.as_ptr() as *const c_char,
                        t.len() as c_int,
                        sqlite_transient(),
                    ),
                    SqlParam::Int(v) => sqlite3_bind_int64(stmt, idx, *v),
                    SqlParam::Null => sqlite3_bind_null(stmt, idx),
                }
            };
            if brc != SQLITE_OK {
                unsafe { sqlite3_finalize(stmt) };
                return Err(format!("bind error at #{}: {}", idx, self.last_err()));
            }
        }

        let src = unsafe { sqlite3_step(stmt) };
        unsafe { sqlite3_finalize(stmt) };
        if src != SQLITE_DONE && src != SQLITE_ROW {
            return Err(format!("step error ({}): {}", src, self.last_err()));
        }
        let rowid = unsafe { sqlite3_last_insert_rowid(self.raw) };
        let chg = unsafe { sqlite3_changes(self.raw) };
        Ok((rowid, chg))
    }

    pub fn query_rows(&self, sql: &str, params: &[SqlParam<'_>]) -> Result<Vec<JsonVal>, String> {
        let c_sql = CString::new(sql).map_err(|_| "NUL in SQL")?;
        let mut stmt: *mut Sqlite3Stmt = ptr::null_mut();
        let rc = unsafe {
            sqlite3_prepare_v2(
                self.raw,
                c_sql.as_ptr(),
                c_sql.as_bytes().len() as c_int,
                &mut stmt,
                ptr::null_mut(),
            )
        };
        if rc != SQLITE_OK || stmt.is_null() {
            return Err(format!("prepare error: {} | sql: {}", self.last_err(), sql));
        }

        for (i, param) in params.iter().enumerate() {
            let idx = (i + 1) as c_int;
            let brc = unsafe {
                match param {
                    SqlParam::Text(t) => sqlite3_bind_text(
                        stmt,
                        idx,
                        t.as_ptr() as *const c_char,
                        t.len() as c_int,
                        sqlite_transient(),
                    ),
                    SqlParam::Int(v) => sqlite3_bind_int64(stmt, idx, *v),
                    SqlParam::Null => sqlite3_bind_null(stmt, idx),
                }
            };
            if brc != SQLITE_OK {
                unsafe { sqlite3_finalize(stmt) };
                return Err(format!("bind error at #{}: {}", idx, self.last_err()));
            }
        }

        let col_count = unsafe { sqlite3_column_count(stmt) };
        let mut col_names = Vec::with_capacity(col_count as usize);
        for c in 0..col_count {
            let nm = unsafe {
                let p = sqlite3_column_name(stmt, c);
                if p.is_null() {
                    format!("col_{}", c)
                } else {
                    CStr::from_ptr(p).to_string_lossy().to_string()
                }
            };
            col_names.push(nm);
        }

        let mut rows = Vec::new();
        loop {
            let src = unsafe { sqlite3_step(stmt) };
            if src == SQLITE_DONE {
                break;
            }
            if src != SQLITE_ROW {
                unsafe { sqlite3_finalize(stmt) };
                return Err(format!("step error ({}): {}", src, self.last_err()));
            }
            let mut obj = JsonVal::obj();
            for c in 0..col_count {
                let ctype = unsafe { sqlite3_column_type(stmt, c) };
                let jv = match ctype {
                    SQLITE_NULL => JsonVal::Null,
                    SQLITE_INTEGER => {
                        let v = unsafe { sqlite3_column_int64(stmt, c) };
                        n_i64(v)
                    }
                    SQLITE_FLOAT => {
                        let v = unsafe { sqlite3_column_double(stmt, c) };
                        JsonVal::Num(v)
                    }
                    SQLITE_TEXT | SQLITE_BLOB | _ => {
                        let ptr_txt = unsafe { sqlite3_column_text(stmt, c) };
                        let len = unsafe { sqlite3_column_bytes(stmt, c) };
                        if ptr_txt.is_null() || len <= 0 {
                            s("")
                        } else {
                            let slice = unsafe { std::slice::from_raw_parts(ptr_txt, len as usize) };
                            s(&String::from_utf8_lossy(slice))
                        }
                    }
                };
                obj.insert(&col_names[c as usize], jv);
            }
            rows.push(obj);
        }
        unsafe { sqlite3_finalize(stmt) };
        Ok(rows)
    }

    pub fn query_i64(&self, sql: &str, params: &[SqlParam<'_>]) -> i64 {
        if let Ok(rows) = self.query_rows(sql, params) {
            if let Some(first) = rows.first() {
                if let JsonVal::Obj(m) = first {
                    if let Some((_, v)) = m.iter().next() {
                        return v.as_i64().unwrap_or(0);
                    }
                }
            }
        }
        0
    }

    fn init_schema(&self) -> Result<(), String> {
        let ddl = r#"
CREATE TABLE IF NOT EXISTS companies (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE,
    scope_patterns TEXT NOT NULL DEFAULT 'localhost,127.0.0.1,::1,10.*,192.168.*,172.16.*',
    authorized_note TEXT NOT NULL DEFAULT 'Local isolated sandbox & authorized workspace scope',
    created_at INTEGER NOT NULL DEFAULT (strftime('%s','now'))
);

CREATE TABLE IF NOT EXISTS tasks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    company_id INTEGER NOT NULL DEFAULT 1 REFERENCES companies(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    target TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'active',
    lang TEXT NOT NULL DEFAULT 'es',
    todolist_json TEXT NOT NULL DEFAULT '[]',
    created_at INTEGER NOT NULL DEFAULT (strftime('%s','now')),
    updated_at INTEGER NOT NULL DEFAULT (strftime('%s','now'))
);

CREATE TABLE IF NOT EXISTS assets (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    company_id INTEGER NOT NULL DEFAULT 1 REFERENCES companies(id) ON DELETE CASCADE,
    parent_id INTEGER REFERENCES assets(id) ON DELETE SET NULL,
    asset_type TEXT NOT NULL,
    value TEXT NOT NULL,
    dedup_key TEXT NOT NULL UNIQUE,
    host TEXT NOT NULL DEFAULT '',
    port INTEGER NOT NULL DEFAULT 0,
    protocol TEXT NOT NULL DEFAULT '',
    http_status INTEGER NOT NULL DEFAULT 0,
    title TEXT NOT NULL DEFAULT '',
    tech_stack TEXT NOT NULL DEFAULT '',
    metadata_json TEXT NOT NULL DEFAULT '{}',
    created_at INTEGER NOT NULL DEFAULT (strftime('%s','now'))
);
CREATE INDEX IF NOT EXISTS idx_assets_type ON assets(asset_type);
CREATE INDEX IF NOT EXISTS idx_assets_host ON assets(host);

CREATE TABLE IF NOT EXISTS exploration_nodes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    task_id INTEGER NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
    node_type TEXT NOT NULL,
    title TEXT NOT NULL,
    content TEXT NOT NULL DEFAULT '',
    status TEXT NOT NULL DEFAULT 'pending',
    severity TEXT NOT NULL DEFAULT 'info',
    owner_worker TEXT NOT NULL DEFAULT 'planner',
    created_at INTEGER NOT NULL DEFAULT (strftime('%s','now')),
    updated_at INTEGER NOT NULL DEFAULT (strftime('%s','now'))
);
CREATE INDEX IF NOT EXISTS idx_exp_nodes_task ON exploration_nodes(task_id, node_type);

CREATE TABLE IF NOT EXISTS exploration_edges (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    task_id INTEGER NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
    from_node_id INTEGER NOT NULL REFERENCES exploration_nodes(id) ON DELETE CASCADE,
    to_node_id INTEGER NOT NULL REFERENCES exploration_nodes(id) ON DELETE CASCADE,
    edge_type TEXT NOT NULL,
    created_at INTEGER NOT NULL DEFAULT (strftime('%s','now')),
    UNIQUE(from_node_id, to_node_id, edge_type)
);

CREATE TABLE IF NOT EXISTS exploration_anchors (
    node_id INTEGER NOT NULL REFERENCES exploration_nodes(id) ON DELETE CASCADE,
    asset_id INTEGER NOT NULL REFERENCES assets(id) ON DELETE CASCADE,
    PRIMARY KEY (node_id, asset_id)
);

CREATE TABLE IF NOT EXISTS findings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    task_id INTEGER NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
    asset_id INTEGER REFERENCES assets(id) ON DELETE SET NULL,
    node_id INTEGER REFERENCES exploration_nodes(id) ON DELETE SET NULL,
    title TEXT NOT NULL,
    severity TEXT NOT NULL DEFAULT 'medium',
    status TEXT NOT NULL DEFAULT 'open',
    cwe TEXT NOT NULL DEFAULT '',
    cvss REAL NOT NULL DEFAULT 0.0,
    description TEXT NOT NULL DEFAULT '',
    reproduction TEXT NOT NULL DEFAULT '',
    remediation TEXT NOT NULL DEFAULT '',
    evidence_id INTEGER,
    created_at INTEGER NOT NULL DEFAULT (strftime('%s','now')),
    updated_at INTEGER NOT NULL DEFAULT (strftime('%s','now'))
);
CREATE INDEX IF NOT EXISTS idx_findings_task ON findings(task_id, severity);

CREATE TABLE IF NOT EXISTS evidence_traffic (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    task_id INTEGER NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
    finding_id INTEGER REFERENCES findings(id) ON DELETE SET NULL,
    method TEXT NOT NULL DEFAULT 'GET',
    url TEXT NOT NULL,
    req_headers TEXT NOT NULL DEFAULT '',
    req_body TEXT NOT NULL DEFAULT '',
    status_code INTEGER NOT NULL DEFAULT 200,
    resp_headers TEXT NOT NULL DEFAULT '',
    resp_body_excerpt TEXT NOT NULL DEFAULT '',
    sha256 TEXT NOT NULL DEFAULT '',
    created_at INTEGER NOT NULL DEFAULT (strftime('%s','now'))
);

CREATE TABLE IF NOT EXISTS worker_traces (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    task_id INTEGER NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
    intent_id INTEGER NOT NULL DEFAULT 0,
    worker_name TEXT NOT NULL,
    step_no INTEGER NOT NULL DEFAULT 1,
    summary TEXT NOT NULL,
    raw_output TEXT NOT NULL DEFAULT '',
    created_at INTEGER NOT NULL DEFAULT (strftime('%s','now'))
);
CREATE INDEX IF NOT EXISTS idx_traces_task ON worker_traces(task_id, intent_id);

CREATE TABLE IF NOT EXISTS intercept_rules (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE,
    pattern TEXT NOT NULL,
    action TEXT NOT NULL DEFAULT 'deny',
    reason TEXT NOT NULL,
    enabled INTEGER NOT NULL DEFAULT 1,
    builtin INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS guard_audit (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ts INTEGER NOT NULL DEFAULT (strftime('%s','now')),
    tool_name TEXT NOT NULL,
    action TEXT NOT NULL,
    reason TEXT NOT NULL DEFAULT '',
    command TEXT NOT NULL DEFAULT '',
    conversation_id TEXT NOT NULL DEFAULT ''
);
"#;
        self.exec_batch(ddl)?;

        let comp_cnt = self.query_i64("SELECT COUNT(*) FROM companies;", &[]);
        if comp_cnt == 0 {
            let _ = self.exec_params(
                "INSERT INTO companies (name, scope_patterns, authorized_note) VALUES (?1, ?2, ?3);",
                &[
                    SqlParam::Text("Local Sandbox & Authorized Scope"),
                    SqlParam::Text("localhost,127.0.0.1,::1,0.0.0.0,10.,192.168.,172.16."),
                    SqlParam::Text("Default authorized local lab & user workspace scope"),
                ],
            );
        }

        let rules_cnt = self.query_i64("SELECT COUNT(*) FROM intercept_rules;", &[]);
        if rules_cnt == 0 {
            let seed_rules: &[(&str, &str, &str, &str)] = &[
                (
                    "fs-root-wipe",
                    "--no-preserve-root|mkfs\\.|dd of=/dev/|wipe /dev/|shred /dev/",
                    "deny",
                    "Destructive disk/filesystem wipe blocked (ARTEX Guard T1561.002)",
                ),
                (
                    "agy-runtime-protect",
                    "rm .*runtime/bin|mv .*runtime/bin|>.*runtime/bin/rish",
                    "deny",
                    "Protected Antigravity Android runtime/bin modification blocked",
                ),
                (
                    "db-drop-destructive",
                    "DROP DATABASE|DROP SCHEMA|FLUSHALL|\\.dropDatabase\\(",
                    "deny",
                    "Destructive database wipe blocked (ARTEX Guard T1485)",
                ),
                (
                    "net-firewall-killall",
                    "iptables -F|nft flush ruleset|kill -9 -1|killall -9",
                    "deny",
                    "Host availability disruption command blocked (ARTEX Guard T1489)",
                ),
            ];
            for (nm, pat, act, rsn) in seed_rules {
                let _ = self.exec_params(
                    "INSERT OR IGNORE INTO intercept_rules (name, pattern, action, reason, enabled, builtin) VALUES (?1, ?2, ?3, ?4, 1, 1);",
                    &[
                        SqlParam::Text(nm),
                        SqlParam::Text(pat),
                        SqlParam::Text(act),
                        SqlParam::Text(rsn),
                    ],
                );
            }
        }
        Ok(())
    }
}
