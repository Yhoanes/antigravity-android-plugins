# ARTEX API & Surface Recon Rules (Android ARM64)

When the `artex-recon` plugin is enabled:

1. **Non-Destructive Recon Boundary (`api-recon` Contract):**
   - `artex-recon` performs **surface, route, RBAC permission-tree, and security-header discovery only** against authorized targets (`localhost`, local repositories, or targets registered in `artex_scope_configure`).
   - Never read >100 KB minified `.js` bundles directly into LLM context — always run `artex_harvest_static` and `artex_route_perm_map` first so static chunks are processed out-of-context and summarized cleanly.
   - For live SPA DOM inspection on Android, pair with `chrome-devtools-plugin` / native ARM64 Chromium (`$HOME/runtime/bin/chrome`) — never invoke the desktop `browser` subagent.

2. **Asset Graph Synchronization:**
   - Keep `sync_asset_graph: true` when calling `artex_harvest_static`, `artex_source_api_scan`, and `artex_enrich_target` so discovered endpoints and security header posture populate `~/.gemini/artex/artex.db` automatically for `artex-audit` and the `127.0.0.1:8787` console.
