---
name: artex-api-recon
description: Non-destructive static & runtime API endpoint, SPA route-map, RBAC permission-tree, and shadow-API discovery workflow ported from artex-global/skills/api-recon for Android ARM64.
---

# ARTEX API & SPA Surface Recon (`artex-api-recon`)

Ported from [`jiwoochris/artex-global/skills/api-recon`](https://github.com/jiwoochris/artex-global/tree/main/skills/api-recon) and adapted to Antigravity Android ARM64.

## Mandatory Execution Order

1. **Source Code Available? Run `artex_source_api_scan` First:**
   - Scans Next.js App Router (`app/api/**/route.ts`), Express/Fastify, FastAPI/Flask, Go, and Spring routes in milliseconds, flagging files missing auth middleware references and syncing every endpoint to `artex.db`.
2. **Compiled Web Build or Authorized URL? Run `artex_harvest_static`:**
   - Never `read_file` or `grep` minified `index-*.js` bundles (>100 KB) into context.
   - Call `artex_harvest_static` (`target: "http://127.0.0.1:3000"` or local `dist/`/`out/`), which recursively expands webpack (`__webpack_require__.u`) and Vite (`__vite__mapDeps`) chunk manifests, writes `api_static.txt` + `routes.txt`, and populates the ARTEX Asset Graph.
3. **RBAC & Route Map Reconstruction (`artex_route_perm_map`):**
   - Call `artex_route_perm_map` on the harvested `js/` folder to extract `route_map.json` and `role_permissions_stub.json` so hidden admin/module routes gated only on the client side can be inventoried without credentials.
4. **Header & TLS Posture (`artex_enrich_target`) + Shadow API Diff (`artex_openapi_diff`):**
   - Run `artex_enrich_target` to inspect `CSP`, `HSTS`, `X-Frame-Options`, `CORS`, and server banners.
   - If the project has an `openapi.json` / `swagger.json`, run `artex_openapi_diff` to uncover undocumented shadow endpoints.
