---
name: artex-surface-sync
description: Attack-surface inventory and external asset-list synchronization into ARTEX's SQLite Asset Graph (ported from artex-global/skills/scopesentry).
---

# ARTEX Surface Sync (`artex-surface-sync`)

Synchronizes authorized domain, subdomain, service, and endpoint inventories (from local project configs, OpenAPI specs, ScopeSentry JSON exports, or DNS/HTTP checks) into `~/.gemini/artex/artex.db`:

1. Register the authorized scope boundary with `artex_scope_configure` (`action: "upsert_company"`).
2. Ingest root domains, services, and endpoints via `artex_asset_upsert` (`root_domain` -> `subdomain` -> `service` -> `endpoint`), `artex_harvest_static`, or `artex_source_api_scan`.
3. Enrich live local/authorized services via `artex_enrich_target` and query uninspected surface via `artex_asset_dsl_search` (`status=200`, `type=endpoint`).
