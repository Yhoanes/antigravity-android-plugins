---
name: github
description: Native Android ARM64 GitHub MCP Server (v2.1.0, 91 tools) and Bionic Git/GH CLI workflow guide for repositories, commits, Pull Requests, code reviews, Issues, GitHub Actions CI/CD logs, Dependabot, and OAuth setup without Docker.
---

# GitHub Native ARM64 Plugin (`v2.1.0-android`)

This plugin runs GitHub's official **`github-mcp-server` (`v2.1.0`) natively on Android ARM64 (`aarch64`)** with zero Docker dependencies, automatic OAuth token discovery (`gh` / `~/.netrc` / PAT), and pre-configured Android Bionic `git` + `gh` fixes.

## 1. Checking Status & One-Command Authentication (`github-mcp-setup`)

- If the user has already signed in via `gh auth login`, `~/.netrc`, or `~/.config/github-mcp/token`, **all 91 MCP tools load automatically** on startup.
- If not yet signed in, run:
  ```bash
  github-mcp-setup
  ```
  - Installs native ARM64 `git` and `gh` via `pkg` if missing.
  - Opens `https://github.com/login/device` in the Android browser via `xdg-open` and prints the 8-character one-time code so the user can authorize with one tap.
  - Alternatively, configure a Personal Access Token non-interactively:
    ```bash
    github-mcp-setup --token "<GITHUB_PAT>"
    ```
  - Automatically configures `http.sslCAInfo`, `GIT_EXEC_PATH`, `GODEBUG=netdns=cgo`, and `~/.netrc` (`0600`) so local `git clone` / `git push` and `github-mcp-server` work seamlessly together.

## 2. Included Native Toolsets (91 Tools Enabled via `--toolsets=all`)

| Toolset | Key Capabilities |
| :--- | :--- |
| **`repos` & `git`** | Browse files (`get_file_contents`), list branches/commits/tags, create branches, commit single or multiple files (`create_or_update_file`, `push_files`), fork & create repositories. |
| **`pull_requests`** | Create PRs (`create_pull_request`), inspect diffs/files/status checks (`pull_request_read`), submit code reviews & inline comments, merge PRs. |
| **`issues` & `labels`** | Search, triage, create, update, comment on, and label Issues (`list_issues`, `issue_read`, `issue_write`). |
| **`actions`** | Inspect GitHub Actions workflows, trigger workflow dispatches, monitor CI runs, and download failed job logs (`actions_list`, `actions_get`, `get_job_logs`). |
| **`code_security` & `dependabot`** | Inspect Dependabot alerts, secret scanning alerts, code scanning findings, and security advisories. |
| **`users`, `orgs`, `projects`, `discussions`, `gists`** | Query authenticated profile (`get_me`), manage GitHub Projects, Discussions, Gists, and Notifications. |

## 3. When to Use MCP Tools vs Local `git` CLI

- **Use `github` MCP tools** for remote repository inspection, reading files without cloning, creating/reviewing PRs, managing Issues, inspecting GitHub Actions logs, searching code across GitHub, and fast multi-file commits (`push_files`).
- **Use local `git` CLI** when compiling, testing, or packaging large binary archives locally in the workspace before pushing (`git push origin main`).
