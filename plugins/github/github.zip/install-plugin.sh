#!/system/bin/sh
# install-plugin.sh - Installs Native ARM64 GitHub MCP + Bionic Git/GH Bridge into Antigravity for Android
set -eu

SRC_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
case "$SRC_DIR" in
    */.gemini/*) HOME="${SRC_DIR%%/.gemini/*}" ;;
    *) HOME="${HOME:-/data/user/0/com.agy/files}" ;;
esac
PREFIX="${PREFIX:-$HOME/usr}"
CONFIG_DIR="$HOME/.gemini/config"
TARGET_DIR="$CONFIG_DIR/plugins/github"

mkdir -p "$CONFIG_DIR/plugins"
if [ "$SRC_DIR" != "$TARGET_DIR" ]; then
    rm -rf "$TARGET_DIR"
    mkdir -p "$TARGET_DIR"
    cp -Rf "$SRC_DIR"/. "$TARGET_DIR"/
fi

chmod 0755 \
    "$TARGET_DIR/install-plugin.sh" \
    "$TARGET_DIR/mcp/bin/start-mcp.sh" \
    "$TARGET_DIR/mcp/bin/github-mcp-server" \
    "$TARGET_DIR/mcp/bin/github-mcp-setup"

rm -f "$PREFIX/bin/github-mcp-server" "$PREFIX/bin/github-mcp-setup" 2>/dev/null || true

WRAP_DIR="$HOME/runtime/bin"
mkdir -p "$WRAP_DIR" 2>/dev/null || true
for tool in github-mcp-server github-mcp-setup; do
    rm -f "$WRAP_DIR/$tool" 2>/dev/null || true
    cat > "$WRAP_DIR/$tool" <<EOF
#!/system/bin/sh
export HOME="$HOME"
export PREFIX="$PREFIX"
exec "$TARGET_DIR/mcp/bin/$tool" "\$@"
EOF
    chmod 0755 "$WRAP_DIR/$tool"
done

# Pre-configure Bionic Git TLS & template paths if git is already installed
if [ -x "$PREFIX/bin/git" ]; then
    GIT_CONFIG_NOSYSTEM=1 "$PREFIX/bin/git" config --global http.sslCAInfo "$PREFIX/etc/tls/cert.pem" 2>/dev/null || true
    GIT_CONFIG_NOSYSTEM=1 "$PREFIX/bin/git" config --global init.templateDir "$PREFIX/share/git-core/templates" 2>/dev/null || true
fi

echo "============================================================"
echo " GitHub Native ARM64 Plugin v2.1.0-android active!"
echo " Run 'github-mcp-setup' once if you haven't signed in yet."
echo "============================================================"
