#!/system/bin/sh
# install-plugin.sh - Installs Native ARM64 GitHub MCP + Bionic Git/GH Bridge into Antigravity for Android
set -eu

SRC_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
case "$SRC_DIR" in
    */.gemini/*) HOME="${SRC_DIR%%/.gemini/*}" ;;
    *) HOME="${HOME:-/data/user/0/com.agy/files}" ;;
esac
PREFIX="${PREFIX:-$HOME/usr}"
CONFIG_DIR="$HOME/.gemini/config"
TARGET_DIR="$CONFIG_DIR/plugins/github"

mkdir -p "$CONFIG_DIR/plugins"
if [ "$SRC_DIR" != "$TARGET_DIR" ]; then
    rm -rf "$TARGET_DIR"
    mkdir -p "$TARGET_DIR"
    cp -Rf "$SRC_DIR"/. "$TARGET_DIR"/
fi

chmod 0755 \
    "$TARGET_DIR/install-plugin.sh" \
    "$TARGET_DIR/mcp/bin/start-mcp.sh" \
    "$TARGET_DIR/mcp/bin/github-mcp-server" \
    "$TARGET_DIR/mcp/bin/github-mcp-setup"

rm -f "$PREFIX/bin/github-mcp-server" "$PREFIX/bin/github-mcp-setup" 2>/dev/null || true

WRAP_DIR="$HOME/runtime/bin"
mkdir -p "$WRAP_DIR" 2>/dev/null || true

rm -f "$WRAP_DIR/github-mcp-server" 2>/dev/null || true
cat > "$WRAP_DIR/github-mcp-server" <<EOF
#!/system/bin/sh
export HOME="$HOME"
export PREFIX="$PREFIX"
export TMPDIR="\${TMPDIR:-$PREFIX/tmp}"
export LD_LIBRARY_PATH="$PREFIX/lib\${LD_LIBRARY_PATH:+:\$LD_LIBRARY_PATH}"
[ -f "$PREFIX/lib/libagy-go-dns.so" ] && export LD_PRELOAD="$PREFIX/lib/libagy-go-dns.so\${LD_PRELOAD:+:\$LD_PRELOAD}"
[ -f "$PREFIX/etc/tls/cert.pem" ] && export SSL_CERT_FILE="$PREFIX/etc/tls/cert.pem"
if [ -x "$PREFIX/bin/env" ]; then
    exec "$PREFIX/bin/env" "$TARGET_DIR/mcp/bin/github-mcp-server" "\$@"
fi
exec "$TARGET_DIR/mcp/bin/github-mcp-server" "\$@"
EOF
chmod 0755 "$WRAP_DIR/github-mcp-server"

rm -f "$WRAP_DIR/github-mcp-setup" 2>/dev/null || true
cat > "$WRAP_DIR/github-mcp-setup" <<EOF
#!/system/bin/sh
export HOME="$HOME"
export PREFIX="$PREFIX"
exec "$TARGET_DIR/mcp/bin/github-mcp-setup" "\$@"
EOF
chmod 0755 "$WRAP_DIR/github-mcp-setup"

# Pre-configure Bionic Git TLS & template paths if git is already installed
if [ -x "$PREFIX/bin/git" ]; then
    GIT_CONFIG_NOSYSTEM=1 "$PREFIX/bin/git" config --global http.sslCAInfo "$PREFIX/etc/tls/cert.pem" 2>/dev/null || true
    GIT_CONFIG_NOSYSTEM=1 "$PREFIX/bin/git" config --global init.templateDir "$PREFIX/share/git-core/templates" 2>/dev/null || true
fi

echo "============================================================"
echo " GitHub Native ARM64 Plugin v2.1.1-android active!"
echo " Run 'github-mcp-setup' once if you haven't signed in yet."
echo "============================================================"
