# GitHub Native ARM64 Rules (Android)

When the `github` plugin is enabled on Antigravity for Android:

1. **Prefer Native `github` MCP Tools for GitHub API Operations:**
   - Use the `github` MCP server's 91 native ARM64 tools (`get_me`, `search_repositories`, `get_file_contents`, `create_or_update_file`, `push_files`, `list_pull_requests`, `create_pull_request`, `pull_request_read`, `list_issues`, `create_issue`, `actions_list`, `get_job_logs`, etc.) instead of scraping HTML or requiring Docker.
   - If only `github_android_status` is listed (unauthenticated fresh install), run `github-mcp-setup` via `run_command` (which launches the Android browser OAuth device flow via `xdg-open` and syncs credentials automatically).

2. **Android Bionic `git` & `gh` Environment Rules:**
   - When running `git` or `gh` directly in `run_command` on Android (`com.agy`), always ensure:
     ```bash
     export PREFIX="/data/user/0/com.agy/files/usr"
     export PATH="$PREFIX/bin:/data/user/0/com.agy/files/runtime/bin:$PATH"
     export GODEBUG="netdns=cgo"
     export GIT_CONFIG_NOSYSTEM=1
     export GIT_EXEC_PATH="$PREFIX/libexec/git-core"
     export SSL_CERT_FILE="$PREFIX/etc/tls/cert.pem"
     ```
   - Never rely on `!gh auth git-credential` in `.gitconfig` on Android (Git invokes `/bin/sh`, which does not exist on unrooted Android); `github-mcp-setup` configures `~/.netrc` (`0600`) so `git clone` and `git push` authenticate natively in-process via `libcurl`.
