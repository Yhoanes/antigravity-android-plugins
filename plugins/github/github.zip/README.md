# GitHub (`v2.1.0-android`) — Servidor MCP Nativo ARM64 + Puente Git/OAuth para Android

Plugin oficial nativo **ARM64 (`aarch64`)** para **Antigravity for Android** que ejecuta localmente el motor oficial **`github-mcp-server` (`v2.1.0`) con sus 91 herramientas MCP** sin requerir Docker, integrando además detección automática de sesión (`gh` / `.netrc` / PAT) y parches Bionic para `git` y `gh`.

---

## ¿Por qué este plugin nativo en Android?

En escritorio, la integración local de GitHub suele requerir **Docker** (`ghcr.io/github/github-mcp-server`), lo cual no puede ejecutarse en teléfonos Android sin root. Esta edición **`Built for Android`** incluye:

| Componente | Descripción |
| :--- | :--- |
| **`github-mcp-server` (`v2.1.0` ARM64)** | Binario nativo `aarch64` con los **21 toolsets activados (91 herramientas MCP)**: Repositorios, Ramas, Commits, Pull Requests, Code Review, Issues, GitHub Actions CI/CD, Dependabot, Code Security, Discussions, Gists y Proyectos. |
| **Auto-Detección de Credenciales (`<2 ms`)** | `start-mcp.sh` detecta automáticamente tu sesión existente en `~/.config/gh/hosts.yml`, `~/.netrc`, `~/.config/github-mcp/token` o variables `GITHUB_PERSONAL_ACCESS_TOKEN` / `GH_TOKEN`. |
| **`github-mcp-setup` (1 Comando)** | Instala `git` + `gh` si faltan, abre el login OAuth (`https://github.com/login/device`) directo en el navegador de Android vía `xdg-open` y configura `GODEBUG=netdns=cgo`, `GIT_EXEC_PATH` y `~/.netrc` (`0600`) para que `git push` nunca falle por `/bin/sh` ni DNS. |
| **Modo Zero-Day Siempre En Verde** | Si lo instalas en un teléfono nuevo sin cuenta vinculada, el servidor MCP arranca en `<1s` en verde y guía el inicio de sesión con `github_android_status`. |

---

## Activación Rápida

1. Instálalo con un toque desde **Customizations &rarr; Marketplace &rarr; Built for Android &rarr; GitHub**.
2. Si ya iniciaste sesión con `gh` en el dispositivo, **las 91 herramientas quedan activas al instante**.
3. Si aún no has vinculado tu cuenta de GitHub, ejecuta una vez:

```bash
github-mcp-setup
```
