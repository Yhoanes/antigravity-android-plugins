// main.rs — Remotion Studio Android (agy-remotion v1.0.0) Native Rust ARM64 MCP Server & CLI
mod json;
mod templates;

use json::{parse_json, JsonVal};
use std::collections::BTreeMap;
use std::env;
use std::fs;
use std::io::{self, BufRead, BufReader, Write};
use std::net::TcpStream;
use std::path::{Path, PathBuf};
use std::process::{Command, Stdio};
use std::thread;
use std::time::Duration;

const SERVER_NAME: &str = "agy-remotion";
const SERVER_VERSION: &str = "1.0.1";

struct EnvPaths {
    home: PathBuf,
    prefix: PathBuf,
    plugin_dir: PathBuf,
    engine_dir: PathBuf,
    tmp_dir: PathBuf,
}

impl EnvPaths {
    fn resolve() -> Self {
        let home = env::var("HOME")
            .map(PathBuf::from)
            .unwrap_or_else(|_| PathBuf::from("/data/user/0/com.agy/files"));
        let prefix = env::var("PREFIX")
            .map(PathBuf::from)
            .unwrap_or_else(|_| home.join("usr"));
        let plugin_dir = home.join(".gemini/config/plugins/agy-remotion");
        let engine_dir = env::var("AGY_REMOTION_ENGINE")
            .map(PathBuf::from)
            .unwrap_or_else(|_| prefix.join("opt/remotion-engine"));
        let tmp_dir = env::var("TMPDIR")
            .map(PathBuf::from)
            .unwrap_or_else(|_| prefix.join("tmp"));
        let _ = fs::create_dir_all(&tmp_dir);
        Self {
            home,
            prefix,
            plugin_dir,
            engine_dir,
            tmp_dir,
        }
    }

    fn preload_cjs(&self) -> PathBuf {
        self.plugin_dir.join("mcp/runtime/android-preload.cjs")
    }

    fn driver_mjs(&self) -> PathBuf {
        self.plugin_dir.join("mcp/runtime/engine-driver.mjs")
    }

    fn setup_sh(&self) -> PathBuf {
        self.plugin_dir.join("mcp/bin/agy-remotion-setup")
    }

    fn chrome_bin(&self) -> Option<PathBuf> {
        let runtime_chrome = self.home.join("runtime/bin/chrome");
        let usr_chromium = self.prefix.join("bin/chromium");
        let usr_chromium_browser = self.prefix.join("bin/chromium-browser");
        if (usr_chromium.exists() || usr_chromium_browser.exists()) && runtime_chrome.exists() {
            Some(runtime_chrome)
        } else if usr_chromium.exists() {
            Some(usr_chromium)
        } else if usr_chromium_browser.exists() {
            Some(usr_chromium_browser)
        } else {
            None
        }
    }

    fn configure_bionic_cmd(&self, cmd: &mut Command) {
        let path_val = format!(
            "{}:{}:/system/bin",
            self.prefix.join("bin").display(),
            self.home.join("runtime/bin").display()
        );
        cmd.env("HOME", &self.home)
            .env("PREFIX", &self.prefix)
            .env("TMPDIR", &self.tmp_dir)
            .env("AGY_REMOTION_ENGINE", &self.engine_dir)
            .env("PATH", path_val);

        let cert = self.prefix.join("etc/tls/cert.pem");
        if cert.exists() {
            cmd.env("SSL_CERT_FILE", &cert).env("CURL_CA_BUNDLE", &cert);
        }
        let fonts = self.prefix.join("etc/fonts");
        if fonts.exists() {
            cmd.env("FONTCONFIG_PATH", &fonts);
        }
        let lib_dir = self.prefix.join("lib");
        if lib_dir.join("libandroid-support.so").exists() {
            cmd.env("LD_LIBRARY_PATH", &lib_dir);
            let mut preloads = Vec::new();
            let dns = lib_dir.join("libagy-go-dns.so");
            let texec = lib_dir.join("libtermux-exec.so");
            if dns.exists() {
                preloads.push(dns.display().to_string());
            }
            if texec.exists() {
                preloads.push(texec.display().to_string());
            }
            if !preloads.is_empty() {
                cmd.env("LD_PRELOAD", preloads.join(":"));
            }
        }
    }

    fn configure_remotion_node_cmd(&self, cmd: &mut Command) {
        self.configure_bionic_cmd(cmd);
        let preload = self.preload_cjs();
        let node_opts = format!("--require {}", preload.display());
        cmd.env("NODE_OPTIONS", node_opts);
        cmd.env("NODE_PATH", self.engine_dir.join("node_modules"));
        let esbuild_bin = self
            .engine_dir
            .join("node_modules/@esbuild/android-arm64/bin/esbuild");
        if esbuild_bin.exists() {
            cmd.env("ESBUILD_BINARY_PATH", esbuild_bin);
        }
        if let Some(chrome) = self.chrome_bin() {
            cmd.env("REMOTION_CHROME_EXECUTABLE", &chrome)
                .env("CHROME_PATH", &chrome)
                .env("PUPPETEER_EXECUTABLE_PATH", &chrome);
        }
    }
}

fn s(v: &str) -> JsonVal {
    JsonVal::Str(v.to_string())
}

fn run_capture(cmd: &mut Command) -> Result<(i32, String, String), String> {
    let out = cmd.output().map_err(|e| format!("Failed to spawn process: {}", e))?;
    let code = out.status.code().unwrap_or(-1);
    let stdout = String::from_utf8_lossy(&out.stdout).trim().to_string();
    let stderr = String::from_utf8_lossy(&out.stderr).trim().to_string();
    Ok((code, stdout, stderr))
}

fn ensure_cli_wrappers(paths: &EnvPaths) {
    let bin_dir = paths.prefix.join("bin");
    let _ = fs::create_dir_all(&bin_dir);
    let setup_link = bin_dir.join("agy-remotion-setup");
    let cli_link = bin_dir.join("agy-remotion");
    let mcp_bin = paths.plugin_dir.join("mcp/bin/agy-remotion-mcp");
    let setup_bin = paths.setup_sh();

    if !setup_link.exists() {
        let script = format!("#!/system/bin/sh\nexec /system/bin/sh \"{}\" \"$@\"\n", setup_bin.display());
        let _ = fs::write(&setup_link, script);
        #[cfg(unix)]
        {
            use std::os::unix::fs::PermissionsExt;
            let _ = fs::set_permissions(&setup_link, fs::Permissions::from_mode(0o755));
        }
    }
    if !cli_link.exists() {
        let script = format!("#!/system/bin/sh\nexec \"{}\" cli \"$@\"\n", mcp_bin.display());
        let _ = fs::write(&cli_link, script);
        #[cfg(unix)]
        {
            use std::os::unix::fs::PermissionsExt;
            let _ = fs::set_permissions(&cli_link, fs::Permissions::from_mode(0o755));
        }
    }
}

// ---------------------------------------------------------------------------
// Tool Implementations
// ---------------------------------------------------------------------------

fn tool_status(paths: &EnvPaths) -> JsonVal {
    ensure_cli_wrappers(paths);

    let node_bin = paths.prefix.join("bin/node");
    let node_ver = if node_bin.exists() {
        let mut c = Command::new(&node_bin);
        paths.configure_bionic_cmd(&mut c);
        c.arg("-v");
        run_capture(&mut c).ok().map(|(_, out, _)| out).unwrap_or_default()
    } else {
        String::new()
    };

    let chromium_installed = paths.prefix.join("bin/chromium").exists()
        || paths.prefix.join("bin/chromium-browser").exists();
    let ffmpeg_bin = paths.prefix.join("bin/ffmpeg");
    let (ffmpeg_installed, mediacodec_gpu) = if ffmpeg_bin.exists() {
        let mut c = Command::new(&ffmpeg_bin);
        paths.configure_bionic_cmd(&mut c);
        c.args(["-hide_banner", "-encoders"]);
        match run_capture(&mut c) {
            Ok((0, out, _)) => (true, out.contains("h264_mediacodec")),
            _ => (true, false),
        }
    } else {
        (false, false)
    };

    let remotion_pkg = paths.engine_dir.join("node_modules/remotion/package.json");
    let remotion_ver = fs::read_to_string(&remotion_pkg)
        .ok()
        .and_then(|txt| parse_json(&txt).ok())
        .and_then(|j| j.get_str("version").map(|x| x.to_string()))
        .unwrap_or_default();

    let comp_wrapper = paths
        .engine_dir
        .join("node_modules/@remotion/compositor-linux-arm64-musl/remotion");
    let musl_loader = paths.engine_dir.join("compositor-raw/libc.musl-aarch64.so.1");
    let compositor_ready = comp_wrapper.exists() && musl_loader.exists();

    let engine_ready =
        !node_ver.is_empty() && chromium_installed && !remotion_ver.is_empty() && compositor_ready;

    let rish_available = paths.prefix.join("bin/rish").exists()
        || paths.home.join("runtime/bin/rish").exists();

    let mut res = JsonVal::obj();
    res.insert("server", s(SERVER_NAME));
    res.insert("plugin_version", s(SERVER_VERSION));
    res.insert("engine_ready", JsonVal::Bool(engine_ready));
    res.insert("engine_dir", s(&paths.engine_dir.display().to_string()));
    res.insert("remotion_version", s(&remotion_ver));
    res.insert("node_version", s(&node_ver));
    res.insert("chromium_arm64_ready", JsonVal::Bool(chromium_installed));
    res.insert(
        "browser_executable",
        s(&paths
            .chrome_bin()
            .map(|p| p.display().to_string())
            .unwrap_or_default()),
    );
    res.insert("compositor_musl_arm64_ready", JsonVal::Bool(compositor_ready));
    res.insert("ffmpeg_bionic_ready", JsonVal::Bool(ffmpeg_installed));
    res.insert("gpu_h264_mediacodec", JsonVal::Bool(mediacodec_gpu));
    res.insert("rish_available", JsonVal::Bool(rish_available));
    if !engine_ready {
        res.insert(
            "next_step",
            s("Call `remotion_setup` (or run `agy-remotion-setup`) to provision the Remotion 4.0 ARM64 engine."),
        );
    }
    res
}

fn tool_setup(paths: &EnvPaths) -> Result<JsonVal, String> {
    ensure_cli_wrappers(paths);
    let mut cmd = Command::new("/system/bin/sh");
    paths.configure_bionic_cmd(&mut cmd);
    cmd.arg(paths.setup_sh());
    let (code, stdout, stderr) = run_capture(&mut cmd)?;
    if code != 0 {
        return Err(format!(
            "agy-remotion-setup exited with code {}:\n{}\n{}",
            code, stdout, stderr
        ));
    }
    let mut status = tool_status(paths);
    status.insert("setup_log_tail", s(&tail_lines(&stdout, 18)));
    Ok(status)
}

fn tail_lines(txt: &str, n: usize) -> String {
    let lines: Vec<&str> = txt.lines().collect();
    let start = lines.len().saturating_sub(n);
    lines[start..].join("\n")
}

fn dimensions_for_aspect(aspect: &str) -> (i64, i64) {
    match aspect {
        "9:16" => (1080, 1920),
        "1:1" => (1080, 1080),
        "4:5" => (1080, 1350),
        _ => (1920, 1080),
    }
}

fn sanitize_slug(name: &str) -> String {
    let mut out = String::new();
    for ch in name.chars() {
        if ch.is_ascii_alphanumeric() || ch == '-' || ch == '_' {
            out.push(ch.to_ascii_lowercase());
        } else if ch == ' ' {
            out.push('-');
        }
    }
    if out.is_empty() {
        "remotion-video".to_string()
    } else {
        out
    }
}

fn tool_project_create(paths: &EnvPaths, args: &JsonVal) -> Result<JsonVal, String> {
    let raw_name = args.get_str("name").unwrap_or("remotion-promo");
    let slug = sanitize_slug(raw_name);
    let project_dir = match args.get_str("project_dir") {
        Some(p) if !p.trim().is_empty() => PathBuf::from(p),
        _ => PathBuf::from("/sdcard/Video").join(&slug),
    };

    let template = args.get_str("template").unwrap_or("saas_launch");
    let default_aspect = if template == "viral_reels_9_16" {
        "9:16"
    } else {
        "16:9"
    };
    let aspect = args.get_str("aspect_ratio").unwrap_or(default_aspect);
    let (width, height) = dimensions_for_aspect(aspect);
    let fps = args.get_i64("fps").unwrap_or(60).clamp(24, 120);
    let duration_sec = args.get_f64("duration_sec").unwrap_or(6.0).clamp(1.0, 300.0);
    let duration_frames = ((duration_sec * (fps as f64)).round() as i64).max(fps);

    let comp_id = args.get_str("composition_id").unwrap_or("MainPromo");
    let title = args
        .get_str("title")
        .unwrap_or("Remotion 4.0 Native on Android");
    let subtitle = args
        .get_str("subtitle")
        .unwrap_or("Programmatic React & TypeScript motion graphics rendered locally at 60 FPS.");
    let accent = args.get_str("accent_color").unwrap_or("#38BDF8");

    let src_dir = project_dir.join("src");
    let pub_dir = project_dir.join("public");
    let out_dir = project_dir.join("out");
    fs::create_dir_all(&src_dir).map_err(|e| format!("Cannot create src dir: {}", e))?;
    fs::create_dir_all(&pub_dir).map_err(|e| format!("Cannot create public dir: {}", e))?;
    fs::create_dir_all(&out_dir).map_err(|e| format!("Cannot create out dir: {}", e))?;

    let (comp_name, file_stem, scene_code) = templates::template_scene(template);

    fs::write(
        project_dir.join("package.json"),
        templates::render_package_json(&slug),
    )
    .map_err(|e| e.to_string())?;
    fs::write(
        project_dir.join("tsconfig.json"),
        templates::render_tsconfig(&paths.engine_dir.display().to_string()),
    )
    .map_err(|e| e.to_string())?;
    fs::write(
        project_dir.join("remotion.config.ts"),
        templates::render_remotion_config(),
    )
    .map_err(|e| e.to_string())?;
    fs::write(src_dir.join("index.ts"), templates::render_index_ts()).map_err(|e| e.to_string())?;
    fs::write(src_dir.join(format!("{}.tsx", file_stem)), scene_code)
        .map_err(|e| e.to_string())?;
    fs::write(
        src_dir.join("Root.tsx"),
        templates::render_root_tsx(
            comp_id,
            comp_name,
            file_stem,
            width,
            height,
            fps,
            duration_frames,
            title,
            subtitle,
            accent,
        ),
    )
    .map_err(|e| e.to_string())?;

    let mut res = JsonVal::obj();
    res.insert("ok", JsonVal::Bool(true));
    res.insert("project_dir", s(&project_dir.display().to_string()));
    res.insert("composition_id", s(comp_id));
    res.insert("template", s(template));
    res.insert("aspect_ratio", s(aspect));
    res.insert("width", JsonVal::Num(width as f64));
    res.insert("height", JsonVal::Num(height as f64));
    res.insert("fps", JsonVal::Num(fps as f64));
    res.insert("duration_frames", JsonVal::Num(duration_frames as f64));
    res.insert("duration_sec", JsonVal::Num(duration_sec));
    res.insert(
        "scene_file",
        s(&src_dir.join(format!("{}.tsx", file_stem)).display().to_string()),
    );
    Ok(res)
}

fn tool_composition_write(_paths: &EnvPaths, args: &JsonVal) -> Result<JsonVal, String> {
    let project_dir = PathBuf::from(
        args.get_str("project_dir")
            .ok_or("`project_dir` is required")?,
    );
    let rel_file = args
        .get_str("file_path")
        .ok_or("`file_path` (e.g. 'src/HeroScene.tsx') is required")?;
    let code = args.get_str("code").ok_or("`code` is required")?;

    if code.contains("transition:") || code.contains("@keyframes") {
        // Warn in metadata while still writing if intentional
    }

    let full_path = if Path::new(rel_file).is_absolute() {
        PathBuf::from(rel_file)
    } else {
        project_dir.join(rel_file)
    };
    if let Some(parent) = full_path.parent() {
        fs::create_dir_all(parent).map_err(|e| e.to_string())?;
    }
    fs::write(&full_path, code).map_err(|e| format!("Failed writing {}: {}", full_path.display(), e))?;

    let mut registered = false;
    if args.get_bool("register_in_root").unwrap_or(false) {
        let comp_id = args.get_str("composition_id").unwrap_or("MainPromo");
        let component_name = args.get_str("component_name").unwrap_or(comp_id);
        let width = args.get_i64("width").unwrap_or(1920);
        let height = args.get_i64("height").unwrap_or(1080);
        let fps = args.get_i64("fps").unwrap_or(60);
        let duration_frames = args.get_i64("duration_frames").unwrap_or(300);

        let stem = full_path
            .file_stem()
            .and_then(|x| x.to_str())
            .unwrap_or("Scene");
        let root_path = project_dir.join("src/Root.tsx");
        let import_line = format!("import {{ {} }} from \"./{}\";\n", component_name, stem);
        let comp_jsx = format!(
            "      <Composition id=\"{}\" component={{{}}} durationInFrames={{{}}} fps={{{}}} width={{{}}} height={{{}}} />\n",
            comp_id, component_name, duration_frames, fps, width, height
        );

        if let Ok(existing) = fs::read_to_string(&root_path) {
            if !existing.contains(&format!("id=\"{}\"", comp_id)) {
                let mut updated = if existing.contains(&import_line) {
                    existing
                } else {
                    format!("{}{}", import_line, existing)
                };
                if let Some(idx) = updated.rfind("</>") {
                    updated.insert_str(idx, &comp_jsx);
                    let _ = fs::write(&root_path, updated);
                    registered = true;
                }
            }
        }
    }

    let mut res = JsonVal::obj();
    res.insert("ok", JsonVal::Bool(true));
    res.insert("written_file", s(&full_path.display().to_string()));
    res.insert("registered_in_root", JsonVal::Bool(registered));
    res.insert(
        "css_animation_warning",
        JsonVal::Bool(code.contains("transition:") || code.contains("@keyframes")),
    );
    Ok(res)
}

fn invoke_driver(paths: &EnvPaths, payload: &JsonVal) -> Result<JsonVal, String> {
    let node_bin = paths.prefix.join("bin/node");
    if !node_bin.exists() {
        return Err("Node.js not found in $PREFIX/bin/node. Run `remotion_setup` first.".into());
    }
    if !paths.engine_dir.join("node_modules/remotion").exists() {
        return Err("Remotion engine not installed yet. Call `remotion_setup` first.".into());
    }

    let mut cmd = Command::new(&node_bin);
    paths.configure_remotion_node_cmd(&mut cmd);
    cmd.arg(paths.driver_mjs()).arg(payload.to_json_string());

    let (code, stdout, stderr) = run_capture(&mut cmd)?;
    if code != 0 {
        return Err(format!(
            "Remotion engine exited with code {}:\n{}\n{}",
            code, stderr, stdout
        ));
    }

    let last_json_line = stdout
        .lines()
        .rev()
        .find(|l| l.trim_start().starts_with('{'))
        .ok_or_else(|| format!("Unexpected driver output: {}\n{}", stdout, stderr))?;

    parse_json(last_json_line)
}

fn tool_compositions_list(paths: &EnvPaths, args: &JsonVal) -> Result<JsonVal, String> {
    let project_dir = args
        .get_str("project_dir")
        .ok_or("`project_dir` is required")?;
    let mut p = JsonVal::obj();
    p.insert("action", s("list"));
    p.insert("project_dir", s(project_dir));
    if let Some(ep) = args.get_str("entry_point") {
        p.insert("entry_point", s(ep));
    }
    invoke_driver(paths, &p)
}

fn tool_still_render(paths: &EnvPaths, args: &JsonVal) -> Result<JsonVal, String> {
    let project_dir = args
        .get_str("project_dir")
        .ok_or("`project_dir` is required")?;
    let comp_id = args.get_str("composition_id").unwrap_or("MainPromo");
    let frame = args.get_i64("frame").unwrap_or(30);
    let default_out = PathBuf::from(project_dir)
        .join("out")
        .join(format!("{}-frame-{}.png", comp_id, frame));
    let output_path = args
        .get_str("output_path")
        .map(PathBuf::from)
        .unwrap_or(default_out);

    let mut p = JsonVal::obj();
    p.insert("action", s("still"));
    p.insert("project_dir", s(project_dir));
    p.insert("composition_id", s(comp_id));
    p.insert("frame", JsonVal::Num(frame as f64));
    p.insert("output_path", s(&output_path.display().to_string()));
    if let Some(scale) = args.get_f64("scale") {
        p.insert("scale", JsonVal::Num(scale));
    }
    if let Some(props) = args.get("props") {
        p.insert("props", props.clone());
    }
    invoke_driver(paths, &p)
}

fn scan_android_gallery(paths: &EnvPaths, video_path: &Path) -> bool {
    let rish = if paths.prefix.join("bin/rish").exists() {
        paths.prefix.join("bin/rish")
    } else if paths.home.join("runtime/bin/rish").exists() {
        paths.home.join("runtime/bin/rish")
    } else {
        return false;
    };

    let uri = format!("file://{}", video_path.display());
    let broadcast = format!(
        "am broadcast -a android.intent.action.MEDIA_SCANNER_SCAN_FILE -d \"{}\"",
        uri
    );
    let mut cmd = Command::new(rish);
    paths.configure_bionic_cmd(&mut cmd);
    cmd.args(["-c", &broadcast]);
    matches!(run_capture(&mut cmd), Ok((0, _, _)))
}

fn tool_render_video(paths: &EnvPaths, args: &JsonVal) -> Result<JsonVal, String> {
    let project_dir = args
        .get_str("project_dir")
        .ok_or("`project_dir` is required")?;
    let comp_id = args.get_str("composition_id").unwrap_or("MainPromo");
    let default_out = PathBuf::from(project_dir)
        .join("out")
        .join(format!("{}.mp4", comp_id));
    let output_path = args
        .get_str("output_path")
        .map(PathBuf::from)
        .unwrap_or(default_out);

    let gpu_mediacodec = args.get_bool("gpu_mediacodec").unwrap_or(false);
    let stage_out = if gpu_mediacodec && output_path.extension().and_then(|e| e.to_str()) == Some("mp4") {
        paths
            .tmp_dir
            .join(format!("remotion-stage-{}.mp4", std::process::id()))
    } else {
        output_path.clone()
    };

    let mut p = JsonVal::obj();
    p.insert("action", s("render"));
    p.insert("project_dir", s(project_dir));
    p.insert("composition_id", s(comp_id));
    p.insert("output_path", s(&stage_out.display().to_string()));
    if let Some(c) = args.get_i64("concurrency") {
        p.insert("concurrency", JsonVal::Num(c as f64));
    }
    if let Some(scale) = args.get_f64("scale") {
        p.insert("scale", JsonVal::Num(scale));
    }
    if let Some(crf) = args.get_i64("crf") {
        p.insert("crf", JsonVal::Num(crf as f64));
    }
    if let Some(codec) = args.get_str("codec") {
        p.insert("codec", s(codec));
    }
    if let Some(props) = args.get("props") {
        p.insert("props", props.clone());
    }

    let mut result = invoke_driver(paths, &p)?;

    let mut used_gpu = false;
    if stage_out != output_path {
        if let Some(parent) = output_path.parent() {
            let _ = fs::create_dir_all(parent);
        }
        let ffmpeg_bin = paths.prefix.join("bin/ffmpeg");
        if ffmpeg_bin.exists() {
            let mut fc = Command::new(&ffmpeg_bin);
            paths.configure_bionic_cmd(&mut fc);
            fc.args([
                "-y",
                "-i",
                &stage_out.display().to_string(),
                "-c:v",
                "h264_mediacodec",
                "-b:v",
                "12M",
                "-g",
                "120",
                "-pix_fmt",
                "nv12",
                "-c:a",
                "copy",
                "-movflags",
                "+faststart",
                &output_path.display().to_string(),
            ]);
            if let Ok((0, _, _)) = run_capture(&mut fc) {
                used_gpu = true;
                let _ = fs::remove_file(&stage_out);
            } else {
                let _ = fs::copy(&stage_out, &output_path);
                let _ = fs::remove_file(&stage_out);
            }
        } else {
            let _ = fs::copy(&stage_out, &output_path);
            let _ = fs::remove_file(&stage_out);
        }
        if let Ok(meta) = fs::metadata(&output_path) {
            result.insert("size_bytes", JsonVal::Num(meta.len() as f64));
        }
        result.insert("output_path", s(&output_path.display().to_string()));
    }

    let gallery_scanned = if args.get_bool("scan_gallery").unwrap_or(true) {
        scan_android_gallery(paths, &output_path)
    } else {
        false
    };

    result.insert("gpu_mediacodec_applied", JsonVal::Bool(used_gpu));
    result.insert("android_gallery_indexed", JsonVal::Bool(gallery_scanned));
    Ok(result)
}

fn port_listening(port: u16) -> bool {
    TcpStream::connect_timeout(
        &format!("127.0.0.1:{}", port).parse().unwrap(),
        Duration::from_millis(250),
    )
    .is_ok()
}

fn tool_studio_server(paths: &EnvPaths, args: &JsonVal) -> Result<JsonVal, String> {
    let action = args.get_str("action").unwrap_or("status");
    let port = args.get_i64("port").unwrap_or(3100) as u16;
    if port == 45157 || port == 45158 {
        return Err("Ports 45157 and 45158 are reserved by Antigravity core; use e.g. 3100.".into());
    }

    let pid_file = paths.tmp_dir.join(format!("remotion-studio-{}.pid", port));
    let log_file = paths.tmp_dir.join(format!("remotion-studio-{}.log", port));
    let url = format!("http://127.0.0.1:{}", port);

    if action == "stop" {
        if let Ok(pid_str) = fs::read_to_string(&pid_file) {
            let pid = pid_str.trim();
            if !pid.is_empty() {
                let _ = Command::new("/system/bin/kill").args(["-9", pid]).output();
            }
            let _ = fs::remove_file(&pid_file);
        }
        let mut res = JsonVal::obj();
        res.insert("ok", JsonVal::Bool(true));
        res.insert("action", s("stop"));
        res.insert("port", JsonVal::Num(port as f64));
        res.insert("running", JsonVal::Bool(port_listening(port)));
        return Ok(res);
    }

    if action == "status" {
        let mut res = JsonVal::obj();
        res.insert("ok", JsonVal::Bool(true));
        res.insert("url", s(&url));
        res.insert("port", JsonVal::Num(port as f64));
        res.insert("running", JsonVal::Bool(port_listening(port)));
        res.insert("log_file", s(&log_file.display().to_string()));
        return Ok(res);
    }

    let project_dir = args
        .get_str("project_dir")
        .ok_or("`project_dir` is required to start Remotion Studio")?;

    if !port_listening(port) {
        let cli_js = paths
            .engine_dir
            .join("node_modules/@remotion/cli/remotion-cli.js");
        if !cli_js.exists() {
            return Err("Remotion engine not installed. Call `remotion_setup` first.".into());
        }
        let log_out = fs::File::create(&log_file).map_err(|e| e.to_string())?;
        let log_err = log_out.try_clone().map_err(|e| e.to_string())?;

        let mut cmd = Command::new(paths.prefix.join("bin/node"));
        paths.configure_remotion_node_cmd(&mut cmd);
        cmd.current_dir(project_dir)
            .args([
                cli_js.display().to_string(),
                "studio".into(),
                "src/index.ts".into(),
                "--port".into(),
                port.to_string(),
                "--ip".into(),
                "127.0.0.1".into(),
                "--no-open".into(),
            ])
            .stdin(Stdio::null())
            .stdout(Stdio::from(log_out))
            .stderr(Stdio::from(log_err));

        let child = cmd.spawn().map_err(|e| format!("Failed starting Studio: {}", e))?;
        let _ = fs::write(&pid_file, child.id().to_string());

        for _ in 0..28 {
            if port_listening(port) {
                break;
            }
            thread::sleep(Duration::from_millis(250));
        }
    }

    let running = port_listening(port);
    let opened = if running && args.get_bool("open_browser").unwrap_or(true) {
        let xdg = paths.home.join("runtime/bin/xdg-open");
        if xdg.exists() {
            let _ = Command::new(xdg).arg(&url).status();
            true
        } else {
            false
        }
    } else {
        false
    };

    let mut res = JsonVal::obj();
    res.insert("ok", JsonVal::Bool(running));
    res.insert("url", s(&url));
    res.insert("port", JsonVal::Num(port as f64));
    res.insert("running", JsonVal::Bool(running));
    res.insert("opened_in_android_browser", JsonVal::Bool(opened));
    res.insert("log_file", s(&log_file.display().to_string()));
    Ok(res)
}

fn tool_captions_generate(paths: &EnvPaths, args: &JsonVal) -> Result<JsonVal, String> {
    let text = args
        .get_str("text")
        .ok_or("`text` script is required for caption generation")?;
    let total_sec = args.get_f64("duration_sec").unwrap_or_else(|| {
        let word_count = text.split_whitespace().count().max(1);
        (word_count as f64 * 0.38).max(1.5)
    });

    let words: Vec<&str> = text.split_whitespace().collect();
    if words.is_empty() {
        return Err("`text` must contain at least one word".into());
    }

    let total_chars: usize = words.iter().map(|w| w.chars().count().max(2)).sum();
    let total_ms = (total_sec * 1000.0).round();
    let mut cursor_ms = 0.0_f64;
    let mut captions = Vec::with_capacity(words.len());

    for (idx, w) in words.iter().enumerate() {
        let weight = w.chars().count().max(2) as f64 / (total_chars as f64);
        let dur = (total_ms * weight).max(120.0);
        let start = cursor_ms.round() as i64;
        let end = if idx + 1 == words.len() {
            total_ms as i64
        } else {
            (cursor_ms + dur).round() as i64
        };
        cursor_ms += dur;

        let mut item = JsonVal::obj();
        let token_txt = if idx == 0 {
            (*w).to_string()
        } else {
            format!(" {}", w)
        };
        item.insert("text", s(&token_txt));
        item.insert("startMs", JsonVal::Num(start as f64));
        item.insert("endMs", JsonVal::Num(end as f64));
        item.insert("timestampMs", JsonVal::Num(((start + end) / 2) as f64));
        item.insert("confidence", JsonVal::Num(1.0));
        captions.push(item);
    }

    let captions_arr = JsonVal::Arr(captions);
    let mut saved_to = String::new();
    if let Some(proj) = args.get_str("project_dir") {
        let out_file = args
            .get_str("output_json")
            .map(PathBuf::from)
            .unwrap_or_else(|| PathBuf::from(proj).join("src/captions.json"));
        if let Some(p) = out_file.parent() {
            let _ = fs::create_dir_all(p);
        }
        fs::write(&out_file, captions_arr.to_json_string()).map_err(|e| e.to_string())?;
        saved_to = out_file.display().to_string();
    }

    // Optional Neural TTS synthesis if edge-tts is available and voiceover requested
    let mut voiceover_path = String::new();
    if args.get_bool("synthesize_tts").unwrap_or(false) {
        if let Some(proj) = args.get_str("project_dir") {
            let voice = args.get_str("voice").unwrap_or("es-MX-DaliaNeural");
            let mp3_out = PathBuf::from(proj).join("public/voiceover.mp3");
            if let Some(p) = mp3_out.parent() {
                let _ = fs::create_dir_all(p);
            }
            let edge_tts = paths.prefix.join("bin/edge-tts");
            if edge_tts.exists() {
                let mut tc = Command::new(&edge_tts);
                paths.configure_bionic_cmd(&mut tc);
                tc.args([
                    "--voice",
                    voice,
                    "--text",
                    text,
                    "--write-media",
                    &mp3_out.display().to_string(),
                ]);
                if let Ok((0, _, _)) = run_capture(&mut tc) {
                    voiceover_path = mp3_out.display().to_string();
                }
            }
        }
    }

    let mut res = JsonVal::obj();
    res.insert("ok", JsonVal::Bool(true));
    res.insert("word_count", JsonVal::Num(words.len() as f64));
    res.insert("duration_ms", JsonVal::Num(total_ms));
    if !saved_to.is_empty() {
        res.insert("saved_json_path", s(&saved_to));
    }
    if !voiceover_path.is_empty() {
        res.insert("voiceover_mp3_path", s(&voiceover_path));
    }
    res.insert("captions", captions_arr);
    Ok(res)
}

fn tool_cli_exec(paths: &EnvPaths, args: &JsonVal) -> Result<JsonVal, String> {
    let cli_js = paths
        .engine_dir
        .join("node_modules/@remotion/cli/remotion-cli.js");
    if !cli_js.exists() {
        return Err("Remotion engine not installed yet. Call `remotion_setup` first.".into());
    }
    let mut cmd = Command::new(paths.prefix.join("bin/node"));
    paths.configure_remotion_node_cmd(&mut cmd);
    if let Some(cwd) = args.get_str("project_dir") {
        cmd.current_dir(cwd);
    }
    cmd.arg(&cli_js);
    if let Some(arr) = args.get("args").and_then(|v| v.as_arr()) {
        for item in arr {
            if let Some(st) = item.as_str() {
                cmd.arg(st);
            }
        }
    } else {
        cmd.arg("versions");
    }

    let (code, stdout, stderr) = run_capture(&mut cmd)?;
    let mut res = JsonVal::obj();
    res.insert("ok", JsonVal::Bool(code == 0));
    res.insert("exit_code", JsonVal::Num(code as f64));
    res.insert("stdout", s(&stdout));
    res.insert("stderr", s(&stderr));
    Ok(res)
}

// ---------------------------------------------------------------------------
// MCP Schema Registry
// ---------------------------------------------------------------------------

fn prop_str(desc: &str) -> JsonVal {
    let mut m = JsonVal::obj();
    m.insert("type", s("string"));
    m.insert("description", s(desc));
    m
}

fn prop_num(desc: &str) -> JsonVal {
    let mut m = JsonVal::obj();
    m.insert("type", s("number"));
    m.insert("description", s(desc));
    m
}

fn prop_bool(desc: &str) -> JsonVal {
    let mut m = JsonVal::obj();
    m.insert("type", s("boolean"));
    m.insert("description", s(desc));
    m
}

fn make_tool(name: &str, desc: &str, props: Vec<(&str, JsonVal)>, req: Vec<&str>) -> JsonVal {
    let mut pmap = BTreeMap::new();
    for (k, v) in props {
        pmap.insert(k.to_string(), v);
    }
    let mut schema = JsonVal::obj();
    schema.insert("type", s("object"));
    schema.insert("properties", JsonVal::Obj(pmap));
    if !req.is_empty() {
        schema.insert(
            "required",
            JsonVal::Arr(req.into_iter().map(s).collect()),
        );
    }
    let mut t = JsonVal::obj();
    t.insert("name", s(name));
    t.insert("description", s(desc));
    t.insert("inputSchema", schema);
    t
}

fn build_tools_list() -> JsonVal {
    let mut arr_props = JsonVal::obj();
    arr_props.insert("type", s("array"));
    arr_props.insert("items", prop_str("CLI argument"));
    arr_props.insert("description", s("Arguments passed to `remotion` CLI (e.g. [\"versions\"] or [\"benchmark\"])"));

    let mut obj_props = JsonVal::obj();
    obj_props.insert("type", s("object"));
    obj_props.insert("description", s("Optional inputProps JSON overrides merged onto composition defaultProps"));

    let tools = vec![
        make_tool(
            "remotion_status",
            "Inspect Remotion Studio Android ARM64 status: Node.js, Remotion 4.0 shared engine ($PREFIX/opt/remotion-engine), musl-bridged Rust compositor, native Chromium, FFmpeg h264_mediacodec GPU support, and Shizuku.",
            vec![],
            vec![],
        ),
        make_tool(
            "remotion_setup",
            "One-step installer/repairer for Remotion Studio Android ARM64: installs chromium & ffmpeg via pkg, sets up Remotion 4.0 in $PREFIX/opt/remotion-engine, and bridges @remotion/compositor-linux-arm64-musl.",
            vec![],
            vec![],
        ),
        make_tool(
            "remotion_project_create",
            "Scaffold a lightweight (<50 KB) Remotion 4.0 React/TypeScript video project safe on /sdcard/Video (noexec-compatible via shared engine) with studio templates.",
            vec![
                ("name", prop_str("Project slug name (e.g. 'saas-promo')")),
                ("project_dir", prop_str("Target project folder (defaults to /sdcard/Video/<name>)")),
                ("template", prop_str("Template: 'saas_launch', 'apple_keynote', 'viral_reels_9_16', 'code_walkthrough', or 'data_charts'")),
                ("aspect_ratio", prop_str("'16:9', '9:16', '1:1', or '4:5'")),
                ("fps", prop_num("Frames per second (default 60)")),
                ("duration_sec", prop_num("Duration in seconds (default 6.0)")),
                ("composition_id", prop_str("Composition ID (default 'MainPromo')")),
                ("title", prop_str("Hero headline text")),
                ("subtitle", prop_str("Subtitle copy")),
                ("accent_color", prop_str("Brand hex color (default '#38BDF8')")),
            ],
            vec![],
        ),
        make_tool(
            "remotion_composition_write",
            "Create or update a Remotion React/TypeScript scene (.tsx) inside a project and optionally register its <Composition> in src/Root.tsx.",
            vec![
                ("project_dir", prop_str("Absolute path to the Remotion project")),
                ("file_path", prop_str("Relative path such as 'src/SaasLaunchScene.tsx'")),
                ("code", prop_str("Full TypeScript/React source code (drive motion from useCurrentFrame/spring/interpolate; avoid CSS transitions)")),
                ("register_in_root", prop_bool("If true, registers <Composition> in src/Root.tsx if not present")),
                ("composition_id", prop_str("Composition ID when registering in Root.tsx")),
                ("component_name", prop_str("Exported React component name")),
                ("width", prop_num("Width in px (default 1920)")),
                ("height", prop_num("Height in px (default 1080)")),
                ("fps", prop_num("FPS (default 60)")),
                ("duration_frames", prop_num("Duration in frames")),
            ],
            vec!["project_dir", "file_path", "code"],
        ),
        make_tool(
            "remotion_compositions_list",
            "Bundle the project headlessly on Android ARM64 and list all registered <Composition> IDs, dimensions, FPS, durations, and defaultProps.",
            vec![
                ("project_dir", prop_str("Absolute path to the Remotion project")),
                ("entry_point", prop_str("Optional custom entry point (defaults to src/index.ts)")),
            ],
            vec!["project_dir"],
        ),
        make_tool(
            "remotion_still_render",
            "Render a single exact frame of a Remotion composition to .png or .jpeg in ~1-2s for fast visual QA before full video rendering.",
            vec![
                ("project_dir", prop_str("Absolute path to the Remotion project")),
                ("composition_id", prop_str("Composition ID (default 'MainPromo')")),
                ("frame", prop_num("Zero-indexed frame number to capture (default 30)")),
                ("output_path", prop_str("Output PNG/JPEG path (defaults to <project_dir>/out/<id>-frame-<n>.png)")),
                ("scale", prop_num("Resolution scale multiplier (default 1.0)")),
                ("props", obj_props.clone()),
            ],
            vec!["project_dir"],
        ),
        make_tool(
            "remotion_render_video",
            "Render a Remotion composition to MP4/WebM/GIF on Android ARM64 with optional hardware GPU h264_mediacodec pass and automatic Android Gallery MediaStore indexing.",
            vec![
                ("project_dir", prop_str("Absolute path to the Remotion project")),
                ("composition_id", prop_str("Composition ID (default 'MainPromo')")),
                ("output_path", prop_str("Output .mp4/.webm/.gif path (defaults to <project_dir>/out/<id>.mp4)")),
                ("concurrency", prop_num("Parallel headless renderer tabs (default auto 2-4)")),
                ("scale", prop_num("Resolution scale multiplier (default 1.0)")),
                ("crf", prop_num("Optional H.264/VP8 CRF quality value")),
                ("codec", prop_str("Codec: 'h264', 'h265', 'vp8', or 'gif'")),
                ("gpu_mediacodec", prop_bool("Run Android hardware GPU h264_mediacodec faststart pass")),
                ("scan_gallery", prop_bool("Index rendered video in Android Gallery via rish (default true)")),
                ("props", obj_props),
            ],
            vec!["project_dir"],
        ),
        make_tool(
            "remotion_studio_server",
            "Start, check status, or stop the live interactive Remotion Studio web timeline on 127.0.0.1:<port> (default 3100) and open it in Android browser via xdg-open.",
            vec![
                ("action", prop_str("'start', 'status', or 'stop'")),
                ("project_dir", prop_str("Absolute path to the Remotion project (required for 'start')")),
                ("port", prop_num("Local port on 127.0.0.1 (default 3100; avoid 45157/45158)")),
                ("open_browser", prop_bool("Open http://127.0.0.1:<port> via xdg-open (default true)")),
            ],
            vec!["action"],
        ),
        make_tool(
            "remotion_captions_generate",
            "Generate millisecond-aligned @remotion/captions Caption[] JSON (word-by-word tokens for TikTok/Reels kinetic subtitles) and optional Neural TTS voiceover.",
            vec![
                ("text", prop_str("Spoken script text to tokenize into timed captions")),
                ("duration_sec", prop_num("Total speech duration in seconds (auto-estimated if omitted)")),
                ("project_dir", prop_str("Optional project folder to save src/captions.json and public/voiceover.mp3")),
                ("output_json", prop_str("Optional explicit JSON output path")),
                ("synthesize_tts", prop_bool("Generate public/voiceover.mp3 via edge-tts if installed")),
                ("voice", prop_str("Neural TTS voice (default 'es-MX-DaliaNeural')")),
            ],
            vec!["text"],
        ),
        make_tool(
            "remotion_cli_exec",
            "Execute any official @remotion/cli command (e.g. versions, benchmark, compositions, bundle) inside the Android ARM64 preload & musl compositor bridge.",
            vec![
                ("project_dir", prop_str("Optional working directory")),
                ("args", arr_props),
            ],
            vec![],
        ),
    ];

    let mut out = JsonVal::obj();
    out.insert("tools", JsonVal::Arr(tools));
    out
}

fn dispatch_tool(paths: &EnvPaths, name: &str, args: &JsonVal) -> Result<JsonVal, String> {
    match name {
        "remotion_status" => Ok(tool_status(paths)),
        "remotion_setup" => tool_setup(paths),
        "remotion_project_create" => tool_project_create(paths, args),
        "remotion_composition_write" => tool_composition_write(paths, args),
        "remotion_compositions_list" => tool_compositions_list(paths, args),
        "remotion_still_render" => tool_still_render(paths, args),
        "remotion_render_video" => tool_render_video(paths, args),
        "remotion_studio_server" => tool_studio_server(paths, args),
        "remotion_captions_generate" => tool_captions_generate(paths, args),
        "remotion_cli_exec" => tool_cli_exec(paths, args),
        other => Err(format!("Unknown tool: {}", other)),
    }
}

// ---------------------------------------------------------------------------
// JSON-RPC 2.0 Stdio Server (Line-delimited + Content-Length auto-detection)
// ---------------------------------------------------------------------------

#[derive(Clone, Copy)]
enum Framing {
    Line,
    ContentLength,
}

fn read_rpc_message<R: BufRead>(reader: &mut R) -> io::Result<Option<(String, Framing)>> {
    loop {
        let mut line = String::new();
        let n = reader.read_line(&mut line)?;
        if n == 0 {
            return Ok(None);
        }
        let trimmed = line.trim();
        if trimmed.is_empty() {
            continue;
        }
        if trimmed.starts_with('{') {
            return Ok(Some((trimmed.to_string(), Framing::Line)));
        }
        let lower = trimmed.to_ascii_lowercase();
        if let Some(rest) = lower.strip_prefix("content-length:") {
            let len: usize = rest
                .trim()
                .parse()
                .map_err(|_| io::Error::new(io::ErrorKind::InvalidData, "Bad Content-Length"))?;
            loop {
                let mut hdr = String::new();
                let hn = reader.read_line(&mut hdr)?;
                if hn == 0 || hdr.trim().is_empty() {
                    break;
                }
            }
            let mut buf = vec![0u8; len];
            reader.read_exact(&mut buf)?;
            let body = String::from_utf8_lossy(&buf).to_string();
            return Ok(Some((body, Framing::ContentLength)));
        }
    }
}

fn write_rpc_message<W: Write>(writer: &mut W, payload: &JsonVal, framing: Framing) -> io::Result<()> {
    let serialized = payload.to_json_string();
    match framing {
        Framing::Line => {
            writer.write_all(serialized.as_bytes())?;
            writer.write_all(b"\n")?;
        }
        Framing::ContentLength => {
            let header = format!("Content-Length: {}\r\n\r\n", serialized.len());
            writer.write_all(header.as_bytes())?;
            writer.write_all(serialized.as_bytes())?;
        }
    }
    writer.flush()
}

fn handle_rpc_request(paths: &EnvPaths, req: &JsonVal) -> Option<JsonVal> {
    let method = req.get_str("method").unwrap_or("");
    if method.starts_with("notifications/") {
        return None;
    }
    let id = req.get("id")?.clone();

    let mut resp = JsonVal::obj();
    resp.insert("jsonrpc", s("2.0"));
    resp.insert("id", id);

    match method {
        "initialize" => {
            let mut server_info = JsonVal::obj();
            server_info.insert("name", s(SERVER_NAME));
            server_info.insert("version", s(SERVER_VERSION));

            let mut caps = JsonVal::obj();
            caps.insert("tools", JsonVal::obj());

            let mut result = JsonVal::obj();
            let proto = req
                .get("params")
                .and_then(|p| p.get_str("protocolVersion"))
                .unwrap_or("2024-11-05");
            result.insert("protocolVersion", s(proto));
            result.insert("capabilities", caps);
            result.insert("serverInfo", server_info);
            resp.insert("result", result);
        }
        "ping" => {
            resp.insert("result", JsonVal::obj());
        }
        "tools/list" => {
            resp.insert("result", build_tools_list());
        }
        "tools/call" => {
            let params = req.get("params").cloned().unwrap_or_else(JsonVal::obj);
            let tool_name = params.get_str("name").unwrap_or("");
            let tool_args = params.get("arguments").cloned().unwrap_or_else(JsonVal::obj);

            match dispatch_tool(paths, tool_name, &tool_args) {
                Ok(val) => {
                    let mut citem = JsonVal::obj();
                    citem.insert("type", s("text"));
                    citem.insert("text", s(&val.to_json_string()));
                    let mut result = JsonVal::obj();
                    result.insert("content", JsonVal::Arr(vec![citem]));
                    resp.insert("result", result);
                }
                Err(err_msg) => {
                    let mut err_obj = JsonVal::obj();
                    err_obj.insert("ok", JsonVal::Bool(false));
                    err_obj.insert("error", s(&err_msg));
                    let mut citem = JsonVal::obj();
                    citem.insert("type", s("text"));
                    citem.insert("text", s(&err_obj.to_json_string()));
                    let mut result = JsonVal::obj();
                    result.insert("content", JsonVal::Arr(vec![citem]));
                    result.insert("isError", JsonVal::Bool(true));
                    resp.insert("result", result);
                }
            }
        }
        _ => {
            let mut err = JsonVal::obj();
            err.insert("code", JsonVal::Num(-32601.0));
            err.insert("message", s(&format!("Method not found: {}", method)));
            resp.insert("error", err);
        }
    }
    Some(resp)
}

fn run_cli(paths: &EnvPaths, cli_args: &[String]) -> i32 {
    let sub = cli_args.first().map(|s| s.as_str()).unwrap_or("status");
    match sub {
        "status" => {
            println!("{}", tool_status(paths).to_json_string());
            0
        }
        "setup" => match tool_setup(paths) {
            Ok(v) => {
                println!("{}", v.to_json_string());
                0
            }
            Err(e) => {
                eprintln!("{}", e);
                1
            }
        },
        "studio" => {
            let cwd = env::current_dir()
                .unwrap_or_else(|_| PathBuf::from("/sdcard/Video"))
                .display()
                .to_string();
            let mut args = JsonVal::obj();
            args.insert("action", s("start"));
            args.insert("project_dir", s(&cwd));
            args.insert("open_browser", JsonVal::Bool(true));
            match tool_studio_server(paths, &args) {
                Ok(v) => {
                    println!("{}", v.to_json_string());
                    0
                }
                Err(e) => {
                    eprintln!("{}", e);
                    1
                }
            }
        }
        _ => {
            let mut args = JsonVal::obj();
            if let Ok(cwd) = env::current_dir() {
                args.insert("project_dir", s(&cwd.display().to_string()));
            }
            args.insert(
                "args",
                JsonVal::Arr(cli_args.iter().map(|x| s(x)).collect()),
            );
            match tool_cli_exec(paths, &args) {
                Ok(v) => {
                    if let Some(out) = v.get_str("stdout") {
                        if !out.is_empty() {
                            println!("{}", out);
                        }
                    }
                    if let Some(err) = v.get_str("stderr") {
                        if !err.is_empty() {
                            eprintln!("{}", err);
                        }
                    }
                    v.get_i64("exit_code").unwrap_or(0) as i32
                }
                Err(e) => {
                    eprintln!("{}", e);
                    1
                }
            }
        }
    }
}

fn main() {
    let paths = EnvPaths::resolve();
    let argv: Vec<String> = env::args().collect();
    if argv.len() > 1 {
        let code = match argv[1].as_str() {
            "status" => run_cli(&paths, &[String::from("status")]),
            "setup" => run_cli(&paths, &[String::from("setup")]),
            "cli" => run_cli(&paths, &argv[2..]),
            _ => run_cli(&paths, &argv[1..]),
        };
        std::process::exit(code);
    }

    let stdin = io::stdin();
    let stdout = io::stdout();
    let mut reader = BufReader::new(stdin.lock());
    let mut writer = stdout.lock();

    while let Ok(Some((raw, framing))) = read_rpc_message(&mut reader) {
        if let Ok(req) = parse_json(&raw) {
            if let Some(resp) = handle_rpc_request(&paths, &req) {
                if write_rpc_message(&mut writer, &resp, framing).is_err() {
                    break;
                }
            }
        }
    }
}
