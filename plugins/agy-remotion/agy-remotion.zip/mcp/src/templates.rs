// templates.rs — Studio-grade Remotion 4.0 React/TypeScript Motion Graphics Templates
#![allow(dead_code)]

pub fn render_tsconfig(engine_dir: &str) -> String {
    format!(
        r#"{{
  "compilerOptions": {{
    "target": "ES2022",
    "module": "ESNext",
    "moduleResolution": "bundler",
    "jsx": "react-jsx",
    "strict": true,
    "esModuleInterop": true,
    "skipLibCheck": true,
    "forceConsistentCasingInFileNames": true,
    "noEmit": true,
    "baseUrl": ".",
    "paths": {{
      "*": ["{engine}/node_modules/*"]
    }}
  }},
  "include": ["src/**/*", "remotion.config.ts"]
}}
"#,
        engine = engine_dir
    )
}

pub fn render_package_json(project_name: &str) -> String {
    format!(
        r#"{{
  "name": "{name}",
  "version": "1.0.0",
  "private": true,
  "description": "Programmatic video built with Remotion Studio Android (agy-remotion)",
  "scripts": {{
    "studio": "agy-remotion studio",
    "render": "agy-remotion render MainPromo out/video.mp4"
  }}
}}
"#,
        name = project_name
    )
}

pub fn render_remotion_config() -> &'static str {
    r#"import { Config } from "@remotion/cli/config";

Config.setVideoImageFormat("jpeg");
Config.setOverwriteOutput(true);
"#
}

pub fn render_index_ts() -> &'static str {
    r#"import { registerRoot } from "remotion";
import { RemotionRoot } from "./Root";

registerRoot(RemotionRoot);
"#
}

pub fn render_root_tsx(
    comp_id: &str,
    component_name: &str,
    import_file: &str,
    width: i64,
    height: i64,
    fps: i64,
    duration_frames: i64,
    title: &str,
    subtitle: &str,
    accent: &str,
) -> String {
    format!(
        r#"import React from "react";
import {{ Composition }} from "remotion";
import {{ {comp_name} }} from "./{import_file}";

export const RemotionRoot: React.FC = () => {{
  return (
    <>
      <Composition
        id="{comp_id}"
        component={{{comp_name}}}
        durationInFrames={{{duration_frames}}}
        fps={{{fps}}}
        width={{{width}}}
        height={{{height}}}
        defaultProps={{{{
          title: {title:?},
          subtitle: {subtitle:?},
          accentColor: {accent:?},
        }}}}
      />
    </>
  );
}};
"#,
        comp_id = comp_id,
        comp_name = component_name,
        import_file = import_file,
        duration_frames = duration_frames,
        fps = fps,
        width = width,
        height = height,
        title = title,
        subtitle = subtitle,
        accent = accent
    )
}

pub fn template_scene(template: &str) -> (&'static str, &'static str, &'static str) {
    match template {
        "viral_reels_9_16" => ("ViralReelScene", "ViralReelScene", VIRAL_REEL_TSX),
        "code_walkthrough" => ("CodeWalkthroughScene", "CodeWalkthroughScene", CODE_WALKTHROUGH_TSX),
        "data_charts" => ("DataChartsScene", "DataChartsScene", DATA_CHARTS_TSX),
        "apple_keynote" => ("AppleKeynoteScene", "AppleKeynoteScene", APPLE_KEYNOTE_TSX),
        _ => ("SaasLaunchScene", "SaasLaunchScene", SAAS_LAUNCH_TSX),
    }
}

const SAAS_LAUNCH_TSX: &str = r###"import React from "react";
import {
  AbsoluteFill,
  Easing,
  interpolate,
  spring,
  useCurrentFrame,
  useVideoConfig,
} from "remotion";

export interface PromoProps {
  title: string;
  subtitle: string;
  accentColor: string;
}

export const SaasLaunchScene: React.FC<PromoProps> = ({
  title,
  subtitle,
  accentColor = "#38BDF8",
}) => {
  const frame = useCurrentFrame();
  const { fps, durationInFrames } = useVideoConfig();

  const heroSpring = spring({
    frame,
    fps,
    config: { damping: 200, stiffness: 130, mass: 0.9 },
  });

  const boardSpring = spring({
    frame: frame - Math.round(0.35 * fps),
    fps,
    config: { damping: 22, stiffness: 160 },
  });

  const cameraDrift = interpolate(frame, [0, durationInFrames], [1, 1.045], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });

  const fadeOut = interpolate(
    frame,
    [durationInFrames - Math.round(0.45 * fps), durationInFrames],
    [1, 0],
    { extrapolateLeft: "clamp", extrapolateRight: "clamp" }
  );

  const metrics = [
    { label: "Render Speed", target: 60, suffix: " FPS", delay: 0.55 },
    { label: "Native ARM64", target: 100, suffix: "%", delay: 0.72 },
    { label: "Setup Time", target: 1.8, suffix: "s", decimals: 1, delay: 0.88 },
  ];

  return (
    <AbsoluteFill
      style={{
        backgroundColor: "#060B19",
        fontFamily: "system-ui, -apple-system, sans-serif",
        color: "#F8FAFC",
        overflow: "hidden",
        opacity: fadeOut,
      }}
    >
      {/* Layered atmospheric glow */}
      <div
        style={{
          position: "absolute",
          inset: -160,
          background: `radial-gradient(circle at 22% 20%, ${accentColor}38 0%, transparent 48%), radial-gradient(circle at 82% 78%, #A855F735 0%, transparent 52%)`,
          transform: `scale(${cameraDrift})`,
        }}
      />

      {/* Subtle architectural grid */}
      <div
        style={{
          position: "absolute",
          inset: 0,
          backgroundImage:
            "linear-gradient(rgba(148,163,184,0.06) 1px, transparent 1px), linear-gradient(90deg, rgba(148,163,184,0.06) 1px, transparent 1px)",
          backgroundSize: "64px 64px",
        }}
      />

      <AbsoluteFill
        style={{
          padding: "84px 110px",
          justifyContent: "space-between",
          transform: `scale(${cameraDrift})`,
        }}
      >
        {/* Top Eyebrow + Headline */}
        <div>
          <div
            style={{
              display: "inline-flex",
              alignItems: "center",
              gap: 12,
              padding: "10px 24px",
              borderRadius: 999,
              background: "rgba(15, 23, 42, 0.78)",
              border: `1px solid ${accentColor}66`,
              marginBottom: 28,
              opacity: heroSpring,
              transform: `translateY(${interpolate(heroSpring, [0, 1], [24, 0])}px)`,
            }}
          >
            <span
              style={{
                width: 11,
                height: 11,
                borderRadius: "50%",
                backgroundColor: accentColor,
                boxShadow: `0 0 16px ${accentColor}`,
              }}
            />
            <span style={{ fontSize: 24, fontWeight: 700, letterSpacing: "0.04em", color: "#E2E8F0" }}>
              REMOTION 4.0 • ANDROID ARM64 STUDIO
            </span>
          </div>

          <h1
            style={{
              fontSize: 88,
              fontWeight: 900,
              letterSpacing: "-0.035em",
              lineHeight: 1.04,
              margin: "0 0 22px 0",
              maxWidth: 1380,
              opacity: heroSpring,
              transform: `translateY(${interpolate(heroSpring, [0, 1], [44, 0])}px)`,
            }}
          >
            {title}
          </h1>

          <p
            style={{
              fontSize: 34,
              fontWeight: 500,
              color: "#94A3B8",
              margin: 0,
              maxWidth: 1120,
              opacity: interpolate(frame, [0.2 * fps, 0.7 * fps], [0, 1], {
                extrapolateLeft: "clamp",
                extrapolateRight: "clamp",
                easing: Easing.out(Easing.cubic),
              }),
            }}
          >
            {subtitle}
          </p>
        </div>

        {/* 3D Glassmorphic Bento Metrics */}
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(3, 1fr)",
            gap: 32,
            transform: `perspective(1400px) rotateX(${interpolate(
              boardSpring,
              [0, 1],
              [16, 0]
            )}deg) translateY(${interpolate(boardSpring, [0, 1], [70, 0])}px)`,
            opacity: boardSpring,
          }}
        >
          {metrics.map((m, idx) => {
            const cardP = spring({
              frame: frame - Math.round(m.delay * fps),
              fps,
              config: { damping: 20, stiffness: 170 },
            });
            const rawVal = m.target * cardP;
            const formatted = m.decimals ? rawVal.toFixed(m.decimals) : Math.round(rawVal).toString();

            return (
              <div
                key={idx}
                style={{
                  padding: "42px 44px",
                  borderRadius: 32,
                  background:
                    "linear-gradient(160deg, rgba(30, 41, 59, 0.78) 0%, rgba(15, 23, 42, 0.88) 100%)",
                  border: "1px solid rgba(148, 163, 184, 0.2)",
                  boxShadow: "0 28px 70px rgba(0, 0, 0, 0.5)",
                  transform: `scale(${interpolate(cardP, [0, 1], [0.9, 1])})`,
                  opacity: cardP,
                }}
              >
                <div style={{ fontSize: 24, fontWeight: 600, color: "#94A3B8", marginBottom: 14 }}>
                  {m.label}
                </div>
                <div
                  style={{
                    fontSize: 74,
                    fontWeight: 900,
                    fontVariantNumeric: "tabular-nums",
                    background: `linear-gradient(120deg, #FFFFFF 25%, ${accentColor} 100%)`,
                    WebkitBackgroundClip: "text",
                    WebkitTextFillColor: "transparent",
                  }}
                >
                  {formatted}
                  {m.suffix}
                </div>
              </div>
            );
          })}
        </div>
      </AbsoluteFill>
    </AbsoluteFill>
  );
};
"###;

const APPLE_KEYNOTE_TSX: &str = r###"import React from "react";
import { AbsoluteFill, interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";

export const AppleKeynoteScene: React.FC<{
  title: string;
  subtitle: string;
  accentColor: string;
}> = ({ title, subtitle, accentColor = "#818CF8" }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const reveal = spring({ frame, fps, config: { damping: 200, stiffness: 110 } });

  return (
    <AbsoluteFill
      style={{
        background: "radial-gradient(circle at 50% 0%, #1E1B4B 0%, #05070F 72%)",
        color: "#FFFFFF",
        fontFamily: "system-ui, sans-serif",
        justifyContent: "center",
        alignItems: "center",
        padding: 100,
        textAlign: "center",
      }}
    >
      <div
        style={{
          transform: `scale(${interpolate(reveal, [0, 1], [0.9, 1])}) translateY(${interpolate(
            reveal,
            [0, 1],
            [40, 0]
          )}px)`,
          opacity: reveal,
        }}
      >
        <div
          style={{
            fontSize: 26,
            fontWeight: 700,
            letterSpacing: "0.18em",
            textTransform: "uppercase",
            color: accentColor,
            marginBottom: 24,
          }}
        >
          KEYNOTE PRESENTATION
        </div>
        <h1 style={{ fontSize: 102, fontWeight: 900, letterSpacing: "-0.04em", margin: "0 0 28px" }}>
          {title}
        </h1>
        <p style={{ fontSize: 38, color: "#94A3B8", maxWidth: 1100, margin: "0 auto" }}>
          {subtitle}
        </p>
      </div>
    </AbsoluteFill>
  );
};
"###;

const VIRAL_REEL_TSX: &str = r###"import React, { useMemo } from "react";
import { AbsoluteFill, Sequence, interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { Caption, createTikTokStyleCaptions } from "@remotion/captions";

const DEFAULT_CAPTIONS: Caption[] = [
  { text: "Programa ", startMs: 0, endMs: 420, timestampMs: 210, confidence: 1 },
  { text: "videos ", startMs: 420, endMs: 820, timestampMs: 620, confidence: 1 },
  { text: "con ", startMs: 820, endMs: 1050, timestampMs: 930, confidence: 1 },
  { text: "React ", startMs: 1050, endMs: 1550, timestampMs: 1300, confidence: 1 },
  { text: "a ", startMs: 1550, endMs: 1720, timestampMs: 1630, confidence: 1 },
  { text: "60 FPS ", startMs: 1720, endMs: 2300, timestampMs: 2000, confidence: 1 },
  { text: "directo ", startMs: 2300, endMs: 2780, timestampMs: 2540, confidence: 1 },
  { text: "en ", startMs: 2780, endMs: 2980, timestampMs: 2880, confidence: 1 },
  { text: "Android!", startMs: 2980, endMs: 3700, timestampMs: 3340, confidence: 1 },
];

export const ViralReelScene: React.FC<{
  title: string;
  subtitle: string;
  accentColor: string;
  captions?: Caption[];
}> = ({ title, subtitle, accentColor = "#38BDF8", captions = DEFAULT_CAPTIONS }) => {
  const frame = useCurrentFrame();
  const { fps, durationInFrames } = useVideoConfig();
  const heroPop = spring({ frame, fps, config: { damping: 15, stiffness: 210 } });

  const { pages } = useMemo(
    () => createTikTokStyleCaptions({ captions, combineTokensWithinMilliseconds: 1200 }),
    [captions]
  );

  const progressPct = interpolate(frame, [0, durationInFrames], [0, 100], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });

  return (
    <AbsoluteFill
      style={{
        background: "linear-gradient(180deg, #090D1E 0%, #131B3A 55%, #090D1E 100%)",
        color: "#FFFFFF",
        fontFamily: "system-ui, sans-serif",
      }}
    >
      <AbsoluteFill style={{ justifyContent: "center", alignItems: "center", padding: "0 72px" }}>
        <div
          style={{
            transform: `scale(${interpolate(heroPop, [0, 1], [0.85, 1])})`,
            opacity: heroPop,
            textAlign: "center",
            marginBottom: 240,
          }}
        >
          <h1 style={{ fontSize: 82, fontWeight: 900, lineHeight: 1.06, margin: "0 0 24px" }}>
            {title}
          </h1>
          <p style={{ fontSize: 38, color: "#94A3B8", margin: 0 }}>{subtitle}</p>
        </div>
      </AbsoluteFill>

      {pages.map((page, i) => {
        const next = pages[i + 1] ?? null;
        const startFrame = Math.round((page.startMs / 1000) * fps);
        const endFrame = Math.round(((next ? next.startMs : page.startMs + 1800) / 1000) * fps);
        const dur = Math.max(1, endFrame - startFrame);
        return (
          <Sequence key={i} from={startFrame} durationInFrames={dur}>
            <CaptionPill page={page} accentColor={accentColor} />
          </Sequence>
        );
      })}

      {/* Bottom progress bar */}
      <div style={{ position: "absolute", bottom: 0, left: 0, right: 0, height: 14, background: "#1E293B" }}>
        <div style={{ width: `${progressPct}%`, height: "100%", background: accentColor }} />
      </div>
    </AbsoluteFill>
  );
};

const CaptionPill: React.FC<{
  page: ReturnType<typeof createTikTokStyleCaptions>["pages"][number];
  accentColor: string;
}> = ({ page, accentColor }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const nowMs = page.startMs + (frame / fps) * 1000;
  const pop = spring({ frame, fps, config: { damping: 14, stiffness: 250 } });

  return (
    <AbsoluteFill style={{ justifyContent: "flex-end", alignItems: "center", paddingBottom: 290 }}>
      <div
        style={{
          transform: `scale(${0.9 + 0.1 * pop})`,
          display: "flex",
          flexWrap: "wrap",
          justifyContent: "center",
          gap: "12px 16px",
          maxWidth: 920,
          padding: "26px 36px",
          borderRadius: 32,
          background: "rgba(9, 13, 28, 0.84)",
          border: "1px solid rgba(255,255,255,0.16)",
        }}
      >
        {page.tokens.map((t, idx) => {
          const active = t.fromMs <= nowMs && nowMs < t.toMs;
          return (
            <span
              key={idx}
              style={{
                fontSize: 58,
                fontWeight: 900,
                padding: "4px 14px",
                borderRadius: 16,
                background: active ? accentColor : "transparent",
                color: active ? "#06101F" : "#FFFFFF",
              }}
            >
              {t.text.trim()}
            </span>
          );
        })}
      </div>
    </AbsoluteFill>
  );
};
"###;

const CODE_WALKTHROUGH_TSX: &str = r###"import React from "react";
import { AbsoluteFill, interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";

const CODE_SNIPPET = `import { spring, useCurrentFrame, useVideoConfig } from "remotion";

export const MotionCard = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const scale = spring({ frame, fps, config: { damping: 200 } });
  return <div style={{ transform: \`scale(\${scale})\` }}>60 FPS Ready</div>;
};`;

export const CodeWalkthroughScene: React.FC<{
  title: string;
  subtitle: string;
  accentColor: string;
}> = ({ title, subtitle, accentColor = "#38BDF8" }) => {
  const frame = useCurrentFrame();
  const { fps, durationInFrames } = useVideoConfig();
  const winPop = spring({ frame, fps, config: { damping: 200, stiffness: 130 } });
  const typedCount = Math.floor(
    interpolate(frame, [Math.round(0.3 * fps), Math.round(durationInFrames * 0.78)], [0, CODE_SNIPPET.length], {
      extrapolateLeft: "clamp",
      extrapolateRight: "clamp",
    })
  );
  const cursorOn = Math.floor(frame / Math.max(1, Math.round(fps * 0.35))) % 2 === 0;

  return (
    <AbsoluteFill
      style={{
        background: "#070B16",
        color: "#F8FAFC",
        fontFamily: "system-ui, sans-serif",
        padding: "76px 110px",
        justifyContent: "space-between",
      }}
    >
      <div>
        <h1 style={{ fontSize: 68, fontWeight: 900, margin: "0 0 12px" }}>{title}</h1>
        <p style={{ fontSize: 30, color: "#94A3B8", margin: 0 }}>{subtitle}</p>
      </div>

      <div
        style={{
          borderRadius: 28,
          background: "#0F172A",
          border: `1px solid ${accentColor}55`,
          boxShadow: "0 30px 90px rgba(0,0,0,0.65)",
          padding: "34px 42px",
          transform: `translateY(${interpolate(winPop, [0, 1], [50, 0])}px)`,
          opacity: winPop,
        }}
      >
        <div style={{ display: "flex", gap: 12, marginBottom: 26 }}>
          <span style={{ width: 16, height: 16, borderRadius: "50%", background: "#EF4444" }} />
          <span style={{ width: 16, height: 16, borderRadius: "50%", background: "#F59E0B" }} />
          <span style={{ width: 16, height: 16, borderRadius: "50%", background: "#10B981" }} />
        </div>
        <pre
          style={{
            fontFamily: "monospace",
            fontSize: 30,
            lineHeight: 1.55,
            color: "#E2E8F0",
            margin: 0,
            whiteSpace: "pre-wrap",
          }}
        >
          {CODE_SNIPPET.slice(0, typedCount)}
          <span style={{ opacity: cursorOn ? 1 : 0, color: accentColor }}>▋</span>
        </pre>
      </div>
    </AbsoluteFill>
  );
};
"###;

const DATA_CHARTS_TSX: &str = r###"import React from "react";
import { AbsoluteFill, spring, useCurrentFrame, useVideoConfig } from "remotion";

export const DataChartsScene: React.FC<{
  title: string;
  subtitle: string;
  accentColor: string;
}> = ({ title, subtitle, accentColor = "#38BDF8" }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const bars = [
    { name: "Q1", value: 42 },
    { name: "Q2", value: 64 },
    { name: "Q3", value: 81 },
    { name: "Q4", value: 98 },
  ];

  return (
    <AbsoluteFill
      style={{
        background: "#060B18",
        color: "#F8FAFC",
        fontFamily: "system-ui, sans-serif",
        padding: "84px 120px",
        justifyContent: "space-between",
      }}
    >
      <div>
        <h1 style={{ fontSize: 74, fontWeight: 900, margin: "0 0 14px" }}>{title}</h1>
        <p style={{ fontSize: 32, color: "#94A3B8", margin: 0 }}>{subtitle}</p>
      </div>

      <div style={{ display: "flex", alignItems: "flex-end", gap: 48, height: 540, paddingBottom: 24 }}>
        {bars.map((b, idx) => {
          const p = spring({
            frame: frame - idx * Math.round(0.14 * fps),
            fps,
            config: { damping: 18, stiffness: 160 },
          });
          return (
            <div key={b.name} style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center" }}>
              <div style={{ fontSize: 42, fontWeight: 800, marginBottom: 16, fontVariantNumeric: "tabular-nums" }}>
                {Math.round(b.value * p)}%
              </div>
              <div
                style={{
                  width: "100%",
                  height: Math.max(12, 420 * (b.value / 100) * p),
                  borderRadius: "24px 24px 10px 10px",
                  background: `linear-gradient(180deg, ${accentColor} 0%, #6366F1 100%)`,
                }}
              />
              <div style={{ fontSize: 28, fontWeight: 700, color: "#94A3B8", marginTop: 18 }}>{b.name}</div>
            </div>
          );
        })}
      </div>
    </AbsoluteFill>
  );
};
"###;
