// android-preload.cjs — Native Android ARM64 Bionic <-> Remotion 4.0 Bridge
// Loaded via NODE_OPTIONS="--require .../android-preload.cjs"
"use strict";

const fs = require("fs");
const os = require("os");
const path = require("path");
const Module = require("module");
const cp = require("child_process");

const HOME = process.env.HOME || "/data/user/0/com.agy/files";
const PREFIX = process.env.PREFIX || path.join(HOME, "usr");
const ENGINE_DIR = process.env.AGY_REMOTION_ENGINE || path.join(PREFIX, "opt", "remotion-engine");
const ENGINE_MODULES = path.join(ENGINE_DIR, "node_modules");
const TMP_DIR = process.env.TMPDIR || path.join(PREFIX, "tmp");

try {
  fs.mkdirSync(TMP_DIR, { recursive: true });
} catch (_) {}

process.env.TMPDIR = TMP_DIR;
process.env.TMP = TMP_DIR;
process.env.TEMP = TMP_DIR;

// 1. Preserve native Android ARM64 esbuild binary BEFORE spoofing process.platform -> 'linux'
const androidEsbuild = path.join(ENGINE_MODULES, "@esbuild", "android-arm64", "bin", "esbuild");
if (!process.env.ESBUILD_BINARY_PATH && fs.existsSync(androidEsbuild)) {
  process.env.ESBUILD_BINARY_PATH = androidEsbuild;
}

// 2. Inject shared $PREFIX/opt/remotion-engine/node_modules so /sdcard projects need 0 local binaries
if (fs.existsSync(ENGINE_MODULES)) {
  const existing = (process.env.NODE_PATH || "").split(path.delimiter).filter(Boolean);
  if (!existing.includes(ENGINE_MODULES)) {
    existing.push(ENGINE_MODULES);
    process.env.NODE_PATH = existing.join(path.delimiter);
    Module._initPaths();
  }
}

// 3. Point Remotion to AGY's native ARM64 Chromium wrapper
const agyChrome = path.join(HOME, "runtime", "bin", "chrome");
const usrChromium = path.join(PREFIX, "bin", "chromium");
const usrChromiumBrowser = path.join(PREFIX, "bin", "chromium-browser");
const browserBin = fs.existsSync(agyChrome)
  ? agyChrome
  : fs.existsSync(usrChromium)
  ? usrChromium
  : fs.existsSync(usrChromiumBrowser)
  ? usrChromiumBrowser
  : "";

if (browserBin && !process.env.REMOTION_CHROME_EXECUTABLE) {
  process.env.REMOTION_CHROME_EXECUTABLE = browserBin;
  process.env.PUPPETEER_EXECUTABLE_PATH = browserBin;
  process.env.CHROME_PATH = browserBin;
}

// 4. Spoof process.platform === 'android' -> 'linux' so @remotion/renderer & @remotion/cli unlock ARM64 paths
if (process.platform === "android") {
  Object.defineProperty(process, "platform", {
    value: "linux",
    writable: false,
    enumerable: true,
    configurable: true,
  });
  os.platform = () => "linux";
}

// 5. Intercept Chromium spawns so headless-shell downloads or missing sandbox flags never crash on Android SELinux
const origSpawn = cp.spawn;
cp.spawn = function patchedSpawn(command, args, options) {
  let cmd = command;
  let argv = Array.isArray(args) ? args.slice() : [];
  let opts = Array.isArray(args) ? options : args;

  if (typeof cmd === "string") {
    const base = path.basename(cmd);
    const looksLikeBrowser =
      base === "chrome" ||
      base === "chromium" ||
      base === "chromium-browser" ||
      base === "chrome-headless-shell" ||
      cmd.includes("chrome-headless-shell");

    if (looksLikeBrowser && browserBin) {
      cmd = browserBin;
      const requiredFlags = [
        "--no-sandbox",
        "--disable-setuid-sandbox",
        "--disable-dev-shm-usage",
        "--disable-gpu",
      ];
      for (const flag of requiredFlags) {
        if (!argv.includes(flag)) {
          argv.unshift(flag);
        }
      }
    }
  }

  if (Array.isArray(args)) {
    return origSpawn.call(this, cmd, argv, opts);
  }
  return origSpawn.call(this, cmd, opts);
};
