// engine-driver.mjs — Remotion 4.0 Android ARM64 Driver (v1.0.1)
// Guarantees ZERO multi-tab tiling/flicker by enforcing concurrency=1 per isolated Chromium process,
// scaling across multiple CPU cores via isolated single-tab worker processes + lossless FFmpeg concat.
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { execFileSync, spawn } from "node:child_process";
import { createRequire } from "node:module";

const HOME = process.env.HOME || "/data/user/0/com.agy/files";
const PREFIX = process.env.PREFIX || path.join(HOME, "usr");
const ENGINE_DIR = process.env.AGY_REMOTION_ENGINE || path.join(PREFIX, "opt", "remotion-engine");
const SELF_PATH = new URL(import.meta.url).pathname;

const requireFromEngine = createRequire(path.join(ENGINE_DIR, "package.json"));

const browserExecutable =
  process.env.REMOTION_CHROME_EXECUTABLE ||
  (fs.existsSync(path.join(HOME, "runtime", "bin", "chrome"))
    ? path.join(HOME, "runtime", "bin", "chrome")
    : fs.existsSync(path.join(PREFIX, "bin", "chromium"))
    ? path.join(PREFIX, "bin", "chromium")
    : path.join(PREFIX, "bin", "chromium-browser"));

const chromeMode = "chrome-for-testing";
const chromiumOptions = {
  enableMultiProcessOnLinux: true,
  disableWebSecurity: false,
};

// Mode 1: Isolated Webpack bundler child (`--bundle-only <entry> <publicDir>`)
if (process.argv[2] === "--bundle-only") {
  const entry = process.argv[3];
  const publicDir = process.argv[4] || "";
  const engineModules = path.join(ENGINE_DIR, "node_modules");
  const { bundle } = requireFromEngine("@remotion/bundler");
  const serveUrl = await bundle({
    entryPoint: entry,
    enableCaching: false,
    publicDir: publicDir && fs.existsSync(publicDir) ? publicDir : null,
    webpackOverride: (currentConfig) => {
      const resolve = currentConfig.resolve || {};
      const modules = Array.isArray(resolve.modules)
        ? [...resolve.modules, engineModules]
        : ["node_modules", engineModules];
      return {
        ...currentConfig,
        cache: false,
        resolve: { ...resolve, modules },
        resolveLoader: {
          ...(currentConfig.resolveLoader || {}),
          modules: ["node_modules", engineModules],
        },
      };
    },
  });
  process.stdout.write(`BUNDLE_PATH=${serveUrl}\n`);
  process.exit(0);
}

// Mode 2: Isolated Single-Tab Chunk Worker (`--render-chunk <json>`)
if (process.argv[2] === "--render-chunk") {
  const cfg = JSON.parse(process.argv[3]);
  const { renderMedia } = requireFromEngine("@remotion/renderer");
  let lastPct = -20;
  await renderMedia({
    composition: cfg.composition,
    serveUrl: cfg.serveUrl,
    codec: cfg.codec,
    outputLocation: cfg.output,
    inputProps: cfg.inputProps || {},
    concurrency: 1, // CRITICAL: strictly 1 tab per Chromium process = 0% surface race / 0% tiling!
    scale: cfg.scale || 1,
    crf: cfg.crf,
    frameRange: cfg.frameRange,
    muted: Boolean(cfg.muted),
    browserExecutable,
    chromeMode,
    chromiumOptions,
    onProgress: ({ progress, renderedFrames }) => {
      const pct = Math.floor(progress * 100);
      if (pct >= lastPct + 20) {
        lastPct = pct;
        process.stderr.write(`[Worker ${cfg.workerId}] ${pct}% (rendered=${renderedFrames})\n`);
      }
    },
  });
  process.exit(0);
}

const { getCompositions, renderMedia, renderStill, selectComposition } =
  requireFromEngine("@remotion/renderer");

function resolveEntryPoint(projectDir, explicitEntry) {
  if (explicitEntry) {
    return path.isAbsolute(explicitEntry)
      ? explicitEntry
      : path.join(projectDir, explicitEntry);
  }
  for (const rel of ["src/index.ts", "src/index.tsx", "src/index.js", "index.ts", "index.tsx"]) {
    const full = path.join(projectDir, rel);
    if (fs.existsSync(full)) return full;
  }
  throw new Error(`No Remotion entry point found in ${projectDir}`);
}

function createProjectBundleIsolated(projectDir, entryPoint) {
  const entry = resolveEntryPoint(projectDir, entryPoint);
  const publicDir = path.join(projectDir, "public");
  const out = execFileSync(
    process.execPath,
    [SELF_PATH, "--bundle-only", entry, fs.existsSync(publicDir) ? publicDir : ""],
    { encoding: "utf8", maxBuffer: 32 * 1024 * 1024 }
  );
  const match = out.split(/\r?\n/).find((l) => l.startsWith("BUNDLE_PATH="));
  if (!match) {
    throw new Error(`Isolated bundler did not return BUNDLE_PATH: ${out}`);
  }
  return match.slice("BUNDLE_PATH=".length).trim();
}

function spawnChunkWorker(workerCfg) {
  return new Promise((resolve, reject) => {
    const child = spawn(process.execPath, [SELF_PATH, "--render-chunk", JSON.stringify(workerCfg)], {
      stdio: ["ignore", "inherit", "inherit"],
      env: process.env,
    });
    child.on("error", reject);
    child.on("exit", (code) => {
      if (code === 0) resolve();
      else reject(new Error(`Chunk worker ${workerCfg.workerId} exited with code ${code}`));
    });
  });
}

async function main() {
  const rawPayload = process.argv[2];
  if (!rawPayload) {
    throw new Error("Missing JSON command payload in argv[2]");
  }
  const cmd = JSON.parse(rawPayload);
  const action = cmd.action;
  const projectDir = path.resolve(cmd.project_dir || process.cwd());
  const inputProps = cmd.props || {};

  const startedAt = Date.now();
  const serveUrl = cmd.prebuilt_bundle || createProjectBundleIsolated(projectDir, cmd.entry_point);

  try {
    if (action === "list") {
      const comps = await getCompositions(serveUrl, {
        inputProps,
        browserExecutable,
        chromeMode,
        chromiumOptions,
      });
      process.stdout.write(
        JSON.stringify({
          ok: true,
          project_dir: projectDir,
          elapsed_ms: Date.now() - startedAt,
          compositions: comps.map((c) => ({
            id: c.id,
            width: c.width,
            height: c.height,
            fps: c.fps,
            durationInFrames: c.durationInFrames,
            durationSeconds: Number((c.durationInFrames / c.fps).toFixed(2)),
            defaultProps: c.defaultProps || {},
          })),
        }) + "\n"
      );
      return;
    }

    const compositionId = cmd.composition_id;
    if (!compositionId) {
      throw new Error("composition_id is required");
    }

    const composition = await selectComposition({
      serveUrl,
      id: compositionId,
      inputProps,
      browserExecutable,
      chromeMode,
      chromiumOptions,
    });

    if (action === "still") {
      const outputPath = path.resolve(cmd.output_path);
      fs.mkdirSync(path.dirname(outputPath), { recursive: true });
      const frame = Math.max(
        0,
        Math.min(
          composition.durationInFrames - 1,
          Number.isFinite(cmd.frame) ? Math.floor(cmd.frame) : 0
        )
      );
      const imageFormat =
        outputPath.toLowerCase().endsWith(".jpg") || outputPath.toLowerCase().endsWith(".jpeg")
          ? "jpeg"
          : "png";

      await renderStill({
        composition,
        serveUrl,
        output: outputPath,
        frame,
        imageFormat,
        scale: cmd.scale || 1,
        inputProps,
        browserExecutable,
        chromeMode,
        chromiumOptions,
      });

      const stat = fs.statSync(outputPath);
      process.stdout.write(
        JSON.stringify({
          ok: true,
          output_path: outputPath,
          size_bytes: stat.size,
          frame,
          width: composition.width,
          height: composition.height,
          elapsed_ms: Date.now() - startedAt,
        }) + "\n"
      );
      return;
    }

    if (action === "render") {
      const outputPath = path.resolve(cmd.output_path);
      fs.mkdirSync(path.dirname(outputPath), { recursive: true });
      const codec =
        cmd.codec ||
        (outputPath.endsWith(".webm") ? "vp8" : outputPath.endsWith(".gif") ? "gif" : "h264");

      const [rStart, rEnd] = cmd.frame_range || [0, composition.durationInFrames - 1];
      const totalFrames = rEnd - rStart + 1;
      const requestedWorkers = Math.min(2, Math.max(1, cmd.concurrency || 2));
      const workers = codec === "h264" && totalFrames >= 120 ? requestedWorkers : 1;

      if (workers === 1) {
        await renderMedia({
          composition,
          serveUrl,
          codec,
          outputLocation: outputPath,
          inputProps,
          concurrency: 1,
          scale: cmd.scale || 1,
          crf: cmd.crf,
          frameRange: [rStart, rEnd],
          muted: Boolean(cmd.muted),
          browserExecutable,
          chromeMode,
          chromiumOptions,
        });
      } else {
        // Multi-process single-tab parallel render: each worker has its own isolated Chrome (1 tab = 0% tiling/flicker!)
        const workTmp = fs.mkdtempSync(path.join(os.tmpdir(), "remotion-mp-chunks-"));
        try {
          const chunkFiles = [];
          const promises = [];
          const perWorker = Math.ceil(totalFrames / workers);

          for (let w = 0; w < workers; w++) {
            const cStart = rStart + w * perWorker;
            const cEnd = Math.min(rEnd, cStart + perWorker - 1);
            if (cStart > rEnd) break;
            const chunkPath = path.join(workTmp, `chunk_${w}.mp4`);
            chunkFiles.push(chunkPath);
            promises.push(
              spawnChunkWorker({
                workerId: w,
                composition,
                serveUrl,
                codec,
                output: chunkPath,
                inputProps,
                scale: cmd.scale || 1,
                crf: cmd.crf || 18,
                frameRange: [cStart, cEnd],
                muted: true,
              })
            );
          }

          // Render exact composition audio track in parallel if not muted
          const audioPath = path.join(workTmp, "full_audio.aac");
          if (!cmd.muted) {
            promises.push(
              renderMedia({
                composition,
                serveUrl,
                codec: "aac",
                outputLocation: audioPath,
                inputProps,
                frameRange: [rStart, rEnd],
                browserExecutable,
                chromeMode,
                chromiumOptions,
              }).catch(() => {})
            );
          }

          await Promise.all(promises);

          const listPath = path.join(workTmp, "concat.txt");
          fs.writeFileSync(
            listPath,
            chunkFiles.map((f) => `file '${f.replace(/'/g, "'\\''")}'`).join("\n") + "\n"
          );

          const ffmpegBin = path.join(PREFIX, "bin", "ffmpeg");
          const ffArgs = ["-y", "-f", "concat", "-safe", "0", "-i", listPath];
          if (!cmd.muted && fs.existsSync(audioPath) && fs.statSync(audioPath).size > 0) {
            ffArgs.push("-i", audioPath, "-c:v", "copy", "-c:a", "copy", "-movflags", "+faststart", outputPath);
          } else {
            ffArgs.push("-c:v", "copy", "-movflags", "+faststart", outputPath);
          }
          execFileSync(ffmpegBin, ffArgs, { stdio: "ignore" });
        } finally {
          fs.rmSync(workTmp, { recursive: true, force: true });
        }
      }

      const stat = fs.statSync(outputPath);
      process.stdout.write(
        JSON.stringify({
          ok: true,
          output_path: outputPath,
          size_bytes: stat.size,
          composition_id: composition.id,
          width: composition.width,
          height: composition.height,
          fps: composition.fps,
          duration_frames: composition.durationInFrames,
          duration_sec: Number((composition.durationInFrames / composition.fps).toFixed(2)),
          workers,
          codec,
          elapsed_ms: Date.now() - startedAt,
        }) + "\n"
      );
      return;
    }

    throw new Error(`Unsupported driver action: ${action}`);
  } finally {
    if (!cmd.prebuilt_bundle) {
      try {
        fs.rmSync(serveUrl, { recursive: true, force: true });
      } catch (_) {}
    }
  }
}

main().catch((err) => {
  process.stderr.write((err && err.stack ? err.stack : String(err)) + "\n");
  process.exit(1);
});
