// engine-driver.mjs — Programmatic Remotion 4.0 Driver for Android ARM64
// Runs Webpack bundle() in an isolated child process that exits before Chromium starts,
// freeing ~800 MB of bundler heap on mobile RAM!
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { execFileSync } from "node:child_process";
import { createRequire } from "node:module";

const HOME = process.env.HOME || "/data/user/0/com.agy/files";
const PREFIX = process.env.PREFIX || path.join(HOME, "usr");
const ENGINE_DIR = process.env.AGY_REMOTION_ENGINE || path.join(PREFIX, "opt", "remotion-engine");

const requireFromEngine = createRequire(path.join(ENGINE_DIR, "package.json"));

// Sub-mode: isolated bundler child process (`node engine-driver.mjs --bundle-only <entry> <publicDir>`)
if (process.argv[2] === "--bundle-only") {
  const entry = process.argv[3];
  const publicDir = process.argv[4] || "";
  const engineModules = path.join(ENGINE_DIR, "node_modules");
  const { bundle } = requireFromEngine("@remotion/bundler");
  const serveUrl = await bundle({
    entryPoint: entry,
    enableCaching: false,
    publicDir: publicDir && fs.existsSync(publicDir) ? publicDir : null,
    webpackOverride: (currentConfig) => {
      const resolve = currentConfig.resolve || {};
      const modules = Array.isArray(resolve.modules)
        ? [...resolve.modules, engineModules]
        : ["node_modules", engineModules];
      return {
        ...currentConfig,
        cache: false,
        resolve: { ...resolve, modules },
        resolveLoader: {
          ...(currentConfig.resolveLoader || {}),
          modules: ["node_modules", engineModules],
        },
      };
    },
  });
  process.stdout.write(`BUNDLE_PATH=${serveUrl}\n`);
  process.exit(0);
}

const { getCompositions, openBrowser, renderMedia, renderStill, selectComposition } =
  requireFromEngine("@remotion/renderer");

const browserExecutable =
  process.env.REMOTION_CHROME_EXECUTABLE ||
  (fs.existsSync(path.join(HOME, "runtime", "bin", "chrome"))
    ? path.join(HOME, "runtime", "bin", "chrome")
    : fs.existsSync(path.join(PREFIX, "bin", "chromium"))
    ? path.join(PREFIX, "bin", "chromium")
    : path.join(PREFIX, "bin", "chromium-browser"));

const chromeMode = "chrome-for-testing";

const chromiumOptions = {
  enableMultiProcessOnLinux: true,
  disableWebSecurity: false,
};

function resolveEntryPoint(projectDir, explicitEntry) {
  if (explicitEntry) {
    return path.isAbsolute(explicitEntry)
      ? explicitEntry
      : path.join(projectDir, explicitEntry);
  }
  for (const rel of ["src/index.ts", "src/index.tsx", "src/index.js", "index.ts", "index.tsx"]) {
    const full = path.join(projectDir, rel);
    if (fs.existsSync(full)) return full;
  }
  throw new Error(`No Remotion entry point found in ${projectDir}`);
}

function createProjectBundleIsolated(projectDir, entryPoint) {
  const entry = resolveEntryPoint(projectDir, entryPoint);
  const publicDir = path.join(projectDir, "public");
  const out = execFileSync(
    process.execPath,
    [
      new URL(import.meta.url).pathname,
      "--bundle-only",
      entry,
      fs.existsSync(publicDir) ? publicDir : "",
    ],
    { encoding: "utf8", maxBuffer: 32 * 1024 * 1024 }
  );
  const match = out.split(/\r?\n/).find((l) => l.startsWith("BUNDLE_PATH="));
  if (!match) {
    throw new Error(`Isolated bundler did not return BUNDLE_PATH: ${out}`);
  }
  return match.slice("BUNDLE_PATH=".length).trim();
}

async function main() {
  const rawPayload = process.argv[2];
  if (!rawPayload) {
    throw new Error("Missing JSON command payload in argv[2]");
  }
  const cmd = JSON.parse(rawPayload);
  const action = cmd.action;
  const projectDir = path.resolve(cmd.project_dir || process.cwd());
  const inputProps = cmd.props || {};

  const startedAt = Date.now();
  const serveUrl = createProjectBundleIsolated(projectDir, cmd.entry_point);

  const puppeteerInstance = await openBrowser("chrome", {
    browserExecutable,
    chromeMode,
    chromiumOptions,
  });

  try {
    if (action === "list") {
      const comps = await getCompositions(serveUrl, {
        inputProps,
        puppeteerInstance,
      });
      process.stdout.write(
        JSON.stringify({
          ok: true,
          project_dir: projectDir,
          elapsed_ms: Date.now() - startedAt,
          compositions: comps.map((c) => ({
            id: c.id,
            width: c.width,
            height: c.height,
            fps: c.fps,
            durationInFrames: c.durationInFrames,
            durationSeconds: Number((c.durationInFrames / c.fps).toFixed(2)),
            defaultProps: c.defaultProps || {},
          })),
        }) + "\n"
      );
      return;
    }

    const compositionId = cmd.composition_id;
    if (!compositionId) {
      throw new Error("composition_id is required");
    }

    const composition = await selectComposition({
      serveUrl,
      id: compositionId,
      inputProps,
      puppeteerInstance,
    });

    if (action === "still") {
      const outputPath = path.resolve(cmd.output_path);
      fs.mkdirSync(path.dirname(outputPath), { recursive: true });
      const frame = Math.max(
        0,
        Math.min(
          composition.durationInFrames - 1,
          Number.isFinite(cmd.frame) ? Math.floor(cmd.frame) : 0
        )
      );
      const imageFormat =
        outputPath.toLowerCase().endsWith(".jpg") || outputPath.toLowerCase().endsWith(".jpeg")
          ? "jpeg"
          : "png";

      await renderStill({
        composition,
        serveUrl,
        puppeteerInstance,
        output: outputPath,
        frame,
        imageFormat,
        scale: cmd.scale || 1,
        inputProps,
      });

      const stat = fs.statSync(outputPath);
      process.stdout.write(
        JSON.stringify({
          ok: true,
          output_path: outputPath,
          size_bytes: stat.size,
          frame,
          width: composition.width,
          height: composition.height,
          elapsed_ms: Date.now() - startedAt,
        }) + "\n"
      );
      return;
    }

    if (action === "render") {
      const outputPath = path.resolve(cmd.output_path);
      fs.mkdirSync(path.dirname(outputPath), { recursive: true });
      const concurrency = cmd.concurrency || 2;
      const codec =
        cmd.codec ||
        (outputPath.endsWith(".webm") ? "vp8" : outputPath.endsWith(".gif") ? "gif" : "h264");

      await renderMedia({
        composition,
        serveUrl,
        puppeteerInstance,
        codec,
        outputLocation: outputPath,
        inputProps,
        concurrency,
        scale: cmd.scale || 1,
        crf: cmd.crf,
        frameRange: cmd.frame_range || null,
        muted: Boolean(cmd.muted),
      });

      const stat = fs.statSync(outputPath);
      process.stdout.write(
        JSON.stringify({
          ok: true,
          output_path: outputPath,
          size_bytes: stat.size,
          composition_id: composition.id,
          width: composition.width,
          height: composition.height,
          fps: composition.fps,
          duration_frames: composition.durationInFrames,
          duration_sec: Number((composition.durationInFrames / composition.fps).toFixed(2)),
          concurrency,
          codec,
          elapsed_ms: Date.now() - startedAt,
        }) + "\n"
      );
      return;
    }

    throw new Error(`Unsupported driver action: ${action}`);
  } finally {
    await puppeteerInstance.close({ silent: true });
    try {
      fs.rmSync(serveUrl, { recursive: true, force: true });
    } catch (_) {}
  }
}

main().catch((err) => {
  process.stderr.write((err && err.stack ? err.stack : String(err)) + "\n");
  process.exit(1);
});
