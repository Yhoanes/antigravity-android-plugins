// engine-driver.mjs — Programmatic Remotion 4.0 Driver for Android ARM64
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { createRequire } from "node:module";

const HOME = process.env.HOME || "/data/user/0/com.agy/files";
const PREFIX = process.env.PREFIX || path.join(HOME, "usr");
const ENGINE_DIR = process.env.AGY_REMOTION_ENGINE || path.join(PREFIX, "opt", "remotion-engine");

const requireFromEngine = createRequire(path.join(ENGINE_DIR, "package.json"));
const { bundle } = requireFromEngine("@remotion/bundler");
const { getCompositions, renderMedia, renderStill, selectComposition } =
  requireFromEngine("@remotion/renderer");

const browserExecutable =
  process.env.REMOTION_CHROME_EXECUTABLE ||
  (fs.existsSync(path.join(HOME, "runtime", "bin", "chrome"))
    ? path.join(HOME, "runtime", "bin", "chrome")
    : fs.existsSync(path.join(PREFIX, "bin", "chromium"))
    ? path.join(PREFIX, "bin", "chromium")
    : path.join(PREFIX, "bin", "chromium-browser"));

const chromeMode = "chrome-for-testing";

const chromiumOptions = {
  enableMultiProcessOnLinux: true,
  disableWebSecurity: false,
};

function resolveEntryPoint(projectDir, explicitEntry) {
  if (explicitEntry) {
    return path.isAbsolute(explicitEntry)
      ? explicitEntry
      : path.join(projectDir, explicitEntry);
  }
  const candidates = [
    "src/index.ts",
    "src/index.tsx",
    "src/index.js",
    "index.ts",
    "index.tsx",
  ];
  for (const rel of candidates) {
    const full = path.join(projectDir, rel);
    if (fs.existsSync(full)) return full;
  }
  throw new Error(
    `No Remotion entry point found in ${projectDir} (expected src/index.ts or src/index.tsx)`
  );
}

async function createProjectBundle(projectDir, entryPoint) {
  const entry = resolveEntryPoint(projectDir, entryPoint);
  const publicDir = path.join(projectDir, "public");
  const engineModules = path.join(ENGINE_DIR, "node_modules");

  return await bundle({
    entryPoint: entry,
    enableCaching: false,
    publicDir: fs.existsSync(publicDir) ? publicDir : null,
    webpackOverride: (currentConfig) => {
      const resolve = currentConfig.resolve || {};
      const modules = Array.isArray(resolve.modules)
        ? [...resolve.modules, engineModules]
        : ["node_modules", engineModules];
      return {
        ...currentConfig,
        cache: false,
        resolve: {
          ...resolve,
          modules,
        },
        resolveLoader: {
          ...(currentConfig.resolveLoader || {}),
          modules: ["node_modules", engineModules],
        },
      };
    },
  });
}

async function main() {
  const rawPayload = process.argv[2];
  if (!rawPayload) {
    throw new Error("Missing JSON command payload in argv[2]");
  }
  const cmd = JSON.parse(rawPayload);
  const action = cmd.action;
  const projectDir = path.resolve(cmd.project_dir || process.cwd());
  const inputProps = cmd.props || {};

  const startedAt = Date.now();
  const serveUrl = await createProjectBundle(projectDir, cmd.entry_point);

  if (action === "list") {
    const comps = await getCompositions(serveUrl, {
      inputProps,
      browserExecutable,
      chromeMode,
      chromiumOptions,
    });
    process.stdout.write(
      JSON.stringify({
        ok: true,
        project_dir: projectDir,
        elapsed_ms: Date.now() - startedAt,
        compositions: comps.map((c) => ({
          id: c.id,
          width: c.width,
          height: c.height,
          fps: c.fps,
          durationInFrames: c.durationInFrames,
          durationSeconds: Number((c.durationInFrames / c.fps).toFixed(2)),
          defaultProps: c.defaultProps || {},
        })),
      }) + "\n"
    );
    return;
  }

  const compositionId = cmd.composition_id;
  if (!compositionId) {
    throw new Error("composition_id is required");
  }

  const composition = await selectComposition({
    serveUrl,
    id: compositionId,
    inputProps,
    browserExecutable,
    chromeMode,
    chromiumOptions,
  });

  if (action === "still") {
    const outputPath = path.resolve(cmd.output_path);
    fs.mkdirSync(path.dirname(outputPath), { recursive: true });
    const frame = Math.max(
      0,
      Math.min(
        composition.durationInFrames - 1,
        Number.isFinite(cmd.frame) ? Math.floor(cmd.frame) : 0
      )
    );
    const imageFormat = outputPath.toLowerCase().endsWith(".jpg") ||
      outputPath.toLowerCase().endsWith(".jpeg")
      ? "jpeg"
      : "png";

    await renderStill({
      composition,
      serveUrl,
      output: outputPath,
      frame,
      imageFormat,
      scale: cmd.scale || 1,
      inputProps,
      browserExecutable,
      chromeMode,
      chromiumOptions,
    });

    const stat = fs.statSync(outputPath);
    process.stdout.write(
      JSON.stringify({
        ok: true,
        output_path: outputPath,
        size_bytes: stat.size,
        frame,
        width: composition.width,
        height: composition.height,
        elapsed_ms: Date.now() - startedAt,
      }) + "\n"
    );
    return;
  }

  if (action === "render") {
    const outputPath = path.resolve(cmd.output_path);
    fs.mkdirSync(path.dirname(outputPath), { recursive: true });
    const cpuCount = Math.max(1, os.cpus()?.length || 4);
    const defaultConcurrency = Math.min(4, Math.max(2, Math.floor(cpuCount / 2)));
    const concurrency = cmd.concurrency || defaultConcurrency;
    const codec = cmd.codec || (outputPath.endsWith(".webm") ? "vp8" : outputPath.endsWith(".gif") ? "gif" : "h264");

    await renderMedia({
      composition,
      serveUrl,
      codec,
      outputLocation: outputPath,
      inputProps,
      concurrency,
      scale: cmd.scale || 1,
      crf: cmd.crf,
      frameRange: cmd.frame_range || null,
      browserExecutable,
      chromeMode,
      chromiumOptions,
      muted: Boolean(cmd.muted),
    });

    const stat = fs.statSync(outputPath);
    process.stdout.write(
      JSON.stringify({
        ok: true,
        output_path: outputPath,
        size_bytes: stat.size,
        composition_id: composition.id,
        width: composition.width,
        height: composition.height,
        fps: composition.fps,
        duration_frames: composition.durationInFrames,
        duration_sec: Number((composition.durationInFrames / composition.fps).toFixed(2)),
        concurrency,
        codec,
        elapsed_ms: Date.now() - startedAt,
      }) + "\n"
    );
    return;
  }

  throw new Error(`Unsupported driver action: ${action}`);
}

main().catch((err) => {
  process.stderr.write((err && err.stack ? err.stack : String(err)) + "\n");
  process.exit(1);
});
