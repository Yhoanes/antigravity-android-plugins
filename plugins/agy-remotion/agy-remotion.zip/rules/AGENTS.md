# Remotion Studio Android Rules (Native Rust ARM64 + Ported Remotion 4.0 Engine)

When the `agy-remotion` plugin is enabled on Antigravity for Android:

1. **Prefer Native `agy-remotion` Rust MCP Tools for Programmatic React/TypeScript Videos:**
   - Check `remotion_status` first; if `engine_ready` is `false`, call `remotion_setup` (or run `agy-remotion-setup`) once to configure the shared Remotion 4.0 engine in `$PREFIX/opt/remotion-engine`, the `musl`-bridged ARM64 Rust compositor, native `chromium`, and `ffmpeg` (`h264_mediacodec`).
   - Scaffold projects with `remotion_project_create` (safe on `/sdcard/Video` and `/storage/emulated/0/Documents/` despite Android `noexec`, because `node_modules` stays inside `$PREFIX/opt/remotion-engine/node_modules`).
   - Author scenes with `remotion_composition_write`, visually verify key frames in `<2s` using `remotion_still_render` + `read_file` before full renders, launch live browser previews with `remotion_studio_server`, and export final `.mp4` videos with `remotion_render_video` (with optional `gpu_mediacodec: true` hardware encoding + instant Android Gallery `MediaStore` scan).

2. **Mandatory Remotion Frame-Deterministic Animation Rules:**
   - **NEVER use CSS `transition`, CSS `@keyframes` / `animation`, Tailwind `animate-*` classes, `setTimeout`, or `requestAnimationFrame`** — headless parallel rendering evaluates frames out of order, so CSS/timer animations flicker or freeze.
   - Drive **100% of motion** mathematically from `useCurrentFrame()` and `useVideoConfig()` (`fps`, `width`, `height`, `durationInFrames`) using `spring()`, `interpolate(..., { extrapolateLeft: "clamp", extrapolateRight: "clamp" })`, `Easing.bezier()`, `<Sequence>`, and `@remotion/transitions` (`<TransitionSeries>`).
   - Keep `useCurrentFrame()` in leaf animated components rather than re-rendering massive static trees every frame.

3. **Android Sandbox & Bionic Safety:**
   - Never run raw `npm install remotion` directly inside `/sdcard/` (`noexec` filesystem blocks native binaries). Always rely on `agy-remotion`'s shared `$PREFIX/opt/remotion-engine` runtime.
   - Never let Remotion download desktop Linux glibc Chrome Headless Shell; `agy-remotion` automatically routes all headless rendering through `/data/user/0/com.agy/files/runtime/bin/chrome` (`--no-sandbox --disable-gpu --disable-dev-shm-usage`) and the `musl`-bridged `@remotion/compositor-linux-arm64-musl`.
   - Never modify or delete anything inside `/data/user/0/com.agy/files/runtime/bin/`; CLI wrappers live exclusively in `$PREFIX/bin/{agy-remotion,agy-remotion-setup}`.
