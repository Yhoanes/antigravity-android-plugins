---
name: agy-remotion
description: Native Android ARM64 Remotion 4.0 Studio & Official Remotion Skills guide. Use whenever creating, designing, previewing, or rendering programmatic React/TypeScript videos, SaaS product launches, Apple/Keynote trailers, 9:16 kinetic-caption Reels/TikToks, animated code walkthroughs, charts, maps, or motion graphics (`remotion_status`, `remotion_setup`, `remotion_project_create`, `remotion_composition_write`, `remotion_still_render`, `remotion_render_video`, `remotion_studio_server`, `remotion_captions_generate`).
---

# Remotion Studio Android (`agy-remotion` v1.0.0 — Native Rust MCP + Ported Remotion 4.0 Engine)

This skill combines **Remotion's official v4.0 Agent Skills** (`remotion-best-practices`, `remotion-markup`, `remotion-saas`, `remotion-captions`, `remotion-studio`, `remotion-render`) with a **ported Android ARM64 Remotion 4.0 Engine** running natively inside Antigravity for Android (`com.agy`).

---

## 1. End-to-End Android ARM64 Workflow

1. **Check & Initialize Engine (`remotion_status` -> `remotion_setup`):**
   - Call `remotion_status` first.
   - If `engine_ready` is `false`, call `remotion_setup` once. It installs native ARM64 `chromium` + `ffmpeg` via `pkg`, provisions the shared Remotion 4.0 workspace at `$PREFIX/opt/remotion-engine`, and wraps `@remotion/compositor-linux-arm64-musl` with an isolated `musl` ARM64 runtime + `android-preload.cjs` (`process.platform -> 'linux'`, `ESBUILD_BINARY_PATH`, and Chromium `--no-sandbox --disable-gpu --disable-dev-shm-usage`).

2. **Scaffold Lightweight Project Anywhere (`remotion_project_create`):**
   - Creates a clean React/TypeScript Remotion project in `<50 KB` even on `/sdcard/Video/<ProjectName>` or `/storage/emulated/0/Documents/...` (bypassing `/sdcard` `noexec` by resolving packages from `$PREFIX/opt/remotion-engine/node_modules`).
   - Built-in studio templates (`template`):
     - `"saas_launch"` (`1920x1080` @ `60fps` — Glassmorphic UI cards, spring physics, staggered metrics, animated cursor & gradient mesh)
     - `"apple_keynote"` (`1920x1080` @ `60fps` — Titanium bento grid, kinetic hero typography, smooth camera zoom & spotlight shimmer)
     - `"viral_reels_9_16"` (`1080x1920` @ `60fps` — Word-by-word `@remotion/captions` highlight pills, punchy spring pop-ins & progress bar)
     - `"code_walkthrough"` (`1920x1080` @ `60fps` — Syntax-highlighted terminal/editor window with token-by-token typing & line spotlight)
     - `"data_charts"` (`1920x1080` @ `60fps` — Spring-driven bar/line/ring charts with dynamic number count-ups)

3. **Write & Register Scenes (`remotion_composition_write` + `remotion_compositions_list`):**
   - Keep `useCurrentFrame()` in leaf animated components so static subtrees do not re-render every frame.
   - Express all durations in seconds multiplied by `fps` from `useVideoConfig()` (e.g., `durationInFrames={Math.round(3.5 * fps)}`).
   - Read detailed motion & layout patterns in:
     - [Animations, Springs & Transitions](./references/animations-and-transitions.md)
     - [SaaS Promo, Keynote Bento & Charts](./references/saas-keynote-and-charts.md)
     - [Kinetic Captions, Audio Sync & Studio Preview](./references/captions-audio-and-studio.md)

4. **Visual Keyframe QA Before Full Render (`remotion_still_render`):**
   - Always render 2–3 critical frames (e.g. `frame: 15`, `frame: 90`, `frame: 180`) to `.png` using `remotion_still_render` and inspect them with `read_file` to verify text contrast, padding, overflow, and spring alignment in `<2 seconds` before launching a full video encode.

5. **Interactive Live Preview OR Final GPU Video Export:**
   - **Live Timeline Preview (`remotion_studio_server`):** Pass `action: "start"` and `open_browser: true` to launch **Remotion Studio** on `127.0.0.1:3100` and open it in Android's browser via `xdg-open`.
   - **Final `.mp4` Export (`remotion_render_video`):** Renders the composition to `/sdcard/Video/...mp4` (optional `gpu_mediacodec: true` hardware H.264 pass + automatic Android `MediaStore` Gallery scan via `rish`).

---

## 2. Golden Rules of Remotion Code (Zero-Flicker Guarantee)

- **FORBIDDEN in Remotion Components:**
  - CSS `transition: ...` or `animation: ...`
  - Tailwind `animate-pulse`, `animate-bounce`, `animate-spin`, `transition-*`
  - `requestAnimationFrame`, `setInterval`, `setTimeout`, `Date.now()`, `Math.random()` (use Remotion's deterministic `random("seed")` instead!)
- **REQUIRED in Remotion Components:**
  - `const frame = useCurrentFrame();`
  - `const { fps, width, height, durationInFrames } = useVideoConfig();`
  - `spring({ frame, fps, config: { damping: 200 } })` for crisp, non-bouncing Apple/SaaS motion, or `{ damping: 14, stiffness: 180 }` for playful pop-ins.
  - `interpolate(frame, [0, 0.6 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" })` — **always clamp** both ends unless unbounded extrapolation is intentional.
  - Use `<Img>`, `<OffthreadVideo>`, `<Audio>` (or `<Html5Audio>`), and `staticFile("...")` from `"remotion"` instead of raw `<img>` / `<video>` tags so Remotion waits for every asset to decode before capturing each frame.
