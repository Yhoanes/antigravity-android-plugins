# Animations, Springs, Sequencing & Transitions (Remotion 4.0)

## 1. Frame-Driven Interpolation & Easing

Always compute seconds via `fps` from `useVideoConfig()` and clamp both sides:

```tsx
import React from "react";
import { Easing, interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";

export const HeroHeadline: React.FC<{ title: string; delaySec?: number }> = ({
  title,
  delaySec = 0,
}) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const localFrame = frame - Math.round(delaySec * fps);

  // Smooth Apple-style spring without overshoot (damping: 200)
  const entrance = spring({
    frame: localFrame,
    fps,
    config: { damping: 200, stiffness: 140, mass: 0.9 },
  });

  const translateY = interpolate(entrance, [0, 1], [48, 0]);
  const opacity = interpolate(localFrame, [0, 0.45 * fps], [0, 1], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
    easing: Easing.out(Easing.cubic),
  });

  return (
    <h1
      style={{
        opacity,
        transform: `translateY(${translateY}px) scale(${interpolate(entrance, [0, 1], [0.94, 1])})`,
        fontSize: 84,
        fontWeight: 800,
        letterSpacing: "-0.03em",
        lineHeight: 1.06,
        color: "#F8FAFC",
        margin: 0,
      }}
    >
      {title}
    </h1>
  );
};
```

## 2. Spring Presets Cheat-Sheet

| Motion Style | `config` | Best Use Case |
| :--- | :--- | :--- |
| **Apple / Keynote Smooth** | `{ damping: 200, stiffness: 120 }` | Hero text, SaaS dashboards, subtle camera zoom (zero bounce) |
| **Snappy UI Card** | `{ damping: 22, stiffness: 220, mass: 0.8 }` | Bento cards, modal popups, badges, notifications |
| **Playful / Viral Pop** | `{ damping: 12, stiffness: 200, mass: 0.7 }` | TikTok/Reels stickers, icons, callouts |
| **Heavy Cinema Reveal** | `{ damping: 200, stiffness: 70, mass: 1.6 }` | Full-screen 3D mockups, background shifts |

## 3. Staggered Lists & Exit Animations (In + Out)

Combine an entrance `spring` with an exit `spring` subtracted at the end of a scene:

```tsx
const inAnim = spring({ frame, fps, config: { damping: 200 } });
const outAnim = spring({
  frame: frame - (durationInFrames - Math.round(0.5 * fps)),
  fps,
  config: { damping: 200 },
});
const progress = inAnim - outAnim; // 0 -> 1 -> 0 smoothly!
```

For staggered cards (`index = 0, 1, 2...`), offset `frame` by `index * Math.round(0.12 * fps)`.

## 4. Scene Sequencing & `<TransitionSeries>` (`@remotion/transitions`)

Use `<TransitionSeries>` from `@remotion/transitions` to overlap scenes cleanly with `fade()`, `slide()`, `wipe()`, or `flip()`:

```tsx
import React from "react";
import { linearTiming, springTiming, TransitionSeries } from "@remotion/transitions";
import { fade } from "@remotion/transitions/fade";
import { slide } from "@remotion/transitions/slide";

export const FullVideo: React.FC = () => {
  return (
    <TransitionSeries>
      <TransitionSeries.Sequence durationInFrames={150}>
        <IntroScene />
      </TransitionSeries.Sequence>

      <TransitionSeries.Transition
        presentation={slide({ direction: "from-right" })}
        timing={springTiming({ config: { damping: 200 }, durationInFrames: 24 })}
      />

      <TransitionSeries.Sequence durationInFrames={180}>
        <FeatureBentoScene />
      </TransitionSeries.Sequence>

      <TransitionSeries.Transition
        presentation={fade()}
        timing={linearTiming({ durationInFrames: 18 })}
      />

      <TransitionSeries.Sequence durationInFrames={120}>
        <OutroCtaScene />
      </TransitionSeries.Sequence>
    </TransitionSeries>
  );
};
```

> **Duration Math Note:** Total duration of a `<TransitionSeries>` equals the sum of all `Sequence` durations **minus** the sum of all `Transition` durations! Always match `<Composition durationInFrames={...}>` to that exact total.

## 5. SVG Path Drawing (`@remotion/paths` & `@remotion/shapes`)

Animate checkmarks, route lines, arrows, or glowing borders with `evolvePath`:

```tsx
import { evolvePath } from "@remotion/paths";

const d = "M 20 70 L 55 105 L 130 30";
const { strokeDasharray, strokeDashoffset } = evolvePath(progress, d);
// Apply strokeDasharray and strokeDashoffset on <path d={d} ... />
```
