# Kinetic Captions (`@remotion/captions`), Audio Sync & Live Studio

## 1. Word-by-Word TikTok / Reels Captions (`9:16` @ `1080x1920`)

Use `remotion_captions_generate` to synthesize neural speech + millisecond-aligned `Caption[]` JSON (or generate captions from script timing), then group words into punchy pages with `createTikTokStyleCaptions` from `@remotion/captions`:

```tsx
import React, { useMemo } from "react";
import { AbsoluteFill, Sequence, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { Caption, createTikTokStyleCaptions } from "@remotion/captions";

export const KineticCaptionsOverlay: React.FC<{ captions: Caption[] }> = ({ captions }) => {
  const { fps } = useVideoConfig();

  const { pages } = useMemo(
    () =>
      createTikTokStyleCaptions({
        captions,
        combineTokensWithinMilliseconds: 1100,
      }),
    [captions]
  );

  return (
    <AbsoluteFill style={{ justifyContent: "flex-end", alignItems: "center", paddingBottom: 260 }}>
      {pages.map((page, idx) => {
        const nextPage = pages[idx + 1] ?? null;
        const startFrame = Math.round((page.startMs / 1000) * fps);
        const endFrame = Math.round(
          ((nextPage ? Math.min(nextPage.startMs, page.startMs + 2200) : page.startMs + 2200) /
            1000) *
            fps
        );
        const duration = Math.max(1, endFrame - startFrame);

        return (
          <Sequence key={idx} from={startFrame} durationInFrames={duration}>
            <CaptionPage page={page} />
          </Sequence>
        );
      })}
    </AbsoluteFill>
  );
};

const CaptionPage: React.FC<{ page: ReturnType<typeof createTikTokStyleCaptions>["pages"][number] }> = ({
  page,
}) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const currentTimeMs = page.startMs + (frame / fps) * 1000;
  const pop = spring({ frame, fps, config: { damping: 16, stiffness: 240 } });

  return (
    <div
      style={{
        transform: `scale(${0.9 + 0.1 * pop})`,
        display: "flex",
        flexWrap: "wrap",
        justifyContent: "center",
        gap: "12px 16px",
        maxWidth: 920,
        padding: "22px 34px",
        borderRadius: 28,
        background: "rgba(9, 13, 28, 0.78)",
        border: "1px solid rgba(255,255,255,0.14)",
      }}
    >
      {page.tokens.map((token, i) => {
        const active = token.fromMs <= currentTimeMs && currentTimeMs < token.toMs;
        return (
          <span
            key={i}
            style={{
              fontSize: 58,
              fontWeight: 900,
              padding: "2px 12px",
              borderRadius: 14,
              backgroundColor: active ? "#38BDF8" : "transparent",
              color: active ? "#06101F" : "#FFFFFF",
              transform: active ? "scale(1.08)" : "scale(1)",
            }}
          >
            {token.text.trim()}
          </span>
        );
      })}
    </div>
  );
};
```

## 2. Audio & Video Media Rules

- Put local audio/images/videos inside `<project>/public/` and reference them via `staticFile("voiceover.mp3")`.
- Use `<Audio src={staticFile("voiceover.mp3")} volume={0.95} />` from `"remotion"`.
- For background music ducking, pass a callback to `volume`:
  ```tsx
  <Audio
    src={staticFile("bgm.mp3")}
    volume={(f) => interpolate(f, [0, 30, durationInFrames - 45, durationInFrames], [0, 0.22, 0.22, 0], { extrapolateLeft: "clamp", extrapolateRight: "clamp" })}
  />
  ```

## 3. Live Remotion Studio on Android (`remotion_studio_server`)

- Avoid ports `45157` and `45158` (reserved by Antigravity core). Default to `3100` (`127.0.0.1:3100`).
- Passing `open_browser: true` to `remotion_studio_server` invokes `xdg-open "http://127.0.0.1:3100"`, opening the full Remotion timeline scrubber in Chrome on the user's phone!
