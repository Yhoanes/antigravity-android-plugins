#!/system/bin/sh
# install-plugin.sh — Installs and configures Remotion Studio Android (v1.0.0, Native Rust ARM64 + Ported Remotion 4.0)
set -eu

SRC_DIR="$(CDPATH= cd -- "$(/system/bin/dirname -- "$0")" && pwd)"
case "$SRC_DIR" in
    */.gemini/*) HOME="${SRC_DIR%%/.gemini/*}" ;;
    *) HOME="${HOME:-/data/user/0/com.agy/files}" ;;
esac
PREFIX="${PREFIX:-$HOME/usr}"
CONFIG_DIR="$HOME/.gemini/config"
TARGET_DIR="$CONFIG_DIR/plugins/agy-remotion"

/system/bin/mkdir -p "$CONFIG_DIR/plugins" "$PREFIX/tmp" "$PREFIX/bin"

if [ "$SRC_DIR" != "$TARGET_DIR" ]; then
    /system/bin/rm -rf "$TARGET_DIR"
    /system/bin/mkdir -p "$TARGET_DIR"
    /system/bin/cp -Rf "$SRC_DIR"/. "$TARGET_DIR"/
fi

/system/bin/chmod 0755 \
    "$TARGET_DIR/install-plugin.sh" \
    "$TARGET_DIR/mcp/bin/start-mcp.sh" \
    "$TARGET_DIR/mcp/bin/agy-remotion-setup" \
    "$TARGET_DIR/mcp/bin/agy-remotion-mcp"

# Self-heal CLI wrappers in $PREFIX/bin (never touch $HOME/runtime/bin)
cat > "$PREFIX/bin/agy-remotion-setup" <<EOF
#!/system/bin/sh
exec /system/bin/sh "$TARGET_DIR/mcp/bin/agy-remotion-setup" "\$@"
EOF
cat > "$PREFIX/bin/agy-remotion" <<EOF
#!/system/bin/sh
exec "$TARGET_DIR/mcp/bin/agy-remotion-mcp" cli "\$@"
EOF
/system/bin/chmod 0755 "$PREFIX/bin/agy-remotion-setup" "$PREFIX/bin/agy-remotion"

echo "================================================================="
echo " Plugin Remotion Studio Android v1.0.0 (Native Rust ARM64) ready"
echo " Path: $TARGET_DIR"
echo "================================================================="
