# Remotion Studio Android (`agy-remotion` v1.0.0)

**Motor oficial Remotion 4.0 ARM64 porteado a Android Bionic + Servidor MCP Nativo en Rust (`<5 MB` RAM) + Skills oficiales de Remotion** para crear, previsualizar en vivo y renderizar videos programáticos en **React & TypeScript a 60 FPS** directamente desde tu dispositivo Android.

---

## Arquitectura Android ARM64

En Android (`com.agy`), instalar únicamente los `SKILL.md` oficiales de Remotion falla porque:
1. `node` reporta `process.platform === "android"`, bloqueando `@remotion/renderer` y `@remotion/cli`.
2. El compositor nativo en Rust (`@remotion/compositor-linux-arm64-musl`) requiere el intérprete ELF `/lib/ld-linux-aarch64.so.1` + `libc.musl` / `libstdc++` / `libz`.
3. Remotion intenta descargar Chrome Headless Shell de Linux Desktop (`glibc`), que crashea bajo SELinux Android.
4. Almacenamiento compartido como `/sdcard/Video` está montado con `noexec`, impidiendo ejecutar binarios dentro de `node_modules`.

**`agy-remotion` resuelve las 4 barreras automáticamente:**
- **Motor compartido en `$PREFIX/opt/remotion-engine`:** Evita descargar `400 MB` por proyecto y permite crear proyectos de `<50 KB` directamente en `/sdcard/Video`.
- **Micro-runtime `musl` ARM64 (`~2 MB`):** Ejecuta el binario oficial en Rust de Remotion 4.0 y su FFmpeg 7.1 (`remotionshm`) a velocidad nativa de CPU ARMv8.1-A.
- **Preload Bridge (`android-preload.cjs`):** Mapea `android -> linux-arm64`, preserva `@esbuild/android-arm64` y redirige todo renderizado headless a Chromium ARM64 nativo (`--no-sandbox --disable-gpu --disable-dev-shm-usage`).
- **Aceleración Hardware MediaCodec + Galería Android:** Opcionalmente pasa el `.mp4` final por `h264_mediacodec` y lo indexa al instante en `MediaStore` vía `rish`.

---

## Las 10 Herramientas MCP (`agy-remotion`)

| Herramienta | Función |
| :--- | :--- |
| `remotion_status` | Verifica estado del motor ARM64, Chromium, FFmpeg (`h264_mediacodec`), compositor `musl` y servidores activos. |
| `remotion_setup` | Instala y configura en 1 paso `chromium`, `ffmpeg`, `remotion-engine` y el runtime `musl` ARM64. |
| `remotion_project_create` | Crea proyectos React/TS ligeros (`saas_launch`, `apple_keynote`, `viral_reels_9_16`, `code_walkthrough`, `data_charts`). |
| `remotion_composition_write` | Escribe escenas `.tsx` y registra `<Composition>` en `src/Root.tsx`. |
| `remotion_compositions_list` | Empaqueta y lista todas las composiciones registradas, dimensiones, FPS y `defaultProps`. |
| `remotion_still_render` | Renderiza un fotograma exacto a `.png`/`.jpeg` en `<2s` para inspección visual rápida. |
| `remotion_render_video` | Exporta `.mp4`/`.webm`/`.gif` a 30/60 FPS con soporte `gpu_mediacodec` y escaneo en Galería Android. |
| `remotion_studio_server` | Inicia, consulta o detiene **Remotion Studio** en `127.0.0.1:3100` y lo abre en el navegador con `xdg-open`. |
| `remotion_captions_generate` | Genera subtítulos `@remotion/captions` palabra por palabra (+ locución TTS opcional). |
| `remotion_cli_exec` | Ejecuta cualquier comando oficial de `@remotion/cli` bajo el puente Android ARM64. |
