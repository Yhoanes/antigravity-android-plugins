#!/system/bin/sh
# install-plugin.sh - Ensures executable permissions for Chrome DevTools MCP on Android ARM64
set -eu
SRC_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
case "$SRC_DIR" in
    */.gemini/*) HOME="${SRC_DIR%%/.gemini/*}" ;;
    *) HOME="${HOME:-/data/user/0/com.agy/files}" ;;
esac
TARGET_DIR="$HOME/.gemini/config/plugins/chrome-devtools-plugin"
if [ "$SRC_DIR" != "$TARGET_DIR" ]; then
    rm -rf "$TARGET_DIR"
    mkdir -p "$TARGET_DIR"
    cp -Rf "$SRC_DIR"/. "$TARGET_DIR"/
fi
chmod 0755 "$TARGET_DIR/install-plugin.sh" "$TARGET_DIR/mcp/bin/start-mcp.sh" 2>/dev/null || true
