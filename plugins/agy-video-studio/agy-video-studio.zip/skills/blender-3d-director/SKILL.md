---
name: blender-3d-director
description: Universal agentic 3D filmmaking, procedural modeling, joint rigging, cinematography, and visual self-correction workflow for Blender 5.0 Headless (custom_bpy + Cycles + OpenImageDenoise) on Android ARM64. Use whenever creating ANY custom 3D animated video from scratch — architectural walkthroughs, product commercials, vehicles, sci-fi/nature cinematics, stylized/clay/low-poly/voxel characters, mechanical explainers, or narrative shorts — without relying on fixed presets.
---

# Agentic 3D Director (`blender-3d-director` — Universal Blender 5.0 Filmmaking)

This skill teaches the **universal programmatic 3D filmmaking technique** (used in frontier agentic Blender workflows) to build, rig, light, visually self-correct, and render **any genre of 3D video from scratch** using `blender_render_scene` (`preset: "custom_bpy"`), `audio_studio_generate`, and `video_universal_edit`.

Never limit yourself to hardcoded presets when the user asks for a new world, product, creature, vehicle, building, or story. Read [Procedural `bpy` Materials, Rigs & Lighting Cookbook](./references/bpy-procedural-cookbook.md) for Blender 5.0 code building blocks.

---

## 1. The 6-Phase Universal 3D Production Pipeline

### Phase 1: Storyboard & Explicit Coordinate Blueprint (Before Writing Code)
1. **Multi-Shot Breakdown (`3–6 shots`, `2.5s–4.5s` each):**
   Real cinema cuts between distinct camera angles rather than holding one static wide shot for 20 seconds:
   - **Establishing Wide (`22–28mm`):** Reveals environment scale, weather/time-of-day, and spatial layout.
   - **Medium Action (`35–50mm`):** Follows character locomotion, vehicle motion, or mechanical assembly.
   - **Hero Close-Up (`55–85mm` + `DOF f/2.4`):** Isolates facial/eye expression, product material craft, dashboard/screen detail, or dramatic reaction.
   - **Payoff / Reveal Cut:** Visual transformation, camera crane pull-back, or comedic/dramatic punchline.
2. **Explicit Spatial Table (`Z = 0.0` Ground Rule):**
   Before writing `bpy` geometry, map out exact meter coordinates `(X, Y, Z)` and bounding dimensions `(W, D, H)` of every hero prop, wall, and camera path so:
   - Feet, tires, furniture legs, and building foundations sit **exactly on `Z = 0.0`** (`center_z = height / 2.0`), never floating or buried.
   - Camera trajectories never clip inside walls, pillars, or roofs.

---

### Phase 2: Universal Procedural Modeling (`bmesh` + Modifiers)
LLMs excel at **compositional, parametric, and modifier-driven geometry** rather than raw vertex sculpting. Match the modeling paradigm to the user's subject:

- **Architecture, Interiors & Cities** *(houses, modern apartments, temples, cafes, server rooms, cyberpunk streets)*:
  - Construct walls from clean slabs with doorway/window openings (segmented slabs or `Boolean` modifiers), `Bevel` (`2–5mm`) on every sharp architectural edge so corners catch specular highlights, `Array` modifiers for stairs/columns/louvers/windows, recessed ceiling light coves, and outdoor `Nishita` physical sky/sunlight.
- **Products, Vehicles & Mechanical Explainers** *(smartphones, watches, cars, drones, rockets, engines)*:
  - Combine beveled chassis blocks, `bmesh.ops.spin` lathed profiles (lenses, rims, thrusters, bottles, goblets), `SimpleDeform` / `Subsurf` smooth body shells, metallic/coat/glass shaders, and **exploded-view animations** (keyframing part offsets outward from center then snapping together).
- **Characters, Creatures & Mascots** *(clay/Pixar vinyl, low-poly, articulated robots/mechs, animals, sea/space monsters)*:
  - Choose the aesthetic that fits the story:
    - **Soft Clay / Vinyl Toy:** Subdivided rounded boxes/spheres/capsules (`Subsurf level 2` + matte `Roughness 0.45` + subtle `Subsurface Weight`).
    - **Stylized Low-Poly:** Icospheres + flat-shaded (`use_smooth = False`) geometric facets.
    - **Hard-Surface / Mech:** Chamfered armor plates + glowing emissive visors/thrusters.
    - **Voxel / Blocky:** Hollow `bmesh` cube grids with `1-segment` `45°` chamfers.
- **Nature, Oceans & Sci-Fi Worlds** *(stormy seas, mountains, forests, planets, portals)*:
  - Displace subdivided grids with layered trigonometric/noise waves (`ShaderNodeBump` + animated phase) for oceans/terrain, scatter instanced mesh data (`bpy.data.objects.new(name, shared_mesh)`) for hundreds of trees/rocks/stars at `0 MB` extra mesh cost, and light with dramatic rim/sun beams.

---

### Phase 3: Pivot-Joint Rigging & Mathematical Animation
- **Never rotate unparented limbs around object centers:** Create an `Empty` pivot (`bpy.data.objects.new("Joint_ShoulderL", None)`) at the **exact physical hinge point** (shoulder, hip, knee, door hinge, car axle, wing root), parent the limb mesh to the pivot, and keyframe `pivot.rotation_euler`!
- **Natural Motion Principles in Code:**
  - **Ease-In / Ease-Out** (`smoothstep(t) = t*t*(3 - 2*t)`) on every camera move and turn — never raw linear motion unless mechanical.
  - **Secondary Overlap & Follow-Through:** Offset phase (`math.sin(t * w - 0.4 * segment_idx)`) across spine segments, tails, tentacles, antennas, or floating cables.
  - **Squash, Stretch & Anticipation:** Dip `Z` slightly (`-0.06m`) and compress `scale.z = 0.92` for 3 frames before a jump or launch.
  - **Camera Rigging:** Always bind the camera with a `TRACK_TO` constraint (`track_axis='TRACK_NEGATIVE_Z'`, `up_axis='UP_Y'`) aimed at an animated `CamTarget` Empty, and set `cam_data.dof.focus_distance = (cam_obj.location - target.location).length`.

---

### Phase 4: Mandatory Visual Self-Correction Loop (The Secret Sauce)
**NEVER render a full `animation` on your first try.** Always run an iterative visual QA loop first:

1. **Render Fast Diagnostic Stills (`6–15s`):**
   Call `blender_render_scene` with `preset: "custom_bpy"`, `render_mode: "preview_stills"`, and `preview_frames: [1, mid_frame, last_frame]`.
2. **Inspect Every Still Multimodal-Visually (`read_file`):**
   Audit all **7 Visual Director Checkpoints**:
   1. **Framing & Silhouette:** Does the hero subject fill `35–70%` of the frame cleanly without being cut off at screen edges?
   2. **Grounding & Collisions:** Are objects resting solidly on `Z=0` / tables without floating or intersecting through walls/floors?
   3. **Lighting Separation:** Is there clear 3D contrast between foreground subject and background (Key + Rim + Fill or Nishita Sun + Sky)? Neither pitch-black underexposed nor blown-out white?
   4. **Shader Integrity:** Zero pink/magenta (`#FF00FF`) missing textures, zero Z-fighting coplanar faces?
   5. **Focus Sharpness:** Is the hero subject crisp and in focus (`DOF` distance accurate)?
   6. **Motion Verification:** Comparing `frame 1` vs `mid` vs `last`, did the subject and camera move smoothly along the intended path?
   7. **Text/UI Readability:** Are any 3D labels or mapped 2D displays upright, unmirrored, and legible?
3. **Self-Correct & Re-Verify:**
   Adjust camera coordinates, focal length, light energy, or joint angles in your `bpy` script and re-run `preview_stills` until the composition looks like a real film frame. Only then switch to `render_mode: "animation"`.

---

### Phase 5: Android ARM64 Performance & Timeout Rules
To render reliably on mobile ARM64 (`5.5–12 GB` RAM, `3-minute` MCP tool call timeout) without OOM or timeouts:
- **Sequential Rendering:** Render **one 3D shot at a time** (never launch multiple `blender_render_scene` animations in parallel).
- **Optimal Mobile Cycles Sweet Spot:**
  - Base render resolution: `640x360` (`16:9`) or `480x854` (`9:16`), `samples: 8–12` (open scenes) or `6–8` (enclosed rooms with many bounces), `fps: 8–10`, `output_fps: 30` (smooth motion-interpolated output via GPU `h264_mediacodec`).
  - Upscale to crisp `1920x1080` or `1080x1920` during final multi-shot assembly in `video_universal_edit`.
- **Android Blender 5.0 Guardrails:**
  - Map 2D screens/posters/labels using **`.png` files or `.png` sequences** (never raw `.mp4` directly inside `ShaderNodeTexImage`, which causes pink/magenta in headless Cycles).
  - For 3D `FONT` curves, load static TrueType fonts (`DejaVuSans-Bold.ttf` or `JetBrainsMono-SemiBold.ttf`) with `bevel_depth <= 0.001` — avoid variable fonts (`Outfit-Bold.ttf`) in 3D extrusion to prevent glyph boolean holes.

---

### Phase 6: Score, Sound Design & Final Cinema Cut
1. **Audio & Foley (`audio_studio_generate`):**
   Match the score to the genre (`"cinematic_epic"` for trailers/architecture/sci-fi, `"lofi_vlog"` for cozy rooms, `"dark_synth_slowed"` for surreal/mystery, `"gemini_keynote"` for product reveals, `"deep_tech_pulse"` for hardware/engineering) + timed `dialogue_lines` (`"natural"`, `"deep_ai"`, `"cute_voxel_bot"`, `"backrooms_echo"`, `"radio_glitch"`) + `sfx_events`.
2. **Final Assembly (`video_universal_edit` + `android_media_and_intent`):**
   Join all rendered 3D shots with cinema color grading (`"cinematic_teal_orange"`, `"warm_vlog"`, `"crisp_tech"`, `"moody_matte"`), transitions (`"none"` hard cuts for action/comedy, `"fade"` / `"fadeblack"` for cinematic/architectural), subtitles, and scan into Android Gallery (`MediaStore`).
