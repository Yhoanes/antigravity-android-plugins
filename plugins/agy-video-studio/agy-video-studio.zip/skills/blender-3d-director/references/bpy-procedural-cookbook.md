# Procedural `bpy` Materials, Rigs & Lighting Cookbook (Blender 5.0 ARM64)

When calling `blender_render_scene` with `preset: "custom_bpy"`, your script executes inside Blender 5.0 with `bpy`, `bmesh`, `math`, `random`, `Vector`, `Euler`, and `CFG` (`width`, `height`, `fps`, `total_frames`) already imported, plus built-in helpers `make_mat`, `create_beveled_box_mesh`, `add_mesh_obj`, `add_area_light`, and `add_3d_text`.

Below are universal, zero-asset procedural recipes for building **any** 3D world from scratch in `custom_bpy`.

---

## 1. Outdoor Physical Sun & Nishita Sky (Architecture, Cars, Nature, Cities)

Zero HDRI downloads required — Cycles' built-in physical atmospheric sky casts realistic sun shadows and sky dome GI:

```python
def setup_nishita_sun_sky(sun_elevation_deg=22.0, sun_rotation_deg=45.0, strength=0.85, air=1.2, dust=1.5):
    world = bpy.data.worlds.new("PhysicalSky")
    bpy.context.scene.world = world
    if getattr(world, "node_tree", None) is None:
        world.use_nodes = True
    nt = world.node_tree
    nt.nodes.clear()
    out = nt.nodes.new("ShaderNodeOutputWorld")
    bg = nt.nodes.new("ShaderNodeBackground")
    sky = nt.nodes.new("ShaderNodeTexSky")
    sky.sky_type = 'NISHITA'
    sky.sun_disc = True
    sky.sun_elevation = math.radians(sun_elevation_deg)
    sky.sun_rotation = math.radians(sun_rotation_deg)
    sky.air_density = air
    sky.dust_density = dust
    bg.inputs["Strength"].default_value = strength
    nt.links.new(sky.outputs["Color"], bg.inputs["Color"])
    nt.links.new(bg.outputs["Background"], out.inputs["Surface"])
```

---

## 2. Universal Zero-Texture Procedural PBR Shaders (Blender 5.0 Compatible)

In Blender 5.0 `Principled BSDF`, key input names are:
- `"Base Color"`, `"Metallic"`, `"Roughness"`, `"IOR"`
- `"Transmission Weight"` (glass/water refraction)
- `"Coat Weight"`, `"Coat Roughness"` (automotive clearcoat / glossy plastic / ceramic)
- `"Subsurface Weight"` (clay, skin, wax, foliage, food)
- `"Emission Color"`, `"Emission Strength"`

```python
def make_glass_or_water_mat(name, tint=(0.82, 0.94, 1.0, 1.0), roughness=0.03, ior=1.333, waves=False):
    mat = bpy.data.materials.new(name)
    nt = ensure_nodes_mat(mat)
    bsdf = nt.nodes.get("Principled BSDF")
    set_bsdf(bsdf, ["Base Color"], tint)
    set_bsdf(bsdf, ["Roughness"], roughness)
    set_bsdf(bsdf, ["IOR"], ior)
    set_bsdf(bsdf, ["Transmission Weight", "Transmission"], 0.96)
    if waves:
        coord = nt.nodes.new("ShaderNodeTexCoord")
        noise = nt.nodes.new("ShaderNodeTexNoise")
        noise.inputs["Scale"].default_value = 18.0
        noise.inputs["Detail"].default_value = 5.0
        bump = nt.nodes.new("ShaderNodeBump")
        bump.inputs["Strength"].default_value = 0.18
        nt.links.new(coord.outputs["Object"], noise.inputs["Vector"])
        nt.links.new(noise.outputs["Fac"], bump.inputs["Height"])
        nt.links.new(bump.outputs["Normal"], bsdf.inputs["Normal"])
    return mat

def make_car_paint_or_ceramic_mat(name, rgba=(0.85, 0.12, 0.08, 1.0), metallic=0.75):
    mat = bpy.data.materials.new(name)
    nt = ensure_nodes_mat(mat)
    bsdf = nt.nodes.get("Principled BSDF")
    set_bsdf(bsdf, ["Base Color"], rgba)
    set_bsdf(bsdf, ["Metallic"], metallic)
    set_bsdf(bsdf, ["Roughness"], 0.22)
    set_bsdf(bsdf, ["Coat Weight", "Clearcoat"], 1.0)
    set_bsdf(bsdf, ["Coat Roughness", "Clearcoat Roughness"], 0.03)
    return mat

def make_procedural_stone_or_wood(name, color_a=(0.38, 0.24, 0.13, 1.0), color_b=(0.22, 0.13, 0.07, 1.0), scale=8.0, bump_str=0.12):
    mat = bpy.data.materials.new(name)
    nt = ensure_nodes_mat(mat)
    bsdf = nt.nodes.get("Principled BSDF")
    set_bsdf(bsdf, ["Roughness"], 0.55)
    coord = nt.nodes.new("ShaderNodeTexCoord")
    noise = nt.nodes.new("ShaderNodeTexNoise")
    noise.inputs["Scale"].default_value = scale
    noise.inputs["Detail"].default_value = 6.0
    ramp = nt.nodes.new("ShaderNodeValToRGB")
    ramp.color_ramp.elements[0].color = color_a
    ramp.color_ramp.elements[1].color = color_b
    bump = nt.nodes.new("ShaderNodeBump")
    bump.inputs["Strength"].default_value = bump_str
    nt.links.new(coord.outputs["Object"], noise.inputs["Vector"])
    nt.links.new(noise.outputs["Fac"], ramp.inputs["Fac"])
    nt.links.new(ramp.outputs["Color"], bsdf.inputs["Base Color"])
    nt.links.new(noise.outputs["Fac"], bump.inputs["Height"])
    nt.links.new(bump.outputs["Normal"], bsdf.inputs["Normal"])
    return mat

def make_clay_vinyl_mat(name, rgba=(0.92, 0.52, 0.38, 1.0)):
    mat = bpy.data.materials.new(name)
    nt = ensure_nodes_mat(mat)
    bsdf = nt.nodes.get("Principled BSDF")
    set_bsdf(bsdf, ["Base Color"], rgba)
    set_bsdf(bsdf, ["Roughness"], 0.42)
    set_bsdf(bsdf, ["Subsurface Weight", "Subsurface"], 0.25)
    return mat
```

---

## 3. Pivot-Joint Rigging Pattern (Characters, Creatures, Vehicles, Doors)

```python
def create_pivot(name, loc=(0, 0, 0), parent=None):
    piv = bpy.data.objects.new(name, None)
    piv.location = loc
    bpy.context.collection.objects.link(piv)
    if parent is not None:
        piv.parent = parent
    return piv

# Example: Door rotating cleanly around its left hinge (not its center!), or a Robot/Creature Leg swinging from Hip:
# hip_l = create_pivot("Hip_L", loc=(-0.22, 0.0, 0.65), parent=body_root)
# leg_mesh_obj = add_mesh_obj("Leg_L", leg_mesh, mat, loc=(0.0, 0.0, -0.30), parent=hip_l)
# Keyframe hip_l.rotation_euler = (math.sin(t * 6.0) * 0.55, 0, 0)
```

---

## 4. Smooth Cinema Camera Rig + Easing Helpers

```python
def smoothstep(x):
    x = max(0.0, min(1.0, x))
    return x * x * (3.0 - 2.0 * x)

def spring_pop(x, damping=6.0, freq=10.0):
    x = max(0.0, min(1.0, x))
    return 1.0 - math.exp(-damping * x) * math.cos(freq * x)

def create_cinema_camera(name="CinemaCam", lens_mm=35.0, fstop=2.8):
    cam_data = bpy.data.cameras.new(name)
    cam_data.lens = lens_mm
    cam_data.dof.use_dof = True
    cam_data.dof.aperture_fstop = fstop
    cam_obj = bpy.data.objects.new(name, cam_data)
    bpy.context.collection.objects.link(cam_obj)
    bpy.context.scene.camera = cam_obj

    target = bpy.data.objects.new(f"{name}_Target", None)
    bpy.context.collection.objects.link(target)
    tr = cam_obj.constraints.new(type='TRACK_TO')
    tr.target = target
    tr.track_axis = 'TRACK_NEGATIVE_Z'
    tr.up_axis = 'UP_Y'
    return cam_obj, cam_data, target
```
