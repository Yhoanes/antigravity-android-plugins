---
name: agy-video-studio
description: Estudio universal nativo Android ARM64 de edicion y produccion de todo tipo de videos (v2.1): YouTube horizontal 16:9, Vlogs de camara, Podcasts en pantalla dividida, Gaming/Facecam PiP, Tutoriales, Documentales, Reels/TikTok 9:16 y Trailers Keynote a 60fps con GPU h264_mediacodec, limpieza de voz, musica/TTS neuronal, puente sin root con CapCut Android y control tactil Shizuku.
---

# AGY Video Studio v2.1 — Estudio Universal de Video para Android

Este plugin independiente convierte **Antigravity for Android (ARM64 Bionic + Shizuku)** en un editor de video completo y todo-terreno para **cualquier formato (`16:9`, `9:16`, `1:1`, `4:5`, `21:9` o resolución original) y cualquier género audiovisual**.

## Mapa de las 14 Herramientas MCP Según el Tipo de Video

### 1. Edición Universal Todo-Terreno (`video_universal_edit`)
Úsala para **Vlogs de cámara, YouTube horizontal `16:9`, Tutoriales, Podcasts, Entrevistas, Reacciones, Gaming, Documentales y Montajes de Fotos + Video**:
- **Formatos (`aspect_ratio`):** `"16:9"` (YouTube), `"9:16"` (TikTok/Reels/Shorts), `"1:1"`, `"4:5"`, `"21:9"` o `"source"` (conserva el tamaño exacto de cámara).
- **Modos de encuadre (`fit_mode`):** `"cover"` (recorte inteligente con `focus_x`, `focus_y`), `"blurred_bg"` (fondo difuminado elegante para pasar `16:9` a `9:16` sin recortar) o `"contain"`.
- **Layouts multicámara (`layout`):**
  - `"single"`: Línea de tiempo clásica combinando videos `.mp4`/`.mov` y fotos `.jpg`/`.png` (con efecto *Ken Burns* automático en fotos).
  - `"split_vertical"`: Pantalla dividida 50/50 arriba y abajo (ideal para **Podcasts, Reacciones y Gameplay + Cámara**).
  - `"pip_corner"`: Cámara flotante (*Facecam*) en cualquier esquina (`bottom_right`, `top_left`, etc.) para **Tutoriales, Clases y Streamers**.
- **Audio de Cámara Real + Limpieza + Ducking:** Conserva la voz original grabada por el micrófono del teléfono (`keep_clip_audio=true`), opcionalmente limpia ruido de fondo con `enhance_speech=true`, cruza el audio suavemente en transiciones (`acrossfade`) y baja automáticamente el volumen de la música de fondo cuando hablas.
- **Transiciones Reales (`transition`):** `"fade"`, `"fadeblack"`, `"slideleft"`, `"slideright"`, `"slideup"`, `"smoothleft"`, `"circleopen"`, `"zoomin"` o corte directo `"none"`.
- **Color Grading (`color_grade`):** `"cinematic_teal_orange"`, `"warm_vlog"`, `"crisp_tech"`, `"moody_matte"` y `"bw_film"`.
- **Banners y Subtítulos (`lower_thirds` + `subtitle_style`):** Plecas de presentación (`name` + `role`) y 3 estilos de subtítulos (`"glass_pill"`, `"cinema_yellow"` estilo cine/documental, y `"viral_pop"`).

### 2. Navaja Suiza de Utilidades Rápidas (`video_utility_ops`)
- **`podcast_voice_enhance`**: Limpia ruido de aire/calle en grabaciones de cámara de celular (`afftdn` + filtro paso-alto + compresor + normalización `-16 LUFS`).
- **`compress_social`**: Comprime videos pesados 4K de cámara al peso exacto en MB (`target_mb`, p. ej. `15 MB`) acelerado por GPU para enviar por WhatsApp, Discord o Telegram.
- **`cover_thumbnail`**: Extrae el mejor fotograma y estampa opcionalmente una portada miniatura con título `Outfit Bold` e insignia para YouTube o Reels.
- **`extract_audio`** y **`to_gif`**: Extrae `.mp3`/`.wav` o convierte cualquier clip en GIF optimizado por paleta.

### 3. Análisis y Auto-Recorte Inteligente (`video_probe_and_scenes` + `video_smart_autocut`)
- Detecta silencios de voz (`silencedetect`), pantallas quietas (`freezedetect`) y cambios de escena (`scdet`) en una sola pasada rápida, eliminando pausas muertas o acelerándolas (`speed_ramp`).

### 4. Estudio de Voz Neuronal y Música Libre de Copyright (`audio_studio_generate`)
- Locución neuronal (`ES`, `EN`, `PT`) con subtítulos alineados al milisegundo + 5 géneros musicales sintetizados sin copyright: `"lofi_vlog"`, `"cinematic_epic"`, `"gemini_keynote"`, `"deep_tech_pulse"` y `"minimal_pad"`.

### 5. Presentaciones Keynote y Formato Corto (`video_render_keynote_trailer` + `video_render_viral_tiktok`)
- **`video_render_keynote_trailer`**: Ahora soporta tanto **`9:16` vertical** como **`16:9` horizontal (YouTube Keynote a 2 columnas)** con marcos de titanio, degradados Gemini y lupas flotantes `pip_crop`.

### 6. Puente CapCut Android Sin Root + Control Táctil Shizuku
- **`capcut_android_list_drafts`** + **`capcut_export_draft`**: Soporta cualquier relación de aspecto (`16:9`, `9:16`, `1:1`, `4:5`), conserva el audio de cámara y aplica *Rootless Draft Hijack* vía Shizuku (`rish`) para abrir proyectos multipista directo en CapCut Mobile sin root.
- **`android_screen_record`**, **`android_ui_inspect`**, **`android_ui_action`** y **`android_media_and_intent`**: Grabación hardware en segundo plano, lectura/toque autónomo de botones en pantalla y escaneo inmediato en la Galería de Android / envío directo a TikTok, YouTube, Instagram, VN o CapCut.
