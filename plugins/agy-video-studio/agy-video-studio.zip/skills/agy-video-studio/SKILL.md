---
name: agy-video-studio
description: Estudio universal nativo Android ARM64 de edicion 2D y animacion 3D con Blender 5.0 Headless (v3.0): personajes Voxel 3D, escenarios Backrooms y codigo bpy con Cycles + OpenImageDenoise, pantallas de codigo/chat animadas, YouTube 16:9, Vlogs, Podcasts, Reels/TikTok 9:16 y Trailers Keynote a 60fps con GPU h264_mediacodec, voces de personaje + SFX, puente CapCut sin root y Shizuku.
---

# AGY Video Studio v3.0 — Estudio Universal 2D + Blender 5.0 3D para Android ARM64

Este plugin convierte **Antigravity for Android (ARM64 Bionic + Bare-Metal `ld-musl` + Shizuku)** en un estudio completo de **edición de video 2D y animación 3D programática real con Blender 5.0 Headless (`Cycles` + `OpenImageDenoise`)**, acelerado por GPU `h264_mediacodec`.

## Mapa de las 18 Herramientas MCP Según el Tipo de Video

### 1. Motor 3D Blender 5.0 Headless + Loop Agéntico Visual (`blender_status`, `blender_setup`, `blender_render_scene`)
Ejecuta **Blender 5.0.0 (`aarch64`)** a velocidad nativa vía `ld-musl-aarch64.so.1` sin necesitar root, servidor X11 ni `proot`:
- **Presets 3D integrados (`preset`):**
  - `"voxel_coder_laptop"`: Escritorio de estudio oscuro con partículas estelares, laptop 3D biselada con teclas individuales, pantalla emisiva sincronizada a video/código y mascota **Vóxel 3D** articulada con ojos brillantes (`eye_expression`: `"normal"`, `"confident"`, `"squint"`, `"wide_shock"` y acciones `"typing_bounce"`, `"retry_panic"`, `"look_screen_then_camera"` + disolución blanca `glitch_dissolve_end`).
  - `"voxel_backrooms_loop"`: Laberinto 3D amarillo estilo *Backrooms* con tapiz `retry() ↻`, luces fluorescentes de techo, texto 3D extruido (`wall_text`: `"ATTEMPT 44"`), barra roja `"CONTEXT"`, clones grises de intentos fallidos (`ghost_clones`) y portal luminoso `"break;"` (`break_door: true`).
  - `"studio_pedestal_3d"`: Escaparate 3D con iluminación de estudio de 3 puntos, texto 3D extruido e importación de `.glb`.
  - `"custom_bpy"`: Ejecución libre de cualquier script Python `import bpy, bmesh` (igual que Blender MCP en escritorio), con soporte para guardar `.blend` y exportar `.glb` (`export_glb_path`).
- **Flujo obligatorio de Autoverificación Visual (Estilo Claude Fable):**
  1. Llama primero a `blender_render_scene` con `render_mode: "preview_stills"` (tarda ~3–6 segundos).
  2. Inspecciona los `.png` devueltos usando `read_file` para comprobar encuadre, iluminación y textos.
  3. Lanza el render final con `render_mode: "animation"` (usa `use_persistent_data` + `OPENIMAGEDENOISE` y codifica el `.mp4` por GPU `h264_mediacodec`).

### 2. Pantallas Nítidas de Código, Terminal y Chat IA (`video_render_code_screen`)
- Modos: `"code_typing"` (editor con coloreado de sintaxis, corrección de caracteres y banners de test), `"test_attempts"` (`$ run tests` + `✗ Attempt 31` + tormenta `Thinking...`), y `"chat_dialogue"` (burbujas animadas estilo asistente IA).
- Úsalo como clip 2D independiente o pásalo en `screen_media_path` para proyectarlo sobre la pantalla de la laptop 3D en Blender.

### 3. Voces de Personaje, Diálogos Cronometrados, SFX y Música (`audio_studio_generate`)
- **Efectos DSP de personaje (`voice_effect`):** `"cute_voxel_bot"` (voz tierna/robótica con *formant/pitch shift*), `"backrooms_echo"`, `"deep_ai"`, `"radio_glitch"` o `"natural"`.
- **Guion multipista (`dialogue_lines`) y Efectos Procedurales (`sfx_events`):** `"mech_typing"`, `"error_buzz"`, `"white_glitch"`, `"portal_flash"`, `"success_chime"` y `"footsteps"`.
- **6 géneros musicales sin copyright:** incluye `"dark_synth_slowed"` (ideal para animaciones 3D/Backrooms), `"gemini_keynote"`, `"lofi_vlog"`, `"cinematic_epic"`, `"deep_tech_pulse"` y `"minimal_pad"`.

### 4. Edición Multipista Universal, Auto-Recorte, Keynote y Puente CapCut (`video_universal_edit`, `video_smart_autocut`, `video_keynote_trailer`, `capcut_export_draft`, `android_media_and_intent`)
- Combina múltiples tomas 3D de Blender + pantallas 2D con transiciones (`"fade"`, `"fadeblack"`, `"zoomin"`), subtítulos sincronizados (`"glass_pill"`, `"cinema_yellow"`, `"viral_pop"`), audio `master_audio.wav` e indexación instantánea #1 en la Galería de Android o inyección directa sin root en **CapCut Mobile**.
