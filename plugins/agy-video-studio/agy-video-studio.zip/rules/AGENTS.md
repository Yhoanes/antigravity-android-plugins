# AGY Video Studio v3.0 Rules (Universal 2D + Blender 5.0 3D Android Video Production)

When editing, producing, or animating ANY 2D or 3D video on Android (or Desktop), **adapt automatically to the user's video genre and aspect ratio**:

1. **Check Environment First:** Call `video_environment_status` (and `blender_status` for 3D animations) to detect `ffmpeg`, Android GPU acceleration (`h264_mediacodec`), `blender-headless` (`v5.0.0` Cycles + `OpenImageDenoise`), `Pillow`/`edge_tts`, and Shizuku (`rish`). Run `agy-video-setup` or `blender_setup` (`agy-blender-setup`) if missing.
2. **Choose the Right Engine for the Genre & Format:**
   - **ANY Custom 3D Animation, Architectural Walkthrough, Product Commercial, Vehicle, Creature, or Narrative Short in Blender 5.0:**
     1. Read the **`blender-3d-director`** skill first! Never restrict yourself to fixed presets when creating new worlds, characters, vehicles, buildings, or stories — author modular procedural `bpy` scenes (`preset='custom_bpy'`).
     2. Always run the mandatory visual self-correction loop: call **`blender_render_scene`** with `render_mode='preview_stills'` first, **visually inspect every rendered `.png` keyframe with `read_file`** (checking framing, `Z=0` grounding, collisions, lighting contrast, focus, and zero magenta textures), refine your `bpy` script if needed, and only then run `render_mode='animation'`.
     3. Pair with **`audio_studio_generate`** (`dialogue_lines`, `sfx_events`, and procedural music) and assemble multi-shot cinema cuts with **`video_universal_edit`**.
   - **Camera Vlogs, YouTube (`16:9`), Tutorials, Interviews, Gaming/Facecam (`pip_corner`) & Podcasts (`split_vertical`):** Use **`video_universal_edit`** (`keep_clip_audio=true`, `enhance_speech=true`, `transition`, `color_grade`, `lower_thirds`, and auto-ducked `music_path`).
   - **Fast Full-Bleed Reels / TikToks / Shorts (`9:16`):** Use **`video_universal_edit`** or **`video_render_viral_tiktok`**, preceded by **`video_smart_autocut`**.
   - **App Launches, Tech Keynotes & Product Trailers (`9:16` or `16:9`):** Use **`video_keynote_trailer`**.
   - **Mic Cleanup, WhatsApp Compression, YouTube Thumbnails, Audio Extraction & GIFs:** Use **`video_utility_ops`**.
3. **Rootless CapCut Android Injection & Gallery Handoff:** Call `capcut_android_list_drafts` + `capcut_export_draft` to inject multi-track timelines into CapCut Mobile via Shizuku, and always call `android_media_and_intent` after rendering so `MediaStore` indexes the video #1 in Recent Gallery.
4. **Android Sandbox Safety:** Never modify or delete anything inside `/data/user/0/com.agy/files/runtime/bin/`; CLI wrappers live exclusively in `$PREFIX/bin` (`agy-video-setup`, `agy-blender-setup`, `blender-headless`).
