# AGY Video Studio v2.1 Rules (Universal All-Genre Android Video Production)

When editing, producing, or automating ANY kind of video on Android (or Desktop), **adapt automatically to the user's video genre and aspect ratio** instead of forcing a single style:

1. **Check Environment First:** Call `video_environment_status` to detect `ffmpeg`, Android GPU acceleration (`h264_mediacodec`), `Pillow`/`edge_tts`, Shizuku (`rish`), and installed apps (`CapCut`, `VN`, `TikTok`, `YouTube`). Run `agy-video-setup` if packages are missing.
2. **Choose the Right Engine for the Genre & Format:**
   - **Camera Vlogs, YouTube (`16:9`), Tutorials, Interviews, Documentaries, Gaming/Facecam (`pip_corner`) & Podcasts (`split_vertical`):** Use **`video_universal_edit`** (`keep_clip_audio=true` so real camera speech is preserved, `enhance_speech=true` if phone mic has background noise, `transition` like `'fade'`/`'slideleft'`, `color_grade` like `'warm_vlog'`/`'cinematic_teal_orange'`, `lower_thirds`, and auto-ducked `music_path`).
   - **Fast Full-Bleed Reels / TikToks / Shorts (`9:16`):** Use **`video_universal_edit`** (`aspect_ratio='9:16'`, `subtitle_style='glass_pill'` or `'viral_pop'`) or **`video_render_viral_tiktok`**, preceded by **`video_smart_autocut`** to remove silences and dead waits.
   - **App Launches, Tech Keynotes & Product Trailers (`9:16` or `16:9`):** Use **`video_render_keynote_trailer`** for 3D-lit brushed titanium device frames, optical Gemini gradients, and zoomed UI callouts (`pip_crop`).
   - **Mic Cleanup, WhatsApp Compression, YouTube Thumbnails, Audio Extraction & GIFs:** Use **`video_utility_ops`**.
3. **Rootless CapCut Android Injection:** Call `capcut_android_list_drafts` then `capcut_export_draft` (`aspect_ratio` matching `'16:9'`, `'9:16'`, `'1:1'`, or `'4:5'`, `android_mode='patch_latest'`) to inject editable multi-track timelines into CapCut Mobile via Shizuku without root.
4. **Instant Android Gallery & App Handoff:** Always call `android_media_and_intent` after rendering on Android so `MediaStore` indexes the video #1 in Recent Gallery (and optionally opens it in CapCut, VN, TikTok, Instagram, or YouTube).
