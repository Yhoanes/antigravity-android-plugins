# AGY Video Studio v2.1 — Estudio Universal de Video para Antigravity Android

**`agy-video-studio` (`v2.1.0`)** es un plugin MCP **100 % independiente y todo-terreno** diseñado para **Antigravity for Android (ARM64 Bionic + Shizuku `rish`)** (y compatible con PC). Sirve para editar **cualquier tipo de video y cualquier formato**.

---

## ¿Qué tipos de video puedes crear y editar?

| Tipo de Video | Formato(s) | Herramienta Principal | Funciones Destacadas |
| :--- | :--- | :--- | :--- |
| **YouTube Horizontal, Cursos y Tutoriales** | `16:9` (`1920×1080`) | `video_universal_edit` | Cámara flotante *Facecam* (`pip_corner`), plecas de nombre (`lower_thirds`), transiciones `xfade`, mezcla de fotos + clips y música con *ducking* bajo tu voz real. |
| **Vlogs de Cámara, Viajes y Cine** | `16:9`, `9:16`, `4:5`, `21:9` | `video_universal_edit` | Etalonaje de color (`cinematic_teal_orange`, `warm_vlog`, `moody_matte`, `bw_film`), subtítulos de cine (`cinema_yellow`) y limpieza de micrófono (`enhance_speech`). |
| **Podcasts, Entrevistas y Gaming** | `9:16` o `16:9` | `video_universal_edit` + `video_smart_autocut` | Pantalla dividida 50/50 (`split_vertical`), eliminación automática de silencios (`silencedetect`) y mejora de voz de estudio (`podcast_voice_enhance`). |
| **Canales *Faceless* / Documentales / Historias** | `16:9` o `9:16` | `audio_studio_generate` + `video_universal_edit` | Voz neuronal (`ES`/`EN`/`PT`) sincronizada al milisegundo + música `cinematic_epic` o `lofi_vlog` sin copyright + fotos con *Ken Burns*. |
| **TikToks, Reels y Shorts Virales** | `9:16` (`1080×1920`) | `video_render_viral_tiktok` / `video_universal_edit` | *Zoom punches*, *speed-ramps*, encuadre `blurred_bg` (para pasar clips `16:9` a `9:16`) y subtítulos animados `Outfit Bold`. |
| **Tráilers de Apps y Presentaciones** | `9:16` y `16:9` | `video_render_keynote_trailer` | Marcos en titanio cepillado, degradados ópticos estilo Google Gemini y lupas flotantes (`pip_crop`) sin usar navegador. |
| **Utilidades Rápidas del Día a Día** | Todos | `video_utility_ops` | Compresión exacta en MB para WhatsApp/Discord (`compress_social`), miniaturas con título para YouTube (`cover_thumbnail`), extracción MP3/WAV y GIFs. |
| **Proyectos Editables en CapCut Android** | `16:9`, `9:16`, `1:1`, `4:5` | `capcut_export_draft` | Inyección multipista **sin root** en CapCut Mobile vía Shizuku conservando el `draft_id` de SQLite. |

---

## Las 14 Herramientas MCP Incluidas

1. `video_environment_status`: Diagnóstico de ARM64, GPU `h264_mediacodec`, fuentes offline, Shizuku y apps instaladas.
2. `video_probe_and_scenes`: Detección rápida de escenas (`scdet`), silencios (`silencedetect`) y pausas congeladas (`freezedetect`).
3. `video_smart_autocut`: Recorte automático de silencios de voz o pantallas muertas.
4. `video_universal_edit`: Editor multipropósito (`16:9`, `9:16`, `1:1`, `4:5`, `source`) con transiciones `xfade`, color grading, *Split-Screen*, *Facecam PiP*, *lower-thirds* y audio de cámara conservado.
5. `video_utility_ops`: Limpieza de micrófono a `-16 LUFS`, compresión para WhatsApp/redes, portadas/miniaturas con texto, extracción de audio y GIFs.
6. `audio_studio_generate`: Locución neuronal (`ES`/`EN`/`PT`) + subtítulos exactos + 5 estilos musicales libres de copyright (`lofi_vlog`, `cinematic_epic`, `gemini_keynote`, `deep_tech_pulse`, `minimal_pad`).
7. `video_render_keynote_trailer`: Motor de presentaciones estilo Google/Apple (`9:16` vertical y `16:9` horizontal a 2 columnas).
8. `video_render_viral_tiktok`: Renderizador rápido de formato corto con *zoom punches* y subtítulos `.ass`.
9. `capcut_android_list_drafts`: Lista proyectos existentes de CapCut Android vía Shizuku (`rish`) o PC.
10. `capcut_export_draft`: Inyección multipista sin root en CapCut Android (`16:9`, `9:16`, `1:1`, `4:5`).
11. `android_screen_record`: Grabación por hardware (`start` en segundo plano / `stop` limpio con `SIGINT` / `timed`).
12. `android_ui_inspect`: Lectura en vivo de botones y coordenadas en pantalla vía `uiautomator`.
13. `android_ui_action`: Toques autónomos (`tap`, `tap_text`, `swipe`, `text`, `keyevent`, `launch_app`).
14. `android_media_and_intent`: Refresco inmediato en Galería (`MediaStore`) y apertura directa en TikTok, YouTube, Instagram, VN o CapCut.

---

## Instalación en Antigravity for Android (1 Comando)

Copia `agy-video-studio-v2.1.0-android.tar.gz` a la carpeta `Download` de tu teléfono Android y ejecuta en la terminal de Antigravity:

```sh
mkdir -p ~/tmp_plugin && tar -xzf /sdcard/Download/agy-video-studio-v2.1.0-android.tar.gz -C ~/tmp_plugin
sh ~/tmp_plugin/agy-video-studio/install-plugin.sh
agy-video-setup
```
