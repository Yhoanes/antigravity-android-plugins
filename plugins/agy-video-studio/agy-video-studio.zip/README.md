# AGY Video Studio 3D v3.0.0 (Native Rust ARM64 + Blender 5.0 Headless)

**`agy-video-studio` (`v3.0.0`)** es un servidor MCP y CLI **compilado en Rust nativo ARM64 (`-O3`, `LTO`, `LSE`)** para **Antigravity for Android**. Combina edición universal de video 2D acelerada por GPU (`h264_mediacodec`), síntesis de música y efectos en **Rust nativo a 48 kHz estéreo**, y animación 3D real con **Blender 5.0.0 Headless (`Cycles` + `OpenImageDenoise`)** vía `ld-musl-aarch64.so.1` sin necesitar root, servidor X11 ni `proot`.

---

## Novedades Clave en v3.0.0 (Edición Rust + Blender 3D)

1. **Binario MCP y CLI 100% en Rust Nativo ARM64 (`mcp/bin/agy-video-mcp` / `agy-video`):**
   - Arranque instantáneo (`<1 ms`, `<4 MB` RAM), sin dependencias externas de crates y compilado con atómicos hardware `+lse`.
2. **Motor 3D Real con Blender 5.0.0 Headless (`blender_status`, `blender_setup`, `blender_render_scene`):**
   - Ejecuta `import bpy, bmesh` real con *raytracing* **Cycles** + denoiser de IA **Intel OpenImageDenoise (`2.3.3`)** directo sobre los núcleos ARM64.
   - **Presets 3D integrados estilo Claude Fable:**
     - `"voxel_coder_laptop"`: Laptop 3D biselada con teclas individuales, pantalla emisiva sincronizada a video de código/chat y mascota **Vóxel 3D** articulada con ojos brillantes y disolución *glitch*.
     - `"voxel_backrooms_loop"`: Laberinto 3D amarillo estilo *Backrooms* con tapiz `retry()`, luces fluorescentes, texto 3D extruido (`ATTEMPT 44`), barra `CONTEXT`, clones grises y portal luminoso `break;`.
     - `"studio_pedestal_3d"` y `"custom_bpy"` (scripts Python `bpy` libres + exportación `.glb` / `.blend`).
3. **Pantallas Animadas de Código, Terminal y Chat (`video_render_code_screen`):**
   - Renderiza ventanas de editor con coloreado de sintaxis (`checkout.js`), bucles `$ run tests -> ✗ Attempt 31 -> Thinking...` y chats animados, listos para TikTok o proyectados dentro de la laptop 3D en Blender.
4. **Estudio de Audio y SFX en Rust Nativo (`audio_studio_generate`):**
   - Síntesis en Rust de 6 estilos musicales (incluyendo `"dark_synth_slowed"`) y 6 efectos estéreo procedurales (`"mech_typing"`, `"error_buzz"`, `"white_glitch"`, `"portal_flash"`, `"success_chime"`, `"footsteps"`), más voces de personaje (`"cute_voxel_bot"`, `"backrooms_echo"`, `"deep_ai"`).

---

## Las 18 Herramientas MCP Incluidas

1. `video_environment_status`: Diagnóstico en Rust de ARM64, GPU `h264_mediacodec`, Blender 5.0, fuentes, Shizuku y apps.
2. `blender_status`: Estado de Blender 5.0 Headless, OpenImageDenoise, RAM libre y presets 3D.
3. `blender_setup`: Instalador bajo demanda de Blender 5.0 ARM64 en `$PREFIX/opt/blender-rootfs`.
4. `blender_render_scene`: Constructor y renderizador 3D (`preview_stills` para autoverificación visual, `animation` MP4 por GPU y `model_only` `.glb`/`.blend`).
5. `video_render_code_screen`: Pantallas animadas de código, intentos de terminal y burbujas de chat IA.
6. `audio_studio_generate`: Síntesis musical y SFX en Rust + diálogos cronometrados con DSP de personaje y subtítulos.
7. `video_probe_and_scenes`: Detección rápida de escenas (`scdet`), silencios y pausas congeladas.
8. `video_smart_autocut`: Recorte automático de silencios o esperas muertas.
9. `video_universal_edit`: Editor multipropósito (`16:9`, `9:16`, `1:1`, `4:5`, `source`) con transiciones `xfade`, color grading, *Split-Screen*, *Facecam PiP* y subtítulos.
10. `video_utility_ops`: Limpieza de micrófono a `-16 LUFS`, compresión para WhatsApp, miniaturas, extracción de audio y GIFs.
11. `video_keynote_trailer`: Presentaciones Keynote a 60fps con marcos de titanio y degradados ópticos.
12. `video_render_viral_tiktok`: Renderizador rápido de formato corto con *zoom punches* y subtítulos `.ass`.
13. `capcut_android_list_drafts`: Lista borradores de CapCut Android vía Shizuku (`rish`).
14. `capcut_export_draft`: Inyección multipista sin root en CapCut Mobile.
15. `android_screen_record`: Grabación por hardware vía Shizuku (`start`, `stop`, `timed`).
16. `android_ui_inspect`: Inspección de botones y coordenadas en pantalla (`uiautomator`).
17. `android_ui_action`: Control táctil autónomo (`tap`, `tap_text`, `swipe`, `launch_app`).
18. `android_media_and_intent`: Refresco en Galería (`MediaStore`) y envío directo a TikTok, YouTube, Instagram o CapCut.
