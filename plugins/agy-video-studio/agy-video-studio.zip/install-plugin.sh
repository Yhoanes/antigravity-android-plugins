#!/system/bin/sh
# install-plugin.sh - Installs AGY Video Studio v3.0.0 into Antigravity for Android (Bionic-safe $PREFIX/bin wrappers).
# Strictly never modifies $HOME/runtime/bin.
set -eu

SRC_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
case "$SRC_DIR" in
    */.gemini/*) HOME="${SRC_DIR%%/.gemini/*}" ;;
    *) HOME="${HOME:-/data/user/0/com.agy/files}" ;;
esac
PREFIX="${PREFIX:-$HOME/usr}"
CONFIG_DIR="$HOME/.gemini/config"
TARGET_DIR="$CONFIG_DIR/plugins/agy-video-studio"

mkdir -p "$CONFIG_DIR/plugins" "$PREFIX/bin"

if [ "$SRC_DIR" != "$TARGET_DIR" ]; then
    rm -rf "$TARGET_DIR"
    mkdir -p "$TARGET_DIR"
    cp -Rf "$SRC_DIR"/. "$TARGET_DIR"/
fi

chmod 0755 \
    "$TARGET_DIR/install-plugin.sh" \
    "$TARGET_DIR/mcp/bin/start-mcp.sh" \
    "$TARGET_DIR/mcp/bin/agy-video-mcp" \
    "$TARGET_DIR/mcp/bin/agy-video-setup" \
    "$TARGET_DIR/mcp/bin/agy-blender-setup"

cat > "$PREFIX/bin/agy-video-mcp" <<EOF
#!/system/bin/sh
export HOME="${HOME}"
export PREFIX="${PREFIX}"
exec "$TARGET_DIR/mcp/bin/start-mcp.sh" "\$@"
EOF

cat > "$PREFIX/bin/agy-video-setup" <<EOF
#!/system/bin/sh
export HOME="${HOME}"
export PREFIX="${PREFIX}"
exec /system/bin/sh "$TARGET_DIR/mcp/bin/agy-video-setup" "\$@"
EOF

cat > "$PREFIX/bin/agy-blender-setup" <<EOF
#!/system/bin/sh
export HOME="${HOME}"
export PREFIX="${PREFIX}"
exec /system/bin/sh "$TARGET_DIR/mcp/bin/agy-blender-setup" "\$@"
EOF

chmod 0755 "$PREFIX/bin/agy-video-mcp" "$PREFIX/bin/agy-video-setup" "$PREFIX/bin/agy-blender-setup"

APP_BIN="$HOME/.gemini/antigravity-app/bin"
mkdir -p "$APP_BIN" 2>/dev/null || true
if [ -d "$APP_BIN" ]; then
    ln -snf "$TARGET_DIR/mcp/bin/agy-video-setup" "$APP_BIN/agy-video-setup" 2>/dev/null || true
    ln -snf "$TARGET_DIR/mcp/bin/agy-blender-setup" "$APP_BIN/agy-blender-setup" 2>/dev/null || true
fi

echo "============================================================"
echo " AGY Video Studio v3.0.0 (2D + Blender 5.0 3D) installed!"
echo " Location: $TARGET_DIR"
echo " Wrappers: $PREFIX/bin/{agy-video-setup,agy-blender-setup}"
echo "============================================================"
