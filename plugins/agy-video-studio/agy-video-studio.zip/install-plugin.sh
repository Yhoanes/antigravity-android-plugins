#!/system/bin/sh
# install-plugin.sh - Installs AGY Video Studio v2.1.3 into Antigravity for Android (universal $HOME, Bionic-safe wrappers).
set -eu

SRC_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
case "$SRC_DIR" in
    */.gemini/*) HOME="${SRC_DIR%%/.gemini/*}" ;;
    *) HOME="${HOME:-/data/user/0/com.agy/files}" ;;
esac
PREFIX="${PREFIX:-$HOME/usr}"
CONFIG_DIR="$HOME/.gemini/config"
TARGET_DIR="$CONFIG_DIR/plugins/agy-video-studio"

mkdir -p "$CONFIG_DIR/plugins"

if [ "$SRC_DIR" != "$TARGET_DIR" ]; then
    rm -rf "$TARGET_DIR"
    mkdir -p "$TARGET_DIR"
    cp -Rf "$SRC_DIR"/. "$TARGET_DIR"/
fi

chmod 0755 \
    "$TARGET_DIR/install-plugin.sh" \
    "$TARGET_DIR/mcp/bin/start-mcp.sh" \
    "$TARGET_DIR/mcp/bin/agy-video-mcp" \
    "$TARGET_DIR/mcp/bin/agy-video-setup"

rm -f "$PREFIX/bin/agy-video-mcp" "$PREFIX/bin/agy-video-setup" 2>/dev/null || true

WRAP_DIR="$HOME/runtime/bin"
[ -d "$WRAP_DIR" ] || WRAP_DIR="$PREFIX/bin"
if [ -d "$WRAP_DIR" ]; then
    rm -f "$WRAP_DIR/agy-video-mcp" "$WRAP_DIR/agy-video-setup" 2>/dev/null || true
    cat > "$WRAP_DIR/agy-video-mcp" <<EOF
#!/system/bin/sh
export HOME="${HOME}"
export PREFIX="${PREFIX}"
exec "$TARGET_DIR/mcp/bin/start-mcp.sh" "\$@"
EOF
    cat > "$WRAP_DIR/agy-video-setup" <<EOF
#!/system/bin/sh
export HOME="${HOME}"
export PREFIX="${PREFIX}"
exec /system/bin/sh "$TARGET_DIR/mcp/bin/agy-video-setup" "\$@"
EOF
    chmod 0755 "$WRAP_DIR/agy-video-mcp" "$WRAP_DIR/agy-video-setup"
fi

APP_BIN="$HOME/.gemini/antigravity-app/bin"
mkdir -p "$APP_BIN" 2>/dev/null || true
if [ -d "$APP_BIN" ]; then
    ln -snf "$TARGET_DIR/mcp/bin/agy-video-setup" "$APP_BIN/agy-video-setup" 2>/dev/null || true
fi

echo "============================================================"
echo " AGY Video Studio v2.1.3 installed in Antigravity Android!"
echo " Location: $TARGET_DIR"
echo " Next step: run 'agy-video-setup' once to verify ARM64 deps."
echo "============================================================"
