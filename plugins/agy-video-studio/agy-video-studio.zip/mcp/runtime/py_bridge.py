#!/usr/bin/env python3
"""Internal 2D Pillow/FFmpeg/CapCut/Shizuku helper invoked on-demand by Native Rust agy-video-mcp v3.0.0."""
from __future__ import annotations

import json
import sys
from pathlib import Path

MCP_DIR = Path(__file__).resolve().parent.parent
if str(MCP_DIR) not in sys.path:
    sys.path.insert(0, str(MCP_DIR))

from lib.android_bridge import (
    android_media_and_intent,
    android_screen_record,
    android_ui_action,
    android_ui_inspect,
)
from lib.autocut_engine import probe_video_extended, smart_autocut
from lib.capcut_bridge import export_capcut_draft, list_capcut_drafts
from lib.code_screen_engine import render_code_screen
from lib.env_utils import find_ffmpeg
from lib.keynote_engine import render_keynote_trailer, render_viral_tiktok
from lib.universal_engine import render_universal_edit, run_video_utility_ops


def main() -> None:
    tool_name = sys.argv[1]
    args = json.loads(sys.stdin.read() or "{}")

    def req_ff() -> str:
        ff = find_ffmpeg()
        if not ff:
            raise RuntimeError("ffmpeg not found. Run 'agy-video-setup' to install native ARM64 ffmpeg.")
        return ff

    if tool_name == "video_probe_and_scenes":
        res = probe_video_extended(
            req_ff(),
            args["video_path"],
            scene_threshold=float(args.get("scene_threshold", 0.20)),
            min_freeze_sec=float(args.get("min_freeze_sec", 0.65)),
            min_silence_sec=float(args.get("min_silence_sec", 0.55)),
        )
    elif tool_name == "video_smart_autocut":
        res = smart_autocut(req_ff(), args)
    elif tool_name == "video_universal_edit":
        res = render_universal_edit(req_ff(), args)
    elif tool_name == "video_utility_ops":
        res = run_video_utility_ops(req_ff(), args)
    elif tool_name in ("video_keynote_trailer", "video_render_keynote_trailer"):
        res = render_keynote_trailer(req_ff(), args)
    elif tool_name == "video_render_viral_tiktok":
        res = render_viral_tiktok(req_ff(), args)
    elif tool_name == "video_render_code_screen":
        res = render_code_screen(req_ff(), args)
    elif tool_name == "capcut_android_list_drafts":
        res = list_capcut_drafts()
    elif tool_name == "capcut_export_draft":
        res = export_capcut_draft(find_ffmpeg(), args)
    elif tool_name == "android_screen_record":
        res = android_screen_record(args)
    elif tool_name == "android_ui_inspect":
        res = android_ui_inspect(args)
    elif tool_name == "android_ui_action":
        res = android_ui_action(args)
    elif tool_name == "android_media_and_intent":
        res = android_media_and_intent(args)
    else:
        raise ValueError(f"Unsupported py_bridge tool: {tool_name}")

    sys.stdout.write(json.dumps(res))
    sys.stdout.flush()


if __name__ == "__main__":
    main()
