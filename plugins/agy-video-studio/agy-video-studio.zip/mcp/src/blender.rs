// blender.rs — Native Rust ARM64 Bare-Metal Blender 5.0 Headless Engine (Cycles + OpenImageDenoise + GPU h264_mediacodec)
use crate::json::JsonVal;
use crate::{call_py_bridge, EnvPaths};
use std::fs;
use std::path::{Path, PathBuf};
use std::process::Command;
use std::time::Instant;

const BPY_SCENE_DRIVER: &str = r#"
import bpy
import bmesh
import json
import math
import os
import random
from mathutils import Vector, Euler

CFG = json.loads(os.environ["AGY_BLENDER_CFG_JSON"])

def clear_scene():
    bpy.ops.wm.read_factory_settings(use_empty=True)

def ensure_nodes_mat(mat):
    if getattr(mat, "node_tree", None) is None:
        mat.use_nodes = True
    return mat.node_tree

def ensure_nodes_world(world):
    if getattr(world, "node_tree", None) is None:
        world.use_nodes = True
    return world.node_tree

def set_bsdf(bsdf, names, value):
    for n in names:
        if n in bsdf.inputs:
            bsdf.inputs[n].default_value = value
            return

def make_mat(name, base_rgba=(0.8, 0.8, 0.8, 1.0), roughness=0.35, metallic=0.0, emission_rgba=None, emission_strength=0.0):
    mat = bpy.data.materials.new(name=name)
    nt = ensure_nodes_mat(mat)
    bsdf = nt.nodes.get("Principled BSDF")
    if not bsdf:
        bsdf = nt.nodes.new("ShaderNodeBsdfPrincipled")
    set_bsdf(bsdf, ["Base Color"], base_rgba)
    set_bsdf(bsdf, ["Roughness"], roughness)
    set_bsdf(bsdf, ["Metallic"], metallic)
    if emission_rgba is not None and emission_strength > 0.0:
        set_bsdf(bsdf, ["Emission Color", "Emission"], emission_rgba)
        set_bsdf(bsdf, ["Emission Strength"], emission_strength)
    return mat

def make_screen_mat(name, media_path, total_frames, strength=1.85):
    mat = bpy.data.materials.new(name=name)
    nt = ensure_nodes_mat(mat)
    nt.nodes.clear()
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    em = nt.nodes.new("ShaderNodeEmission")
    em.inputs["Strength"].default_value = strength
    nt.links.new(em.outputs["Emission"], out.inputs["Surface"])

    if media_path and os.path.exists(media_path):
        coord = nt.nodes.new("ShaderNodeTexCoord")
        tex = nt.nodes.new("ShaderNodeTexImage")
        if os.path.isdir(media_path):
            # PNG image sequence directory (100% reliable OpenImageIO in Cycles!)
            first_png = os.path.join(media_path, "scr_0001.png")
            if os.path.isfile(first_png):
                img = bpy.data.images.load(first_png, check_existing=True)
                img.source = 'SEQUENCE'
                tex.image = img
                tex.image_user.use_auto_refresh = True
                tex.image_user.frame_duration = max(1, int(total_frames))
                tex.image_user.frame_start = 1
                tex.image_user.frame_offset = 0
        else:
            img = bpy.data.images.load(media_path, check_existing=True)
            tex.image = img
        tex.extension = "CLIP"
        nt.links.new(coord.outputs["UV"], tex.inputs["Vector"])
        nt.links.new(tex.outputs["Color"], em.inputs["Color"])
    else:
        em.inputs["Color"].default_value = (0.04, 0.08, 0.16, 1.0)
    return mat

def make_tiled_image_mat(name, img_path, scale_xy=(4.5, 2.5), roughness=0.86):
    mat = bpy.data.materials.new(name=name)
    nt = ensure_nodes_mat(mat)
    bsdf = nt.nodes.get("Principled BSDF")
    set_bsdf(bsdf, ["Roughness"], roughness)
    if img_path and os.path.isfile(img_path):
        coord = nt.nodes.new("ShaderNodeTexCoord")
        mapping = nt.nodes.new("ShaderNodeMapping")
        mapping.inputs["Rotation"].default_value = (0.0, 0.0, math.radians(90.0))
        mapping.inputs["Scale"].default_value = (scale_xy[0], scale_xy[1], 1.0)
        tex = nt.nodes.new("ShaderNodeTexImage")
        tex.image = bpy.data.images.load(img_path, check_existing=True)
        nt.links.new(coord.outputs["UV"], mapping.inputs["Vector"])
        nt.links.new(mapping.outputs["Vector"], tex.inputs["Vector"])
        nt.links.new(tex.outputs["Color"], bsdf.inputs["Base Color"])
    else:
        set_bsdf(bsdf, ["Base Color"], (0.76, 0.66, 0.36, 1.0))
    return mat

def create_beveled_box_mesh(name, sx, sy, sz, bevel_amt=0.005, segments=1, smooth=False):
    mesh = bpy.data.meshes.new(name)
    bm = bmesh.new()
    bmesh.ops.create_cube(bm, size=1.0)
    for v in bm.verts:
        v.co.x *= sx
        v.co.y *= sy
        v.co.z *= sz
    if bevel_amt > 0:
        bmesh.ops.bevel(bm, geom=list(bm.edges), offset=bevel_amt, segments=segments, affect='EDGES')
    bmesh.ops.recalc_face_normals(bm, faces=list(bm.faces))
    bm.to_mesh(mesh)
    bm.free()
    for poly in mesh.polygons:
        poly.use_smooth = smooth
    return mesh

def add_mesh_obj(name, mesh, mat, loc=(0,0,0), rot=(0,0,0), parent=None):
    obj = bpy.data.objects.new(name, mesh)
    obj.location = loc
    obj.rotation_euler = rot
    bpy.context.collection.objects.link(obj)
    if mat is not None:
        if len(obj.data.materials) == 0:
            obj.data.materials.append(mat)
        obj.material_slots[0].link = 'OBJECT'
        obj.material_slots[0].material = mat
    if parent is not None:
        obj.parent = parent
    return obj

def build_voxel_mascot(prefix, location=(0,0,0), rotation_z=0.0, scale=1.0, body_rgba=(0.83, 0.36, 0.19, 1.0), eye_rgba=(1.0, 0.78, 0.52, 1.0), eye_strength=16.0):
    root = bpy.data.objects.new(f"{prefix}_Root", None)
    root.location = location
    root.rotation_euler = (0.0, 0.0, rotation_z)
    root.scale = (scale, scale, scale)
    bpy.context.collection.objects.link(root)

    step = 0.072
    c_sz = 0.0685
    mat_body = make_mat(f"{prefix}_BodyMat", base_rgba=body_rgba, roughness=0.32, metallic=0.04)
    mat_foot = make_mat(f"{prefix}_FootMat", base_rgba=(0.95, 0.95, 0.98, 1.0), roughness=0.25, emission_rgba=(1.0, 0.95, 0.9, 1.0), emission_strength=2.5)
    mat_eye = make_mat(f"{prefix}_EyeMat", base_rgba=eye_rgba, roughness=0.12, emission_rgba=eye_rgba, emission_strength=eye_strength)

    torso_mesh = bpy.data.meshes.new(f"{prefix}_TorsoMesh")
    bm = bmesh.new()

    nx, ny, nz = 11, 6, 8
    for ix in range(nx):
        for iy in range(ny):
            for iz in range(nz):
                if 0 < ix < nx - 1 and 0 < iy < ny - 1 and 0 < iz < nz - 1:
                    continue
                if iy == 0 and iz in (3, 4, 5) and (ix in (2, 3) or ix in (7, 8)):
                    continue
                res = bmesh.ops.create_cube(bm, size=c_sz)
                cx = (ix - (nx - 1) / 2.0) * step
                cy = (iy - (ny - 1) / 2.0) * step
                cz = (iz + 2.5) * step
                bmesh.ops.translate(bm, verts=res["verts"], vec=(cx, cy, cz))

    bmesh.ops.bevel(bm, geom=list(bm.edges), offset=0.0038, segments=1, affect='EDGES')
    bmesh.ops.recalc_face_normals(bm, faces=list(bm.faces))
    bm.to_mesh(torso_mesh)
    bm.free()
    for p in torso_mesh.polygons:
        p.use_smooth = False

    torso_obj = add_mesh_obj(f"{prefix}_Torso", torso_mesh, mat_body, (0, 0, 0), parent=root)

    eye_mesh = create_beveled_box_mesh(f"{prefix}_EyeBlock", step * 1.94, step * 0.95, step * 2.88, bevel_amt=0.004)
    front_y = -(ny - 1) / 2.0 * step - 0.012
    eye_z = (4.0 + 2.5) * step
    left_eye = add_mesh_obj(f"{prefix}_EyeL", eye_mesh, mat_eye, (-2.5 * step, front_y, eye_z), parent=root)
    right_eye = add_mesh_obj(f"{prefix}_EyeR", eye_mesh, mat_eye, (2.5 * step, front_y, eye_z), parent=root)

    arm_mesh = create_beveled_box_mesh(f"{prefix}_ArmMesh", step * 1.85, step * 2.7, step * 2.7, bevel_amt=0.008)
    arm_x = ((nx - 1) / 2.0 + 1.35) * step
    arm_z = (3.8 + 2.5) * step
    left_arm = add_mesh_obj(f"{prefix}_ArmL", arm_mesh, mat_body, (-arm_x, 0.0, arm_z), parent=root)
    right_arm = add_mesh_obj(f"{prefix}_ArmR", arm_mesh, mat_body, (arm_x, 0.0, arm_z), parent=root)

    leg_mesh = create_beveled_box_mesh(f"{prefix}_LegMesh", step * 1.75, step * 1.75, step * 2.2, bevel_amt=0.007)
    toe_mesh = create_beveled_box_mesh(f"{prefix}_ToeMesh", step * 0.85, step * 0.85, step * 0.65, bevel_amt=0.004)
    legs = []
    for lx_s, ly_s, tag in ((-3.2, -1.5, "FL"), (3.2, -1.5, "FR"), (-3.2, 1.5, "BL"), (3.2, 1.5, "BR")):
        leg = add_mesh_obj(f"{prefix}_Leg_{tag}", leg_mesh, mat_body, (lx_s * step, ly_s * step, 1.3 * step), parent=root)
        if tag in ("FL", "FR"):
            add_mesh_obj(f"{prefix}_Toe_{tag}", toe_mesh, mat_foot, (0.3 * step, -0.4 * step, -0.95 * step), parent=leg)
        legs.append(leg)

    return {
        "root": root,
        "torso": torso_obj,
        "eye_l": left_eye,
        "eye_r": right_eye,
        "arm_l": left_arm,
        "arm_r": right_arm,
        "legs": legs,
        "mat_body": mat_body,
    }

def animate_mascot(m, total_frames, fps, action="typing_bounce", eye_expr="normal"):
    root = m["root"]
    eye_l, eye_r = m["eye_l"], m["eye_r"]
    arm_l, arm_r = m["arm_l"], m["arm_r"]
    legs = m["legs"]
    base_loc = Vector(root.location)
    base_rot = Euler(root.rotation_euler)

    ez_scale = 1.0
    if eye_expr == "squint":
        ez_scale = 0.28
    elif eye_expr == "confident":
        ez_scale = 0.62
    elif eye_expr == "wide_shock":
        ez_scale = 1.28

    for f in range(1, total_frames + 1):
        t = (f - 1) / float(max(1, fps))
        prog = (f - 1) / float(max(1, total_frames - 1))

        if action == "typing_bounce":
            hop = abs(math.sin(t * 9.5)) * 0.045
            tilt = math.sin(t * 9.5) * 0.06
            root.location = (base_loc.x, base_loc.y, base_loc.z + hop)
            root.rotation_euler = (base_rot.x + 0.04, base_rot.y + tilt, base_rot.z)
            arm_l.rotation_euler = (math.sin(t * 18.0) * 0.45, 0, 0)
            arm_r.rotation_euler = (-math.sin(t * 18.0) * 0.45, 0, 0)
            for idx, lg in enumerate(legs):
                lg.location.z = 0.093 + (0.022 * math.sin(t * 18.0 + idx * 1.5))
        elif action == "retry_panic":
            shake_x = math.sin(t * 28.0) * 0.035
            hop = abs(math.sin(t * 14.0)) * 0.07
            root.location = (base_loc.x + shake_x, base_loc.y, base_loc.z + hop)
            arm_l.rotation_euler = (0, 0, 0.55 + math.sin(t * 26.0) * 0.55)
            arm_r.rotation_euler = (0, 0, -0.55 - math.sin(t * 26.0) * 0.55)
        elif action == "walk_forward":
            walk_dist = float(CFG.get("walk_distance", 1.55))
            ang = base_rot.z
            dx = -math.sin(ang) * walk_dist * prog
            dy = -math.cos(ang) * walk_dist * prog
            bob = abs(math.sin(t * 7.5)) * 0.042
            root.location = (base_loc.x + dx, base_loc.y + dy, base_loc.z + bob)
            root.rotation_euler = (base_rot.x, math.sin(t * 7.5) * 0.05, base_rot.z)
            for idx, lg in enumerate(legs):
                phase = 0.0 if idx in (0, 3) else math.pi
                lg.rotation_euler = (math.sin(t * 7.5 + phase) * 0.42, 0, 0)
        elif action == "look_screen_then_camera":
            turn_p = max(0.0, min(1.0, (prog - 0.25) / 0.35))
            smooth = turn_p * turn_p * (3.0 - 2.0 * turn_p)
            root.rotation_euler = (base_rot.x, 0.0, base_rot.z * (1.0 - smooth))
            root.location = (base_loc.x, base_loc.y, base_loc.z + math.sin(smooth * math.pi) * 0.06)
        else:
            root.location = (base_loc.x, base_loc.y, base_loc.z + math.sin(t * 3.2) * 0.015)

        blink = 0.12 if (0.82 <= prog <= 0.86) else ez_scale
        eye_l.scale = (1.0, 1.0, blink)
        eye_r.scale = (1.0, 1.0, blink)

        root.keyframe_insert(data_path="location", frame=f)
        root.keyframe_insert(data_path="rotation_euler", frame=f)
        arm_l.keyframe_insert(data_path="rotation_euler", frame=f)
        arm_r.keyframe_insert(data_path="rotation_euler", frame=f)
        eye_l.keyframe_insert(data_path="scale", frame=f)
        eye_r.keyframe_insert(data_path="scale", frame=f)
        for lg in legs:
            lg.keyframe_insert(data_path="location", frame=f)
            lg.keyframe_insert(data_path="rotation_euler", frame=f)

    if bool(CFG.get("glitch_dissolve_end", False)):
        bsdf = m["mat_body"].node_tree.nodes.get("Principled BSDF")
        if bsdf and "Emission Strength" in bsdf.inputs:
            g_frame = max(1, int(total_frames * 0.72))
            set_bsdf(bsdf, ["Emission Color", "Emission"], (1.0, 1.0, 1.0, 1.0))
            bsdf.inputs["Emission Strength"].default_value = 0.0
            bsdf.inputs["Emission Strength"].keyframe_insert(data_path="default_value", frame=g_frame)
            bsdf.inputs["Emission Strength"].default_value = 24.0
            bsdf.inputs["Emission Strength"].keyframe_insert(data_path="default_value", frame=total_frames)

def add_area_light(name, loc, rot_deg, energy, size=1.8, color=(1.0, 1.0, 1.0)):
    ldata = bpy.data.lights.new(name=name, type='AREA')
    ldata.energy = energy
    ldata.size = size
    ldata.color = color
    lobj = bpy.data.objects.new(name, ldata)
    lobj.location = loc
    lobj.rotation_euler = tuple(math.radians(a) for a in rot_deg)
    bpy.context.collection.objects.link(lobj)
    return lobj

def add_3d_text(name, text_str, loc, rot_deg=(90, 0, 0), size=0.22, extrude=0.018, mat=None, align_x='CENTER'):
    curve = bpy.data.curves.new(type="FONT", name=f"{name}_Curve")
    curve.body = text_str
    curve.size = size
    curve.extrude = extrude
    curve.bevel_depth = 0.0005
    curve.align_x = align_x
    font_path = CFG.get("font_bold_path")
    if font_path and os.path.isfile(font_path):
        try:
            curve.font = bpy.data.fonts.load(font_path)
        except Exception:
            pass
    tobj = bpy.data.objects.new(name, curve)
    tobj.location = loc
    tobj.rotation_euler = tuple(math.radians(a) for a in rot_deg)
    if mat:
        tobj.data.materials.append(mat)
    bpy.context.collection.objects.link(tobj)
    return tobj

def build_scene_voxel_coder_laptop(total_frames, fps):
    world = bpy.data.worlds.new("StudioWorld")
    bpy.context.scene.world = world
    nt_w = ensure_nodes_world(world)
    bg = nt_w.nodes.get("Background")
    if bg:
        bg.inputs[0].default_value = (0.005, 0.006, 0.010, 1.0)
        bg.inputs[1].default_value = 0.6

    mat_desk = make_mat("DeskMat", base_rgba=(0.055, 0.036, 0.024, 1.0), roughness=0.28, metallic=0.05)
    desk_mesh = create_beveled_box_mesh("DeskMesh", 9.0, 7.0, 0.12, bevel_amt=0.01)
    add_mesh_obj("Desk", desk_mesh, mat_desk, (0, 0.4, -0.06))

    mat_alu = make_mat("LaptopAlu", base_rgba=(0.045, 0.048, 0.058, 1.0), roughness=0.26, metallic=0.82)
    mat_key = make_mat("KeycapMat", base_rgba=(0.022, 0.024, 0.030, 1.0), roughness=0.38, metallic=0.25)
    mat_pad = make_mat("TrackpadMat", base_rgba=(0.065, 0.070, 0.082, 1.0), roughness=0.18, metallic=0.70)

    base_w, base_d, base_h = 2.55, 1.72, 0.075
    base_mesh = create_beveled_box_mesh("LaptopBaseMesh", base_w, base_d, base_h, bevel_amt=0.014, segments=3)
    add_mesh_obj("LaptopBase", base_mesh, mat_alu, (0, 0, base_h / 2.0))

    pad_mesh = create_beveled_box_mesh("PadMesh", 0.78, 0.46, 0.012, bevel_amt=0.004)
    add_mesh_obj("Trackpad", pad_mesh, mat_pad, (0, -0.50, base_h + 0.002))

    kb_mesh = bpy.data.meshes.new("KeyboardKeysMesh")
    bm = bmesh.new()
    cols, rows = 14, 5
    kw, kd, kh = 0.142, 0.132, 0.024
    for r in range(rows):
        for c in range(cols):
            res = bmesh.ops.create_cube(bm, size=1.0)
            for v in res["verts"]:
                v.co.x *= kw
                v.co.y *= kd
                v.co.z *= kh
            kx = (c - (cols - 1) / 2.0) * 0.158
            ky = 0.02 + r * 0.150
            kz = base_h + kh / 2.0
            bmesh.ops.translate(bm, verts=res["verts"], vec=(kx, ky, kz))
    bmesh.ops.bevel(bm, geom=list(bm.edges), offset=0.004, segments=2, affect='EDGES')
    bmesh.ops.recalc_face_normals(bm, faces=list(bm.faces))
    bm.to_mesh(kb_mesh)
    bm.free()
    for p in kb_mesh.polygons:
        p.use_smooth = True
    add_mesh_obj("KeyboardKeys", kb_mesh, mat_key, (0, 0, 0))

    lid_pivot = bpy.data.objects.new("LidPivot", None)
    lid_pivot.location = (0, base_d / 2.0 - 0.04, base_h)
    lid_pivot.rotation_euler = (math.radians(-14.0), 0, 0)
    bpy.context.collection.objects.link(lid_pivot)

    scr_h = 1.62
    lid_mesh = create_beveled_box_mesh("LidMesh", base_w, 0.045, scr_h, bevel_amt=0.012, segments=2)
    add_mesh_obj("LaptopLid", lid_mesh, mat_alu, (0, 0, scr_h / 2.0), parent=lid_pivot)

    scr_w_inner = base_w - 0.14
    scr_h_inner = scr_h - 0.14
    bpy.ops.mesh.primitive_plane_add(size=1.0, location=(0, -0.026, scr_h / 2.0), rotation=(math.radians(90), 0, 0))
    scr_plane = bpy.context.active_object
    scr_plane.name = "LaptopScreen"
    scr_plane.scale = (scr_w_inner, scr_h_inner, 1.0)
    scr_plane.parent = lid_pivot
    scr_mat = make_screen_mat("ScreenEmissiveMat", CFG.get("screen_media_path"), total_frames, strength=float(CFG.get("screen_emission", 2.1)))
    scr_plane.data.materials.append(scr_mat)

    bpy.ops.mesh.primitive_cylinder_add(vertices=32, radius=0.22, depth=0.46, location=(1.78, 0.32, 0.23))
    mug = bpy.context.active_object
    mug.data.materials.append(make_mat("MugMat", base_rgba=(0.03, 0.032, 0.04, 1.0), roughness=0.14, metallic=0.3))
    for p in mug.data.polygons:
        p.use_smooth = True

    rng = random.Random(42)
    star_mat = make_mat("StarMat", emission_rgba=(0.88, 0.92, 1.0, 1.0), emission_strength=9.0)
    star_mesh = create_beveled_box_mesh("StarMesh", 0.035, 0.035, 0.035, bevel_amt=0.008)
    for idx in range(36):
        sx = rng.uniform(-4.5, 4.5)
        sy = rng.uniform(2.0, 5.5)
        sz = rng.uniform(0.2, 2.8)
        add_mesh_obj(f"Star_{idx}", star_mesh, star_mat, (sx, sy, sz))

    floating_title = str(CFG.get("floating_title", "")).strip()
    if floating_title:
        t_mat = make_mat("TitleMat", emission_rgba=(0.98, 0.98, 1.0, 1.0), emission_strength=4.5)
        add_3d_text("FloatingTitle", floating_title, loc=(0.55, 0.45, 1.18), rot_deg=(84, 0, -14), size=0.135, extrude=0.006, mat=t_mat)

    v_col = CFG.get("voxel_rgba") or [0.83, 0.36, 0.19, 1.0]
    face_screen = bool(CFG.get("mascot_face_screen", False))
    rot_z = math.pi if face_screen else math.radians(float(CFG.get("mascot_rot_deg", -14.0)))
    mascot = build_voxel_mascot("ClaudeVoxel", location=(0.05, 0.15, base_h + 0.022), rotation_z=rot_z, scale=0.72, body_rgba=tuple(v_col))
    animate_mascot(
        mascot,
        total_frames=total_frames,
        fps=fps,
        action=str(CFG.get("action", "typing_bounce")),
        eye_expr=str(CFG.get("eye_expression", "normal")),
    )

    add_area_light("KeyLight", loc=(-2.2, -2.4, 2.4), rot_deg=(54, 0, -38), energy=95.0, size=2.2, color=(1.0, 0.88, 0.76))
    add_area_light("RimLight", loc=(2.4, 1.8, 2.2), rot_deg=(58, 0, 142), energy=75.0, size=1.8, color=(0.72, 0.84, 1.0))
    add_area_light("MascotFill", loc=(0.2, -1.6, 0.9), rot_deg=(75, 0, 6), energy=22.0, size=1.2, color=(1.0, 0.78, 0.62))

    cam_data = bpy.data.cameras.new("MainCam")
    cam_obj = bpy.data.objects.new("MainCam", cam_data)
    bpy.context.collection.objects.link(cam_obj)
    bpy.context.scene.camera = cam_obj

    shot = str(CFG.get("camera_shot", "wide_push_in"))
    aspect = CFG["width"] / float(max(1, CFG["height"]))
    cam_data.lens = 36.0 if aspect >= 1.0 else 28.0
    cam_data.dof.use_dof = True
    cam_data.dof.aperture_fstop = 2.8

    target = bpy.data.objects.new("CamTarget", None)
    bpy.context.collection.objects.link(target)
    track = cam_obj.constraints.new(type='TRACK_TO')
    track.target = target
    track.track_axis = 'TRACK_NEGATIVE_Z'
    track.up_axis = 'UP_Y'

    for f in range(1, total_frames + 1):
        p = (f - 1) / float(max(1, total_frames - 1))
        sp = p * p * (3.0 - 2.0 * p)
        if shot == "close_hero":
            cam_obj.location = (0.32 - 0.18 * sp, -1.35 + 0.22 * sp, 0.56 + 0.04 * sp)
            target.location = (0.04, 0.20, 0.44)
            cam_data.dof.focus_distance = 1.45
        elif shot == "over_shoulder_screen":
            cam_obj.location = (0.18 - 0.12 * sp, -1.55 + 0.25 * sp, 0.68 + 0.10 * sp)
            target.location = (0.0, 0.82, 0.82)
            cam_data.dof.focus_distance = 2.15
        else:
            dist_mult = 1.0 if aspect >= 1.0 else 1.32
            cam_obj.location = ((-1.55 + 0.35 * sp) * dist_mult, (-2.85 + 0.55 * sp) * dist_mult, 1.18 - 0.16 * sp)
            target.location = (0.08, 0.32, 0.66)
            cam_data.dof.focus_distance = (cam_obj.location - target.location).length

        cam_obj.keyframe_insert(data_path="location", frame=f)
        target.keyframe_insert(data_path="location", frame=f)


def build_scene_voxel_backrooms(total_frames, fps):
    world = bpy.data.worlds.new("BackroomsWorld")
    bpy.context.scene.world = world
    nt_w = ensure_nodes_world(world)
    bg = nt_w.nodes.get("Background")
    if bg:
        bg.inputs[0].default_value = (0.18, 0.15, 0.07, 1.0)

    mat_wall = make_tiled_image_mat("WallpaperMat", CFG.get("wallpaper_png"), scale_xy=(5.0, 2.5), roughness=0.86)
    mat_floor = make_mat("CarpetMat", base_rgba=(0.48, 0.41, 0.24, 1.0), roughness=0.95)
    mat_ceil = make_mat("CeilMat", base_rgba=(0.76, 0.73, 0.58, 1.0), roughness=0.85)
    mat_lamp = make_mat("FluorescentMat", emission_rgba=(1.0, 0.98, 0.86, 1.0), emission_strength=14.0)
    mat_trim = make_mat("BaseboardMat", base_rgba=(0.24, 0.18, 0.09, 1.0), roughness=0.7)

    bpy.ops.mesh.primitive_plane_add(size=14.0, location=(0, 1.5, 0.0))
    bpy.context.active_object.data.materials.append(mat_floor)

    bpy.ops.mesh.primitive_plane_add(size=14.0, location=(0, 1.5, 2.95), rotation=(math.pi, 0, 0))
    bpy.context.active_object.data.materials.append(mat_ceil)

    panel_mesh = create_beveled_box_mesh("LampPanel", 0.85, 0.45, 0.03, bevel_amt=0.004)
    for lx in (-1.8, 0.0, 1.8):
        for ly in (-0.4, 2.0):
            add_mesh_obj(f"Lamp_{lx}_{ly}", panel_mesh, mat_lamp, (lx, ly, 2.93))
            add_area_light(f"CeilArea_{lx}_{ly}", (lx, ly, 2.86), rot_deg=(0, 0, 0), energy=38.0, size=0.85, color=(1.0, 0.95, 0.78))

    def add_uv_wall(name, sx, sy, sz, loc):
        bpy.ops.mesh.primitive_cube_add(size=1.0, location=loc)
        w = bpy.context.active_object
        w.name = name
        w.scale = (sx, sy, sz)
        bpy.ops.object.transform_apply(scale=True)
        w.data.materials.append(mat_wall)
        return w

    break_door = bool(CFG.get("break_door", False))
    if not break_door:
        add_uv_wall("CenterWall", 2.35, 0.25, 2.95, (0.0, 2.8, 1.475))
    else:
        add_uv_wall("CenterWallL", 0.68, 0.25, 2.95, (-0.83, 2.8, 1.475))
        add_uv_wall("CenterWallR", 0.68, 0.25, 2.95, (0.83, 2.8, 1.475))
        add_uv_wall("CenterWallTop", 1.00, 0.25, 1.45, (0.0, 2.8, 2.225))
        portal_mat = make_mat("PortalGlow", emission_rgba=(1.0, 1.0, 1.0, 1.0), emission_strength=32.0)
        portal_mesh = create_beveled_box_mesh("PortalMesh", 0.96, 0.08, 1.48, bevel_amt=0.005)
        add_mesh_obj("BreakPortal", portal_mesh, portal_mat, (0.0, 2.86, 0.74))
        brk_mat = make_mat("BreakTextMat", emission_rgba=(1.0, 1.0, 1.0, 1.0), emission_strength=12.0)
        add_3d_text("BreakLabel", "break;", loc=(0.0, 2.65, 1.66), rot_deg=(90, 0, 0), size=0.22, extrude=0.015, mat=brk_mat)

    add_uv_wall("LeftFarWall", 1.6, 0.25, 2.95, (-2.95, 2.8, 1.475))
    add_uv_wall("RightFarWall", 1.6, 0.25, 2.95, (2.95, 2.8, 1.475))
    add_uv_wall("BackDeepWall", 9.0, 0.25, 2.95, (0.0, 5.2, 1.475))
    add_uv_wall("SideWallL", 0.25, 8.0, 2.95, (-3.7, 1.5, 1.475))
    add_uv_wall("SideWallR", 0.25, 8.0, 2.95, (3.7, 1.5, 1.475))

    wall_text = str(CFG.get("wall_text", "ATTEMPT 44"))
    mat_gold = make_mat("WallTextMat", base_rgba=(0.36, 0.27, 0.09, 1.0), roughness=0.45)
    text_z = 2.38 if break_door else 1.72
    add_3d_text("AttemptText", wall_text, loc=(0.0, 2.66, text_z), rot_deg=(90, 0, 0), size=0.23, extrude=0.025, mat=mat_gold)

    ctx_fill = max(0.08, min(1.0, float(CFG.get("context_fill", 0.46))))
    bar_bg = create_beveled_box_mesh("CtxBg", 1.10, 0.03, 0.11, bevel_amt=0.004)
    bar_fg = create_beveled_box_mesh("CtxFg", 1.06 * ctx_fill, 0.04, 0.085, bevel_amt=0.004)
    add_mesh_obj("ContextBarBg", bar_bg, mat_trim, (0.12, 2.67, text_z + 0.36))
    mat_red_glow = make_mat("CtxRed", emission_rgba=(1.0, 0.28, 0.22, 1.0), emission_strength=6.5)
    add_mesh_obj("ContextBarFg", bar_fg, mat_red_glow, (0.12 - 0.53 * (1.0 - ctx_fill), 2.66, text_z + 0.36))

    exit_mat = make_mat("ExitGreen", emission_rgba=(0.22, 0.95, 0.48, 1.0), emission_strength=7.5)
    exit_box = create_beveled_box_mesh("ExitBox", 0.46, 0.05, 0.18, bevel_amt=0.006)
    add_mesh_obj("ExitSign", exit_box, exit_mat, (1.65, 2.66, 2.35))

    ghost_count = int(CFG.get("ghost_clones", 4))
    rng = random.Random(77)
    for g_idx in range(ghost_count):
        gx = rng.uniform(-2.4, 2.4)
        gy = rng.uniform(0.6, 2.3)
        if abs(gx) < 0.65 and gy < 1.5:
            gx += 1.15
        g_m = build_voxel_mascot(
            f"Ghost_{g_idx}",
            location=(gx, gy, 0.0),
            rotation_z=rng.uniform(-math.pi, math.pi),
            scale=0.62,
            body_rgba=(0.42, 0.41, 0.38, 1.0),
            eye_rgba=(0.92, 0.95, 1.0, 1.0),
            eye_strength=8.0,
        )
        animate_mascot(g_m, total_frames, fps, action="idle", eye_expr="normal")

    hero_rot = math.pi if break_door else math.radians(float(CFG.get("mascot_rot_deg", 12.0)))
    hero_act = "walk_forward" if break_door else str(CFG.get("action", "idle"))
    hero = build_voxel_mascot("HeroVoxel", location=(0.0, 0.85, 0.0), rotation_z=hero_rot, scale=0.68)
    animate_mascot(hero, total_frames, fps, action=hero_act, eye_expr=str(CFG.get("eye_expression", "wide_shock" if not break_door else "squint")))

    cam_data = bpy.data.cameras.new("BackroomsCam")
    cam_data.lens = 24.0 if (CFG["width"] >= CFG["height"]) else 20.0
    cam_obj = bpy.data.objects.new("BackroomsCam", cam_data)
    bpy.context.collection.objects.link(cam_obj)
    bpy.context.scene.camera = cam_obj

    target = bpy.data.objects.new("BrTarget", None)
    bpy.context.collection.objects.link(target)
    track = cam_obj.constraints.new(type='TRACK_TO')
    track.target = target
    track.track_axis = 'TRACK_NEGATIVE_Z'
    track.up_axis = 'UP_Y'

    for f in range(1, total_frames + 1):
        p = (f - 1) / float(max(1, total_frames - 1))
        sp = p * p * (3.0 - 2.0 * p)
        cam_obj.location = (0.15 * math.sin(p * 3.14), -1.65 + 0.55 * sp, 0.48 + 0.06 * sp)
        target.location = (0.0, 1.85, 0.85 if break_door else 1.05)
        cam_obj.keyframe_insert(data_path="location", frame=f)
        target.keyframe_insert(data_path="location", frame=f)


def build_scene_studio_pedestal(total_frames, fps):
    world = bpy.data.worlds.new("PedestalWorld")
    bpy.context.scene.world = world
    nt_w = ensure_nodes_world(world)
    bg = nt_w.nodes.get("Background")
    if bg:
        bg.inputs[0].default_value = (0.012, 0.014, 0.022, 1.0)

    mat_floor = make_mat("StudioFloor", base_rgba=(0.03, 0.035, 0.048, 1.0), roughness=0.18, metallic=0.35)
    bpy.ops.mesh.primitive_plane_add(size=16.0, location=(0, 0, 0))
    bpy.context.active_object.data.materials.append(mat_floor)

    bpy.ops.mesh.primitive_cylinder_add(vertices=64, radius=0.95, depth=0.18, location=(0, 0, 0.09))
    ped = bpy.context.active_object
    ped.data.materials.append(make_mat("PedestalMat", base_rgba=(0.06, 0.065, 0.085, 1.0), roughness=0.22, metallic=0.75))

    glb_path = CFG.get("glb_path")
    if glb_path and os.path.isfile(glb_path):
        bpy.ops.import_scene.gltf(filepath=glb_path)
    else:
        hero = build_voxel_mascot("PedestalHero", location=(0, 0, 0.18), rotation_z=0.0, scale=0.88)
        for f in range(1, total_frames + 1):
            p = (f - 1) / float(max(1, total_frames - 1))
            hero["root"].rotation_euler = (0, 0, p * math.pi * 2.0)
            hero["root"].keyframe_insert(data_path="rotation_euler", frame=f)

    title = str(CFG.get("floating_title", "")).strip()
    if title:
        tmat = make_mat("PedTitleMat", emission_rgba=(0.85, 0.92, 1.0, 1.0), emission_strength=4.0)
        add_3d_text("PedTitle", title, loc=(0, 1.35, 1.45), rot_deg=(90, 0, 0), size=0.24, extrude=0.015, mat=tmat)

    add_area_light("PedKey", (-2.4, -2.4, 2.8), (52, 0, -42), 120.0, 2.4, (1.0, 0.92, 0.84))
    add_area_light("PedRim", (2.4, 2.0, 2.4), (56, 0, 140), 95.0, 2.0, (0.65, 0.82, 1.0))

    cam_data = bpy.data.cameras.new("PedCam")
    cam_data.lens = 40.0 if CFG["width"] >= CFG["height"] else 30.0
    cam_obj = bpy.data.objects.new("PedCam", cam_data)
    cam_obj.location = (0, -3.4, 1.25)
    cam_obj.rotation_euler = (math.radians(74), 0, 0)
    bpy.context.collection.objects.link(cam_obj)
    bpy.context.scene.camera = cam_obj


clear_scene()
fps = int(CFG["fps"])
total_frames = int(CFG["total_frames"])
preset = CFG["preset"]

if preset == "custom_bpy":
    custom_code = CFG["custom_bpy_code"]
    exec(compile(custom_code, "<custom_bpy_script>", "exec"), globals(), globals())
elif preset == "voxel_backrooms_loop":
    build_scene_voxel_backrooms(total_frames, fps)
elif preset == "studio_pedestal_3d":
    build_scene_studio_pedestal(total_frames, fps)
else:
    build_scene_voxel_coder_laptop(total_frames, fps)

scene = bpy.context.scene
scene.render.engine = 'CYCLES'
scene.cycles.device = 'CPU'
scene.cycles.samples = int(CFG["samples"])
scene.cycles.use_adaptive_sampling = True
scene.cycles.adaptive_threshold = 0.05
scene.cycles.use_denoising = bool(CFG.get("use_denoising", True))
if scene.cycles.use_denoising:
    scene.cycles.denoiser = 'OPENIMAGEDENOISE'
    if hasattr(scene.cycles, "denoising_prefilter"):
        scene.cycles.denoising_prefilter = 'FAST'
scene.cycles.max_bounces = 3
scene.cycles.diffuse_bounces = 1
scene.cycles.glossy_bounces = 2
scene.cycles.transmission_bounces = 2
scene.cycles.volume_bounces = 0
scene.render.use_persistent_data = True

scene.render.resolution_x = int(CFG["width"])
scene.render.resolution_y = int(CFG["height"])
scene.render.resolution_percentage = 100
scene.render.fps = fps
scene.frame_start = 1
scene.frame_end = total_frames
scene.render.image_settings.file_format = 'PNG'
scene.render.image_settings.color_mode = 'RGB'

def export_glb_seccomp_safe(filepath):
    """Pure-Python IEEE-754 Binary glTF 2.0 (.glb) exporter immune to Android seccomp OpenBLAS SIGSYS."""
    import struct
    deps = bpy.context.evaluated_depsgraph_get()
    bin_chunks = bytearray()
    buffer_views = []
    accessors = []
    meshes = []
    nodes = []
    materials = [{"pbrMetallicRoughness": {"baseColorFactor": [0.83, 0.36, 0.19, 1.0], "roughnessFactor": 0.35, "metallicFactor": 0.05}}]
    mat_map = {}

    def get_mat_idx(obj):
        if len(obj.material_slots) == 0 or obj.material_slots[0].material is None:
            return 0
        m = obj.material_slots[0].material
        if m.name in mat_map:
            return mat_map[m.name]
        base = [0.8, 0.8, 0.8, 1.0]
        rough = 0.4
        metal = 0.0
        emiss = [0.0, 0.0, 0.0]
        if getattr(m, "node_tree", None):
            bsdf = m.node_tree.nodes.get("Principled BSDF")
            if bsdf:
                if "Base Color" in bsdf.inputs:
                    c = bsdf.inputs["Base Color"].default_value
                    base = [float(c[0]), float(c[1]), float(c[2]), float(c[3])]
                if "Roughness" in bsdf.inputs:
                    rough = float(bsdf.inputs["Roughness"].default_value)
                if "Metallic" in bsdf.inputs:
                    metal = float(bsdf.inputs["Metallic"].default_value)
                estr = float(bsdf.inputs["Emission Strength"].default_value) if "Emission Strength" in bsdf.inputs else 0.0
                if estr > 0.0:
                    ename = "Emission Color" if "Emission Color" in bsdf.inputs else "Emission"
                    if ename in bsdf.inputs:
                        ec = bsdf.inputs[ename].default_value
                        emiss = [min(1.0, float(ec[0]) * min(1.0, estr / 8.0)), min(1.0, float(ec[1]) * min(1.0, estr / 8.0)), min(1.0, float(ec[2]) * min(1.0, estr / 8.0))]
        idx = len(materials)
        materials.append({
            "name": m.name,
            "pbrMetallicRoughness": {"baseColorFactor": base, "roughnessFactor": rough, "metallicFactor": metal},
            "emissiveFactor": emiss,
        })
        mat_map[m.name] = idx
        return idx

    for obj in bpy.context.scene.objects:
        if obj.type not in ('MESH', 'FONT', 'CURVE') or obj.hide_render:
            continue
        eval_obj = obj.evaluated_get(deps)
        try:
            me = eval_obj.to_mesh()
        except Exception:
            continue
        if me is None or len(me.polygons) == 0:
            continue
        me.calc_loop_triangles()
        if len(me.loop_triangles) == 0:
            eval_obj.to_mesh_clear()
            continue

        # Convert Blender Z-up world coords -> glTF Y-up (x, z, -y)
        mw = eval_obj.matrix_world
        verts_gl = []
        min_v = [1e9, 1e9, 1e9]
        max_v = [-1e9, -1e9, -1e9]
        for v in me.vertices:
            wv = mw @ v.co
            gx, gy, gz = float(wv.x), float(wv.z), float(-wv.y)
            verts_gl.extend((gx, gy, gz))
            if gx < min_v[0]: min_v[0] = gx
            if gy < min_v[1]: min_v[1] = gy
            if gz < min_v[2]: min_v[2] = gz
            if gx > max_v[0]: max_v[0] = gx
            if gy > max_v[1]: max_v[1] = gy
            if gz > max_v[2]: max_v[2] = gz

        indices = []
        for tri in me.loop_triangles:
            indices.extend((int(tri.vertices[0]), int(tri.vertices[1]), int(tri.vertices[2])))

        v_count = len(me.vertices)
        i_count = len(indices)
        eval_obj.to_mesh_clear()

        v_bytes = struct.pack(f"<{len(verts_gl)}f", *verts_gl)
        i_bytes = struct.pack(f"<{len(indices)}I", *indices)

        while len(bin_chunks) % 4 != 0:
            bin_chunks.append(0)
        v_off = len(bin_chunks)
        bin_chunks.extend(v_bytes)
        bv_pos = len(buffer_views)
        buffer_views.append({"buffer": 0, "byteOffset": v_off, "byteLength": len(v_bytes), "target": 34962})
        acc_pos = len(accessors)
        accessors.append({"bufferView": bv_pos, "componentType": 5126, "count": v_count, "type": "VEC3", "min": min_v, "max": max_v})

        while len(bin_chunks) % 4 != 0:
            bin_chunks.append(0)
        i_off = len(bin_chunks)
        bin_chunks.extend(i_bytes)
        bv_idx = len(buffer_views)
        buffer_views.append({"buffer": 0, "byteOffset": i_off, "byteLength": len(i_bytes), "target": 34963})
        acc_idx = len(accessors)
        accessors.append({"bufferView": bv_idx, "componentType": 5125, "count": i_count, "type": "SCALAR"})

        m_idx = len(meshes)
        meshes.append({"name": obj.name, "primitives": [{"attributes": {"POSITION": acc_pos}, "indices": acc_idx, "material": get_mat_idx(obj)}]})
        nodes.append({"name": obj.name, "mesh": m_idx})

    while len(bin_chunks) % 4 != 0:
        bin_chunks.append(0)

    gltf_dict = {
        "asset": {"version": "2.0", "generator": "AGY-Video-Studio-Rust-Blender5"},
        "scene": 0,
        "scenes": [{"nodes": list(range(len(nodes)))}],
        "nodes": nodes,
        "meshes": meshes,
        "materials": materials,
        "accessors": accessors,
        "bufferViews": buffer_views,
        "buffers": [{"byteLength": len(bin_chunks)}],
    }
    json_bytes = json.dumps(gltf_dict, separators=(",", ":")).encode("utf-8")
    while len(json_bytes) % 4 != 0:
        json_bytes += b" "

    total_len = 12 + 8 + len(json_bytes) + 8 + len(bin_chunks)
    with open(filepath, "wb") as f:
        f.write(struct.pack("<4sII", b"glTF", 2, total_len))
        f.write(struct.pack("<I4s", len(json_bytes), b"JSON"))
        f.write(json_bytes)
        f.write(struct.pack("<I4s", len(bin_chunks), b"BIN\x00"))
        f.write(bin_chunks)

if CFG.get("save_blend_path"):
    os.makedirs(os.path.dirname(CFG["save_blend_path"]), exist_ok=True)
    bpy.ops.wm.save_as_mainfile(filepath=CFG["save_blend_path"])

if CFG.get("export_glb_path"):
    os.makedirs(os.path.dirname(CFG["export_glb_path"]), exist_ok=True)
    export_glb_seccomp_safe(CFG["export_glb_path"])

render_mode = CFG["render_mode"]
frames_dir = CFG["frames_dir"]
os.makedirs(frames_dir, exist_ok=True)

rendered_files = []
if render_mode == "preview_stills":
    for f_num in CFG["preview_frames"]:
        f_clamped = max(1, min(total_frames, int(f_num)))
        scene.frame_set(f_clamped)
        out_p = os.path.join(frames_dir, f"preview_{f_clamped:04d}.png")
        scene.render.filepath = out_p
        bpy.ops.render.render(write_still=True)
        rendered_files.append(out_p)
elif render_mode == "animation":
    scene.render.filepath = os.path.join(frames_dir, "frame_")
    bpy.ops.render.render(animation=True)
    rendered_files = sorted(
        os.path.join(frames_dir, fn) for fn in os.listdir(frames_dir) if fn.startswith("frame_") and fn.endswith(".png")
    )

print("AGY_BLENDER_RESULT_JSON:" + json.dumps({"rendered_count": len(rendered_files), "first_files": rendered_files[:4]}))
"#;

pub fn find_blender_bin(env_p: &EnvPaths) -> Option<PathBuf> {
    if let Ok(eb) = std::env::var("AGY_BLENDER_BIN") {
        let p = PathBuf::from(eb);
        if p.is_file() {
            return Some(p);
        }
    }
    let b1 = env_p.prefix.join("bin/blender-headless");
    if b1.is_file() {
        return Some(b1);
    }
    None
}

pub fn available_ram_mb() -> Option<i64> {
    let txt = fs::read_to_string("/proc/meminfo").ok()?;
    for line in txt.lines() {
        if line.starts_with("MemAvailable:") {
            let kb: i64 = line.split_whitespace().nth(1)?.parse().ok()?;
            return Some(kb / 1024);
        }
    }
    None
}

pub fn get_blender_status_rust(env_p: &EnvPaths) -> JsonVal {
    let b_bin = find_blender_bin(env_p);
    let rootfs = env_p.prefix.join("opt/blender-rootfs");
    let usr_lib = rootfs.join("usr/lib");
    let mut oidn_ready = false;
    if let Ok(entries) = fs::read_dir(&usr_lib) {
        for e in entries.flatten() {
            if e.file_name().to_string_lossy().starts_with("libOpenImageDenoise") {
                oidn_ready = true;
                break;
            }
        }
    }

    let mut ver_str: Option<String> = None;
    if let Some(ref b) = b_bin {
        if let Ok(out) = Command::new(b).arg("--version").output() {
            if out.status.success() {
                let s = String::from_utf8_lossy(&out.stdout);
                ver_str = s.lines().next().map(|l| l.trim().to_string());
            }
        }
    }

    let mut res = JsonVal::obj();
    res.insert("engine", JsonVal::Str("native_rust_arm64_blender5_driver".to_string()));
    res.insert("blender_ready", JsonVal::Bool(ver_str.is_some()));
    res.insert(
        "blender_bin",
        b_bin.map(|p| JsonVal::Str(p.display().to_string())).unwrap_or(JsonVal::Null),
    );
    res.insert("blender_version", ver_str.map(JsonVal::Str).unwrap_or(JsonVal::Null));
    res.insert("rootfs_dir", JsonVal::Str(rootfs.display().to_string()));
    res.insert("cycles_oidn_denoiser", JsonVal::Bool(oidn_ready));
    res.insert(
        "available_ram_mb",
        available_ram_mb().map(|m| JsonVal::Num(m as f64)).unwrap_or(JsonVal::Null),
    );
    res.insert(
        "builtin_3d_presets",
        JsonVal::Arr(vec![
            JsonVal::Str("voxel_coder_laptop".to_string()),
            JsonVal::Str("voxel_backrooms_loop".to_string()),
            JsonVal::Str("studio_pedestal_3d".to_string()),
            JsonVal::Str("custom_bpy".to_string()),
        ]),
    );
    res
}

pub fn run_blender_setup_rust(env_p: &EnvPaths) -> Result<JsonVal, String> {
    let setup_sh = env_p.plugin_dir.join("mcp/bin/agy-blender-setup");
    if !setup_sh.is_file() {
        return Err(format!("Missing setup script at {}", setup_sh.display()));
    }
    let out = Command::new("/system/bin/sh")
        .arg(&setup_sh)
        .output()
        .map_err(|e| e.to_string())?;
    let mut st = get_blender_status_rust(env_p);
    let combined = format!(
        "{}\n{}",
        String::from_utf8_lossy(&out.stdout),
        String::from_utf8_lossy(&out.stderr)
    );
    let tail: Vec<&str> = combined.lines().rev().take(20).collect::<Vec<_>>().into_iter().rev().collect();
    st.insert("setup_log_tail", JsonVal::Str(tail.join("\n")));
    if !out.status.success() {
        return Err(format!("agy-blender-setup failed:\n{}", tail.join("\n")));
    }
    Ok(st)
}

fn generate_wallpaper_png_ffmpeg(
    env_p: &EnvPaths,
    ffmpeg_bin: &Path,
    dest_png: &Path,
    label: &str,
) -> Result<(), String> {
    // Generate 1024x1024 tiled Backrooms wallpaper in <0.25s directly via FFmpeg lavfi + JetBrainsMono font!
    let font_p = env_p.plugin_dir.join("assets/fonts/JetBrainsMono-SemiBold.ttf");
    let safe_txt = label.replace(':', "\\:").replace('\'', "");
    let mut vf = String::from("geq=r='if(lt(mod(X,32),12),185,194)':g='if(lt(mod(X,32),12),159,169)':b='if(lt(mod(X,32),12),82,92)'");
    if font_p.is_file() {
        for row in 0..10 {
            let y = 32 + row * 98;
            let x0 = if row % 2 == 0 { 24 } else { -80 };
            for col in 0..4 {
                let x = x0 + col * 260;
                vf.push_str(&format!(
                    ",drawtext=fontfile='{}':text='{}':x={}:y={}:fontsize=32:fontcolor=0x8E7634",
                    font_p.display(),
                    safe_txt,
                    x,
                    y
                ));
            }
        }
    }
    let mut cmd = Command::new(ffmpeg_bin);
    env_p.configure_bionic_cmd(&mut cmd);
    let out = cmd
        .args(["-y", "-f", "lavfi", "-i", "color=c=0xC2A95C:s=1024x1024:d=0.1", "-vf", &vf, "-frames:v", "1"])
        .arg(dest_png)
        .output()
        .map_err(|e| e.to_string())?;
    if !out.status.success() {
        return Err(format!("Wallpaper generation failed: {}", String::from_utf8_lossy(&out.stderr)));
    }
    Ok(())
}

pub fn render_blender_scene_rust(
    env_p: &EnvPaths,
    ffmpeg_bin: &Path,
    args: &JsonVal,
) -> Result<JsonVal, String> {
    let b_bin = match find_blender_bin(env_p) {
        Some(b) => b,
        None => {
            let _ = run_blender_setup_rust(env_p)?;
            find_blender_bin(env_p).ok_or_else(|| "Blender 5.0 Headless binary not found after setup.".to_string())?
        }
    };

    let preset = args.get_str("preset").unwrap_or("voxel_coder_laptop");
    let render_mode = args.get_str("render_mode").unwrap_or("preview_stills");
    let aspect = args.get_str("aspect_ratio").unwrap_or("9:16");

    let (mut width, mut height) = match (args.get_i64("width"), args.get_i64("height")) {
        (Some(w), Some(h)) => (w, h),
        _ => match aspect {
            "16:9" => (854, 480),
            "1:1" => (640, 640),
            _ => (540, 960),
        },
    };
    width = (width - (width % 2)).max(240);
    height = (height - (height % 2)).max(240);

    let fps = args.get_i64("fps").unwrap_or(16).clamp(8, 60);
    let duration_sec = args.get_f64("duration_sec").unwrap_or(3.5).clamp(0.5, 60.0);
    let total_frames = ((duration_sec * fps as f64).round() as i64).max(1);
    let default_samples = if render_mode == "animation" { 12 } else { 18 };
    let samples = args.get_i64("samples").unwrap_or(default_samples).clamp(4, 128);
    let threads = args.get_i64("threads").unwrap_or(6).clamp(1, 8);

    let out_path = args.get_str("output_path").map(PathBuf::from);
    let work_dir = if let Some(ref op) = out_path {
        let stem = op.file_stem().map(|s| s.to_string_lossy().to_string()).unwrap_or_else(|| "scene".to_string());
        op.parent().unwrap_or(&env_p.tmp_dir).join(format!(".blender_work_{}", stem))
    } else {
        env_p.tmp_dir.join(format!("agy_blender_{}", std::process::id()))
    };
    let frames_dir = work_dir.join("frames");
    let _ = fs::remove_dir_all(&frames_dir);
    fs::create_dir_all(&frames_dir).map_err(|e| e.to_string())?;

    // Auto-generate crisp laptop screen texture via video_render_code_screen and unpack to OpenImageIO-safe PNGs!
    let mut screen_media = args.get_str("screen_media_path").map(|s| s.to_string());
    if preset == "voxel_coder_laptop" && screen_media.is_none() {
        let auto_scr = work_dir.join("auto_laptop_screen.mp4");
        let mut scr_cfg = args.get("screen_config").cloned().unwrap_or_else(JsonVal::obj);
        scr_cfg.insert("output_path", JsonVal::Str(auto_scr.display().to_string()));
        scr_cfg.insert("duration_sec", JsonVal::Num(duration_sec));
        scr_cfg.insert("fps", JsonVal::Num(fps as f64));
        if call_py_bridge(env_p, "video_render_code_screen", &scr_cfg).is_ok() && auto_scr.is_file() {
            screen_media = Some(auto_scr.display().to_string());
        }
    }
    // Convert any .mp4/.mov screen_media into a crisp PNG sequence (or single preview PNG for stills) so Cycles never shows magenta!
    if let Some(ref sm) = screen_media.clone() {
        let sm_p = PathBuf::from(sm);
        let ext = sm_p.extension().map(|e| e.to_string_lossy().to_lowercase()).unwrap_or_default();
        if matches!(ext.as_str(), "mp4" | "mov" | "mkv" | "webm") && sm_p.is_file() {
            if render_mode == "preview_stills" {
                let preview_png = sm_p.with_extension("preview.png");
                if preview_png.is_file() {
                    screen_media = Some(preview_png.display().to_string());
                } else {
                    let single_png = work_dir.join("scr_still.png");
                    let mut ff = Command::new(ffmpeg_bin);
                    env_p.configure_bionic_cmd(&mut ff);
                    let _ = ff.args(["-y", "-i"]).arg(&sm_p).args(["-frames:v", "1"]).arg(&single_png).output();
                    if single_png.is_file() {
                        screen_media = Some(single_png.display().to_string());
                    }
                }
            } else {
                let seq_dir = work_dir.join("scr_seq");
                let _ = fs::create_dir_all(&seq_dir);
                let mut ff = Command::new(ffmpeg_bin);
                env_p.configure_bionic_cmd(&mut ff);
                let _ = ff
                    .args(["-y", "-i"])
                    .arg(&sm_p)
                    .args(["-vf", &format!("fps={}", fps)])
                    .arg(seq_dir.join("scr_%04d.png"))
                    .output();
                if seq_dir.join("scr_0001.png").is_file() {
                    screen_media = Some(seq_dir.display().to_string());
                }
            }
        }
    }

    let mut wallpaper_png: Option<String> = None;
    if preset == "voxel_backrooms_loop" {
        let wp = work_dir.join("backrooms_wallpaper.png");
        let lbl = args.get_str("wallpaper_label").unwrap_or("retry()");
        if generate_wallpaper_png_ffmpeg(env_p, ffmpeg_bin, &wp, lbl).is_ok() {
            wallpaper_png = Some(wp.display().to_string());
        }
    }

    let mut custom_bpy = String::new();
    if preset == "custom_bpy" {
        if let Some(sp) = args.get_str("bpy_script_path") {
            custom_bpy = fs::read_to_string(sp).map_err(|e| format!("Failed reading bpy_script_path: {}", e))?;
        } else if let Some(sc) = args.get_str("bpy_script") {
            custom_bpy = sc.to_string();
        }
        if custom_bpy.trim().is_empty() {
            return Err("For preset='custom_bpy', provide 'bpy_script' or 'bpy_script_path'.".to_string());
        }
    }

    let mut preview_frames = Vec::new();
    if let Some(arr) = args.get("preview_frames").and_then(|v| v.as_arr()) {
        for item in arr {
            if let Some(f) = item.as_i64() {
                let fc = f.clamp(1, total_frames);
                if !preview_frames.contains(&fc) {
                    preview_frames.push(fc);
                }
            }
        }
    }
    if preview_frames.is_empty() {
        for fc in [1, (total_frames / 2).max(1), total_frames] {
            if !preview_frames.contains(&fc) {
                preview_frames.push(fc);
            }
        }
    }

    // Use static DejaVuSans-Bold for clean 3D extruded glyph triangulation (variable fonts overlap contours in 3D extrusion)
    let static_dejavu = env_p.prefix.join("opt/blender-rootfs/usr/share/fonts/dejavu/DejaVuSans-Bold.ttf");
    let font_bold = if static_dejavu.is_file() {
        static_dejavu
    } else {
        env_p.plugin_dir.join("assets/fonts/JetBrainsMono-SemiBold.ttf")
    };

    let mut cfg = JsonVal::obj();
    cfg.insert("preset", JsonVal::Str(preset.to_string()));
    cfg.insert("render_mode", JsonVal::Str(render_mode.to_string()));
    cfg.insert("width", JsonVal::Num(width as f64));
    cfg.insert("height", JsonVal::Num(height as f64));
    cfg.insert("fps", JsonVal::Num(fps as f64));
    cfg.insert("total_frames", JsonVal::Num(total_frames as f64));
    cfg.insert("samples", JsonVal::Num(samples as f64));
    cfg.insert("use_denoising", JsonVal::Bool(args.get_bool("use_denoising").unwrap_or(true)));
    cfg.insert("frames_dir", JsonVal::Str(frames_dir.display().to_string()));
    cfg.insert(
        "preview_frames",
        JsonVal::Arr(preview_frames.iter().map(|&n| JsonVal::Num(n as f64)).collect()),
    );
    cfg.insert(
        "screen_media_path",
        screen_media.map(JsonVal::Str).unwrap_or(JsonVal::Null),
    );
    cfg.insert("screen_emission", JsonVal::Num(args.get_f64("screen_emission").unwrap_or(2.1)));
    cfg.insert(
        "floating_title",
        JsonVal::Str(args.get_str("floating_title").unwrap_or("").to_string()),
    );
    if let Some(vcol) = args.get("voxel_rgba") {
        cfg.insert("voxel_rgba", vcol.clone());
    }
    cfg.insert("mascot_face_screen", JsonVal::Bool(args.get_bool("mascot_face_screen").unwrap_or(false)));
    cfg.insert("mascot_rot_deg", JsonVal::Num(args.get_f64("mascot_rot_deg").unwrap_or(-14.0)));
    cfg.insert("action", JsonVal::Str(args.get_str("action").unwrap_or("typing_bounce").to_string()));
    cfg.insert(
        "eye_expression",
        JsonVal::Str(args.get_str("eye_expression").unwrap_or("normal").to_string()),
    );
    cfg.insert(
        "camera_shot",
        JsonVal::Str(args.get_str("camera_shot").unwrap_or("wide_push_in").to_string()),
    );
    cfg.insert("glitch_dissolve_end", JsonVal::Bool(args.get_bool("glitch_dissolve_end").unwrap_or(false)));
    cfg.insert("wallpaper_png", wallpaper_png.map(JsonVal::Str).unwrap_or(JsonVal::Null));
    cfg.insert("wall_text", JsonVal::Str(args.get_str("wall_text").unwrap_or("ATTEMPT 44").to_string()));
    cfg.insert("context_fill", JsonVal::Num(args.get_f64("context_fill").unwrap_or(0.46)));
    cfg.insert("ghost_clones", JsonVal::Num(args.get_i64("ghost_clones").unwrap_or(4) as f64));
    cfg.insert("break_door", JsonVal::Bool(args.get_bool("break_door").unwrap_or(false)));
    cfg.insert("walk_distance", JsonVal::Num(args.get_f64("walk_distance").unwrap_or(1.55)));
    cfg.insert(
        "glb_path",
        args.get_str("glb_path").map(|s| JsonVal::Str(s.to_string())).unwrap_or(JsonVal::Null),
    );
    cfg.insert(
        "save_blend_path",
        args.get_str("save_blend_path").map(|s| JsonVal::Str(s.to_string())).unwrap_or(JsonVal::Null),
    );
    cfg.insert(
        "export_glb_path",
        args.get_str("export_glb_path").map(|s| JsonVal::Str(s.to_string())).unwrap_or(JsonVal::Null),
    );
    cfg.insert(
        "font_bold_path",
        if font_bold.is_file() {
            JsonVal::Str(font_bold.display().to_string())
        } else {
            JsonVal::Null
        },
    );
    cfg.insert("custom_bpy_code", JsonVal::Str(custom_bpy));

    let driver_py = work_dir.join("agy_blender_driver.py");
    fs::write(&driver_py, BPY_SCENE_DRIVER).map_err(|e| e.to_string())?;

    let t0 = Instant::now();
    let out = Command::new(&b_bin)
        .args([
            "-b",
            "--factory-startup",
            "--python-exit-code",
            "1",
            "--threads",
            &threads.to_string(),
            "-P",
        ])
        .arg(&driver_py)
        .env("AGY_BLENDER_CFG_JSON", cfg.to_json_string())
        .output()
        .map_err(|e| format!("Failed spawning blender-headless: {}", e))?;

    let elapsed = (t0.elapsed().as_secs_f64() * 100.0).round() / 100.0;
    if !out.status.success() {
        let log = format!(
            "{}\n{}",
            String::from_utf8_lossy(&out.stdout),
            String::from_utf8_lossy(&out.stderr)
        );
        let tail: Vec<&str> = log.lines().rev().take(35).collect::<Vec<_>>().into_iter().rev().collect();
        return Err(format!("Blender 5.0 exited with error:\n{}", tail.join("\n")));
    }

    if render_mode == "preview_stills" {
        let mut stills = Vec::new();
        if let Ok(rd) = fs::read_dir(&frames_dir) {
            for e in rd.flatten() {
                let fn_s = e.file_name().to_string_lossy().to_string();
                if fn_s.starts_with("preview_") && fn_s.ends_with(".png") {
                    stills.push(e.path().display().to_string());
                }
            }
        }
        stills.sort();
        let mut res = JsonVal::obj();
        res.insert("status", JsonVal::Str("ok".to_string()));
        res.insert("engine", JsonVal::Str("native_rust_arm64_blender5".to_string()));
        res.insert("render_mode", JsonVal::Str("preview_stills".to_string()));
        res.insert("preset", JsonVal::Str(preset.to_string()));
        res.insert("preview_stills", JsonVal::Arr(stills.into_iter().map(JsonVal::Str).collect()));
        res.insert("width", JsonVal::Num(width as f64));
        res.insert("height", JsonVal::Num(height as f64));
        res.insert("samples", JsonVal::Num(samples as f64));
        res.insert("blender_elapsed_sec", JsonVal::Num(elapsed));
        res.insert("export_glb_path", cfg.get("export_glb_path").cloned().unwrap_or(JsonVal::Null));
        res.insert(
            "qa_hint",
            JsonVal::Str("Inspect 'preview_stills' with read_file to verify framing, lighting, and text before rendering full animation.".to_string()),
        );
        return Ok(res);
    }

    if render_mode == "model_only" {
        let mut res = JsonVal::obj();
        res.insert("status", JsonVal::Str("ok".to_string()));
        res.insert("engine", JsonVal::Str("native_rust_arm64_blender5".to_string()));
        res.insert("render_mode", JsonVal::Str("model_only".to_string()));
        res.insert("preset", JsonVal::Str(preset.to_string()));
        res.insert("save_blend_path", cfg.get("save_blend_path").cloned().unwrap_or(JsonVal::Null));
        res.insert("export_glb_path", cfg.get("export_glb_path").cloned().unwrap_or(JsonVal::Null));
        res.insert("blender_elapsed_sec", JsonVal::Num(elapsed));
        return Ok(res);
    }

    let final_mp4 = out_path.ok_or_else(|| "'output_path' (.mp4) is required when render_mode='animation'.".to_string())?;
    if let Some(parent) = final_mp4.parent() {
        fs::create_dir_all(parent).map_err(|e| e.to_string())?;
    }

    let mut pngs = Vec::new();
    if let Ok(rd) = fs::read_dir(&frames_dir) {
        for e in rd.flatten() {
            let fn_s = e.file_name().to_string_lossy().to_string();
            if fn_s.starts_with("frame_") && fn_s.ends_with(".png") {
                pngs.push(e.path());
            }
        }
    }
    pngs.sort();
    if pngs.is_empty() {
        return Err("No animation PNG frames were produced by Blender.".to_string());
    }

    let target_fps = args.get_i64("output_fps").unwrap_or(30).clamp(12, 60);
    let use_hw = args.get_bool("use_hw_accel").unwrap_or(true) && env_p.has_h264_mediacodec(ffmpeg_bin);
    let audio_path = args.get_str("audio_path").map(PathBuf::from).filter(|p| p.is_file());

    let mut vf_parts = Vec::new();
    if let (Some(uw), Some(uh)) = (args.get_i64("upscale_width"), args.get_i64("upscale_height")) {
        vf_parts.push(format!("scale={}:{}:flags=lanczos", uw - (uw % 2), uh - (uh % 2)));
    }
    if target_fps > fps && args.get_bool("smooth_fps_blend").unwrap_or(true) {
        vf_parts.push(format!("framerate=fps={}:interp_start=0:interp_end=255:scene=8.2", target_fps));
    }

    let encode_attempt = |hw: bool| -> Result<String, String> {
        let mut ff = Command::new(ffmpeg_bin);
        env_p.configure_bionic_cmd(&mut ff);
        ff.args(["-y", "-framerate", &fps.to_string(), "-i"])
            .arg(frames_dir.join("frame_%04d.png"));
        if let Some(ref ap) = audio_path {
            ff.arg("-i").arg(ap);
        }
        if !vf_parts.is_empty() {
            ff.arg("-vf").arg(vf_parts.join(","));
        }
        let enc_label = if hw {
            ff.args(["-c:v", "h264_mediacodec", "-b:v", "10.0M", "-g", "120", "-pix_fmt", "nv12"]);
            "h264_mediacodec"
        } else {
            ff.args(["-c:v", "libx264", "-preset", "veryfast", "-crf", "18", "-pix_fmt", "yuv420p"]);
            "libx264"
        };
        if audio_path.is_some() {
            ff.args(["-c:a", "aac", "-b:a", "192k", "-shortest"]);
        }
        ff.args(["-movflags", "+faststart"]).arg(&final_mp4);
        let out_ff = ff.output().map_err(|e| e.to_string())?;
        if !out_ff.status.success() {
            return Err(String::from_utf8_lossy(&out_ff.stderr).to_string());
        }
        Ok(enc_label.to_string())
    };

    let used_enc = match encode_attempt(use_hw) {
        Ok(enc) => enc,
        Err(_) if use_hw => encode_attempt(false)?,
        Err(e) => return Err(format!("FFmpeg MP4 encode failed: {}", e)),
    };

    let kf1 = final_mp4.with_extension("kf1.png");
    let kf2 = final_mp4.with_extension("kf2.png");
    let _ = fs::copy(&pngs[0], &kf1);
    let _ = fs::copy(&pngs[pngs.len() / 2], &kf2);

    if !args.get_bool("keep_raw_frames").unwrap_or(false) {
        let _ = fs::remove_dir_all(&work_dir);
    }

    let mut res = JsonVal::obj();
    res.insert("status", JsonVal::Str("ok".to_string()));
    res.insert("engine", JsonVal::Str("native_rust_arm64_blender5".to_string()));
    res.insert("render_mode", JsonVal::Str("animation".to_string()));
    res.insert("preset", JsonVal::Str(preset.to_string()));
    res.insert("output_path", JsonVal::Str(final_mp4.display().to_string()));
    res.insert(
        "keyframe_previews",
        JsonVal::Arr(vec![
            JsonVal::Str(kf1.display().to_string()),
            JsonVal::Str(kf2.display().to_string()),
        ]),
    );
    res.insert("rendered_frames", JsonVal::Num(pngs.len() as f64));
    res.insert("blender_fps", JsonVal::Num(fps as f64));
    res.insert("output_fps", JsonVal::Num(target_fps as f64));
    res.insert("width", JsonVal::Num(width as f64));
    res.insert("height", JsonVal::Num(height as f64));
    res.insert("samples", JsonVal::Num(samples as f64));
    res.insert("encoder", JsonVal::Str(used_enc));
    res.insert("blender_elapsed_sec", JsonVal::Num(elapsed));
    res.insert("export_glb_path", cfg.get("export_glb_path").cloned().unwrap_or(JsonVal::Null));
    Ok(res)
}
