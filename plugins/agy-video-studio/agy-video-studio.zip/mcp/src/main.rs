// main.rs — AGY Video Studio 3D (v3.0.0) Native Android ARM64 Rust MCP Server & CLI
// Combines Bare-Metal Blender 5.0 Headless (Cycles + OpenImageDenoise), Native Rust 48kHz Stereo Score/SFX DSP,
// Dynamic Code/Chat Screens, GPU h264_mediacodec encoding, CapCut Rootless Bridge & Shizuku Control.

mod blender;
mod dsp;
mod json;

use blender::{find_blender_bin, get_blender_status_rust, render_blender_scene_rust, run_blender_setup_rust};
use dsp::handle_audio_studio_generate;
use json::{parse_json, JsonVal};
use std::env;
use std::fs;
use std::io::{self, BufRead, Write};
use std::path::{Path, PathBuf};
use std::process::{Command, Stdio};

const SERVER_NAME: &str = "agy-video-studio";
const SERVER_VERSION: &str = "3.0.0";

pub struct EnvPaths {
    pub home: PathBuf,
    pub prefix: PathBuf,
    pub plugin_dir: PathBuf,
    pub tmp_dir: PathBuf,
}

impl EnvPaths {
    pub fn resolve() -> Self {
        let home = env::var("HOME")
            .map(PathBuf::from)
            .unwrap_or_else(|_| PathBuf::from("/data/user/0/com.agy/files"));
        let prefix = env::var("PREFIX")
            .map(PathBuf::from)
            .unwrap_or_else(|_| home.join("usr"));
        let plugin_dir = home.join(".gemini/config/plugins/agy-video-studio");
        let tmp_dir = env::var("TMPDIR")
            .map(PathBuf::from)
            .unwrap_or_else(|_| prefix.join("tmp"));
        let _ = fs::create_dir_all(&tmp_dir);
        Self {
            home,
            prefix,
            plugin_dir,
            tmp_dir,
        }
    }

    pub fn configure_bionic_cmd(&self, cmd: &mut Command) {
        let path_val = format!(
            "{}:{}:/system/bin",
            self.prefix.join("bin").display(),
            self.home.join("runtime/bin").display()
        );
        cmd.env("HOME", &self.home)
            .env("PREFIX", &self.prefix)
            .env("TMPDIR", &self.tmp_dir)
            .env("PATH", path_val);

        let cert = self.prefix.join("etc/tls/cert.pem");
        if cert.exists() {
            cmd.env("SSL_CERT_FILE", &cert).env("CURL_CA_BUNDLE", &cert);
        }
        let fonts = self.prefix.join("etc/fonts");
        if fonts.exists() {
            cmd.env("FONTCONFIG_PATH", &fonts);
        }
        let lib_dir = self.prefix.join("lib");
        if lib_dir.join("libandroid-support.so").exists() {
            cmd.env("LD_LIBRARY_PATH", &lib_dir);
            let mut preloads = Vec::new();
            let dns = lib_dir.join("libagy-go-dns.so");
            let texec = lib_dir.join("libtermux-exec.so");
            if dns.exists() {
                preloads.push(dns.display().to_string());
            }
            if texec.exists() {
                preloads.push(texec.display().to_string());
            }
            if !preloads.is_empty() {
                cmd.env("LD_PRELOAD", preloads.join(":"));
            }
        }
    }

    pub fn find_ffmpeg(&self) -> Option<PathBuf> {
        if let Ok(ef) = env::var("AGY_FFMPEG_BIN") {
            let p = PathBuf::from(ef);
            if p.is_file() {
                return Some(p);
            }
        }
        let p1 = self.prefix.join("bin/ffmpeg");
        if p1.is_file() {
            return Some(p1);
        }
        None
    }

    pub fn has_h264_mediacodec(&self, ffmpeg_bin: &Path) -> bool {
        let mut cmd = Command::new(ffmpeg_bin);
        self.configure_bionic_cmd(&mut cmd);
        if let Ok(out) = cmd.args(["-hide_banner", "-encoders"]).output() {
            let s = String::from_utf8_lossy(&out.stdout);
            return s.contains("h264_mediacodec");
        }
        false
    }

    pub fn find_rish(&self) -> Option<PathBuf> {
        for cand in [self.prefix.join("bin/rish"), self.home.join("runtime/bin/rish")] {
            if cand.is_file() {
                return Some(cand);
            }
        }
        None
    }
}

pub fn call_py_bridge(env_p: &EnvPaths, tool_name: &str, args: &JsonVal) -> Result<JsonVal, String> {
    let py_bin = env_p.prefix.join("bin/python3");
    let bridge = env_p.plugin_dir.join("mcp/runtime/py_bridge.py");
    if !py_bin.is_file() {
        return Err("python3 not found in $PREFIX/bin. Run 'agy-video-setup'.".to_string());
    }
    let mut cmd = Command::new(&py_bin);
    env_p.configure_bionic_cmd(&mut cmd);
    cmd.arg(&bridge)
        .arg(tool_name)
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped());

    let mut child = cmd.spawn().map_err(|e| format!("Failed spawning runtime helper: {}", e))?;
    if let Some(mut sin) = child.stdin.take() {
        let _ = sin.write_all(args.to_json_string().as_bytes());
    }
    let out = child.wait_with_output().map_err(|e| e.to_string())?;
    if !out.status.success() {
        let err_s = String::from_utf8_lossy(&out.stderr);
        let tail: Vec<&str> = err_s.lines().rev().take(12).collect::<Vec<_>>().into_iter().rev().collect();
        return Err(tail.join("\n"));
    }
    let stdout_s = String::from_utf8_lossy(&out.stdout);
    parse_json(&stdout_s).map_err(|e| format!("Invalid JSON from helper: {}", e))
}

fn environment_status_rust(env_p: &EnvPaths) -> JsonVal {
    let ff = env_p.find_ffmpeg();
    let mut h264_mc = false;
    let mut hevc_mc = false;
    if let Some(ref fbin) = ff {
        let mut cmd = Command::new(fbin);
        env_p.configure_bionic_cmd(&mut cmd);
        if let Ok(out) = cmd.args(["-hide_banner", "-encoders"]).output() {
            let s = String::from_utf8_lossy(&out.stdout);
            h264_mc = s.contains("h264_mediacodec");
            hevc_mc = s.contains("hevc_mediacodec");
        }
    }

    let b_bin = find_blender_bin(env_p);
    let mut shz_ok = false;
    let mut shz_info = String::from("rish not found");
    let mut screen_obj = JsonVal::Null;
    let mut editors = Vec::new();
    let mut socials = Vec::new();

    if let Some(rbin) = env_p.find_rish() {
        let mut cmd = Command::new(&rbin);
        env_p.configure_bionic_cmd(&mut cmd);
        if let Ok(out) = cmd.args(["-c", "id"]).output() {
            let s = String::from_utf8_lossy(&out.stdout).trim().to_string();
            if out.status.success() && s.contains("uid=") {
                shz_ok = true;
                shz_info = s;
            } else {
                shz_info = String::from_utf8_lossy(&out.stderr).trim().to_string();
            }
        }
        if shz_ok {
            let mut sc = Command::new(&rbin);
            env_p.configure_bionic_cmd(&mut sc);
            if let Ok(out) = sc.args(["-c", "wm size"]).output() {
                let s = String::from_utf8_lossy(&out.stdout);
                for tok in s.split_whitespace() {
                    if let Some((w_s, h_s)) = tok.split_once('x') {
                        if let (Ok(w), Ok(h)) = (w_s.parse::<i64>(), h_s.parse::<i64>()) {
                            let mut so = JsonVal::obj();
                            so.insert("width", JsonVal::Num(w as f64));
                            so.insert("height", JsonVal::Num(h as f64));
                            screen_obj = so;
                            break;
                        }
                    }
                }
            }
            let mut pm = Command::new(&rbin);
            env_p.configure_bionic_cmd(&mut pm);
            if let Ok(out) = pm.args(["-c", "pm list packages"]).output() {
                let s = String::from_utf8_lossy(&out.stdout);
                let known = [
                    ("com.lemon.lvoverseas", "CapCut Global", true),
                    ("com.lemon.lv", "CapCut CN", true),
                    ("com.frontrow.vlog", "VN Video Editor", true),
                    ("com.zhiliaoapp.musically", "TikTok Global", false),
                    ("com.ss.android.ugc.trill", "TikTok LatAm/Asia", false),
                    ("com.instagram.android", "Instagram", false),
                    ("com.google.android.youtube", "YouTube", false),
                ];
                for (pkg, label, is_ed) in known {
                    if s.lines().any(|l| l.trim() == format!("package:{}", pkg)) {
                        let mut item = JsonVal::obj();
                        item.insert("package", JsonVal::Str(pkg.to_string()));
                        item.insert("name", JsonVal::Str(label.to_string()));
                        if is_ed {
                            editors.push(item);
                        } else {
                            socials.push(item);
                        }
                    }
                }
            }
        }
    }

    let mut py_pillow = false;
    let mut py_numpy = false;
    let mut py_tts = false;
    let py_bin = env_p.prefix.join("bin/python3");
    if py_bin.is_file() {
        let mut cmd = Command::new(&py_bin);
        env_p.configure_bionic_cmd(&mut cmd);
        if let Ok(out) = cmd
            .args([
                "-c",
                "import importlib.util as u; print(int(u.find_spec('PIL') is not None), int(u.find_spec('numpy') is not None), int(u.find_spec('edge_tts') is not None))",
            ])
            .output()
        {
            let out_s = String::from_utf8_lossy(&out.stdout);
            let parts: Vec<&str> = out_s.split_whitespace().collect();
            if parts.len() == 3 {
                py_pillow = parts[0] == "1";
                py_numpy = parts[1] == "1";
                py_tts = parts[2] == "1";
            }
        }
    }

    let mut fonts_vec = Vec::new();
    let fdir = env_p.plugin_dir.join("assets/fonts");
    if let Ok(rd) = fs::read_dir(&fdir) {
        let mut names: Vec<String> = rd
            .flatten()
            .map(|e| e.file_name().to_string_lossy().to_string())
            .filter(|n| n.ends_with(".ttf"))
            .collect();
        names.sort();
        for n in names {
            fonts_vec.push(JsonVal::Str(n));
        }
    }

    let mut hw = JsonVal::obj();
    hw.insert("h264_mediacodec", JsonVal::Bool(h264_mc));
    hw.insert("hevc_mediacodec", JsonVal::Bool(hevc_mc));

    let mut pym = JsonVal::obj();
    pym.insert("pillow", JsonVal::Bool(py_pillow));
    pym.insert("numpy", JsonVal::Bool(py_numpy));
    pym.insert("edge_tts", JsonVal::Bool(py_tts));

    let mut apps = JsonVal::obj();
    apps.insert("android_editors", JsonVal::Arr(editors));
    apps.insert("android_social", JsonVal::Arr(socials));

    let mut res = JsonVal::obj();
    res.insert("server_version", JsonVal::Str(SERVER_VERSION.to_string()));
    res.insert("runtime", JsonVal::Str("native_rust_arm64_lse_v3".to_string()));
    res.insert("platform", JsonVal::Str("android-arm64".to_string()));
    res.insert("machine", JsonVal::Str(std::env::consts::ARCH.to_string()));
    res.insert("ffmpeg_available", JsonVal::Bool(ff.is_some()));
    res.insert(
        "ffmpeg_path",
        ff.map(|p| JsonVal::Str(p.display().to_string())).unwrap_or(JsonVal::Null),
    );
    res.insert("hardware_encoders", hw);
    res.insert("blender_3d_ready", JsonVal::Bool(b_bin.is_some()));
    res.insert(
        "blender_bin",
        b_bin.map(|p| JsonVal::Str(p.display().to_string())).unwrap_or(JsonVal::Null),
    );
    res.insert("python_modules", pym);
    res.insert("bundled_google_fonts", JsonVal::Arr(fonts_vec));
    res.insert("shizuku_active", JsonVal::Bool(shz_ok));
    res.insert("shizuku_info", JsonVal::Str(shz_info));
    res.insert("android_screen", screen_obj);
    res.insert("detected_apps", apps);
    res
}

const TOOLS_SCHEMA_JSON: &str = r#"[
  {
    "name": "video_environment_status",
    "description": "Inspect Native Rust ARM64 video & 3D studio capabilities: ffmpeg path, Android hardware GPU encoders (h264_mediacodec / hevc_mediacodec), Bare-Metal Blender 5.0 Headless status, Pillow/edge_tts, bundled fonts, Shizuku (rish), and installed social/editor apps.",
    "inputSchema": {"type": "object", "properties": {}}
  },
  {
    "name": "blender_status",
    "description": "Inspect Native Android ARM64 Bare-Metal Blender 5.0 Headless status ($PREFIX/bin/blender-headless, Cycles + Intel OpenImageDenoise readiness, available RAM, and built-in 3D procedural presets).",
    "inputSchema": {"type": "object", "properties": {}}
  },
  {
    "name": "blender_setup",
    "description": "Install or verify native Android ARM64 Bare-Metal Blender 5.0 Headless (Cycles + OpenImageDenoise) in $PREFIX/opt/blender-rootfs via ld-musl-aarch64.so.1 without root, X11, or proot overhead.",
    "inputSchema": {"type": "object", "properties": {}}
  },
  {
    "name": "blender_render_scene",
    "description": "Build and render real 3D Blender 5.0 Cycles + OpenImageDenoise scenes on Android ARM64 via Native Rust! Supports studio presets ('voxel_coder_laptop', 'voxel_backrooms_loop', 'studio_pedestal_3d') AND custom Python 'bpy' scripts ('custom_bpy'). Use render_mode='preview_stills' first to inspect keyframe PNGs visually via read_file (agentic self-correction), then render_mode='animation' to output GPU-encoded .mp4 clips (and/or export .glb / .blend).",
    "inputSchema": {
      "type": "object",
      "properties": {
        "preset": {"type": "string", "enum": ["voxel_coder_laptop", "voxel_backrooms_loop", "studio_pedestal_3d", "custom_bpy"]},
        "render_mode": {"type": "string", "enum": ["preview_stills", "animation", "model_only"]},
        "output_path": {"type": "string", "description": "Destination .mp4 path (required for render_mode='animation')"},
        "aspect_ratio": {"type": "string", "enum": ["9:16", "16:9", "1:1"]},
        "width": {"type": "integer"},
        "height": {"type": "integer"},
        "fps": {"type": "integer", "description": "Blender render FPS (default 16; smoothly interpolated to output_fps)"},
        "output_fps": {"type": "integer", "description": "Final MP4 frame rate (default 30)"},
        "duration_sec": {"type": "number", "description": "Scene duration in seconds (default 3.5)"},
        "samples": {"type": "integer", "description": "Cycles samples with OpenImageDenoise (default 12 animation / 18 stills)"},
        "preview_frames": {"type": "array", "items": {"type": "integer"}},
        "screen_media_path": {"type": "string", "description": "Path to .mp4 or .png projected as emissive screen on 3D laptop"},
        "screen_config": {"type": "object", "description": "Auto-generate laptop screen texture via video_render_code_screen options"},
        "floating_title": {"type": "string", "description": "Optional 3D extruded floating title text in scene"},
        "action": {"type": "string", "enum": ["typing_bounce", "retry_panic", "walk_forward", "look_screen_then_camera", "idle"]},
        "eye_expression": {"type": "string", "enum": ["normal", "confident", "squint", "wide_shock"]},
        "camera_shot": {"type": "string", "enum": ["wide_push_in", "close_hero", "over_shoulder_screen"]},
        "glitch_dissolve_end": {"type": "boolean"},
        "wall_text": {"type": "string", "description": "Extruded 3D Backrooms wall label (e.g. 'ATTEMPT 44')"},
        "wallpaper_label": {"type": "string", "description": "Tiled Backrooms wallpaper text (default 'retry()')"},
        "context_fill": {"type": "number"},
        "ghost_clones": {"type": "integer"},
        "break_door": {"type": "boolean"},
        "bpy_script": {"type": "string"},
        "bpy_script_path": {"type": "string"},
        "audio_path": {"type": "string"},
        "save_blend_path": {"type": "string"},
        "export_glb_path": {"type": "string"},
        "use_hw_accel": {"type": "boolean"}
      }
    }
  },
  {
    "name": "video_render_code_screen",
    "description": "Render pixel-sharp animated IDE code typing ('code_typing'), terminal retry loops & Thinking... storms ('test_attempts'), or dark AI chat bubbles ('chat_dialogue') to .mp4 + .preview.png via GPU h264_mediacodec. Use standalone or pass 'output_path' as 'screen_media_path' in 'blender_render_scene'.",
    "inputSchema": {
      "type": "object",
      "properties": {
        "output_path": {"type": "string"},
        "mode": {"type": "string", "enum": ["code_typing", "test_attempts", "chat_dialogue"]},
        "width": {"type": "integer"},
        "height": {"type": "integer"},
        "fps": {"type": "integer"},
        "duration_sec": {"type": "number"},
        "filename": {"type": "string"},
        "start_line": {"type": "integer"},
        "code": {"type": "string"},
        "instant_code": {"type": "boolean"},
        "highlight_fix_char": {"type": "object"},
        "status_banner": {"type": "object"},
        "end_glitch": {"type": "boolean"},
        "attempts": {"type": "array", "items": {"type": "integer"}},
        "thinking_storm": {"type": "boolean"},
        "messages": {"type": "array", "items": {"type": "object"}},
        "use_hw_accel": {"type": "boolean"}
      },
      "required": ["output_path"]
    }
  },
  {
    "name": "audio_studio_generate",
    "description": "Native Rust ARM64 48kHz Stereo Audio & SFX Studio: generates neural TTS voiceover OR multi-line timed character dialogue ('cute_voxel_bot', 'backrooms_echo', 'deep_ai', 'radio_glitch', 'natural') with captions, procedural stereo SFX ('mech_typing', 'error_buzz', 'white_glitch', 'portal_flash', 'success_chime', 'footsteps'), and copyright-free scores ('dark_synth_slowed', 'lofi_vlog', 'cinematic_epic', 'gemini_keynote', 'deep_tech_pulse', 'minimal_pad').",
    "inputSchema": {
      "type": "object",
      "properties": {
        "output_dir": {"type": "string"},
        "script_text": {"type": "string"},
        "dialogue_lines": {"type": "array", "items": {"type": "object"}},
        "voice_effect": {"type": "string", "enum": ["natural", "cute_voxel_bot", "backrooms_echo", "deep_ai", "radio_glitch"]},
        "sfx_events": {"type": "array", "items": {"type": "object"}},
        "lang": {"type": "string"},
        "voice": {"type": "string"},
        "rate": {"type": "string"},
        "pitch": {"type": "string"},
        "music_style": {"type": "string", "enum": ["dark_synth_slowed", "lofi_vlog", "cinematic_epic", "gemini_keynote", "deep_tech_pulse", "minimal_pad"]},
        "bpm": {"type": "number"},
        "duration_sec": {"type": "number"},
        "music_volume": {"type": "number"}
      },
      "required": ["output_dir"]
    }
  },
  {
    "name": "video_probe_and_scenes",
    "description": "Analyze any video (.mp4/.mkv/.mov) in a single fast pass to extract resolution, FPS, duration, visual scene-change timestamps (scdet), frozen intervals (freezedetect), and speech silences (silencedetect).",
    "inputSchema": {
      "type": "object",
      "properties": {
        "video_path": {"type": "string"},
        "scene_threshold": {"type": "number"},
        "min_freeze_sec": {"type": "number"},
        "min_silence_sec": {"type": "number"}
      },
      "required": ["video_path"]
    }
  },
  {
    "name": "video_smart_autocut",
    "description": "Automatically remove dead speech silences or motionless waits, or speed-ramp idle waits at 2.5x-4x via GPU h264_mediacodec.",
    "inputSchema": {
      "type": "object",
      "properties": {
        "video_path": {"type": "string"},
        "mode": {"type": "string", "enum": ["cut", "speed_ramp"]},
        "criterion": {"type": "string", "enum": ["auto", "freeze", "silence", "both"]},
        "min_dead_sec": {"type": "number"},
        "padding_sec": {"type": "number"},
        "idle_speed": {"type": "number"},
        "output_path": {"type": "string"},
        "use_hw_accel": {"type": "boolean"}
      },
      "required": ["video_path"]
    }
  },
  {
    "name": "video_universal_edit",
    "description": "All-purpose multi-genre video editor ('16:9', '9:16', '1:1', '4:5', 'source') combining 3D Blender clips, 2D screens, camera vlogs, split-screen, Facecam PiP, xfade transitions, color grading, subtitles, and auto-ducked music.",
    "inputSchema": {
      "type": "object",
      "properties": {
        "output_path": {"type": "string"},
        "aspect_ratio": {"type": "string", "enum": ["16:9", "9:16", "1:1", "4:5", "4:3", "21:9", "source"]},
        "fit_mode": {"type": "string", "enum": ["cover", "blurred_bg", "contain"]},
        "layout": {"type": "string", "enum": ["single", "split_vertical", "pip_corner"]},
        "segments": {"type": "array", "items": {"type": "object"}},
        "secondary_source": {"type": "string"},
        "secondary_start_sec": {"type": "number"},
        "pip_position": {"type": "string", "enum": ["bottom_right", "bottom_left", "top_right", "top_left"]},
        "pip_scale": {"type": "number"},
        "audio_source_index": {"type": "integer"},
        "keep_clip_audio": {"type": "boolean"},
        "enhance_speech": {"type": "boolean"},
        "transition": {"type": "string", "enum": ["none", "fade", "fadeblack", "slideleft", "slideright", "slideup", "smoothleft", "circleopen", "zoomin"]},
        "transition_sec": {"type": "number"},
        "color_grade": {"type": "string", "enum": ["none", "cinematic_teal_orange", "warm_vlog", "crisp_tech", "moody_matte", "bw_film"]},
        "subtitle_style": {"type": "string", "enum": ["glass_pill", "cinema_yellow", "viral_pop"]},
        "captions": {"type": "array", "items": {"type": "object"}},
        "lower_thirds": {"type": "array", "items": {"type": "object"}},
        "voiceover_path": {"type": "string"},
        "music_path": {"type": "string"},
        "music_volume": {"type": "number"},
        "fps": {"type": "integer"},
        "use_hw_accel": {"type": "boolean"}
      },
      "required": ["output_path", "segments"]
    }
  },
  {
    "name": "video_utility_ops",
    "description": "Fast Swiss-Army-Knife video utilities: 'podcast_voice_enhance', 'compress_social', 'cover_thumbnail', 'extract_audio', and 'to_gif'.",
    "inputSchema": {
      "type": "object",
      "properties": {
        "operation": {"type": "string", "enum": ["podcast_voice_enhance", "compress_social", "cover_thumbnail", "extract_audio", "to_gif"]},
        "input_path": {"type": "string"},
        "output_path": {"type": "string"},
        "target_mb": {"type": "number"},
        "timestamp_sec": {"type": "number"},
        "title": {"type": "string"},
        "badge": {"type": "string"},
        "start_sec": {"type": "number"},
        "duration_sec": {"type": "number"}
      },
      "required": ["operation", "input_path", "output_path"]
    }
  },
  {
    "name": "video_render_keynote_trailer",
    "description": "Product Showcase & Presentation Engine ('9:16' or '16:9') with brushed titanium device frames, optical Gemini gradients, and zoomed UI callouts.",
    "inputSchema": {
      "type": "object",
      "properties": {
        "output_path": {"type": "string"},
        "aspect_ratio": {"type": "string", "enum": ["9:16", "16:9", "1:1", "4:5"]},
        "scenes": {"type": "array", "items": {"type": "object"}},
        "captions": {"type": "array", "items": {"type": "object"}},
        "master_audio_path": {"type": "string"},
        "voiceover_path": {"type": "string"},
        "music_path": {"type": "string"},
        "music_volume": {"type": "number"},
        "fps": {"type": "integer"},
        "use_hw_accel": {"type": "boolean"}
      },
      "required": ["output_path", "scenes"]
    }
  },
  {
    "name": "video_render_viral_tiktok",
    "description": "Fast full-bleed short-form renderer ('9:16', '16:9', '1:1', '4:5') with speed-ramps, zoom-punches, and spring-pop ASS captions.",
    "inputSchema": {
      "type": "object",
      "properties": {
        "output_path": {"type": "string"},
        "aspect_ratio": {"type": "string", "enum": ["9:16", "16:9", "1:1", "4:5"]},
        "segments": {"type": "array", "items": {"type": "object"}},
        "captions": {"type": "array", "items": {"type": "object"}},
        "voiceover_path": {"type": "string"},
        "music_path": {"type": "string"},
        "music_volume": {"type": "number"},
        "use_hw_accel": {"type": "boolean"}
      },
      "required": ["output_path", "segments"]
    }
  },
  {
    "name": "capcut_android_list_drafts",
    "description": "List existing CapCut projects on Android (via Shizuku rish) or Desktop for rootless timeline injection.",
    "inputSchema": {"type": "object", "properties": {}}
  },
  {
    "name": "capcut_export_draft",
    "description": "Generate an editable multi-track CapCut project in ANY ratio ('16:9', '9:16', '1:1', '4:5') via Rootless Draft Hijack over Shizuku.",
    "inputSchema": {
      "type": "object",
      "properties": {
        "project_name": {"type": "string"},
        "aspect_ratio": {"type": "string", "enum": ["16:9", "9:16", "1:1", "4:5", "4:3"]},
        "keep_clip_audio": {"type": "boolean"},
        "segments": {"type": "array", "items": {"type": "object"}},
        "captions": {"type": "array", "items": {"type": "object"}},
        "audio_tracks": {"type": "array", "items": {"type": "object"}},
        "android_mode": {"type": "string", "enum": ["patch_latest", "new_folder", "stage_only"]},
        "target_draft_folder": {"type": "string"},
        "restore_backup": {"type": "boolean"},
        "launch_capcut": {"type": "boolean"},
        "output_draft_dir": {"type": "string"}
      },
      "required": ["segments"]
    }
  },
  {
    "name": "android_screen_record",
    "description": "Control native high-bitrate Android hardware screen recording via Shizuku (rish).",
    "inputSchema": {
      "type": "object",
      "properties": {
        "mode": {"type": "string", "enum": ["timed", "start", "stop", "status"]},
        "output_path": {"type": "string"},
        "duration_sec": {"type": "integer"},
        "bitrate_mbps": {"type": "integer"},
        "size": {"type": "string"}
      }
    }
  },
  {
    "name": "android_ui_inspect",
    "description": "Inspect the live foreground Android app screen via Shizuku uiautomator dump.",
    "inputSchema": {
      "type": "object",
      "properties": {
        "query": {"type": "string"},
        "only_interactive": {"type": "boolean"},
        "max_nodes": {"type": "integer"}
      }
    }
  },
  {
    "name": "android_ui_action",
    "description": "Autonomously interact with Android apps via Shizuku: tap, tap_text, swipe, text, keyevent, or launch_app.",
    "inputSchema": {
      "type": "object",
      "properties": {
        "action": {"type": "string", "enum": ["tap", "tap_text", "swipe", "text", "keyevent", "launch_app"]},
        "x": {"type": "integer"},
        "y": {"type": "integer"},
        "x2": {"type": "integer"},
        "y2": {"type": "integer"},
        "duration_ms": {"type": "integer"},
        "text": {"type": "string"},
        "key": {"type": "string"},
        "package": {"type": "string"},
        "wait_after_ms": {"type": "integer"}
      },
      "required": ["action"]
    }
  },
  {
    "name": "android_media_and_intent",
    "description": "Stage a rendered .mp4 into /storage/emulated/0/Movies/AGY_Studio/, refresh Android MediaStore (#1 in Gallery), and optionally open in CapCut, VN, TikTok, Instagram, or YouTube.",
    "inputSchema": {
      "type": "object",
      "properties": {
        "media_path": {"type": "string"},
        "open_in": {"type": "string"}
      },
      "required": ["media_path"]
    }
  }
]"#;

fn dispatch_tool(env_p: &EnvPaths, name: &str, args: &JsonVal) -> Result<JsonVal, String> {
    match name {
        "video_environment_status" => Ok(environment_status_rust(env_p)),
        "blender_status" => Ok(get_blender_status_rust(env_p)),
        "blender_setup" => run_blender_setup_rust(env_p),
        "blender_render_scene" => {
            let ff = env_p
                .find_ffmpeg()
                .ok_or_else(|| "ffmpeg not found. Run 'agy-video-setup'.".to_string())?;
            render_blender_scene_rust(env_p, &ff, args)
        }
        "audio_studio_generate" => {
            let ff = env_p
                .find_ffmpeg()
                .ok_or_else(|| "ffmpeg not found. Run 'agy-video-setup'.".to_string())?;
            handle_audio_studio_generate(env_p, &ff, args)
        }
        "video_probe_and_scenes"
        | "video_smart_autocut"
        | "video_universal_edit"
        | "video_utility_ops"
        | "video_render_keynote_trailer"
        | "video_render_viral_tiktok"
        | "video_render_code_screen"
        | "capcut_android_list_drafts"
        | "capcut_export_draft"
        | "android_screen_record"
        | "android_ui_inspect"
        | "android_ui_action"
        | "android_media_and_intent" => call_py_bridge(env_p, name, args),
        _ => Err(format!("Unknown tool: {}", name)),
    }
}

fn send_json_line(out: &mut impl Write, val: &JsonVal) {
    let _ = writeln!(out, "{}", val.to_json_string());
    let _ = out.flush();
}

fn run_mcp_stdio(env_p: &EnvPaths) {
    let tools_val = parse_json(TOOLS_SCHEMA_JSON).unwrap_or_else(|_| JsonVal::Arr(Vec::new()));
    let stdin = io::stdin();
    let mut stdout = io::stdout();

    for line_res in stdin.lock().lines() {
        let line = match line_res {
            Ok(l) => l,
            Err(_) => break,
        };
        let trimmed = line.trim();
        if trimmed.is_empty() {
            continue;
        }
        let req = match parse_json(trimmed) {
            Ok(v) => v,
            Err(_) => continue,
        };
        let method = req.get_str("method").unwrap_or("");
        let msg_id = match req.get("id") {
            Some(id) if *id != JsonVal::Null => id.clone(),
            _ => continue,
        };

        if method == "initialize" {
            let proto = req
                .get("params")
                .and_then(|p| p.get_str("protocolVersion"))
                .unwrap_or("2024-11-05");
            let mut caps = JsonVal::obj();
            caps.insert("tools", JsonVal::obj());

            let mut sinfo = JsonVal::obj();
            sinfo.insert("name", JsonVal::Str(SERVER_NAME.to_string()));
            sinfo.insert("version", JsonVal::Str(SERVER_VERSION.to_string()));

            let mut result = JsonVal::obj();
            result.insert("protocolVersion", JsonVal::Str(proto.to_string()));
            result.insert("capabilities", caps);
            result.insert("serverInfo", sinfo);

            let mut resp = JsonVal::obj();
            resp.insert("jsonrpc", JsonVal::Str("2.0".to_string()));
            resp.insert("id", msg_id);
            resp.insert("result", result);
            send_json_line(&mut stdout, &resp);
        } else if method == "tools/list" {
            let mut result = JsonVal::obj();
            result.insert("tools", tools_val.clone());

            let mut resp = JsonVal::obj();
            resp.insert("jsonrpc", JsonVal::Str("2.0".to_string()));
            resp.insert("id", msg_id);
            resp.insert("result", result);
            send_json_line(&mut stdout, &resp);
        } else if method == "tools/call" {
            let params = req.get("params").cloned().unwrap_or_else(JsonVal::obj);
            let t_name = params.get_str("name").unwrap_or("");
            let t_args = params.get("arguments").cloned().unwrap_or_else(JsonVal::obj);

            let mut resp = JsonVal::obj();
            resp.insert("jsonrpc", JsonVal::Str("2.0".to_string()));
            resp.insert("id", msg_id);

            match dispatch_tool(env_p, t_name, &t_args) {
                Ok(res_val) => {
                    let mut c_item = JsonVal::obj();
                    c_item.insert("type", JsonVal::Str("text".to_string()));
                    c_item.insert("text", JsonVal::Str(res_val.to_json_string()));
                    let mut result = JsonVal::obj();
                    result.insert("content", JsonVal::Arr(vec![c_item]));
                    resp.insert("result", result);
                }
                Err(err_msg) => {
                    let mut c_item = JsonVal::obj();
                    c_item.insert("type", JsonVal::Str("text".to_string()));
                    c_item.insert("text", JsonVal::Str(format!("Error: {}", err_msg)));
                    let mut result = JsonVal::obj();
                    result.insert("isError", JsonVal::Bool(true));
                    result.insert("content", JsonVal::Arr(vec![c_item]));
                    resp.insert("result", result);
                }
            }
            send_json_line(&mut stdout, &resp);
        } else if method == "ping" {
            let mut resp = JsonVal::obj();
            resp.insert("jsonrpc", JsonVal::Str("2.0".to_string()));
            resp.insert("id", msg_id);
            resp.insert("result", JsonVal::obj());
            send_json_line(&mut stdout, &resp);
        } else {
            let mut err = JsonVal::obj();
            err.insert("code", JsonVal::Num(-32601.0));
            err.insert("message", JsonVal::Str(format!("Method not found: {}", method)));
            let mut resp = JsonVal::obj();
            resp.insert("jsonrpc", JsonVal::Str("2.0".to_string()));
            resp.insert("id", msg_id);
            resp.insert("error", err);
            send_json_line(&mut stdout, &resp);
        }
    }
}

fn main() {
    let env_p = EnvPaths::resolve();
    let cli_args: Vec<String> = env::args().skip(1).collect();

    if let Some(sub) = cli_args.first().map(|s| s.as_str()) {
        match sub {
            "--version" | "-V" | "version" => {
                println!("{} {} (native-rust-arm64-lse)", SERVER_NAME, SERVER_VERSION);
                return;
            }
            "status" => {
                println!("{}", environment_status_rust(&env_p).to_json_string());
                return;
            }
            "blender-status" => {
                println!("{}", get_blender_status_rust(&env_p).to_json_string());
                return;
            }
            "blender-setup" => match run_blender_setup_rust(&env_p) {
                Ok(v) => println!("{}", v.to_json_string()),
                Err(e) => {
                    eprintln!("Error: {}", e);
                    std::process::exit(1);
                }
            },
            "--help" | "-h" | "help" => {
                println!("AGY Video Studio 3D v{} — Native Rust ARM64 MCP & CLI", SERVER_VERSION);
                println!("Usage: agy-video-mcp [status | blender-status | blender-setup | --version]");
                println!("(No args starts JSON-RPC 2.0 MCP server on stdio)");
                return;
            }
            _ => {}
        }
        if matches!(sub, "blender-setup") {
            return;
        }
    }

    run_mcp_stdio(&env_p);
}
