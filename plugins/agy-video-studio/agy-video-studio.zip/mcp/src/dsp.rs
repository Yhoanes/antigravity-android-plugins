// dsp.rs — Native Rust ARM64 48kHz Stereo Score Synthesizer, Procedural SFX Engine & Character Voice DSP (v3.0.0)
use crate::json::JsonVal;
use crate::EnvPaths;
use std::f32::consts::PI;
use std::fs::{self, File};
use std::io::{BufWriter, Write};
use std::path::{Path, PathBuf};
use std::process::Command;

const KEYNOTE_CHORDS: [(f32, [f32; 5]); 4] = [
    (87.31, [174.61, 220.00, 261.63, 329.63, 392.00]), // Fmaj9
    (73.42, [146.83, 220.00, 261.63, 329.63, 349.23]), // Dm9
    (58.27, [116.54, 174.61, 220.00, 261.63, 293.66]), // Bbmaj9
    (65.41, [130.81, 196.00, 220.00, 261.63, 349.23]), // C11
];

const DARK_SYNTH_CHORDS: [(f32, [f32; 5]); 4] = [
    (73.42, [146.83, 220.00, 261.63, 329.63, 440.00]), // Dm
    (58.27, [116.54, 174.61, 233.08, 293.66, 349.23]), // Bb
    (87.31, [174.61, 220.00, 261.63, 349.23, 440.00]), // F
    (65.41, [130.81, 196.00, 246.94, 293.66, 392.00]), // C
];

struct XorShift64(u64);

impl XorShift64 {
    fn new(seed: u64) -> Self {
        Self(if seed == 0 { 0x9E37_79B9_7F4A_7C15 } else { seed })
    }
    fn next_u64(&mut self) -> u64 {
        let mut x = self.0;
        x ^= x << 13;
        x ^= x >> 7;
        x ^= x << 17;
        self.0 = x;
        x
    }
    fn next_f32(&mut self) -> f32 {
        ((self.next_u64() >> 40) as f32) / ((1u64 << 24) as f32)
    }
    fn range_f32(&mut self, lo: f32, hi: f32) -> f32 {
        lo + (hi - lo) * self.next_f32()
    }
    fn signed_noise(&mut self) -> f32 {
        self.next_f32() * 2.0 - 1.0
    }
}

pub fn write_stereo_wav_i16(path: &Path, sample_rate: u32, left: &[f32], right: &[f32]) -> Result<(), String> {
    if let Some(parent) = path.parent() {
        fs::create_dir_all(parent).map_err(|e| e.to_string())?;
    }
    let n = left.len().min(right.len());
    let data_bytes = (n * 4) as u32;
    let riff_size = 36u32.saturating_add(data_bytes);
    let byte_rate = sample_rate * 4;

    let f = File::create(path).map_err(|e| format!("Failed creating WAV {}: {}", path.display(), e))?;
    let mut w = BufWriter::with_capacity(65536, f);

    w.write_all(b"RIFF").map_err(|e| e.to_string())?;
    w.write_all(&riff_size.to_le_bytes()).map_err(|e| e.to_string())?;
    w.write_all(b"WAVEfmt ").map_err(|e| e.to_string())?;
    w.write_all(&16u32.to_le_bytes()).map_err(|e| e.to_string())?;
    w.write_all(&1u16.to_le_bytes()).map_err(|e| e.to_string())?; // PCM
    w.write_all(&2u16.to_le_bytes()).map_err(|e| e.to_string())?; // Stereo
    w.write_all(&sample_rate.to_le_bytes()).map_err(|e| e.to_string())?;
    w.write_all(&byte_rate.to_le_bytes()).map_err(|e| e.to_string())?;
    w.write_all(&4u16.to_le_bytes()).map_err(|e| e.to_string())?; // BlockAlign
    w.write_all(&16u16.to_le_bytes()).map_err(|e| e.to_string())?; // BitsPerSample
    w.write_all(b"data").map_err(|e| e.to_string())?;
    w.write_all(&data_bytes.to_le_bytes()).map_err(|e| e.to_string())?;

    for i in 0..n {
        let sl = (left[i].clamp(-1.0, 1.0) * 32767.0) as i16;
        let sr = (right[i].clamp(-1.0, 1.0) * 32767.0) as i16;
        w.write_all(&sl.to_le_bytes()).map_err(|e| e.to_string())?;
        w.write_all(&sr.to_le_bytes()).map_err(|e| e.to_string())?;
    }
    w.flush().map_err(|e| e.to_string())
}

pub fn synthesize_ambient_score_rust(
    out_wav: &Path,
    duration_sec: f64,
    style: &str,
    bpm: f64,
    sample_rate: u32,
) -> Result<(), String> {
    let dur = duration_sec.clamp(2.0, 300.0) as f32;
    let n_samples = (dur * sample_rate as f32) as usize;
    let eff_bpm = if style == "dark_synth_slowed" && (bpm - 90.0).abs() < 0.01 {
        74.0
    } else {
        bpm.clamp(45.0, 160.0) as f32
    };
    let bar_sec = (60.0 / eff_bpm) * 4.0;
    let chords = if style == "dark_synth_slowed" {
        &DARK_SYNTH_CHORDS
    } else {
        &KEYNOTE_CHORDS
    };

    let mut left = vec![0.0f32; n_samples];
    let mut right = vec![0.0f32; n_samples];
    let sr_f = sample_rate as f32;
    let two_pi = 2.0 * PI;

    let bar_count = (dur / bar_sec).ceil() as usize;
    for bar_idx in 0..bar_count {
        let b_start = ((bar_idx as f32) * bar_sec * sr_f) as usize;
        let b_end = n_samples.min((((bar_idx as f32) + 1.42) * bar_sec * sr_f) as usize);
        if b_end <= b_start {
            continue;
        }
        let (bass_hz, notes_hz) = chords[bar_idx % chords.len()];
        let swell_len = (bar_sec * 1.35).max(0.5);

        for idx in b_start..b_end {
            let t_local = (idx - b_start) as f32 / sr_f;
            let norm_p = (t_local / swell_len).clamp(0.0, 1.0);
            let env = (PI * norm_p).sin().max(0.0).powf(1.25);
            let cello = if style == "dark_synth_slowed" {
                (0.55 * (two_pi * bass_hz * t_local).sin()
                    + 0.28 * (two_pi * bass_hz * 1.004 * t_local).sin()
                    + 0.17 * (1.8 * (two_pi * bass_hz * 2.0 * t_local).sin()).tanh())
                    * env
                    * 0.26
            } else {
                (0.78 * (two_pi * bass_hz * t_local).sin()
                    + 0.22 * (two_pi * bass_hz * 2.0 * t_local).sin())
                    * env
                    * 0.22
            };
            left[idx] += cello;
            right[idx] += cello * 0.96;
        }

        let beat_sec = bar_sec / 4.0;
        for (n_idx, &freq) in notes_hz.iter().enumerate() {
            let note_offset = if style == "minimal_pad" {
                0.0
            } else if style == "dark_synth_slowed" {
                (n_idx as f32) * 0.25 * beat_sec
            } else {
                (n_idx as f32) * 0.50 * beat_sec
            };
            let ns = (((bar_idx as f32) * bar_sec + note_offset) * sr_f) as usize;
            let ne = n_samples.min(ns + (3.6 * sr_f) as usize);
            if ne <= ns || ns >= n_samples {
                continue;
            }
            let att_div = if style == "dark_synth_slowed" {
                0.30
            } else if style == "cinematic_epic" {
                0.18
            } else {
                0.024
            };
            let decay_rate = if matches!(style, "minimal_pad" | "cinematic_epic" | "dark_synth_slowed") {
                0.48
            } else if style == "lofi_vlog" {
                1.55
            } else {
                1.25
            };
            let pan = 0.28 + 0.44 * (n_idx as f32 / 4.0);
            let gl = 1.0 - pan * 0.45;
            let gr = 0.55 + pan * 0.45;

            for idx in ns..ne {
                let tn = (idx - ns) as f32 / sr_f;
                let attack = (tn / att_div).min(1.0);
                let decay = (-tn * decay_rate).exp();
                let vib = if matches!(style, "lofi_vlog" | "dark_synth_slowed") {
                    1.0 + 0.003 * (two_pi * 3.4 * tn).sin()
                } else {
                    1.0
                };
                let tone = (0.76 * (two_pi * freq * vib * tn).sin()
                    + 0.18 * (two_pi * freq * 1.005 * tn).sin()
                    + 0.06 * (two_pi * freq * 2.0 * tn).sin() * (-tn * 2.4).exp())
                    * attack
                    * decay
                    * 0.115;
                left[idx] += tone * gl;
                right[idx] += tone * gr;
            }
        }

        if matches!(style, "deep_tech_pulse" | "lofi_vlog" | "dark_synth_slowed") {
            for beat in 0..4 {
                if style == "dark_synth_slowed" && beat != 0 && beat != 2 {
                    continue;
                }
                let swing = if style == "lofi_vlog" && beat % 2 == 1 {
                    0.04 * beat_sec
                } else {
                    0.0
                };
                let ps = (((bar_idx as f32) * bar_sec + (beat as f32) * beat_sec + swing) * sr_f) as usize;
                let pe = n_samples.min(ps + (0.30 * sr_f) as usize);
                if pe <= ps || ps >= n_samples {
                    continue;
                }
                let gain_k = if style == "deep_tech_pulse" { 0.14 } else { 0.11 };
                for idx in ps..pe {
                    let tp = (idx - ps) as f32 / sr_f;
                    let kf = 48.0 + 44.0 * (-tp * 24.0).exp();
                    let pulse = (two_pi * kf * tp).sin() * (-tp * 14.0).exp() * gain_k;
                    left[idx] += pulse;
                    right[idx] += pulse;
                }
            }
        }
    }

    // Smooth fade-in (0.6s) and fade-out (1.6s) + peak normalization
    let fi = n_samples.min((0.6 * sr_f) as usize);
    let fo = n_samples.min((1.6 * sr_f) as usize);
    for i in 0..fi {
        let r = i as f32 / fi.max(1) as f32;
        left[i] *= r;
        right[i] *= r;
    }
    for i in 0..fo {
        let r = 1.0 - (i as f32 / fo.max(1) as f32);
        let pos = n_samples - fo + i;
        left[pos] *= r;
        right[pos] *= r;
    }

    let mut peak = 1e-5f32;
    for i in 0..n_samples {
        peak = peak.max(left[i].abs()).max(right[i].abs());
    }
    let gain = (0.85 / peak).min(1.0);
    for i in 0..n_samples {
        left[i] *= gain;
        right[i] *= gain;
    }

    write_stereo_wav_i16(out_wav, sample_rate, &left, &right)
}

pub fn synthesize_sfx_timeline_rust(
    out_wav: &Path,
    duration_sec: f64,
    sfx_events: &[JsonVal],
    sample_rate: u32,
) -> Result<(), String> {
    let dur = duration_sec.clamp(0.5, 300.0) as f32;
    let n_samples = (dur * sample_rate as f32) as usize;
    let sr_f = sample_rate as f32;
    let two_pi = 2.0 * PI;

    let mut left = vec![0.0f32; n_samples];
    let mut right = vec![0.0f32; n_samples];
    let mut rng = XorShift64::new(0x2026_B1E4_DE55);

    for ev in sfx_events {
        let at_s = ev.get_f64("at_sec").unwrap_or(0.0).max(0.0) as f32;
        let kind = ev.get_str("sfx").unwrap_or("mech_typing");
        let ev_dur = ev
            .get_f64("duration")
            .unwrap_or(if kind == "mech_typing" { 1.4 } else { 0.45 }) as f32;
        let vol = ev.get_f64("volume").unwrap_or(0.58) as f32;
        let s0 = (at_s * sr_f) as usize;
        if s0 >= n_samples {
            continue;
        }

        match kind {
            "mech_typing" => {
                let mut t_cur = at_s;
                let t_end = (dur - 0.04).min(at_s + ev_dur);
                while t_cur < t_end {
                    let ks = (t_cur * sr_f) as usize;
                    let ke = n_samples.min(ks + (0.028 * sr_f) as usize);
                    let freq = rng.range_f32(1650.0, 2480.0);
                    let pan = rng.range_f32(0.35, 0.65);
                    for idx in ks..ke {
                        let tk = (idx - ks) as f32 / sr_f;
                        let click = (rng.signed_noise() * 0.55 * (-tk * 190.0).exp()
                            + 0.45 * (two_pi * freq * tk).sin() * (-tk * 140.0).exp())
                            * vol
                            * 0.48;
                        left[idx] += click * (1.0 - pan * 0.4);
                        right[idx] += click * (0.6 + pan * 0.4);
                    }
                    t_cur += rng.range_f32(0.065, 0.145);
                }
            }
            "error_buzz" => {
                let elen = (n_samples - s0).min((ev_dur.max(0.24) * sr_f) as usize);
                for i in 0..elen {
                    let te = i as f32 / sr_f;
                    let env = (-te * 7.5).exp();
                    let sig = (0.65 * (3.2 * (two_pi * 118.0 * te).sin()).tanh()
                        + 0.35 * (two_pi * 88.5 * te).sin())
                        * env
                        * vol
                        * 0.55;
                    left[s0 + i] += sig;
                    right[s0 + i] += sig;
                }
            }
            "white_glitch" => {
                let glen = (n_samples - s0).min((ev_dur.max(0.35) * sr_f) as usize);
                let g_tot = (glen as f32 / sr_f).max(0.05);
                for i in 0..glen {
                    let tg = i as f32 / sr_f;
                    let norm_g = tg / g_tot;
                    let stutter = if (two_pi * 22.0 * tg).sin() > -0.25 { 1.0 } else { 0.0 };
                    let sweep = (two_pi * (240.0 + 1850.0 * norm_g * norm_g) * tg).sin();
                    let sig = (0.55 * rng.signed_noise() * 0.5 * stutter + 0.45 * sweep)
                        * (norm_g * 2.5).min(1.0)
                        * vol
                        * 0.55;
                    left[s0 + i] += sig;
                    right[s0 + i] += sig * 0.92;
                }
            }
            "portal_flash" => {
                let plen = (n_samples - s0).min((ev_dur.max(0.65) * sr_f) as usize);
                for i in 0..plen {
                    let tp = i as f32 / sr_f;
                    let sub = (two_pi * (95.0 * (-tp * 2.8).exp() + 38.0) * tp).sin() * (-tp * 3.2).exp();
                    let shim = (0.4 * (two_pi * 523.25 * tp).sin() + 0.35 * (two_pi * 783.99 * tp).sin())
                        * (-tp * 2.4).exp();
                    let sig = (0.65 * sub + 0.35 * shim) * vol * 0.62;
                    left[s0 + i] += sig;
                    right[s0 + i] += sig;
                }
            }
            "success_chime" => {
                let clen = (n_samples - s0).min((0.85 * sr_f) as usize);
                for i in 0..clen {
                    let tc = i as f32 / sr_f;
                    let n1 = (two_pi * 587.33 * tc).sin() * (-tc * 5.5).exp();
                    let n2 = if tc >= 0.11 {
                        let t2 = tc - 0.11;
                        (two_pi * 880.0 * t2).sin() * (-t2 * 3.6).exp()
                    } else {
                        0.0
                    };
                    let sig = (0.5 * n1 + 0.6 * n2) * vol * 0.52;
                    left[s0 + i] += sig;
                    right[s0 + i] += sig;
                }
            }
            "footsteps" => {
                let mut t_cur = at_s;
                let t_end = (dur - 0.04).min(at_s + ev_dur);
                while t_cur < t_end {
                    let fs_i = (t_cur * sr_f) as usize;
                    let fe_i = n_samples.min(fs_i + (0.055 * sr_f) as usize);
                    for idx in fs_i..fe_i {
                        let tf = (idx - fs_i) as f32 / sr_f;
                        let thud = (two_pi * 135.0 * (-tf * 30.0).exp() * tf).sin()
                            * (-tf * 45.0).exp()
                            * vol
                            * 0.48;
                        left[idx] += thud;
                        right[idx] += thud;
                    }
                    t_cur += 0.28;
                }
            }
            _ => {}
        }
    }

    write_stereo_wav_i16(out_wav, sample_rate, &left, &right)
}

fn voice_for_effect(lang: &str, explicit_voice: Option<&str>, effect: &str) -> String {
    if let Some(v) = explicit_voice {
        if !v.trim().is_empty() {
            return v.trim().to_string();
        }
    }
    let l = lang.to_lowercase();
    if matches!(effect, "cute_voxel_bot" | "backrooms_echo") {
        if l.starts_with("es") {
            return "es-MX-DaliaNeural".to_string();
        }
        return "en-US-AvaNeural".to_string();
    }
    match l.as_str() {
        "es" => "es-US-AlonsoNeural",
        "es-mx" => "es-MX-JorgeNeural",
        "es-es" => "es-ES-AlvaroNeural",
        "es-f" => "es-MX-DaliaNeural",
        "en" => "en-US-AndrewNeural",
        "en-f" => "en-US-AvaNeural",
        "pt" => "pt-BR-AntonioNeural",
        _ => "es-US-AlonsoNeural",
    }
    .to_string()
}

fn voice_effect_af(effect: &str) -> &'static str {
    match effect {
        "cute_voxel_bot" => "aformat=sample_rates=48000:channel_layouts=stereo,asetrate=48000*1.27,aresample=48000,atempo=0.85,highpass=f=185,volume=1.25",
        "backrooms_echo" => "aformat=sample_rates=48000:channel_layouts=stereo,asetrate=48000*1.24,aresample=48000,atempo=0.86,aecho=0.85:0.78:65|135:0.34|0.22,volume=1.25",
        "deep_ai" => "aformat=sample_rates=48000:channel_layouts=stereo,asetrate=48000*0.83,aresample=48000,atempo=1.15,lowpass=f=6500,volume=1.2",
        "radio_glitch" => "aformat=sample_rates=48000:channel_layouts=stereo,highpass=f=350,lowpass=f=3600,acrusher=bits=8:mix=0.38,volume=1.2",
        _ => "aformat=sample_rates=48000:channel_layouts=stereo,volume=1.05",
    }
}

pub fn probe_audio_duration(env_p: &EnvPaths, ffmpeg_bin: &Path, audio_path: &Path) -> f64 {
    let mut cmd = Command::new(ffmpeg_bin);
    env_p.configure_bionic_cmd(&mut cmd);
    cmd.arg("-hide_banner").arg("-i").arg(audio_path);
    if let Ok(out) = cmd.output() {
        let stderr = String::from_utf8_lossy(&out.stderr);
        if let Some(pos) = stderr.find("Duration:") {
            let sub = &stderr[pos + 9..];
            let trimmed = sub.trim_start();
            let end = trimmed.find(',').unwrap_or(trimmed.len().min(16));
            let parts: Vec<&str> = trimmed[..end].split(':').collect();
            if parts.len() == 3 {
                let h = parts[0].trim().parse::<f64>().unwrap_or(0.0);
                let m = parts[1].trim().parse::<f64>().unwrap_or(0.0);
                let s = parts[2].trim().parse::<f64>().unwrap_or(0.0);
                return h * 3600.0 + m * 60.0 + s;
            }
        }
    }
    0.0
}

fn parse_hms_ms(ts: &str) -> Option<f64> {
    let clean = ts.trim().replace(',', ".");
    let parts: Vec<&str> = clean.split(':').collect();
    if parts.len() == 3 {
        let h = parts[0].parse::<f64>().ok()?;
        let m = parts[1].parse::<f64>().ok()?;
        let s = parts[2].parse::<f64>().ok()?;
        Some(h * 3600.0 + m * 60.0 + s)
    } else if parts.len() == 2 {
        let m = parts[0].parse::<f64>().ok()?;
        let s = parts[1].parse::<f64>().ok()?;
        Some(m * 60.0 + s)
    } else {
        None
    }
}

fn parse_vtt_captions(vtt: &str) -> Vec<JsonVal> {
    let mut out = Vec::new();
    let lines: Vec<&str> = vtt.lines().collect();
    let mut i = 0;
    while i < lines.len() {
        let l = lines[i].trim();
        if let Some(arrow) = l.find("-->") {
            let s_str = l[..arrow].trim();
            let e_part = l[arrow + 3..].split_whitespace().next().unwrap_or("");
            if let (Some(st), Some(et)) = (parse_hms_ms(s_str), parse_hms_ms(e_part)) {
                i += 1;
                let mut text_parts = Vec::new();
                while i < lines.len() && !lines[i].trim().is_empty() {
                    text_parts.push(lines[i].trim());
                    i += 1;
                }
                let joined = text_parts.join(" ");
                if !joined.is_empty() {
                    let mut c = JsonVal::obj();
                    c.insert("start_sec", JsonVal::Num((st * 1000.0).round() / 1000.0));
                    c.insert("end_sec", JsonVal::Num((et.max(st + 0.25) * 1000.0).round() / 1000.0));
                    c.insert("text", JsonVal::Str(joined));
                    out.push(c);
                }
                continue;
            }
        }
        i += 1;
    }
    out
}

fn run_edge_tts_cli(
    env_p: &EnvPaths,
    text: &str,
    voice: &str,
    rate: &str,
    pitch: &str,
    out_mp3: &Path,
    out_vtt: Option<&Path>,
) -> Result<(), String> {
    let py = env_p.prefix.join("bin/python3");
    let mut cmd = if py.exists() {
        let mut c = Command::new(&py);
        c.arg("-m").arg("edge_tts");
        c
    } else {
        Command::new("edge-tts")
    };
    env_p.configure_bionic_cmd(&mut cmd);
    cmd.arg("--voice")
        .arg(voice)
        .arg(format!("--rate={}", rate))
        .arg(format!("--pitch={}", pitch))
        .arg("--text")
        .arg(text)
        .arg("--write-media")
        .arg(out_mp3);
    if let Some(vp) = out_vtt {
        cmd.arg("--write-subtitles").arg(vp);
    }
    let out = cmd.output().map_err(|e| format!("Failed invoking edge_tts: {}", e))?;
    if !out.status.success() {
        return Err(format!(
            "edge_tts failed: {}",
            String::from_utf8_lossy(&out.stderr)
        ));
    }
    Ok(())
}

pub fn handle_audio_studio_generate(env_p: &EnvPaths, ffmpeg_bin: &Path, args: &JsonVal) -> Result<JsonVal, String> {
    let out_dir_str = args
        .get_str("output_dir")
        .ok_or_else(|| "Missing 'output_dir'".to_string())?;
    let out_dir = PathBuf::from(out_dir_str);
    fs::create_dir_all(&out_dir).map_err(|e| e.to_string())?;

    let script_text = args.get_str("script_text").unwrap_or("").trim();
    let lang = args.get_str("lang").unwrap_or("es");
    let voice_arg = args.get_str("voice");
    let voice_effect = args.get_str("voice_effect").unwrap_or("natural");
    let rate = args.get_str("rate").unwrap_or("+2%");
    let pitch = args.get_str("pitch").unwrap_or("-1Hz");
    let music_style = args.get_str("music_style").unwrap_or("gemini_keynote");
    let bpm = args.get_f64("bpm").unwrap_or(90.0);
    let music_volume = args.get_f64("music_volume").unwrap_or(0.26);
    let tail_sec = args.get_f64("tail_sec").unwrap_or(1.5).max(0.5);

    let mut vo_path: Option<PathBuf> = None;
    let mut captions: Vec<JsonVal> = Vec::new();
    let mut used_voice: Option<String> = None;
    let mut vo_dur = 0.0f64;

    if let Some(dlg_arr) = args.get("dialogue_lines").and_then(|v| v.as_arr()) {
        if !dlg_arr.is_empty() {
            let mut line_wavs: Vec<(f64, PathBuf)> = Vec::new();
            let mut max_end = 0.0f64;

            for (idx, item) in dlg_arr.iter().enumerate() {
                let txt = item.get_str("text").unwrap_or("").trim();
                if txt.is_empty() {
                    continue;
                }
                let at_s = item.get_f64("at_sec").unwrap_or(idx as f64 * 2.0).max(0.0);
                let l_lang = item.get_str("lang").unwrap_or(lang);
                let l_eff = item.get_str("effect").unwrap_or(voice_effect);
                let l_voice = voice_for_effect(l_lang, item.get_str("voice").or(voice_arg), l_eff);
                used_voice = Some(l_voice.clone());

                let raw_mp3 = out_dir.join(format!("_dlg_{:02}_raw.mp3", idx));
                let proc_wav = out_dir.join(format!("_dlg_{:02}.wav", idx));
                run_edge_tts_cli(env_p, txt, &l_voice, rate, pitch, &raw_mp3, None)?;

                let mut ff = Command::new(ffmpeg_bin);
                env_p.configure_bionic_cmd(&mut ff);
                let out_ff = ff
                    .args(["-y", "-i"])
                    .arg(&raw_mp3)
                    .args(["-af", voice_effect_af(l_eff), "-ar", "48000", "-ac", "2", "-c:a", "pcm_s16le"])
                    .arg(&proc_wav)
                    .output()
                    .map_err(|e| e.to_string())?;
                let _ = fs::remove_file(&raw_mp3);
                if !out_ff.status.success() {
                    return Err(format!("FFmpeg voice DSP failed: {}", String::from_utf8_lossy(&out_ff.stderr)));
                }

                let ldur = probe_audio_duration(env_p, ffmpeg_bin, &proc_wav).max(0.35);
                let end_s = at_s + ldur;
                if end_s > max_end {
                    max_end = end_s;
                }
                line_wavs.push((at_s, proc_wav));

                let mut cap = JsonVal::obj();
                cap.insert("start_sec", JsonVal::Num((at_s * 1000.0).round() / 1000.0));
                cap.insert("end_sec", JsonVal::Num(((end_s + 0.12) * 1000.0).round() / 1000.0));
                cap.insert("text", JsonVal::Str(txt.to_string()));
                captions.push(cap);
            }

            vo_dur = max_end;
            let pre_target = args.get_f64("duration_sec").unwrap_or(0.0);
            let total_d = if pre_target > 0.0 { pre_target } else { vo_dur + tail_sec };

            if !line_wavs.is_empty() {
                let vo_comb = out_dir.join("voiceover.wav");
                let mut ff = Command::new(ffmpeg_bin);
                env_p.configure_bionic_cmd(&mut ff);
                ff.arg("-y");
                let mut fc_parts = Vec::new();
                let mut labels = String::new();
                for (idx, (at_s, lwav)) in line_wavs.iter().enumerate() {
                    ff.arg("-i").arg(lwav);
                    let ms = (at_s * 1000.0).round() as i64;
                    fc_parts.push(format!("[{}:a]adelay={}|{},apad=whole_dur={:.3}[d{}]", idx, ms, ms, total_d, idx));
                    labels.push_str(&format!("[d{}]", idx));
                }
                fc_parts.push(format!("{}amix=inputs={}:duration=first:normalize=0[vout]", labels, line_wavs.len()));
                let out_mix = ff
                    .arg("-filter_complex")
                    .arg(fc_parts.join(";"))
                    .args(["-map", "[vout]", "-ar", "48000", "-ac", "2"])
                    .arg(&vo_comb)
                    .output()
                    .map_err(|e| e.to_string())?;
                for (_, lw) in &line_wavs {
                    let _ = fs::remove_file(lw);
                }
                if !out_mix.status.success() {
                    return Err(format!("Dialogue mix failed: {}", String::from_utf8_lossy(&out_mix.stderr)));
                }
                vo_path = Some(vo_comb);
            }
        }
    } else if !script_text.is_empty() {
        let chosen = voice_for_effect(lang, voice_arg, voice_effect);
        used_voice = Some(chosen.clone());
        let raw_mp3 = out_dir.join("voiceover_raw.mp3");
        let vtt_path = out_dir.join("voiceover.vtt");
        run_edge_tts_cli(env_p, script_text, &chosen, rate, pitch, &raw_mp3, Some(&vtt_path))?;
        if let Ok(vtt_str) = fs::read_to_string(&vtt_path) {
            captions = parse_vtt_captions(&vtt_str);
        }
        let _ = fs::remove_file(&vtt_path);

        if voice_effect != "natural" {
            let old_d = probe_audio_duration(env_p, ffmpeg_bin, &raw_mp3).max(0.1);
            let proc_wav = out_dir.join("voiceover.wav");
            let mut ff = Command::new(ffmpeg_bin);
            env_p.configure_bionic_cmd(&mut ff);
            let out_ff = ff
                .args(["-y", "-i"])
                .arg(&raw_mp3)
                .args(["-af", voice_effect_af(voice_effect), "-ar", "48000", "-ac", "2", "-c:a", "pcm_s16le"])
                .arg(&proc_wav)
                .output()
                .map_err(|e| e.to_string())?;
            let _ = fs::remove_file(&raw_mp3);
            if !out_ff.status.success() {
                return Err(format!("Voice DSP failed: {}", String::from_utf8_lossy(&out_ff.stderr)));
            }
            vo_dur = probe_audio_duration(env_p, ffmpeg_bin, &proc_wav);
            let ratio = if old_d > 0.0 { vo_dur / old_d } else { 1.0 };
            for c in &mut captions {
                if let (Some(st), Some(et)) = (c.get_f64("start_sec"), c.get_f64("end_sec")) {
                    c.insert("start_sec", JsonVal::Num((st * ratio * 1000.0).round() / 1000.0));
                    c.insert("end_sec", JsonVal::Num((et * ratio * 1000.0).round() / 1000.0));
                }
            }
            vo_path = Some(proc_wav);
        } else {
            let final_mp3 = out_dir.join("voiceover.mp3");
            let _ = fs::rename(&raw_mp3, &final_mp3);
            vo_dur = probe_audio_duration(env_p, ffmpeg_bin, &final_mp3);
            vo_path = Some(final_mp3);
        }
    }

    let req_dur = args.get_f64("duration_sec").unwrap_or(0.0);
    let target_dur = if req_dur > 0.0 {
        req_dur
    } else if vo_dur > 0.0 {
        vo_dur + tail_sec
    } else {
        15.0
    };

    // Synthesize 48kHz stereo music & procedural SFX natively in Rust!
    let music_wav = out_dir.join("ambient_keynote_music.wav");
    synthesize_ambient_score_rust(&music_wav, target_dur, music_style, bpm, 48000)?;

    let mut sfx_path: Option<PathBuf> = None;
    if let Some(sfx_arr) = args.get("sfx_events").and_then(|v| v.as_arr()) {
        if !sfx_arr.is_empty() {
            let sp = out_dir.join("sfx_track.wav");
            synthesize_sfx_timeline_rust(&sp, target_dur, sfx_arr, 48000)?;
            sfx_path = Some(sp);
        }
    }

    let master_wav = out_dir.join("master_audio.wav");
    if let Some(ref vp) = vo_path {
        let mut ff = Command::new(ffmpeg_bin);
        env_p.configure_bionic_cmd(&mut ff);
        ff.args(["-y", "-i"]).arg(vp).arg("-i").arg(&music_wav);
        let fc = if let Some(ref sp) = sfx_path {
            ff.arg("-i").arg(sp);
            format!(
                "[0:a]aformat=sample_rates=48000:channel_layouts=stereo,apad=whole_dur={td:.3},volume=1.18[vo];\
                 [1:a]aformat=sample_rates=48000:channel_layouts=stereo,atrim=0:{td:.3},volume={mv:.3}[bgm];\
                 [2:a]aformat=sample_rates=48000:channel_layouts=stereo,atrim=0:{td:.3},volume=0.95[sfx];\
                 [bgm][vo]sidechaincompress=threshold=0.025:ratio=4.5:attack=15:release=260[duck];\
                 [vo][duck][sfx]amix=inputs=3:duration=first:dropout_transition=0:normalize=0,alimiter=limit=0.95[out]",
                td = target_dur,
                mv = music_volume
            )
        } else {
            format!(
                "[0:a]aformat=sample_rates=48000:channel_layouts=stereo,apad=whole_dur={td:.3},volume=1.15[vo];\
                 [1:a]aformat=sample_rates=48000:channel_layouts=stereo,atrim=0:{td:.3},volume={mv:.3}[bgm];\
                 [bgm][vo]sidechaincompress=threshold=0.025:ratio=5:attack=15:release=280[duck];\
                 [vo][duck]amix=inputs=2:duration=longest:dropout_transition=0:normalize=0,alimiter=limit=0.95[out]",
                td = target_dur,
                mv = music_volume
            )
        };
        let out_m = ff
            .arg("-filter_complex")
            .arg(fc)
            .args(["-map", "[out]", "-ar", "48000", "-ac", "2", "-c:a", "pcm_s16le"])
            .arg(&master_wav)
            .output()
            .map_err(|e| e.to_string())?;
        if !out_m.status.success() {
            return Err(format!("Master mix failed: {}", String::from_utf8_lossy(&out_m.stderr)));
        }
    } else if let Some(ref sp) = sfx_path {
        let mut ff = Command::new(ffmpeg_bin);
        env_p.configure_bionic_cmd(&mut ff);
        let fc = format!(
            "[0:a]aformat=sample_rates=48000:channel_layouts=stereo,atrim=0:{td:.3},volume={mv:.3}[bgm];\
             [1:a]aformat=sample_rates=48000:channel_layouts=stereo,atrim=0:{td:.3},volume=0.95[sfx];\
             [bgm][sfx]amix=inputs=2:duration=first:normalize=0,alimiter=limit=0.95[out]",
            td = target_dur,
            mv = music_volume
        );
        let out_m = ff
            .args(["-y", "-i"])
            .arg(&music_wav)
            .arg("-i")
            .arg(sp)
            .arg("-filter_complex")
            .arg(fc)
            .args(["-map", "[out]", "-ar", "48000", "-ac", "2", "-c:a", "pcm_s16le"])
            .arg(&master_wav)
            .output()
            .map_err(|e| e.to_string())?;
        if !out_m.status.success() {
            return Err(format!("Instrumental+SFX mix failed: {}", String::from_utf8_lossy(&out_m.stderr)));
        }
    } else {
        fs::copy(&music_wav, &master_wav).map_err(|e| e.to_string())?;
    }

    let mut res = JsonVal::obj();
    res.insert("engine", JsonVal::Str("native_rust_arm64_dsp_v3".to_string()));
    res.insert("output_dir", JsonVal::Str(out_dir.display().to_string()));
    res.insert(
        "voice_used",
        used_voice.map(JsonVal::Str).unwrap_or(JsonVal::Null),
    );
    res.insert("voice_effect", JsonVal::Str(voice_effect.to_string()));
    res.insert(
        "voiceover_path",
        vo_path.map(|p| JsonVal::Str(p.display().to_string())).unwrap_or(JsonVal::Null),
    );
    res.insert(
        "sfx_path",
        sfx_path.map(|p| JsonVal::Str(p.display().to_string())).unwrap_or(JsonVal::Null),
    );
    res.insert("music_path", JsonVal::Str(music_wav.display().to_string()));
    res.insert("master_audio_path", JsonVal::Str(master_wav.display().to_string()));
    res.insert("duration_sec", JsonVal::Num((target_dur * 100.0).round() / 100.0));
    res.insert("voiceover_duration_sec", JsonVal::Num((vo_dur * 100.0).round() / 100.0));
    res.insert("captions", JsonVal::Arr(captions));
    Ok(res)
}
