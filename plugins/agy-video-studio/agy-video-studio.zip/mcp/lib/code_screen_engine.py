"""
Crisp Programmatic Code, Terminal Attempt Loop & AI Chat Screen Renderer (v3.0).
Generates pixel-sharp 2D animated videos (.mp4 via Android GPU h264_mediacodec) and keyframe stills (.png)
for standalone coding TikToks/Reels OR as dynamic emissive screen textures inside 3D Blender laptops.
"""

from __future__ import annotations

import math
import random
import re
import subprocess
from pathlib import Path

from .env_utils import resolve_font_path, select_video_encoder_args

# Token regex for lightweight zero-dependency syntax highlighting (JS/TS/Python/Rust/C)
_TOKEN_RE = re.compile(
    r"(//[^\n]*|#[^\n]*)"
    r"|(\"(?:\\.|[^\"\\])*\"|'(?:\\.|[^'\\])*'|`(?:\\.|[^`\\])*`)"
    r"|\b(function|const|let|var|if|else|return|async|await|for|while|break|continue|import|from|def|class|try|except|fn|pub|mut|true|false|null|None)\b"
    r"|\b(\d+(?:\.\d+)?)\b"
    r"|([a-zA-Z_]\w*)(?=\s*\()"
    r"|(\s+)"
    r"|([^\s\w]+|\w+)"
)


def _require_pillow():
    try:
        from PIL import Image, ImageDraw, ImageFont  # type: ignore

        return Image, ImageDraw, ImageFont
    except ImportError as exc:
        raise RuntimeError(
            "Pillow is required for 'video_render_code_screen'. Run 'agy-video-setup' or 'pkg install python-pillow'."
        ) from exc


def _load_font(role: str, size: int):
    _, _, ImageFont = _require_pillow()
    fp = resolve_font_path(role)
    if fp and fp.is_file():
        return ImageFont.truetype(str(fp), size=size)
    return ImageFont.load_default()


def _tokenize_line(line: str) -> list[tuple[str, tuple[int, int, int]]]:
    tokens: list[tuple[str, tuple[int, int, int]]] = []
    for m in _TOKEN_RE.finditer(line):
        comment, string_lit, kw, num, fn_call, ws, other = m.groups()
        if comment is not None:
            tokens.append((comment, (110, 122, 145)))
        elif string_lit is not None:
            tokens.append((string_lit, (158, 224, 158)))
        elif kw is not None:
            tokens.append((kw, (255, 148, 112)))  # Warm Claude coral-orange keywords
        elif num is not None:
            tokens.append((num, (245, 194, 118)))
        elif fn_call is not None:
            tokens.append((fn_call, (138, 186, 255)))
        elif ws is not None:
            tokens.append((ws, (230, 235, 245)))
        else:
            tokens.append((other or "", (232, 236, 244)))
    return tokens


def _ease_out_cubic(x: float) -> float:
    x = max(0.0, min(1.0, x))
    return 1.0 - (1.0 - x) ** 3


def _render_code_typing_frame(
    width: int,
    height: int,
    t_sec: float,
    dur_sec: float,
    args: dict,
    fonts: dict,
):
    Image, ImageDraw, _ = _require_pillow()
    img = Image.new("RGB", (width, height), (9, 11, 16))
    draw = ImageDraw.Draw(img)

    pad_x = int(width * 0.055)
    pad_y = int(height * 0.07)
    filename = str(args.get("filename", "checkout.js"))
    start_line = int(args.get("start_line", 39))
    code_text = str(
        args.get(
            "code",
            "function checkout(cart) {\n  const items = cart.items\n  let total = 0\n  total = sum(items)\n  return round(total * 1.11);\n}",
        )
    )
    highlight_fix = args.get("highlight_fix_char")  # e.g. {"line_offset": 3, "append": ";", "at_progress": 0.55}

    # Subtle top editor bar
    bar_h = int(height * 0.10)
    draw.rectangle([(0, 0), (width, bar_h)], fill=(15, 18, 26))
    draw.line([(0, bar_h), (width, bar_h)], fill=(34, 40, 56), width=2)

    dot_r = max(5, int(height * 0.010))
    dot_y = bar_h // 2
    for idx, col in enumerate(((255, 95, 86), (255, 189, 46), (39, 201, 63))):
        cx = pad_x + idx * (dot_r * 3)
        draw.ellipse((cx - dot_r, dot_y - dot_r, cx + dot_r, dot_y + dot_r), fill=col)

    draw.text((pad_x + dot_r * 11, dot_y - int(bar_h * 0.24)), filename, font=fonts["ui_sm"], fill=(168, 178, 198))

    typing_end = float(args.get("typing_duration_sec", max(0.8, dur_sec * 0.62)))
    progress = max(0.0, min(1.0, t_sec / max(0.05, typing_end)))

    active_code = code_text
    if isinstance(highlight_fix, dict):
        fix_prog = float(highlight_fix.get("at_progress", 0.55))
        if (t_sec / max(0.05, dur_sec)) >= fix_prog:
            lines_tmp = active_code.splitlines()
            l_idx = int(highlight_fix.get("line_offset", 0))
            if 0 <= l_idx < len(lines_tmp):
                lines_tmp[l_idx] = lines_tmp[l_idx] + str(highlight_fix.get("append", ";"))
            active_code = "\n".join(lines_tmp)

    total_chars = len(active_code)
    instant_show = bool(args.get("instant_code", False))
    visible_chars = total_chars if instant_show else int(round(total_chars * progress))
    shown_text = active_code[:visible_chars]
    lines = shown_text.split("\n")

    line_h = int(fonts["code_size"] * 1.52)
    y_cursor = bar_h + pad_y
    gutter_w = int(fonts["code_size"] * 2.6)

    last_x = pad_x + gutter_w
    last_y = y_cursor

    for idx, line_str in enumerate(lines):
        ly = y_cursor + idx * line_h
        if ly > height - line_h:
            break
        lnum = str(start_line + idx)
        # Subtle highlight on active typing line
        if idx == len(lines) - 1 and not instant_show and progress < 0.99:
            draw.rectangle([(0, ly - 4), (width, ly + line_h - 6)], fill=(18, 22, 33))
        draw.text((pad_x, ly), lnum, font=fonts["code"], fill=(86, 96, 118))

        cx = pad_x + gutter_w
        for tok_str, tok_col in _tokenize_line(line_str):
            if not tok_str:
                continue
            draw.text((cx, ly), tok_str, font=fonts["code"], fill=tok_col)
            bbox = fonts["code"].getbbox(tok_str)
            cx += max(0, bbox[2] - bbox[0])
        last_x = cx
        last_y = ly

    # Blinking cursor
    if int(t_sec * 3.2) % 2 == 0:
        cur_w = max(8, int(fonts["code_size"] * 0.52))
        cur_h = int(fonts["code_size"] * 1.08)
        draw.rectangle([(last_x + 3, last_y + 3), (last_x + 3 + cur_w, last_y + 3 + cur_h)], fill=(238, 129, 88))

    # Optional bottom status banner (error / passed)
    banner = args.get("status_banner")
    if isinstance(banner, dict):
        at_p = float(banner.get("at_progress", 0.65))
        now_p = t_sec / max(0.05, dur_sec)
        if now_p >= at_p:
            slide = _ease_out_cubic((now_p - at_p) / 0.10)
            b_kind = str(banner.get("type", "error")).lower()
            b_text = str(banner.get("text", "✗ 1 test failed"))
            bh = int(height * 0.20)
            by = int(height - bh * slide)
            bg_col = (118, 24, 28) if b_kind == "error" else (20, 108, 52)
            fg_col = (255, 195, 195) if b_kind == "error" else (210, 255, 222)
            draw.rectangle([(0, by), (width, height)], fill=bg_col)
            draw.text((pad_x, by + (bh - fonts["ui_lg_size"]) // 2 - 4), b_text, font=fonts["ui_lg"], fill=fg_col)

    # Optional cascading retry() glitch storm at end (01:08 TikTok twist)
    if bool(args.get("end_glitch", False)):
        g_start = float(args.get("glitch_start_progress", 0.80))
        now_p = t_sec / max(0.05, dur_sec)
        if now_p >= g_start:
            rng = random.Random(int(t_sec * 30) + 1337)
            intensity = min(1.0, (now_p - g_start) / max(0.05, 1.0 - g_start))
            count = int(6 + 48 * intensity)
            for _ in range(count):
                gx = rng.randint(-40, width - 80)
                gy = rng.randint(bar_h, height - 40)
                col = (225, 232, 245) if rng.random() > 0.25 else (255, 115, 92)
                draw.text((gx, gy), "retry()", font=fonts["code"], fill=col)

    return img


def _render_test_attempts_frame(
    width: int,
    height: int,
    t_sec: float,
    dur_sec: float,
    args: dict,
    fonts: dict,
):
    Image, ImageDraw, _ = _require_pillow()
    img = Image.new("RGB", (width, height), (8, 9, 13))
    draw = ImageDraw.Draw(img)

    attempts = args.get("attempts") or [3, 12, 31]
    thinking_storm = bool(args.get("thinking_storm", True))
    storm_split = 0.68 if thinking_storm else 1.0
    norm_t = t_sec / max(0.05, dur_sec)

    pad_x = int(width * 0.06)
    pad_y = int(height * 0.08)

    if norm_t < storm_split:
        draw.text((pad_x, pad_y), "$ run tests", font=fonts["code"], fill=(150, 162, 182))
        phase = norm_t / max(0.05, storm_split)
        idx = min(len(attempts) - 1, int(phase * len(attempts)))
        att_num = attempts[idx]

        # Big crisp red X in center
        cx, cy = width // 2, int(height * 0.44)
        arm = int(min(width, height) * 0.19)
        stroke = max(14, int(min(width, height) * 0.036))
        draw.line([(cx - arm, cy - arm), (cx + arm, cy + arm)], fill=(255, 102, 92), width=stroke)
        draw.line([(cx - arm, cy + arm), (cx + arm, cy - arm)], fill=(255, 102, 92), width=stroke)

        label = f"Attempt {att_num}"
        bbox = fonts["hero"].getbbox(label)
        tw = bbox[2] - bbox[0]
        draw.text(((width - tw) // 2, int(height * 0.72)), label, font=fonts["hero"], fill=(242, 245, 250))
    else:
        storm_p = (norm_t - storm_split) / max(0.05, 1.0 - storm_split)
        rng = random.Random(int(t_sec * 24) + 99)
        # Spinning arc + Thinking... multiplying
        arc_box = (pad_x, pad_y + 10, pad_x + 84, pad_y + 94)
        ang = int((t_sec * 420) % 360)
        draw.arc(arc_box, start=ang, end=ang + 250, fill=(225, 230, 240), width=10)
        draw.text((pad_x + 112, pad_y + 18), "Thinking...", font=fonts["hero"], fill=(238, 242, 248))

        extra = int(2 + 34 * storm_p)
        for _ in range(extra):
            tx = rng.randint(-30, width - 160)
            ty = rng.randint(int(height * 0.18), int(height * 0.88))
            shade = rng.randint(150, 245)
            draw.text((tx, ty), "Thinking...", font=fonts["ui_lg"], fill=(shade, shade, min(255, shade + 10)))

    return img


def _render_chat_dialogue_frame(
    width: int,
    height: int,
    t_sec: float,
    dur_sec: float,
    args: dict,
    fonts: dict,
):
    Image, ImageDraw, _ = _require_pillow()
    img = Image.new("RGB", (width, height), (8, 10, 15))
    draw = ImageDraw.Draw(img)

    messages = args.get("messages") or [
        {"role": "agent", "text": "Quick question before I continue...", "at_sec": 0.35},
        {"role": "user", "text": "Line 42. Missing semicolon.", "at_sec": 1.65},
        {"role": "user", "text": "Why didn't you just ask?", "at_sec": 2.75},
    ]

    pad_x = int(width * 0.08)
    y_cur = int(height * 0.14)
    b_pad_x = int(width * 0.032)
    b_pad_y = int(height * 0.024)

    for msg in messages:
        at_s = float(msg.get("at_sec", 0.3))
        if t_sec < at_s:
            continue
        pop = _ease_out_cubic((t_sec - at_s) / 0.24)
        txt = str(msg.get("text", ""))
        role = str(msg.get("role", "user")).lower()

        bbox = fonts["ui_md"].getbbox(txt)
        tw = (bbox[2] - bbox[0]) + b_pad_x * 2
        th = (bbox[3] - bbox[1]) + b_pad_y * 2

        if role == "agent":
            bx = (width - tw) // 2
            bg = (212, 105, 66)  # Warm Claude terracotta bubble
            fg = (255, 250, 246)
        else:
            bx = pad_x
            bg = (25, 30, 42)
            fg = (232, 237, 246)

        by = int(y_cur + (1.0 - pop) * 22)
        draw.rounded_rectangle([(bx, by), (bx + tw, by + th)], radius=22, fill=bg, outline=(48, 56, 74) if role != "agent" else None, width=2)
        draw.text((bx + b_pad_x, by + b_pad_y - 3), txt, font=fonts["ui_md"], fill=fg)
        y_cur += th + int(height * 0.032)

    # Sleek bottom prompt input bar
    bar_h = int(height * 0.11)
    by0 = height - bar_h - int(height * 0.06)
    draw.rounded_rectangle(
        [(pad_x, by0), (width - pad_x, by0 + bar_h)],
        radius=bar_h // 2,
        fill=(14, 17, 25),
        outline=(46, 54, 72),
        width=2,
    )
    draw.text((pad_x + 28, by0 + (bar_h - fonts["ui_sm_size"]) // 2 - 2), "Ask Claude...", font=fonts["ui_sm"], fill=(112, 122, 145))
    return img


def render_code_screen(ffmpeg_bin: str, args: dict) -> dict:
    """Render a high-clarity animated code/terminal/chat screen MP4 (+ keyframe PNG) for 2D or 3D laptop mapping."""
    out_path = Path(args["output_path"]).resolve()
    out_path.parent.mkdir(parents=True, exist_ok=True)

    mode = str(args.get("mode", "code_typing")).lower()
    width = int(args.get("width", 1280))
    height = int(args.get("height", 800))
    # Ensure even dimensions for H.264 encoders
    width = max(320, width - (width % 2))
    height = max(240, height - (height % 2))
    fps = int(args.get("fps", 30))
    dur_sec = max(0.8, min(120.0, float(args.get("duration_sec", 4.5))))
    use_hw = bool(args.get("use_hw_accel", True))

    scale = height / 800.0
    code_sz = max(16, int(round(30 * scale)))
    ui_sm_sz = max(14, int(round(22 * scale)))
    ui_md_sz = max(18, int(round(30 * scale)))
    ui_lg_sz = max(22, int(round(38 * scale)))
    hero_sz = max(32, int(round(68 * scale)))

    fonts = {
        "code": _load_font("mono_semibold", code_sz),
        "code_size": code_sz,
        "ui_sm": _load_font("sans_semibold", ui_sm_sz),
        "ui_sm_size": ui_sm_sz,
        "ui_md": _load_font("sans_semibold", ui_md_sz),
        "ui_lg": _load_font("display_bold", ui_lg_sz),
        "ui_lg_size": ui_lg_sz,
        "hero": _load_font("display_bold", hero_sz),
    }

    total_frames = max(2, int(round(dur_sec * fps)))
    still_frame_idx = min(total_frames - 1, max(0, int(total_frames * 0.78)))
    still_path = out_path.with_suffix(".preview.png")

    enc_args, enc_name = select_video_encoder_args(ffmpeg_bin, use_hw_accel=use_hw, bitrate_mbps=8.0, crf=17)
    cmd = [
        ffmpeg_bin,
        "-y",
        "-f",
        "rawvideo",
        "-pix_fmt",
        "rgb24",
        "-s",
        f"{width}x{height}",
        "-r",
        str(fps),
        "-i",
        "pipe:0",
        *enc_args,
        "-movflags",
        "+faststart",
        str(out_path),
    ]

    proc = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    assert proc.stdin is not None

    try:
        for f_idx in range(total_frames):
            t_sec = f_idx / float(fps)
            if mode == "test_attempts":
                frame_img = _render_test_attempts_frame(width, height, t_sec, dur_sec, args, fonts)
            elif mode == "chat_dialogue":
                frame_img = _render_chat_dialogue_frame(width, height, t_sec, dur_sec, args, fonts)
            else:
                frame_img = _render_code_typing_frame(width, height, t_sec, dur_sec, args, fonts)

            if f_idx == still_frame_idx:
                frame_img.save(still_path, format="PNG")
            proc.stdin.write(frame_img.tobytes())
        proc.stdin.close()
    except Exception:
        proc.kill()
        raise

    _, stderr_bytes = proc.communicate()
    if proc.returncode != 0:
        # Automatic fallback to libx264 if hardware encoder fails on unusual resolutions
        if enc_name != "libx264":
            args_retry = dict(args)
            args_retry["use_hw_accel"] = False
            return render_code_screen(ffmpeg_bin, args_retry)
        raise RuntimeError(f"FFmpeg screen encode failed: {stderr_bytes.decode('utf-8', errors='ignore')[-600:]}")

    return {
        "output_path": str(out_path),
        "still_preview_path": str(still_path),
        "mode": mode,
        "width": width,
        "height": height,
        "fps": fps,
        "frames": total_frames,
        "duration_sec": round(total_frames / float(fps), 2),
        "encoder": enc_name,
    }
