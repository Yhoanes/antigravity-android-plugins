"""
Universal All-Purpose Video Editing & Utility Engine (v2.1):
  1. video_universal_edit: Supports ANY genre & aspect ratio (16:9 YouTube, 9:16 Reels/TikTok/Shorts, 1:1, 4:5, source):
     - Multi-clip camera + B-roll + photo Ken Burns editing
     - Preserves native camera/mic audio with optional voice enhancement & auto-ducked music
     - Cinema xfade + acrossfade transitions (fade, fadeblack, slideleft, smoothleft, zoomin, circleopen)
     - Color grading presets (cinematic_teal_orange, warm_vlog, crisp_tech, moody_matte, bw_film)
     - Layouts: single (cover / blurred_bg / contain), split_vertical (Podcast/Gameplay 50-50), pip_corner (Facecam)
     - Lower-third speaker banners & universal subtitle styles (glass_pill, cinema_yellow, viral_pop)
  2. video_utility_ops: Everyday creator utilities on Android:
     - podcast_voice_enhance (denoise + EQ + -16 LUFS normalization on video or audio)
     - compress_social (smart target-MB hardware compression for WhatsApp/Discord/Telegram)
     - youtube_cover_thumbnail (extract sharp frame + optional bold title cover PNG)
     - extract_audio (.mp3 / .wav)
     - to_gif (high-quality palette-optimized GIF)
"""

from __future__ import annotations

import math
import os
import shutil
import subprocess
import uuid
from pathlib import Path

from .autocut_engine import probe_video_extended
from .env_utils import FONTS_DIR, resolve_font_path, select_video_encoder_args
from .keynote_engine import (
    _load_pil_font,
    _render_subtitle_pill_png,
    _require_pillow,
    _run_ffmpeg_with_hw_fallback,
    _wrap_lines,
    _write_tiktok_ass,
)

ASPECT_PRESETS: dict[str, tuple[int, int]] = {
    "9:16": (1080, 1920),
    "16:9": (1920, 1080),
    "1:1": (1080, 1080),
    "4:5": (1080, 1350),
    "4:3": (1440, 1080),
    "21:9": (2560, 1080),
}

COLOR_GRADE_FILTERS: dict[str, str] = {
    "none": "",
    "cinematic_teal_orange": (
        "eq=contrast=1.08:brightness=-0.015:saturation=1.12,"
        "colorbalance=rs=-0.05:gs=-0.01:bs=0.06:rm=0.03:gm=0.01:bm=-0.03:rh=0.05:gh=0.02:bh=-0.04"
    ),
    "warm_vlog": (
        "eq=contrast=1.04:brightness=0.02:saturation=1.14,"
        "colorbalance=rm=0.04:gm=0.02:bm=-0.04:rh=0.04:gh=0.02:bh=-0.03"
    ),
    "crisp_tech": "eq=contrast=1.06:saturation=1.05,unsharp=5:5:0.55:5:5:0.0",
    "moody_matte": "eq=contrast=0.95:saturation=0.82:brightness=-0.02,colorbalance=rs=-0.02:gs=0.01:bs=0.04",
    "bw_film": "hue=s=0,eq=contrast=1.18:brightness=-0.01",
}

VALID_XFADES = {
    "fade",
    "fadeblack",
    "fadewhite",
    "slideleft",
    "slideright",
    "slideup",
    "slidedown",
    "smoothleft",
    "smoothright",
    "circleopen",
    "circleclose",
    "wipeleft",
    "wiperight",
    "zoomin",
}

IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".webp", ".bmp"}


def resolve_canvas_dimensions(
    aspect_ratio: str,
    explicit_w: int | None,
    explicit_h: int | None,
    first_source_meta: dict | None = None,
) -> tuple[int, int]:
    if explicit_w and explicit_h:
        return (max(240, (int(explicit_w) // 2) * 2), max(240, (int(explicit_h) // 2) * 2))
    ar = (aspect_ratio or "9:16").strip().lower()
    if ar == "source" and first_source_meta and first_source_meta.get("width") and first_source_meta.get("height"):
        w = (int(first_source_meta["width"]) // 2) * 2
        h = (int(first_source_meta["height"]) // 2) * 2
        return max(240, w), max(240, h)
    if ar in ASPECT_PRESETS:
        return ASPECT_PRESETS[ar]
    return (1080, 1920)


def _atempo_chain(speed: float) -> str:
    spd = max(0.25, min(6.0, speed))
    if abs(spd - 1.0) < 0.01:
        return "anull"
    if 0.5 <= spd <= 2.0:
        return f"atempo={spd:.4f}"
    if spd > 2.0:
        stages = 2 if spd <= 4.0 else 3
        root = spd ** (1.0 / stages)
        return ",".join(f"atempo={root:.4f}" for _ in range(stages))
    # 0.25 <= spd < 0.5
    half = spd ** 0.5
    return f"atempo={half:.4f},atempo={half:.4f}"


def _build_fit_vf(
    out_w: int,
    out_h: int,
    fit_mode: str,
    zoom: float = 1.0,
    focus_x: float = 0.5,
    focus_y: float = 0.5,
) -> str:
    scaled_w = max(out_w, (int(round(out_w * zoom)) // 2) * 2)
    scaled_h = max(out_h, (int(round(out_h * zoom)) // 2) * 2)
    crop_x = int(round((scaled_w - out_w) * focus_x))
    crop_y = int(round((scaled_h - out_h) * focus_y))

    if fit_mode == "contain":
        return (
            f"scale={out_w}:{out_h}:force_original_aspect_ratio=decrease,"
            f"pad={out_w}:{out_h}:(ow-iw)/2:(oh-ih)/2:color=#05060A,"
            f"scale={scaled_w}:{scaled_h},crop={out_w}:{out_h}:{crop_x}:{crop_y},setsar=1"
        )
    # Default "cover"
    return (
        f"scale={scaled_w}:{scaled_h}:force_original_aspect_ratio=increase,"
        f"crop={out_w}:{out_h}:'(iw-{out_w})*{focus_x:.3f}':'(ih-{out_h})*{focus_y:.3f}',setsar=1"
    )


def _render_lower_third_png(info: dict, out_png: Path, canvas_w: int) -> tuple[int, int]:
    """Render a clean broadcast/YouTube glass lower-third banner (Name + Role/Subtitle)."""
    Image, ImageDraw, ImageFilter, _ = _require_pillow()
    name_txt = str(info.get("name", "")).strip()
    role_txt = str(info.get("role", "")).strip()
    accent_hex = str(info.get("accent_hex", "#8AB4F8")).lstrip("#")
    try:
        ac_rgb = (int(accent_hex[0:2], 16), int(accent_hex[2:4], 16), int(accent_hex[4:6], 16))
    except Exception:
        ac_rgb = (138, 180, 248)

    scale_k = max(0.75, min(1.25, canvas_w / 1080.0))
    f_name = _load_pil_font("display_bold", int(round(36 * scale_k)))
    f_role = _load_pil_font("sans_semibold", int(round(23 * scale_k)))

    bb_n = f_name.getbbox(name_txt or " ")
    nw, nh = bb_n[2] - bb_n[0], bb_n[3] - bb_n[1]
    rw, rh = 0, 0
    bb_r = (0, 0, 0, 0)
    if role_txt:
        bb_r = f_role.getbbox(role_txt)
        rw, rh = bb_r[2] - bb_r[0], bb_r[3] - bb_r[1]

    pad_x = int(round(34 * scale_k))
    pad_y = int(round(20 * scale_k))
    bar_w = max(6, int(round(7 * scale_k)))
    box_w = ((max(nw, rw) + pad_x * 2 + bar_w + 16) // 2) * 2
    box_h = ((nh + (rh + 10 if role_txt else 0) + pad_y * 2) // 2) * 2
    margin = 16

    img = Image.new("RGBA", (box_w + margin * 2, box_h + margin * 2), (0, 0, 0, 0))
    sd = ImageDraw.Draw(img)
    sd.rounded_rectangle((margin, margin + 4, margin + box_w, margin + box_h + 6), radius=20, fill=(0, 0, 0, 150))
    img = img.filter(ImageFilter.GaussianBlur(radius=7))

    d = ImageDraw.Draw(img)
    d.rounded_rectangle(
        (margin, margin, margin + box_w, margin + box_h),
        radius=20,
        fill=(10, 13, 21, 232),
        outline=(255, 255, 255, 38),
        width=2,
    )
    # Accent vertical bar on left
    d.rounded_rectangle(
        (margin + 16, margin + 16, margin + 16 + bar_w, margin + box_h - 16),
        radius=bar_w // 2,
        fill=(*ac_rgb, 255),
    )

    tx = margin + 16 + bar_w + 18
    ty = margin + pad_y
    d.text((tx - bb_n[0], ty - bb_n[1]), name_txt, font=f_name, fill=(248, 249, 252, 255))
    if role_txt:
        d.text((tx - bb_r[0], ty + nh + 10 - bb_r[1]), role_txt, font=f_role, fill=(168, 199, 250, 240))

    img.save(str(out_png), format="PNG")
    return img.size[0], img.size[1]


def _write_cinema_yellow_ass(ass_path: Path, captions: list[dict], width: int, height: int) -> None:
    from .keynote_engine import _ass_ts

    fsize = max(34, int(round(height * 0.036))) if width > height else max(46, int(round(width * 0.046)))
    margin_v = int(round(height * 0.085)) if width > height else int(round(height * 0.14))
    header = f"""[Script Info]
ScriptType: v4.00+
PlayResX: {width}
PlayResY: {height}
WrapStyle: 0
ScaledBorderAndShadow: yes

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: CinemaSub,Plus Jakarta Sans SemiBold,{fsize},&H0048E6FF,&H00FFFFFF,&H00080808,&H80000000,-1,0,0,0,100,100,0,0,1,3,2,2,80,80,{margin_v},1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""
    lines = [header]
    for cap in captions:
        st = _ass_ts(float(cap["start_sec"]))
        en = _ass_ts(float(cap["end_sec"]))
        txt = str(cap["text"]).replace("\n", r"\N")
        lines.append(f"Dialogue: 1,{st},{en},CinemaSub,,0,0,0,,{txt}")
    ass_path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def render_universal_edit(ffmpeg_bin: str, args: dict) -> dict:
    """
    All-purpose multi-genre video editor for Camera Vlogs, YouTube 16:9, Podcasts, Gaming/Facecam, Tutorials & Reels.
    """
    output_path = Path(args["output_path"]).resolve()
    output_path.parent.mkdir(parents=True, exist_ok=True)
    fps = int(args.get("fps", 60))
    use_hw_accel = bool(args.get("use_hw_accel", True))
    layout = str(args.get("layout", "single")).strip().lower()  # "single", "split_vertical", "pip_corner"
    aspect_ratio = str(args.get("aspect_ratio", "9:16")).strip().lower()
    fit_mode = str(args.get("fit_mode", "cover")).strip().lower()  # "cover", "blurred_bg", "contain"
    color_grade = str(args.get("color_grade", "none")).strip().lower()
    transition = str(args.get("transition", "none")).strip().lower()
    transition_dur = max(0.15, min(1.2, float(args.get("transition_sec", 0.35))))
    keep_clip_audio = bool(args.get("keep_clip_audio", True))
    enhance_speech = bool(args.get("enhance_speech", False))
    subtitle_style = str(args.get("subtitle_style", "glass_pill")).strip().lower()  # "glass_pill", "cinema_yellow", "viral_pop"
    captions = args.get("captions") or []
    lower_thirds = args.get("lower_thirds") or []
    voiceover_path = args.get("voiceover_path")
    music_path = args.get("music_path")
    music_volume = float(args.get("music_volume", 0.20))

    segments = args.get("segments") or []
    if not segments and args.get("primary_source"):
        segments = [{"source": args["primary_source"]}]
    if not segments:
        raise ValueError("Provide at least one clip in 'segments' (or 'primary_source').")

    first_src = Path(segments[0]["source"]).resolve()
    first_meta = None
    if first_src.is_file() and first_src.suffix.lower() not in IMAGE_EXTS:
        first_meta = probe_video_extended(ffmpeg_bin, str(first_src), scene_threshold=0.98, min_freeze_sec=99.0, min_silence_sec=99.0)

    out_w, out_h = resolve_canvas_dimensions(
        aspect_ratio,
        args.get("width"),
        args.get("height"),
        first_meta,
    )

    work_dir = output_path.parent / f".agy_univ_{uuid.uuid4().hex[:8]}"
    work_dir.mkdir(parents=True, exist_ok=True)

    try:
        grade_vf = COLOR_GRADE_FILTERS.get(color_grade, "")
        encoder_used = "libx264"

        # ----------------------------------------------------------------------
        # SPECIAL COMPOSITE LAYOUTS: split_vertical (Podcast/Gameplay) & pip_corner (Facecam)
        # ----------------------------------------------------------------------
        if layout in ("split_vertical", "pip_corner") and args.get("secondary_source"):
            prim_path = Path(segments[0]["source"]).resolve()
            sec_path = Path(args["secondary_source"]).resolve()
            p_meta = probe_video_extended(ffmpeg_bin, str(prim_path), scene_threshold=0.98, min_freeze_sec=99.0, min_silence_sec=99.0)
            start_s = float(segments[0].get("start_sec", 0.0))
            end_s = float(segments[0].get("end_sec", p_meta["duration_sec"] or 10.0))
            dur = max(0.5, end_s - start_s)

            comp_mp4 = work_dir / "layout_base.mp4"
            grade_suffix = f",{grade_vf}" if grade_vf else ""

            if layout == "split_vertical":
                half_h = (out_h // 4) * 2
                bot_h = out_h - half_h
                fc = (
                    f"[0:v]fps={fps},scale={out_w}:{half_h}:force_original_aspect_ratio=increase,crop={out_w}:{half_h}[vtop];"
                    f"[1:v]fps={fps},scale={out_w}:{bot_h}:force_original_aspect_ratio=increase,crop={out_w}:{bot_h}[vbot];"
                    f"[vtop][vbot]vstack=inputs=2,drawbox=x=0:y={half_h - 2}:w={out_w}:h=4:color=#8AB4F8@0.65:t=fill{grade_suffix},format=yuv420p[vout]"
                )
            else:
                # pip_corner (e.g. YouTube 16:9 tutorial or 9:16 streamer reaction)
                pip_pos = str(args.get("pip_position", "bottom_right")).lower()
                pip_scale = max(0.18, min(0.45, float(args.get("pip_scale", 0.28))))
                pw = (int(round(out_w * pip_scale)) // 2) * 2
                ph = (int(round(pw * (9.0 / 16.0 if out_w > out_h else 4.0 / 3.0))) // 2) * 2
                pad = 36
                px = (out_w - pw - pad) if "right" in pip_pos else pad
                py = (out_h - ph - (190 if out_h > out_w else 44)) if "bottom" in pip_pos else pad
                fc = (
                    f"[0:v]fps={fps},{_build_fit_vf(out_w, out_h, fit_mode)}[vmain];"
                    f"[1:v]fps={fps},scale={pw}:{ph}:force_original_aspect_ratio=increase,crop={pw}:{ph},"
                    f"pad={pw + 8}:{ph + 8}:4:4:color=#8AB4F8[vpip];"
                    f"[vmain][vpip]overlay={px}:{py}:shortest=1{grade_suffix},format=yuv420p[vout]"
                )

            aud_source_idx = int(args.get("audio_source_index", 0))  # 0=primary, 1=secondary, 2=mix_both
            s_meta = probe_video_extended(ffmpeg_bin, str(sec_path), scene_threshold=0.98, min_freeze_sec=99.0, min_silence_sec=99.0)
            if keep_clip_audio and (p_meta["has_audio"] or s_meta["has_audio"]):
                if aud_source_idx == 2 and p_meta["has_audio"] and s_meta["has_audio"]:
                    fc += ";[0:a]aformat=sample_rates=48000:channel_layouts=stereo[a0];[1:a]aformat=sample_rates=48000:channel_layouts=stereo[a1];[a0][a1]amix=inputs=2:duration=shortest:normalize=0[aout]"
                elif (aud_source_idx == 1 and s_meta["has_audio"]) or not p_meta["has_audio"]:
                    fc += ";[1:a]aformat=sample_rates=48000:channel_layouts=stereo[aout]"
                else:
                    fc += ";[0:a]aformat=sample_rates=48000:channel_layouts=stereo[aout]"
                aud_maps = ["-map", "[aout]", "-c:a", "aac", "-b:a", "256k"]
            else:
                fc += f";anullsrc=channel_layout=stereo:sample_rate=48000,atrim=0:{dur:.3f}[aout]"
                aud_maps = ["-map", "[aout]", "-c:a", "aac", "-b:a", "192k"]

            cmd = [
                ffmpeg_bin,
                "-y",
                "-ss", f"{start_s:.3f}", "-t", f"{dur:.3f}", "-i", str(prim_path),
                "-ss", f"{ float(args.get('secondary_start_sec', 0.0)):.3f}", "-t", f"{dur:.3f}", "-i", str(sec_path),
                "-filter_complex", fc,
                "-map", "[vout]",
                *aud_maps,
            ]
            encoder_used = _run_ffmpeg_with_hw_fallback(ffmpeg_bin, cmd, comp_mp4, use_hw_accel=use_hw_accel, fps=fps)
            merged_av = comp_mp4
            total_dur = dur

        else:
            # ------------------------------------------------------------------
            # STANDARD MULTI-CLIP NLE PIPELINE (Camera Vlogs + B-Roll + Photos)
            # ------------------------------------------------------------------
            norm_clips: list[tuple[Path, float]] = []
            for idx, seg in enumerate(segments):
                src = Path(seg["source"]).resolve()
                if not src.is_file():
                    raise FileNotFoundError(f"Segment {idx} source not found: {src}")

                is_img = src.suffix.lower() in IMAGE_EXTS
                zoom = max(1.0, min(2.8, float(seg.get("zoom", 1.04 if is_img else 1.0))))
                fx = max(0.0, min(1.0, float(seg.get("focus_x", 0.5))))
                fy = max(0.0, min(1.0, float(seg.get("focus_y", 0.5))))
                seg_fit = str(seg.get("fit_mode", fit_mode)).lower()

                norm_mp4 = work_dir / f"norm_{idx:03d}.mp4"
                grade_suffix = f",{grade_vf}" if grade_vf else ""

                if is_img:
                    dur_out = max(0.5, float(seg.get("duration_sec", seg.get("end_sec", 3.5)) - float(seg.get("start_sec", 0.0))))
                    vf = (
                        f"fps={fps},{_build_fit_vf(int(out_w * 1.06), int(out_h * 1.06), 'cover')},"
                        f"crop={out_w}:{out_h}:'(iw-ow)/2':'(ih-oh)/2 - (t/{dur_out:.3f})*16'"
                        f"{grade_suffix},format=yuv420p"
                    )
                    cmd = [
                        ffmpeg_bin, "-y",
                        "-loop", "1", "-t", f"{dur_out:.3f}", "-i", str(src),
                        "-f", "lavfi", "-t", f"{dur_out:.3f}", "-i", "anullsrc=channel_layout=stereo:sample_rate=48000",
                        "-vf", vf,
                        "-map", "0:v:0", "-map", "1:a:0",
                        "-c:a", "aac", "-b:a", "192k", "-shortest",
                    ]
                    encoder_used = _run_ffmpeg_with_hw_fallback(ffmpeg_bin, cmd, norm_mp4, use_hw_accel=use_hw_accel, fps=fps)
                    norm_clips.append((norm_mp4, dur_out))
                else:
                    meta = probe_video_extended(ffmpeg_bin, str(src), scene_threshold=0.98, min_freeze_sec=99.0, min_silence_sec=99.0)
                    st_s = max(0.0, float(seg.get("start_sec", 0.0)))
                    en_s = float(seg.get("end_sec", meta["duration_sec"] or 5.0))
                    spd = max(0.25, min(6.0, float(seg.get("speed", 1.0))))
                    dur_in = max(0.15, en_s - st_s)
                    dur_out = dur_in / spd
                    seg_vol = float(seg.get("volume", 1.0 if keep_clip_audio else 0.0))

                    has_aud_usable = bool(meta["has_audio"] and keep_clip_audio and seg_vol > 0.001)

                    if seg_fit == "blurred_bg":
                        fc_v = (
                            f"[0:v]setpts=(PTS-STARTPTS)/{spd:.4f},fps={fps},split=2[vbg][vfg];"
                            f"[vbg]scale={out_w}:{out_h}:force_original_aspect_ratio=increase,crop={out_w}:{out_h},"
                            f"boxblur=24:4,eq=brightness=-0.18[bg];"
                            f"[vfg]scale={out_w}:{out_h}:force_original_aspect_ratio=decrease[fg];"
                            f"[bg][fg]overlay=(W-w)/2:(H-h)/2,setsar=1{grade_suffix},format=yuv420p[vout]"
                        )
                    else:
                        fc_v = (
                            f"[0:v]setpts=(PTS-STARTPTS)/{spd:.4f},fps={fps},"
                            f"{_build_fit_vf(out_w, out_h, seg_fit, zoom=zoom, focus_x=fx, focus_y=fy)}"
                            f"{grade_suffix},format=yuv420p[vout]"
                        )

                    if has_aud_usable:
                        speech_chain = (
                            ",highpass=f=80,afftdn=nf=-24,acompressor=threshold=-18dB:ratio=3:makeup=2"
                            if enhance_speech
                            else ""
                        )
                        fc_a = (
                            f"[0:a]{_atempo_chain(spd)},aformat=sample_rates=48000:channel_layouts=stereo,"
                            f"volume={seg_vol:.3f}{speech_chain},apad=whole_dur={dur_out:.3f},atrim=0:{dur_out:.3f}[aout]"
                        )
                        inputs = ["-ss", f"{st_s:.3f}", "-to", f"{en_s:.3f}", "-i", str(src)]
                        full_fc = f"{fc_v};{fc_a}"
                    else:
                        inputs = [
                            "-ss", f"{st_s:.3f}", "-to", f"{en_s:.3f}", "-i", str(src),
                            "-f", "lavfi", "-t", f"{dur_out:.3f}", "-i", "anullsrc=channel_layout=stereo:sample_rate=48000",
                        ]
                        full_fc = f"{fc_v};[1:a]aformat=sample_rates=48000:channel_layouts=stereo[aout]"

                    cmd = [
                        ffmpeg_bin, "-y",
                        *inputs,
                        "-filter_complex", full_fc,
                        "-map", "[vout]", "-map", "[aout]",
                        "-t", f"{dur_out:.3f}",
                        "-c:a", "aac", "-b:a", "256k",
                    ]
                    encoder_used = _run_ffmpeg_with_hw_fallback(ffmpeg_bin, cmd, norm_mp4, use_hw_accel=use_hw_accel, fps=fps)
                    norm_clips.append((norm_mp4, dur_out))

            # Join normalized clips via xfade + acrossfade OR lossless concat
            merged_av = work_dir / "merged_av.mp4"
            if len(norm_clips) == 1:
                shutil.copy2(norm_clips[0][0], merged_av)
                total_dur = norm_clips[0][1]
            elif transition in VALID_XFADES and len(norm_clips) <= 20:
                xf_inputs: list[str] = []
                for p_clip, _ in norm_clips:
                    xf_inputs += ["-i", str(p_clip)]

                v_chains = [f"[{i}:v]fps={fps},settb=AVTB[v{i}]" for i in range(len(norm_clips))]
                a_chains = [f"[{i}:a]aformat=sample_rates=48000:channel_layouts=stereo[a{i}]" for i in range(len(norm_clips))]

                cum_dur = norm_clips[0][1]
                prev_v = "v0"
                prev_a = "a0"
                for i in range(1, len(norm_clips)):
                    d_cur = norm_clips[i][1]
                    td = min(transition_dur, 0.4 * min(cum_dur, d_cur))
                    offset = max(0.05, cum_dur - td)
                    nxt_v = f"vx{i}"
                    nxt_a = f"ax{i}"
                    v_chains.append(f"[{prev_v}][v{i}]xfade=transition={transition}:duration={td:.3f}:offset={offset:.3f}[{nxt_v}]")
                    a_chains.append(f"[{prev_a}][a{i}]acrossfade=d={td:.3f}:c1=tri:c2=tri[{nxt_a}]")
                    cum_dur = cum_dur + d_cur - td
                    prev_v = nxt_v
                    prev_a = nxt_a

                xf_cmd = [
                    ffmpeg_bin, "-y",
                    *xf_inputs,
                    "-filter_complex", ";".join(v_chains + a_chains),
                    "-map", f"[{prev_v}]", "-map", f"[{prev_a}]",
                    "-c:a", "aac", "-b:a", "256k",
                ]
                encoder_used = _run_ffmpeg_with_hw_fallback(ffmpeg_bin, xf_cmd, merged_av, use_hw_accel=use_hw_accel, fps=fps)
                total_dur = cum_dur
            else:
                concat_f = work_dir / "concat.txt"
                concat_f.write_text("\n".join(f"file '{p.as_posix()}'" for p, _ in norm_clips) + "\n", encoding="utf-8")
                subprocess.run(
                    [ffmpeg_bin, "-y", "-f", "concat", "-safe", "0", "-i", str(concat_f), "-c", "copy", str(merged_av)],
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    check=True,
                )
                total_dur = sum(d for _, d in norm_clips)

        # ----------------------------------------------------------------------
        # OVERLAY LOWER-THIRDS & SUBTITLES (GLASS PILL / CINEMA YELLOW / VIRAL POP)
        # ----------------------------------------------------------------------
        stage_av = merged_av
        valid_caps = [c for c in captions if str(c.get("text", "")).strip() and float(c["start_sec"]) < total_dur]
        valid_lts = [lt for lt in lower_thirds if str(lt.get("name", "")).strip() and float(lt.get("start_sec", 0.0)) < total_dur]

        if valid_lts or (valid_caps and subtitle_style == "glass_pill"):
            _require_pillow()
            overlay_items: list[tuple[Path, int, int, float, float]] = []
            for lt_i, lt in enumerate(valid_lts):
                lt_png = work_dir / f"lt_{lt_i:02d}.png"
                lw, lh = _render_lower_third_png(lt, lt_png, out_w)
                st_t = max(0.0, float(lt.get("start_sec", 0.8)))
                en_t = min(total_dur, float(lt.get("end_sec", st_t + 4.5)))
                lx = int(lt.get("pos_x", 56 if out_w >= out_h else 48))
                ly = int(lt.get("pos_y", out_h - lh - (110 if out_w > out_h else 310)))
                overlay_items.append((lt_png, lx, ly, st_t, en_t))

            if valid_caps and subtitle_style == "glass_pill":
                max_pill_w = min(1300, out_w - 130)
                for c_i, cap in enumerate(valid_caps):
                    p_png = work_dir / f"upill_{c_i:03d}.png"
                    pw, ph = _render_subtitle_pill_png(str(cap["text"]), p_png, max_width=max_pill_w)
                    st_t = max(0.0, float(cap["start_sec"]))
                    en_t = min(total_dur, float(cap["end_sec"]))
                    px = (out_w - pw) // 2
                    default_py = (out_h - ph - 64) if out_w > out_h else (out_h - ph - 155)
                    overlay_items.append((p_png, px, int(cap.get("pos_y", default_py)), st_t, en_t))

            batch_sz = 18
            cur_stage = stage_av
            for b_i in range(0, len(overlay_items), batch_sz):
                batch = overlay_items[b_i : b_i + batch_sz]
                ov_inputs = ["-i", str(cur_stage)]
                parts = []
                last_v = "0:v"
                for k, (png_p, ox, oy, st_t, en_t) in enumerate(batch):
                    ov_inputs += ["-loop", "1", "-t", f"{en_t + 0.05:.3f}", "-i", str(png_p)]
                    lbl = f"ov{k}"
                    parts.append(
                        f"[{last_v}][{k + 1}:v]overlay={ox}:{oy}:eof_action=pass:enable='between(t,{st_t:.3f},{en_t:.3f})'[{lbl}]"
                    )
                    last_v = lbl
                nxt_stage = work_dir / f"ov_stage_{b_i:03d}.mp4"
                ov_cmd = [
                    ffmpeg_bin, "-y",
                    *ov_inputs,
                    "-filter_complex", ";".join(parts),
                    "-map", f"[{last_v}]", "-map", "0:a:0",
                    "-c:a", "copy",
                ]
                encoder_used = _run_ffmpeg_with_hw_fallback(ffmpeg_bin, ov_cmd, nxt_stage, use_hw_accel=use_hw_accel, fps=fps)
                cur_stage = nxt_stage
            stage_av = cur_stage

        if valid_caps and subtitle_style in ("cinema_yellow", "viral_pop"):
            ass_f = work_dir / "subs.ass"
            if subtitle_style == "cinema_yellow":
                _write_cinema_yellow_ass(ass_f, valid_caps, out_w, out_h)
            else:
                _write_tiktok_ass(ass_f, valid_caps, out_w, out_h)
            ass_esc = ass_f.as_posix().replace(":", r"\:")
            fonts_esc = FONTS_DIR.as_posix().replace(":", r"\:")
            ass_out = work_dir / "ass_stage.mp4"
            ass_cmd = [
                ffmpeg_bin, "-y",
                "-i", str(stage_av),
                "-vf", f"ass='{ass_esc}':fontsdir='{fonts_esc}'",
                "-map", "0:v:0", "-map", "0:a:0",
                "-c:a", "copy",
            ]
            encoder_used = _run_ffmpeg_with_hw_fallback(ffmpeg_bin, ass_cmd, ass_out, use_hw_accel=use_hw_accel, fps=fps)
            stage_av = ass_out

        # ----------------------------------------------------------------------
        # FINAL AUDIO MASTERING: Native Camera Audio + Optional Voiceover + Auto-Ducked Music
        # ----------------------------------------------------------------------
        if voiceover_path or music_path:
            aud_inputs = ["-i", str(stage_av)]
            idx_vo = None
            idx_bgm = None
            next_idx = 1
            if voiceover_path and os.path.isfile(str(voiceover_path)):
                aud_inputs += ["-i", str(Path(voiceover_path).resolve())]
                idx_vo = next_idx
                next_idx += 1
            if music_path and os.path.isfile(str(music_path)):
                aud_inputs += ["-stream_loop", "-1", "-t", f"{total_dur:.3f}", "-i", str(Path(music_path).resolve())]
                idx_bgm = next_idx

            fc_audio_parts = [f"[0:a]aformat=sample_rates=48000:channel_layouts=stereo[clip_a]"]
            if idx_vo is not None:
                fc_audio_parts.append(
                    f"[{idx_vo}:a]aformat=sample_rates=48000:channel_layouts=stereo,apad=whole_dur={total_dur:.3f},atrim=0:{total_dur:.3f},volume=1.12[vo_a];"
                    f"[clip_a][vo_a]amix=inputs=2:duration=first:normalize=0[speech_bus]"
                )
            else:
                fc_audio_parts.append("[clip_a]anull[speech_bus]")

            if idx_bgm is not None:
                fc_audio_parts.append(
                    f"[speech_bus]asplit=2[sp_main][sp_sc];"
                    f"[{idx_bgm}:a]aformat=sample_rates=48000:channel_layouts=stereo,atrim=0:{total_dur:.3f},volume={music_volume:.3f}[bgm_a];"
                    f"[bgm_a][sp_sc]sidechaincompress=threshold=0.025:ratio=4.5:attack=18:release=300[duck_bgm];"
                    f"[sp_main][duck_bgm]amix=inputs=2:duration=first:normalize=0,alimiter=limit=0.95[afinal]"
                )
            else:
                fc_audio_parts.append("[speech_bus]alimiter=limit=0.95[afinal]")

            subprocess.run(
                [
                    ffmpeg_bin, "-y",
                    *aud_inputs,
                    "-filter_complex", ";".join(fc_audio_parts),
                    "-map", "0:v:0", "-map", "[afinal]",
                    "-c:v", "copy",
                    "-ar", "48000", "-ac", "2", "-c:a", "aac", "-b:a", "320k",
                    "-shortest",
                    str(output_path),
                ],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                check=True,
            )
        else:
            shutil.copy2(stage_av, output_path)

        return {
            "output_path": str(output_path),
            "resolution": f"{out_w}x{out_h}",
            "aspect_ratio": aspect_ratio,
            "layout": layout,
            "color_grade": color_grade,
            "transition": transition,
            "duration_sec": round(total_dur, 2),
            "encoder_used": encoder_used,
            "size_mb": round(output_path.stat().st_size / (1024 * 1024), 2),
        }
    finally:
        shutil.rmtree(work_dir, ignore_errors=True)


def run_video_utility_ops(ffmpeg_bin: str, args: dict) -> dict:
    """
    Everyday Swiss-Army-Knife video operations on Android:
      - podcast_voice_enhance: Studio noise reduction + EQ + -16 LUFS normalization on noisy phone mic video/audio
      - compress_social: Smart target-MB compression (WhatsApp / Discord / Telegram / Email) with GPU acceleration
      - cover_thumbnail: Extract crisp frame & optionally stamp bold YouTube/Reel title cover PNG
      - extract_audio: Save clean .mp3 or .wav from any video
      - to_gif: Palette-optimized crisp animated GIF
    """
    op = str(args["operation"]).strip().lower()
    in_path = Path(args["input_path"]).resolve()
    if not in_path.is_file():
        raise FileNotFoundError(f"Input file not found: {in_path}")
    out_path = Path(args["output_path"]).resolve()
    out_path.parent.mkdir(parents=True, exist_ok=True)

    if op == "extract_audio":
        is_wav = out_path.suffix.lower() == ".wav"
        codec = ["-c:a", "pcm_s16le"] if is_wav else ["-c:a", "libmp3lame", "-b:a", "256k"]
        subprocess.run(
            [ffmpeg_bin, "-y", "-i", str(in_path), "-vn", "-ar", "48000", "-ac", "2", *codec, str(out_path)],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            check=True,
        )
        return {"operation": op, "output_path": str(out_path), "size_mb": round(out_path.stat().st_size / (1024 * 1024), 2)}

    if op == "podcast_voice_enhance":
        af = (
            "highpass=f=80,lowpass=f=14000,afftdn=nf=-25,"
            "acompressor=threshold=-19dB:ratio=3.5:attack=12:release=180:makeup=3,"
            "loudnorm=I=-16:TP=-1.5:LRA=11"
        )
        is_audio_only = out_path.suffix.lower() in (".wav", ".mp3", ".m4a", ".aac")
        if is_audio_only:
            codec = ["-c:a", "pcm_s16le"] if out_path.suffix.lower() == ".wav" else ["-c:a", "aac", "-b:a", "256k"]
            cmd = [ffmpeg_bin, "-y", "-i", str(in_path), "-vn", "-af", af, *codec, str(out_path)]
        else:
            cmd = [ffmpeg_bin, "-y", "-i", str(in_path), "-c:v", "copy", "-af", af, "-c:a", "aac", "-b:a", "256k", str(out_path)]
        subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True)
        return {"operation": op, "output_path": str(out_path), "size_mb": round(out_path.stat().st_size / (1024 * 1024), 2)}

    if op == "compress_social":
        meta = probe_video_extended(ffmpeg_bin, str(in_path), scene_threshold=0.98, min_freeze_sec=99.0, min_silence_sec=99.0)
        dur = max(1.0, meta["duration_sec"])
        target_mb = max(2.0, float(args.get("target_mb", 15.0)))
        max_dim = int(args.get("max_dimension", 1280))
        total_kbps = (target_mb * 8192.0 * 0.92) / dur
        aud_kbps = 128.0 if meta["has_audio"] else 0.0
        vid_mbps = max(0.45, (total_kbps - aud_kbps) / 1000.0)

        vf = f"scale='min({max_dim},iw)':'min({max_dim},ih)':force_original_aspect_ratio=decrease,pad=ceil(iw/2)*2:ceil(ih/2)*2"
        enc_flags, enc_used = select_video_encoder_args(ffmpeg_bin, use_hw_accel=True, bitrate_mbps=vid_mbps, crf=24)
        sw_flags = [
            "-c:v", "libx264", "-preset", "veryfast",
            "-b:v", f"{vid_mbps:.2f}M", "-maxrate", f"{vid_mbps * 1.25:.2f}M", "-bufsize", f"{vid_mbps * 2.0:.2f}M",
            "-pix_fmt", "yuv420p",
        ]
        if enc_used == "libx264":
            enc_flags = sw_flags
        aud_flags = ["-c:a", "aac", "-b:a", "128k"] if meta["has_audio"] else ["-an"]
        cmd = [ffmpeg_bin, "-y", "-i", str(in_path), "-vf", vf, *enc_flags, *aud_flags, str(out_path)]
        proc = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        if proc.returncode != 0 and enc_used != "libx264":
            enc_used = "libx264"
            cmd_sw = [ffmpeg_bin, "-y", "-i", str(in_path), "-vf", vf, *sw_flags, *aud_flags, str(out_path)]
            subprocess.run(cmd_sw, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True)
        elif proc.returncode != 0:
            raise RuntimeError(f"FFmpeg compress_social failed: {proc.stderr.decode(errors='ignore')[-350:]}")
        return {
            "operation": op,
            "output_path": str(out_path),
            "target_mb": target_mb,
            "actual_size_mb": round(out_path.stat().st_size / (1024 * 1024), 2),
            "encoder_used": enc_used,
        }

    if op == "to_gif":
        st_s = float(args.get("start_sec", 0.0))
        dur_s = min(15.0, max(0.5, float(args.get("duration_sec", 4.0))))
        gif_w = int(args.get("width", 540))
        gif_fps = int(args.get("fps", 15))
        vf = f"fps={gif_fps},scale={gif_w}:-1:flags=lanczos,split[s0][s1];[s0]palettegen[p];[s1][p]paletteuse"
        subprocess.run(
            [ffmpeg_bin, "-y", "-ss", f"{st_s:.3f}", "-t", f"{dur_s:.3f}", "-i", str(in_path), "-vf", vf, str(out_path)],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            check=True,
        )
        return {"operation": op, "output_path": str(out_path), "size_mb": round(out_path.stat().st_size / (1024 * 1024), 2)}

    if op == "cover_thumbnail":
        ts = float(args.get("timestamp_sec", 1.0))
        title_txt = str(args.get("title", "")).strip()
        badge_txt = str(args.get("badge", "")).strip()
        raw_png = out_path if not title_txt else out_path.with_name(f".raw_{out_path.stem}.png")
        subprocess.run(
            [ffmpeg_bin, "-y", "-ss", f"{ts:.3f}", "-i", str(in_path), "-frames:v", "1", str(raw_png)],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            check=True,
        )
        if title_txt:
            Image, ImageDraw, _, _ = _require_pillow()
            im = Image.open(raw_png).convert("RGBA")
            w, h = im.size
            # Bottom dark gradient scrim for crisp YouTube/Reel cover legibility
            grad = Image.new("RGBA", (1, h), (0, 0, 0, 0))
            gpx = grad.load()
            for y in range(h):
                t = max(0.0, (y - h * 0.38) / (h * 0.62))
                gpx[0, y] = (4, 6, 10, int(round(235 * (t ** 1.35))))
            im = Image.alpha_composite(im, grad.resize((w, h), Image.Resampling.BILINEAR))

            f_size = max(44, int(round(min(w, h) * 0.082)))
            f_title = _load_pil_font("display_bold", f_size)
            lines = _wrap_lines(title_txt, f_title, w - 120)[:3]
            d = ImageDraw.Draw(im)
            cur_y = h - (len(lines) * (f_size + 14)) - int(h * 0.08)
            if badge_txt:
                f_b = _load_pil_font("mono_semibold", max(22, int(round(f_size * 0.38))))
                bb = f_b.getbbox(badge_txt.upper())
                bw, bh = (bb[2] - bb[0]) + 32, (bb[3] - bb[1]) + 18
                bx = 64
                by = cur_y - bh - 20
                d.rounded_rectangle((bx, by, bx + bw, by + bh), radius=12, fill=(138, 180, 248, 235))
                d.text((bx + 16 - bb[0], by + 9 - bb[1]), badge_txt.upper(), font=f_b, fill=(8, 12, 20, 255))
            for ln in lines:
                d.text((66, cur_y + 3), ln, font=f_title, fill=(0, 0, 0, 180))
                d.text((64, cur_y), ln, font=f_title, fill=(248, 249, 252, 255))
                cur_y += f_size + 14
            im.convert("RGB").save(str(out_path), format="PNG")
            raw_png.unlink(missing_ok=True)
        return {"operation": op, "output_path": str(out_path), "size_mb": round(out_path.stat().st_size / (1024 * 1024), 2)}

    raise ValueError(
        f"Unsupported operation '{op}'. Choose from: extract_audio, podcast_voice_enhance, compress_social, to_gif, cover_thumbnail."
    )
