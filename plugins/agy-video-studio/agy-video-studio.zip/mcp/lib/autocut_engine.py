"""Scene-change, silence, and frozen-screen analyzer + Smart Auto-Cut engine."""

from __future__ import annotations

import re
import shutil
import subprocess
import uuid
from pathlib import Path

from .env_utils import select_video_encoder_args


def probe_video_extended(
    ffmpeg_bin: str,
    video_path: str,
    scene_threshold: float = 0.20,
    min_freeze_sec: float = 0.65,
    min_silence_sec: float = 0.55,
    silence_db: float = -38.0,
) -> dict:
    p = Path(video_path)
    if not p.is_file():
        raise FileNotFoundError(f"Video file not found: {video_path}")

    info_proc = subprocess.run([ffmpeg_bin, "-hide_banner", "-i", str(p)], stderr=subprocess.PIPE, text=True)
    stderr = info_proc.stderr

    dur_m = re.search(r"Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)", stderr)
    duration_sec = 0.0
    if dur_m:
        duration_sec = int(dur_m.group(1)) * 3600 + int(dur_m.group(2)) * 60 + float(dur_m.group(3))

    res_m = re.search(r"Video:.*?,\s*(\d{2,5})x(\d{2,5})", stderr)
    width = int(res_m.group(1)) if res_m else 0
    height = int(res_m.group(2)) if res_m else 0

    fps_m = re.search(r"(\d+(?:\.\d+)?)\s*fps", stderr)
    fps = float(fps_m.group(1)) if fps_m else 30.0
    has_audio = "Audio:" in stderr
    has_video = width > 0 and height > 0

    if not has_video:
        return {
            "path": str(p.resolve()),
            "width": 0,
            "height": 0,
            "fps": 0.0,
            "duration_sec": round(duration_sec, 3),
            "has_audio": has_audio,
            "scene_changes": [],
            "frozen_intervals": [],
            "silence_intervals": [],
        }

    vf_chain = f"scale=320:-2,scdet=threshold={scene_threshold * 100.0:.1f},freezedetect=n=0.003:d={min_freeze_sec:.2f}"
    cmd = [ffmpeg_bin, "-hide_banner", "-i", str(p), "-vf", vf_chain]
    if has_audio:
        cmd += ["-af", f"silencedetect=noise={silence_db:.1f}dB:d={min_silence_sec:.2f}"]
    else:
        cmd += ["-an"]
    cmd += ["-f", "null", "-"]

    an_proc = subprocess.run(cmd, stderr=subprocess.PIPE, text=True)
    log = an_proc.stderr

    scene_changes = []
    for m in re.finditer(r"lavfi\.scd\.score:\s*([\d.]+),\s*lavfi\.scd\.time:\s*([\d.]+)", log):
        score = float(m.group(1))
        t_sec = round(float(m.group(2)), 3)
        if not scene_changes or (t_sec - scene_changes[-1]["time_sec"]) >= 0.35:
            scene_changes.append({"time_sec": t_sec, "score": round(score, 2)})

    frozen_intervals = []
    cur_freeze_start: float | None = None
    for line in log.splitlines():
        ms = re.search(r"freeze_start:\s*([\d.]+)", line)
        if ms:
            cur_freeze_start = float(ms.group(1))
            continue
        me = re.search(r"freeze_end:\s*([\d.]+)", line)
        if me and cur_freeze_start is not None:
            fe = float(me.group(1))
            if fe > cur_freeze_start:
                frozen_intervals.append(
                    {
                        "start_sec": round(cur_freeze_start, 3),
                        "end_sec": round(fe, 3),
                        "duration_sec": round(fe - cur_freeze_start, 3),
                    }
                )
            cur_freeze_start = None
    if cur_freeze_start is not None and duration_sec > cur_freeze_start + min_freeze_sec:
        frozen_intervals.append(
            {
                "start_sec": round(cur_freeze_start, 3),
                "end_sec": round(duration_sec, 3),
                "duration_sec": round(duration_sec - cur_freeze_start, 3),
            }
        )

    silence_intervals = []
    cur_sil_start: float | None = None
    for line in log.splitlines():
        ms = re.search(r"silence_start:\s*([\d.]+)", line)
        if ms:
            cur_sil_start = float(ms.group(1))
            continue
        me = re.search(r"silence_end:\s*([\d.]+)", line)
        if me and cur_sil_start is not None:
            se = float(me.group(1))
            if se > cur_sil_start:
                silence_intervals.append(
                    {
                        "start_sec": round(cur_sil_start, 3),
                        "end_sec": round(se, 3),
                        "duration_sec": round(se - cur_sil_start, 3),
                    }
                )
            cur_sil_start = None
    if cur_sil_start is not None and duration_sec > cur_sil_start + min_silence_sec:
        silence_intervals.append(
            {
                "start_sec": round(cur_sil_start, 3),
                "end_sec": round(duration_sec, 3),
                "duration_sec": round(duration_sec - cur_sil_start, 3),
            }
        )

    return {
        "path": str(p.resolve()),
        "width": width,
        "height": height,
        "fps": fps,
        "duration_sec": round(duration_sec, 3),
        "has_audio": has_audio,
        "scene_changes": scene_changes[:100],
        "frozen_intervals": frozen_intervals[:100],
        "silence_intervals": silence_intervals[:100],
    }


def _merge_intervals(intervals: list[tuple[float, float]], gap_tol: float = 0.08) -> list[tuple[float, float]]:
    if not intervals:
        return []
    items = sorted(intervals, key=lambda x: x[0])
    merged = [items[0]]
    for st, en in items[1:]:
        prev_st, prev_en = merged[-1]
        if st <= prev_en + gap_tol:
            merged[-1] = (prev_st, max(prev_en, en))
        else:
            merged.append((st, en))
    return merged


def _intersect_intervals(a: list[tuple[float, float]], b: list[tuple[float, float]]) -> list[tuple[float, float]]:
    out = []
    for s1, e1 in a:
        for s2, e2 in b:
            st = max(s1, s2)
            en = min(e1, e2)
            if en > st:
                out.append((st, en))
    return _merge_intervals(out)


def smart_autocut(ffmpeg_bin: str, args: dict) -> dict:
    """Compute tight active EDL segments (and optionally render MP4) by removing or speed-ramping dead pauses."""
    video_path = str(Path(args["video_path"]).resolve())
    min_dead_sec = max(0.3, float(args.get("min_dead_sec", 0.75)))
    padding_sec = max(0.0, min(0.5, float(args.get("padding_sec", 0.12))))
    mode = str(args.get("mode", "cut")).lower()  # "cut" or "speed_ramp"
    idle_speed = max(1.5, min(6.0, float(args.get("idle_speed", 3.2))))
    cut_criterion = str(args.get("criterion", "auto")).lower()  # "auto", "freeze", "silence", "both"
    output_path = args.get("output_path")
    use_hw_accel = bool(args.get("use_hw_accel", True))

    meta = probe_video_extended(
        ffmpeg_bin,
        video_path,
        min_freeze_sec=min_dead_sec,
        min_silence_sec=min_dead_sec,
    )
    dur = meta["duration_sec"]
    if dur <= 0.2:
        raise ValueError(f"Invalid video duration ({dur}s) for {video_path}")

    freezes = [(x["start_sec"], x["end_sec"]) for x in meta["frozen_intervals"]]
    silences = [(x["start_sec"], x["end_sec"]) for x in meta["silence_intervals"]]

    if cut_criterion == "freeze" or (cut_criterion == "auto" and not meta["has_audio"]):
        raw_dead = freezes
    elif cut_criterion == "silence":
        raw_dead = silences
    elif cut_criterion == "both":
        raw_dead = _intersect_intervals(freezes, silences)
    else:
        # "auto" with audio: cut when silent & frozen if freezes exist, otherwise silent
        both = _intersect_intervals(freezes, silences)
        raw_dead = both if both else (freezes if not silences else silences)

    # Apply breath padding around active regions so cuts feel natural
    dead_trimmed: list[tuple[float, float]] = []
    for st, en in _merge_intervals(raw_dead):
        s_pad = st + padding_sec
        e_pad = en - padding_sec
        if (e_pad - s_pad) >= min_dead_sec:
            dead_trimmed.append((round(s_pad, 3), round(e_pad, 3)))

    segments = []
    cursor = 0.0
    for d_st, d_en in dead_trimmed:
        if d_st > cursor + 0.08:
            segments.append(
                {
                    "source": video_path,
                    "start_sec": round(cursor, 3),
                    "end_sec": round(d_st, 3),
                    "speed": 1.0,
                    "kind": "active",
                }
            )
        if mode == "speed_ramp":
            segments.append(
                {
                    "source": video_path,
                    "start_sec": round(d_st, 3),
                    "end_sec": round(d_en, 3),
                    "speed": idle_speed,
                    "kind": "idle_ramped",
                }
            )
        cursor = d_en

    if dur > cursor + 0.08:
        segments.append(
            {
                "source": video_path,
                "start_sec": round(cursor, 3),
                "end_sec": round(dur, 3),
                "speed": 1.0,
                "kind": "active",
            }
        )

    if not segments:
        segments = [{"source": video_path, "start_sec": 0.0, "end_sec": round(dur, 3), "speed": 1.0, "kind": "active"}]

    new_dur = sum((s["end_sec"] - s["start_sec"]) / s["speed"] for s in segments)
    rendered_info = None

    if output_path:
        out_p = Path(output_path).resolve()
        out_p.parent.mkdir(parents=True, exist_ok=True)
        work_dir = out_p.parent / f".agy_autocut_{uuid.uuid4().hex[:8]}"
        work_dir.mkdir(parents=True, exist_ok=True)
        try:
            v_enc_flags, enc_used = select_video_encoder_args(ffmpeg_bin, use_hw_accel=use_hw_accel)
            part_files = []
            for idx, seg in enumerate(segments):
                part = work_dir / f"part_{idx:03d}.mp4"
                spd = float(seg["speed"])
                vf = f"setpts=PTS/{spd:.4f}"
                cmd = [
                    ffmpeg_bin,
                    "-y",
                    "-ss",
                    f"{seg['start_sec']:.3f}",
                    "-to",
                    f"{seg['end_sec']:.3f}",
                    "-i",
                    video_path,
                    "-vf",
                    vf,
                ]
                if meta["has_audio"]:
                    # atempo supports 0.5..2.0 per stage; chain two stages if speed > 2.0
                    if spd <= 2.0:
                        af = f"atempo={spd:.4f}"
                    elif spd <= 4.0:
                        half = spd ** 0.5
                        af = f"atempo={half:.4f},atempo={half:.4f}"
                    else:
                        third = spd ** (1.0 / 3.0)
                        af = f"atempo={third:.4f},atempo={third:.4f},atempo={third:.4f}"
                    cmd += ["-af", af, "-c:a", "aac", "-b:a", "192k"]
                else:
                    cmd += ["-an"]

                run_res = subprocess.run(cmd + v_enc_flags + [str(part)], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                if run_res.returncode != 0 and enc_used != "libx264":
                    sw_flags, enc_used = select_video_encoder_args(ffmpeg_bin, use_hw_accel=False)
                    subprocess.run(cmd + sw_flags + [str(part)], stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True)
                elif run_res.returncode != 0:
                    raise RuntimeError(f"FFmpeg autocut segment failed: {run_res.stderr.decode(errors='ignore')[-300:]}")
                part_files.append(part)

            concat_file = work_dir / "concat.txt"
            concat_file.write_text("\n".join(f"file '{pf.as_posix()}'" for pf in part_files) + "\n", encoding="utf-8")
            subprocess.run(
                [ffmpeg_bin, "-y", "-f", "concat", "-safe", "0", "-i", str(concat_file), "-c", "copy", str(out_p)],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                check=True,
            )
            rendered_info = {
                "output_path": str(out_p),
                "encoder_used": enc_used,
                "size_mb": round(out_p.stat().st_size / (1024 * 1024), 2),
            }
        finally:
            shutil.rmtree(work_dir, ignore_errors=True)

    return {
        "original_duration_sec": round(dur, 2),
        "edited_duration_sec": round(new_dur, 2),
        "saved_sec": round(max(0.0, dur - new_dur), 2),
        "dead_intervals_removed": len(dead_trimmed),
        "segments": segments,
        "rendered": rendered_info,
    }
