"""AGY Video Studio v2.1.1 - Universal Native Android ARM64 & Cross-Platform Video Production Library."""

__version__ = "2.1.1"
