"""
Native Android & Cross-Platform Video Renderers:
  1. Google Gemini / Pixel Keynote 60fps 9:16 Trailer Engine (Pillow + FFmpeg + Android h264_mediacodec)
  2. Fast Viral TikTok ASS + Zoom-Punch Renderer
"""

from __future__ import annotations

import math
import shutil
import subprocess
import textwrap
import uuid
from pathlib import Path

from .autocut_engine import probe_video_extended
from .env_utils import FONTS_DIR, resolve_font_path, select_video_encoder_args


# ==============================================================================
# PILLOW HELPERS FOR GOOGLE GEMINI / PIXEL KEYNOTE VISUAL DESIGN
# ==============================================================================


def _require_pillow():
    try:
        from PIL import Image, ImageDraw, ImageFilter, ImageFont  # type: ignore

        return Image, ImageDraw, ImageFilter, ImageFont
    except ImportError as exc:
        raise RuntimeError(
            "Pillow (PIL) is required for 'video_render_keynote_trailer'. "
            "Run 'agy-video-setup' (or 'pkg install python-pillow' / 'pip install pillow')."
        ) from exc


def _load_pil_font(role: str, size: int):
    _, _, _, ImageFont = _require_pillow()
    fp = resolve_font_path(role)
    if fp and fp.is_file():
        return ImageFont.truetype(str(fp), size=size)
    return ImageFont.load_default()


def _create_studio_backdrop(width: int = 1080, height: int = 1920, accent_variant: int = 0):
    """Render a minimalist Obsidian (#05060A) studio backdrop with soft sapphire/violet radial light & subtle grid."""
    Image, ImageDraw, ImageFilter, _ = _require_pillow()

    base = Image.new("RGBA", (width, height), (5, 6, 10, 255))
    glow = Image.new("RGBA", (width // 4, height // 4), (0, 0, 0, 0))
    g_draw = ImageDraw.Draw(glow)

    # Subtle Google Gemini sapphire + amethyst light pools
    if accent_variant % 2 == 0:
        g_draw.ellipse((-40, 25, 220, 240), fill=(42, 86, 178, 68))
        g_draw.ellipse((80, 160, 310, 390), fill=(112, 68, 175, 46))
    else:
        g_draw.ellipse((60, 20, 310, 235), fill=(95, 72, 180, 62))
        g_draw.ellipse((-30, 175, 210, 395), fill=(36, 98, 186, 52))

    glow = glow.filter(ImageFilter.GaussianBlur(radius=42)).resize((width, height), Image.Resampling.BILINEAR)
    canvas = Image.alpha_composite(base, glow)

    # Hairline architectural studio grid (very subtle 2.8% opacity)
    grid = Image.new("RGBA", (width, height), (0, 0, 0, 0))
    gr_draw = ImageDraw.Draw(grid)
    step = 60
    for x in range(0, width, step):
        gr_draw.line([(x, 0), (x, height)], fill=(255, 255, 255, 6), width=1)
    for y in range(0, height, step):
        gr_draw.line([(0, y), (width, y)], fill=(255, 255, 255, 6), width=1)

    return Image.alpha_composite(canvas, grid)


def _make_gemini_gradient_strip(w: int, h: int):
    """Create a smooth horizontal Google Gemini gradient (#FFFFFF -> #D2E3FC -> #8AB4F8 -> #C58AF9)."""
    Image, _, _, _ = _require_pillow()
    stops = [
        (0.00, (255, 255, 255)),
        (0.32, (210, 227, 252)),
        (0.68, (138, 180, 248)),
        (1.00, (197, 138, 249)),
    ]
    row = Image.new("RGB", (max(2, w), 1))
    px = row.load()
    for x in range(max(2, w)):
        t = x / float(max(1, w - 1))
        for i in range(len(stops) - 1):
            t0, c0 = stops[i]
            t1, c1 = stops[i + 1]
            if t <= t1 or i == len(stops) - 2:
                local = (t - t0) / max(1e-5, t1 - t0)
                local = max(0.0, min(1.0, local))
                r = int(round(c0[0] + (c1[0] - c0[0]) * local))
                g = int(round(c0[1] + (c1[1] - c0[1]) * local))
                b = int(round(c0[2] + (c1[2] - c0[2]) * local))
                px[x, 0] = (r, g, b)
                break
    return row.resize((max(2, w), max(2, h)), Image.Resampling.NEAREST)


def _draw_centered_gradient_line(canvas, text: str, font, center_x: int, y: int, solid_rgb=None) -> int:
    """Draw crisp antialiased text centered at center_x, filled either solid or with optical Gemini gradient."""
    Image, ImageDraw, _, _ = _require_pillow()
    if not text:
        return y
    bbox = font.getbbox(text)
    tw = max(4, bbox[2] - bbox[0])
    th = max(4, bbox[3] - bbox[1] + 16)
    ox = -bbox[0] + 4
    oy = -bbox[1] + 4

    mask = Image.new("L", (tw + 8, th + 8), 0)
    m_draw = ImageDraw.Draw(mask)
    m_draw.text((ox, oy), text, font=font, fill=255)

    if solid_rgb is not None:
        color_img = Image.new("RGB", mask.size, solid_rgb)
    else:
        color_img = _make_gemini_gradient_strip(mask.size[0], mask.size[1])

    paste_x = int(center_x - mask.size[0] // 2)
    paste_y = int(y)
    rgba_glyphs = color_img.convert("RGBA")
    rgba_glyphs.putalpha(mask)
    canvas.alpha_composite(rgba_glyphs, (paste_x, paste_y))
    return paste_y + (bbox[3] - bbox[1])


def _wrap_lines(text: str, font, max_px: int) -> list[str]:
    if not text:
        return []
    out: list[str] = []
    for raw_line in text.splitlines():
        words = raw_line.split()
        if not words:
            continue
        cur = words[0]
        for w in words[1:]:
            test = f"{cur} {w}"
            bb = font.getbbox(test)
            if (bb[2] - bb[0]) <= max_px:
                cur = test
            else:
                out.append(cur)
                cur = w
        out.append(cur)
    return out


def _draw_eyebrow_pill(canvas, text: str, center_x: int, y: int) -> int:
    Image, ImageDraw, _, _ = _require_pillow()
    if not text:
        return y
    label = "  ".join(text.upper().strip()) if len(text) <= 14 else text.upper().strip()
    font = _load_pil_font("mono_semibold", 22)
    bb = font.getbbox(label)
    tw, th = bb[2] - bb[0], bb[3] - bb[1]
    pad_x, pad_y = 26, 13
    pw, ph = tw + pad_x * 2, th + pad_y * 2

    overlay = Image.new("RGBA", canvas.size, (0, 0, 0, 0))
    od = ImageDraw.Draw(overlay)
    x1 = center_x - pw // 2
    y1 = y
    od.rounded_rectangle(
        (x1, y1, x1 + pw, y1 + ph),
        radius=ph // 2,
        fill=(138, 180, 248, 22),
        outline=(138, 180, 248, 72),
        width=2,
    )
    od.text((x1 + pad_x - bb[0], y1 + pad_y - bb[1]), label, font=font, fill=(174, 203, 250, 245))
    canvas.alpha_composite(overlay)
    return y1 + ph


def _draw_hero_sculpture_emblem(canvas, center_x: int, center_y: int, emblem_style: str = "gemini_prism") -> None:
    """Draw a sleek, hardware-lit minimalist glass & titanium 3D emblem for hero cards."""
    Image, ImageDraw, ImageFilter, _ = _require_pillow()
    layer = Image.new("RGBA", canvas.size, (0, 0, 0, 0))
    ld = ImageDraw.Draw(layer)

    # Soft studio glow halo
    ld.ellipse(
        (center_x - 140, center_y - 140, center_x + 140, center_y + 140),
        fill=(102, 152, 246, 52),
    )
    layer = layer.filter(ImageFilter.GaussianBlur(radius=34))
    canvas.alpha_composite(layer)

    fg = Image.new("RGBA", canvas.size, (0, 0, 0, 0))
    fd = ImageDraw.Draw(fg)
    r_box = 92
    x1, y1, x2, y2 = center_x - r_box, center_y - r_box, center_x + r_box, center_y + r_box

    # Tilted back glass plane (3D depth cue)
    fd.rounded_rectangle(
        (x1 + 16, y1 - 14, x2 + 16, y2 - 14),
        radius=42,
        fill=(26, 33, 52, 130),
        outline=(197, 138, 249, 85),
        width=2,
    )
    # Front frosted obsidian-titanium squircle
    fd.rounded_rectangle(
        (x1, y1, x2, y2),
        radius=44,
        fill=(13, 17, 27, 238),
        outline=(168, 199, 250, 145),
        width=3,
    )
    # Inner specular rim
    fd.rounded_rectangle(
        (x1 + 6, y1 + 6, x2 - 6, y2 - 6),
        radius=39,
        outline=(255, 255, 255, 26),
        width=1,
    )

    if emblem_style == "bionic_chip":
        # Minimalist ARM64 Silicon Die pins + core
        for offset in (-36, -12, 12, 36):
            fd.line([(center_x + offset, y1 + 26), (center_x + offset, y1 + 42)], fill=(138, 180, 248, 210), width=4)
            fd.line([(center_x + offset, y2 - 42), (center_x + offset, y2 - 26)], fill=(138, 180, 248, 210), width=4)
            fd.line([(x1 + 26, center_y + offset), (x1 + 42, center_y + offset)], fill=(197, 138, 249, 210), width=4)
            fd.line([(x2 - 42, center_y + offset), (x2 - 26, center_y + offset)], fill=(197, 138, 249, 210), width=4)
        fd.rounded_rectangle(
            (center_x - 42, center_y - 42, center_x + 42, center_y + 42),
            radius=14,
            fill=(24, 34, 58, 255),
            outline=(168, 199, 250, 225),
            width=3,
        )
    else:
        # Antigravity iconic geometric A-arc + Gemini star sparkle
        pts_left = [(center_x, center_y - 46), (center_x - 40, center_y + 42)]
        pts_right = [(center_x, center_y - 46), (center_x + 40, center_y + 42)]
        fd.line(pts_left, fill=(138, 180, 248, 255), width=11)
        fd.line(pts_right, fill=(197, 138, 249, 255), width=11)
        fd.arc((center_x - 32, center_y - 4, center_x + 32, center_y + 46), start=200, end=340, fill=(232, 240, 254, 245), width=7)
        fd.ellipse((center_x - 7, center_y - 52, center_x + 7, center_y - 38), fill=(255, 255, 255, 255))

    canvas.alpha_composite(fg)


def _render_hero_card_png(scene: dict, out_png: Path, width: int = 1080, height: int = 1920, idx: int = 0) -> Path:
    Image, ImageDraw, _, _ = _require_pillow()
    canvas = _create_studio_backdrop(width, height, accent_variant=idx)

    eyebrow = str(scene.get("eyebrow", "")).strip()
    title = str(scene.get("title", "")).strip()
    accent_title = str(scene.get("accent_title", "")).strip()
    subtitle = str(scene.get("subtitle", "")).strip()
    cta_url = str(scene.get("cta_url", "")).strip()
    tags = scene.get("tags") or []
    emblem = str(scene.get("emblem", "gemini_prism")).strip()

    cx = width // 2
    is_landscape = width > height
    cursor_y = int(height * (0.13 if is_landscape else (0.265 if cta_url else 0.305)))

    if emblem != "none":
        _draw_hero_sculpture_emblem(canvas, cx, cursor_y + (55 if is_landscape else 0), emblem_style=emblem)
        cursor_y += 175 if is_landscape else 145

    if eyebrow:
        cursor_y = _draw_eyebrow_pill(canvas, eyebrow, cx, cursor_y) + (26 if is_landscape else 38)

    title_font = _load_pil_font("display_bold", 68 if is_landscape else 76)
    max_tw = min(1320, width - 140)
    for line in _wrap_lines(title, title_font, max_tw):
        cursor_y = _draw_centered_gradient_line(canvas, line, title_font, cx, cursor_y, solid_rgb=(248, 249, 252)) + 14

    if accent_title:
        for line in _wrap_lines(accent_title, title_font, max_tw):
            cursor_y = _draw_centered_gradient_line(canvas, line, title_font, cx, cursor_y, solid_rgb=None) + 16

    if subtitle:
        cursor_y += 14
        sub_font = _load_pil_font("sans_semibold", 29 if is_landscape else 31)
        for line in _wrap_lines(subtitle, sub_font, min(1150, width - 170)):
            cursor_y = _draw_centered_gradient_line(canvas, line, sub_font, cx, cursor_y, solid_rgb=(154, 160, 166)) + 12

    if cta_url or tags:
        cursor_y += 30 if is_landscape else 46
        card_layer = Image.new("RGBA", canvas.size, (0, 0, 0, 0))
        cd = ImageDraw.Draw(card_layer)
        cw = min(920, width - 160)
        ch = 185 if (cta_url and tags) else 115
        cx1 = cx - cw // 2
        cy1 = cursor_y
        cd.rounded_rectangle(
            (cx1, cy1, cx1 + cw, cy1 + ch),
            radius=28,
            fill=(13, 17, 26, 225),
            outline=(138, 180, 248, 72),
            width=2,
        )
        inner_y = cy1 + 30
        if cta_url:
            mono_f = _load_pil_font("mono_semibold", 28)
            # Emerald live status dot
            cd.ellipse((cx1 + 36, inner_y + 8, cx1 + 52, inner_y + 24), fill=(52, 211, 153, 255))
            cd.text((cx1 + 70, inner_y), cta_url, font=mono_f, fill=(232, 240, 254, 255))
            inner_y += 58

        if tags:
            tag_f = _load_pil_font("sans_semibold", 22)
            tx = cx1 + 36
            for tg in tags[:4]:
                t_str = str(tg)
                tbb = tag_f.getbbox(t_str)
                tw_t = (tbb[2] - tbb[0]) + 30
                th_t = 42
                if tx + tw_t > cx1 + cw - 28:
                    break
                cd.rounded_rectangle(
                    (tx, inner_y, tx + tw_t, inner_y + th_t),
                    radius=12,
                    fill=(255, 255, 255, 16),
                    outline=(255, 255, 255, 34),
                    width=1,
                )
                cd.text((tx + 15 - tbb[0], inner_y + 9 - tbb[1]), t_str, font=tag_f, fill=(189, 198, 212, 245))
                tx += tw_t + 14

        canvas.alpha_composite(card_layer)

    canvas.convert("RGB").save(str(out_png), format="PNG")
    return out_png


def _render_device_layers(
    scene: dict,
    bg_png: Path,
    frame_overlay_png: Path,
    src_w: int,
    src_h: int,
    width: int = 1080,
    height: int = 1920,
    idx: int = 0,
) -> tuple[int, int, int, int]:
    """
    Create:
      1) bg_png: Studio backdrop + header typography + soft drop shadow behind phone
      2) frame_overlay_png: Exact corner mask matching bg_png + brushed titanium bezel + camera punch-hole
    Returns (vp_x, vp_y, vp_w, vp_h) even-integer viewport coordinates for FFmpeg overlay.
    """
    Image, ImageDraw, ImageFilter, _ = _require_pillow()
    canvas = _create_studio_backdrop(width, height, accent_variant=idx)
    is_landscape = width > height
    text_cx = int(width * 0.28) if is_landscape else (width // 2)
    text_max_w = int(width * 0.46) if is_landscape else (width - 130)

    eyebrow = str(scene.get("eyebrow", "")).strip()
    title = str(scene.get("title", "")).strip()
    accent_title = str(scene.get("accent_title", "")).strip()
    subtitle = str(scene.get("subtitle", "")).strip()

    header_y = int(height * 0.26) if is_landscape else 135
    if eyebrow:
        header_y = _draw_eyebrow_pill(canvas, eyebrow, text_cx, header_y) + 24

    t_font = _load_pil_font("display_bold", 54 if is_landscape else 56)
    for line in _wrap_lines(title, t_font, text_max_w):
        header_y = _draw_centered_gradient_line(canvas, line, t_font, text_cx, header_y, solid_rgb=(248, 249, 252)) + 10

    if accent_title:
        for line in _wrap_lines(accent_title, t_font, text_max_w):
            header_y = _draw_centered_gradient_line(canvas, line, t_font, text_cx, header_y, solid_rgb=None) + 12

    if subtitle:
        header_y += 8
        s_font = _load_pil_font("sans_semibold", 25 if is_landscape else 26)
        for line in _wrap_lines(subtitle, s_font, text_max_w - 20)[:3]:
            header_y = _draw_centered_gradient_line(canvas, line, s_font, text_cx, header_y, solid_rgb=(154, 160, 166)) + 8

    # Compute ideal rounded device viewport preserving source aspect ratio inside safe zone
    aspect = (src_w / float(src_h)) if (src_w > 0 and src_h > 0) else (9.0 / 19.5)
    if is_landscape:
        max_vp_h = height - 150
        max_vp_w = int(width * 0.42)
        vp_h = max_vp_h
        vp_w = int(round(vp_h * aspect))
        if vp_w > max_vp_w:
            vp_w = max_vp_w
            vp_h = int(round(vp_w / max(0.25, aspect)))
        vp_w = max(240, (vp_w // 2) * 2)
        vp_h = max(240, (vp_h // 2) * 2)
        dev_cx = int(width * 0.74)
        vp_x = ((dev_cx - vp_w // 2) // 2) * 2
        vp_y = (((height - vp_h) // 2) // 2) * 2
    else:
        top_avail = max(int(height * 0.22), header_y + 38)
        bottom_limit = height - 175
        max_vp_h = max(420, bottom_limit - top_avail)
        max_vp_w = min(740, width - 160)
        vp_h = max_vp_h
        vp_w = int(round(vp_h * aspect))
        if vp_w > max_vp_w:
            vp_w = max_vp_w
            vp_h = int(round(vp_w / max(0.25, aspect)))
        vp_w = max(240, (vp_w // 2) * 2)
        vp_h = max(320, (vp_h // 2) * 2)
        vp_x = ((width - vp_w) // 4) * 2
        vp_y = ((top_avail + (max_vp_h - vp_h) // 2) // 2) * 2

    # Draw studio ambient glow + deep drop shadow onto bg_png
    shadow_layer = Image.new("RGBA", (width, height), (0, 0, 0, 0))
    sd = ImageDraw.Draw(shadow_layer)
    sd.rounded_rectangle(
        (vp_x - 24, vp_y - 16, vp_x + vp_w + 24, vp_y + vp_h + 36),
        radius=62,
        fill=(0, 0, 0, 185),
    )
    sd.rounded_rectangle(
        (vp_x - 16, vp_y - 16, vp_x + vp_w + 16, vp_y + vp_h + 16),
        radius=58,
        outline=(118, 165, 248, 52),
        width=12,
    )
    shadow_layer = shadow_layer.filter(ImageFilter.GaussianBlur(radius=28))
    bg_composited = Image.alpha_composite(canvas, shadow_layer)
    bg_composited.convert("RGB").save(str(bg_png), format="PNG")

    # Build frame_overlay_png:
    # 1. Start transparent everywhere, EXCEPT copy bg_composited pixels inside [vp_x..vp_x+vp_w, vp_y..vp_y+vp_h]
    #    where the rounded inner screen mask is 0 (the 4 outer corner triangles!), masking video corners cleanly!
    corner_radius = 44
    inner_mask = Image.new("L", (vp_w, vp_h), 0)
    imd = ImageDraw.Draw(inner_mask)
    imd.rounded_rectangle((0, 0, vp_w - 1, vp_h - 1), radius=corner_radius, fill=255)

    # Invert mask -> 255 in the 4 outer corner wedges, 0 inside the rounded screen
    inv_corner_mask = inner_mask.point(lambda p: 255 - p)
    bg_crop = bg_composited.crop((vp_x, vp_y, vp_x + vp_w, vp_y + vp_h)).convert("RGBA")
    bg_crop.putalpha(inv_corner_mask)

    overlay = Image.new("RGBA", (width, height), (0, 0, 0, 0))
    overlay.alpha_composite(bg_crop, (vp_x, vp_y))

    # 2. Draw Brushed Titanium Hardware Bezel + Inner Black Glass Rim + Camera Punch-Hole + Side Buttons
    od = ImageDraw.Draw(overlay)
    # Side physical buttons (right side of titanium frame)
    btn_x1 = vp_x + vp_w + 11
    od.rounded_rectangle((btn_x1, vp_y + 210, btn_x1 + 5, vp_y + 295), radius=2, fill=(108, 118, 138, 235))
    od.rounded_rectangle((btn_x1, vp_y + 330, btn_x1 + 5, vp_y + 465), radius=2, fill=(92, 102, 122, 235))

    # Outer metallic titanium rim
    od.rounded_rectangle(
        (vp_x - 12, vp_y - 12, vp_x + vp_w + 12, vp_y + vp_h + 12),
        radius=corner_radius + 12,
        outline=(118, 128, 148, 245),
        width=5,
    )
    # Mid dark anodized titanium chamfer
    od.rounded_rectangle(
        (vp_x - 8, vp_y - 8, vp_x + vp_w + 8, vp_y + vp_h + 8),
        radius=corner_radius + 8,
        outline=(24, 28, 36, 255),
        width=6,
    )
    # Inner black screen bezel + specular inner highlight
    od.rounded_rectangle(
        (vp_x - 3, vp_y - 3, vp_x + vp_w + 3, vp_y + vp_h + 3),
        radius=corner_radius + 3,
        outline=(8, 10, 14, 255),
        width=5,
    )
    od.rounded_rectangle(
        (vp_x - 1, vp_y - 1, vp_x + vp_w + 1, vp_y + vp_h + 1),
        radius=corner_radius + 1,
        outline=(255, 255, 255, 38),
        width=1,
    )

    # Subtle front camera punch-hole
    cam_r = 9
    cam_cx = vp_x + vp_w // 2
    cam_cy = vp_y + 22
    od.ellipse((cam_cx - cam_r, cam_cy - cam_r, cam_cx + cam_r, cam_cy + cam_r), fill=(6, 7, 10, 240), outline=(45, 52, 68, 180), width=1)

    overlay.save(str(frame_overlay_png), format="PNG")
    return vp_x, vp_y, vp_w, vp_h


def _render_pip_frame_png(pip_w: int, pip_h: int, label: str, out_png: Path) -> tuple[int, int]:
    """Render a floating glass bezel with label badge around a zoomed UI PiP callout."""
    Image, ImageDraw, ImageFilter, _ = _require_pillow()
    pad = 24
    tot_w = pip_w + pad * 2
    tot_h = pip_h + pad * 2 + (38 if label else 0)
    top_off = 38 if label else 0

    img = Image.new("RGBA", (tot_w, tot_h), (0, 0, 0, 0))
    sd = ImageDraw.Draw(img)
    sd.rounded_rectangle(
        (pad - 6, pad + top_off - 4, pad + pip_w + 6, pad + top_off + pip_h + 10),
        radius=20,
        fill=(0, 0, 0, 190),
    )
    img = img.filter(ImageFilter.GaussianBlur(radius=10))

    # Clear inside rounded viewport (radius=16) so live PiP video shows through with crisp rounded corners
    pip_mask = Image.new("L", (pip_w, pip_h), 0)
    pmd = ImageDraw.Draw(pip_mask)
    pmd.rounded_rectangle((0, 0, pip_w - 1, pip_h - 1), radius=16, fill=255)
    inv_pip_mask = pip_mask.point(lambda p: 255 - p)

    corner_cap = Image.new("RGBA", (pip_w, pip_h), (8, 10, 16, 255))
    corner_cap.putalpha(inv_pip_mask)

    clear_box = Image.new("RGBA", (pip_w, pip_h), (0, 0, 0, 0))
    img.paste(clear_box, (pad, pad + top_off))
    img.alpha_composite(corner_cap, (pad, pad + top_off))

    d = ImageDraw.Draw(img)
    d.rounded_rectangle(
        (pad - 3, pad + top_off - 3, pad + pip_w + 3, pad + top_off + pip_h + 3),
        radius=16,
        outline=(138, 180, 248, 225),
        width=3,
    )
    if label:
        f = _load_pil_font("mono_semibold", 19)
        bb = f.getbbox(label.upper())
        lw = (bb[2] - bb[0]) + 24
        lh = 30
        d.rounded_rectangle(
            (pad, pad + 2, pad + lw, pad + 2 + lh),
            radius=10,
            fill=(14, 20, 34, 240),
            outline=(138, 180, 248, 160),
            width=1,
        )
        d.text((pad + 12 - bb[0], pad + 7 - bb[1]), label.upper(), font=f, fill=(174, 203, 250, 255))

    img.save(str(out_png), format="PNG")
    return pad, pad + top_off


def _render_subtitle_pill_png(text: str, out_png: Path, max_width: int = 900) -> tuple[int, int]:
    """Render a minimalist translucent Google-style subtitle pill (no neon borders!)."""
    Image, ImageDraw, ImageFilter, _ = _require_pillow()
    font = _load_pil_font("sans_semibold", 32)
    lines = _wrap_lines(text.strip(), font, max_width - 76)[:3]
    if not lines:
        lines = [""]

    line_bboxes = [font.getbbox(ln) for ln in lines]
    text_w = max((bb[2] - bb[0]) for bb in line_bboxes)
    line_h = max((bb[3] - bb[1]) for bb in line_bboxes) + 12
    total_text_h = line_h * len(lines) - 8

    pad_x, pad_y = 36, 20
    pill_w = ((text_w + pad_x * 2 + 1) // 2) * 2
    pill_h = ((total_text_h + pad_y * 2 + 1) // 2) * 2
    margin = 16
    img_w = pill_w + margin * 2
    img_h = pill_h + margin * 2

    img = Image.new("RGBA", (img_w, img_h), (0, 0, 0, 0))
    sd = ImageDraw.Draw(img)
    sd.rounded_rectangle(
        (margin, margin + 4, margin + pill_w, margin + pill_h + 6),
        radius=26,
        fill=(0, 0, 0, 145),
    )
    img = img.filter(ImageFilter.GaussianBlur(radius=7))

    d = ImageDraw.Draw(img)
    d.rounded_rectangle(
        (margin, margin, margin + pill_w, margin + pill_h),
        radius=26,
        fill=(11, 14, 22, 228),
        outline=(190, 212, 252, 58),
        width=2,
    )

    cy = margin + pad_y
    for ln, bb in zip(lines, line_bboxes):
        lw = bb[2] - bb[0]
        lx = margin + (pill_w - lw) // 2 - bb[0]
        d.text((lx, cy - bb[1]), ln, font=font, fill=(248, 249, 252, 255))
        cy += line_h

    img.save(str(out_png), format="PNG")
    return img_w, img_h


# ==============================================================================
# FLAGSHIP GOOGLE KEYNOTE 60FPS RENDERER (PILLOW + FFMPEG + MEDIACODEC)
# ==============================================================================


def _run_ffmpeg_with_hw_fallback(ffmpeg_bin: str, base_cmd_before_enc: list[str], out_file: Path, use_hw_accel: bool, fps: int = 60) -> str:
    enc_flags, enc_name = select_video_encoder_args(ffmpeg_bin, use_hw_accel=use_hw_accel, bitrate_mbps=10.5, crf=18)
    full_cmd = base_cmd_before_enc + ["-r", str(fps)] + enc_flags + [str(out_file)]
    proc = subprocess.run(full_cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if proc.returncode == 0:
        return enc_name
    if enc_name != "libx264":
        sw_flags, sw_name = select_video_encoder_args(ffmpeg_bin, use_hw_accel=False, crf=18)
        sw_cmd = base_cmd_before_enc + ["-r", str(fps)] + sw_flags + [str(out_file)]
        proc2 = subprocess.run(sw_cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        if proc2.returncode == 0:
            return sw_name
        raise RuntimeError(f"FFmpeg Keynote segment failed: {proc2.stderr.decode(errors='ignore')[-450:]}")
    raise RuntimeError(f"FFmpeg Keynote segment failed: {proc.stderr.decode(errors='ignore')[-450:]}")


def render_keynote_trailer(ffmpeg_bin: str, args: dict) -> dict:
    """
    Render a Google Gemini / Pixel Keynote-style 1080x1920 60fps trailer natively via Pillow + FFmpeg.
    Supports 'hero_card' and 'device_showcase' scenes, PiP zoom callouts, translucent subtitle pills,
    and Android hardware GPU encoding (h264_mediacodec).
    """
    _require_pillow()
    scenes = args["scenes"]
    if not scenes:
        raise ValueError("'scenes' list cannot be empty.")

    output_path = Path(args["output_path"]).resolve()
    output_path.parent.mkdir(parents=True, exist_ok=True)
    ar_map = {"9:16": (1080, 1920), "16:9": (1920, 1080), "1:1": (1080, 1080), "4:5": (1080, 1350)}
    def_w, def_h = ar_map.get(str(args.get("aspect_ratio", "9:16")).strip(), (1080, 1920))
    out_w = int(args.get("width", def_w))
    out_h = int(args.get("height", def_h))
    out_fps = int(args.get("fps", 60))
    use_hw_accel = bool(args.get("use_hw_accel", True))
    captions = args.get("captions") or []
    master_audio_path = args.get("master_audio_path")
    voiceover_path = args.get("voiceover_path")
    music_path = args.get("music_path")
    music_volume = float(args.get("music_volume", 0.24))

    work_dir = output_path.parent / f".agy_keynote_{uuid.uuid4().hex[:8]}"
    work_dir.mkdir(parents=True, exist_ok=True)

    try:
        seg_files: list[Path] = []
        encoder_used = "libx264"
        cursor_sec = 0.0

        for idx, sc in enumerate(scenes):
            sc_type = str(sc.get("type", "device_showcase" if sc.get("source") else "hero_card")).lower()
            fade_dur = 0.26

            if sc_type == "hero_card":
                dur = max(1.2, float(sc.get("duration_sec", 3.5)))
                card_png = work_dir / f"hero_{idx:03d}.png"
                _render_hero_card_png(sc, card_png, width=out_w, height=out_h, idx=idx)

                # Subtle smooth cinematic push-in (1.0 -> 1.032) + fade in/out
                fade_out_st = max(0.1, dur - fade_dur)
                vf = (
                    f"fps={out_fps},"
                    f"scale={int(out_w * 1.04)}:{int(out_h * 1.04)},"
                    f"crop={out_w}:{out_h}:'(iw-ow)/2':'(ih-oh)/2 - (t/{dur:.3f})*18',"
                    f"fade=t=in:st=0:d={fade_dur:.2f},"
                    f"fade=t=out:st={fade_out_st:.3f}:d={fade_dur:.2f},format=yuv420p"
                )
                seg_mp4 = work_dir / f"seg_{idx:03d}.mp4"
                cmd = [
                    ffmpeg_bin,
                    "-y",
                    "-loop",
                    "1",
                    "-t",
                    f"{dur:.3f}",
                    "-i",
                    str(card_png),
                    "-vf",
                    vf,
                    "-an",
                ]
                encoder_used = _run_ffmpeg_with_hw_fallback(ffmpeg_bin, cmd, seg_mp4, use_hw_accel=use_hw_accel, fps=out_fps)
                seg_files.append(seg_mp4)
                cursor_sec += dur

            else:
                # device_showcase
                src_path = Path(sc["source"]).resolve()
                if not src_path.is_file():
                    raise FileNotFoundError(f"Scene {idx} video source not found: {src_path}")

                meta = probe_video_extended(ffmpeg_bin, str(src_path), scene_threshold=0.95, min_freeze_sec=99.0, min_silence_sec=99.0)
                start_s = max(0.0, float(sc.get("start_sec", 0.0)))
                end_s = float(sc.get("end_sec", meta["duration_sec"] or 5.0))
                speed = max(0.35, min(6.0, float(sc.get("speed", 1.0))))
                dur = max(0.6, (end_s - start_s) / speed)

                bg_png = work_dir / f"dev_bg_{idx:03d}.png"
                frame_png = work_dir / f"dev_frame_{idx:03d}.png"
                vp_x, vp_y, vp_w, vp_h = _render_device_layers(
                    sc,
                    bg_png,
                    frame_png,
                    src_w=meta["width"] or 1080,
                    src_h=meta["height"] or 2340,
                    width=out_w,
                    height=out_h,
                    idx=idx,
                )

                inputs = [
                    "-loop", "1", "-t", f"{dur:.3f}", "-i", str(bg_png),
                    "-ss", f"{start_s:.3f}", "-to", f"{end_s:.3f}", "-i", str(src_path),
                    "-loop", "1", "-t", f"{dur:.3f}", "-i", str(frame_png),
                ]

                pip = sc.get("pip_crop")
                fade_out_st = max(0.1, dur - fade_dur)

                if pip and isinstance(pip, dict):
                    # Split video stream to drive both main device screen AND floating glass zoom PiP!
                    src_w = max(64, meta["width"] or 1080)
                    src_h = max(64, meta["height"] or 2340)
                    cx_norm = max(0.0, min(0.85, float(pip.get("x", 0.06))))
                    cy_norm = max(0.0, min(0.85, float(pip.get("y", 0.22))))
                    cw_norm = max(0.12, min(1.0 - cx_norm, float(pip.get("w", 0.88))))
                    ch_norm = max(0.08, min(1.0 - cy_norm, float(pip.get("h", 0.20))))

                    crop_x = int(src_w * cx_norm)
                    crop_y = int(src_h * cy_norm)
                    crop_w = max(64, (int(src_w * cw_norm) // 2) * 2)
                    crop_h = max(48, (int(src_h * ch_norm) // 2) * 2)

                    pip_disp_w = min(860, max(420, int(pip.get("display_width", 800)) // 2 * 2))
                    pip_disp_h = max(90, (int(round(pip_disp_w * (crop_h / float(crop_w)))) // 2) * 2)
                    pip_label = str(pip.get("label", "LIVE FOCUS")).strip()

                    pip_border_png = work_dir / f"pip_border_{idx:03d}.png"
                    pad_l, pad_t = _render_pip_frame_png(pip_disp_w, pip_disp_h, pip_label, pip_border_png)
                    inputs += ["-loop", "1", "-t", f"{dur:.3f}", "-i", str(pip_border_png)]

                    pip_x = (out_w - pip_disp_w) // 2
                    pip_y = int(pip.get("pos_y", min(1240, vp_y + vp_h - pip_disp_h - 165)))

                    fc = (
                        f"[1:v]setpts=(PTS-STARTPTS)/{speed:.4f},fps={out_fps},split=2[vmain][vpip];"
                        f"[vmain]scale={vp_w}:{vp_h}:force_original_aspect_ratio=increase,crop={vp_w}:{vp_h}[vscr];"
                        f"[0:v][vscr]overlay={vp_x}:{vp_y}:shortest=1[s1];"
                        f"[s1][2:v]overlay=0:0:shortest=1[s2];"
                        f"[vpip]crop={crop_w}:{crop_h}:{crop_x}:{crop_y},scale={pip_disp_w}:{pip_disp_h}[vpz];"
                        f"[s2][vpz]overlay={pip_x}:{pip_y}:shortest=1[s3];"
                        f"[s3][3:v]overlay={pip_x - pad_l}:{pip_y - pad_t}:shortest=1,"
                        f"fade=t=in:st=0:d={fade_dur:.2f},fade=t=out:st={fade_out_st:.3f}:d={fade_dur:.2f},format=yuv420p[vout]"
                    )
                else:
                    fc = (
                        f"[1:v]setpts=(PTS-STARTPTS)/{speed:.4f},fps={out_fps},"
                        f"scale={vp_w}:{vp_h}:force_original_aspect_ratio=increase,crop={vp_w}:{vp_h}[vscr];"
                        f"[0:v][vscr]overlay={vp_x}:{vp_y}:shortest=1[s1];"
                        f"[s1][2:v]overlay=0:0:shortest=1,"
                        f"fade=t=in:st=0:d={fade_dur:.2f},fade=t=out:st={fade_out_st:.3f}:d={fade_dur:.2f},format=yuv420p[vout]"
                    )

                seg_mp4 = work_dir / f"seg_{idx:03d}.mp4"
                cmd = [ffmpeg_bin, "-y"] + inputs + ["-filter_complex", fc, "-map", "[vout]", "-t", f"{dur:.3f}", "-an"]
                encoder_used = _run_ffmpeg_with_hw_fallback(ffmpeg_bin, cmd, seg_mp4, use_hw_accel=use_hw_accel, fps=out_fps)
                seg_files.append(seg_mp4)
                cursor_sec += dur

        # Concatenate rendered 60fps scenes losslessly
        concat_txt = work_dir / "concat.txt"
        concat_txt.write_text("\n".join(f"file '{sf.as_posix()}'" for sf in seg_files) + "\n", encoding="utf-8")
        merged_mp4 = work_dir / "merged.mp4"
        subprocess.run(
            [ffmpeg_bin, "-y", "-f", "concat", "-safe", "0", "-i", str(concat_txt), "-c", "copy", str(merged_mp4)],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            check=True,
        )

        video_stage = merged_mp4

        # Apply minimalist translucent Google-style subtitle pills if captions provided
        valid_caps = [c for c in captions if str(c.get("text", "")).strip() and float(c["start_sec"]) < cursor_sec]
        if valid_caps:
            # Batch captions in groups of 18 so FFmpeg input count stays compact on Android
            batch_size = 18
            cur_in = video_stage
            for b_idx in range(0, len(valid_caps), batch_size):
                batch = valid_caps[b_idx : b_idx + batch_size]
                sub_inputs = ["-i", str(cur_in)]
                chain_parts = []
                last_label = "0:v"
                for c_i, cap in enumerate(batch):
                    pill_png = work_dir / f"cap_{b_idx + c_i:03d}.png"
                    pw, ph = _render_subtitle_pill_png(str(cap["text"]), pill_png, max_width=out_w - 140)
                    st_t = max(0.0, float(cap["start_sec"]))
                    en_t = min(cursor_sec, float(cap["end_sec"]))
                    sub_inputs += ["-loop", "1", "-t", f"{en_t + 0.05:.3f}", "-i", str(pill_png)]
                    px = (out_w - pw) // 2
                    py = int(cap.get("pos_y", out_h - ph - 145))
                    out_lbl = f"v{c_i}"
                    chain_parts.append(
                        f"[{last_label}][{c_i + 1}:v]overlay={px}:{py}:eof_action=pass:enable='between(t,{st_t:.3f},{en_t:.3f})'[{out_lbl}]"
                    )
                    last_label = out_lbl

                sub_out = work_dir / f"sub_stage_{b_idx:03d}.mp4"
                sub_cmd = [
                    ffmpeg_bin,
                    "-y",
                    *sub_inputs,
                    "-filter_complex",
                    ";".join(chain_parts),
                    "-map",
                    f"[{last_label}]",
                    "-an",
                ]
                encoder_used = _run_ffmpeg_with_hw_fallback(ffmpeg_bin, sub_cmd, sub_out, use_hw_accel=use_hw_accel, fps=out_fps)
                cur_in = sub_out
            video_stage = cur_in

        # Final Audio Muxing (Master Audio OR Voiceover + Sidechain Music OR Video-Only)
        if master_audio_path and os.path.isfile(str(master_audio_path)):
            subprocess.run(
                [
                    ffmpeg_bin,
                    "-y",
                    "-i",
                    str(video_stage),
                    "-i",
                    str(Path(master_audio_path).resolve()),
                    "-map",
                    "0:v:0",
                    "-map",
                    "1:a:0",
                    "-c:v",
                    "copy",
                    "-ar",
                    "48000",
                    "-ac",
                    "2",
                    "-c:a",
                    "aac",
                    "-b:a",
                    "320k",
                    "-shortest",
                    str(output_path),
                ],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                check=True,
            )
        elif voiceover_path and music_path:
            subprocess.run(
                [
                    ffmpeg_bin,
                    "-y",
                    "-i",
                    str(video_stage),
                    "-i",
                    str(Path(voiceover_path).resolve()),
                    "-i",
                    str(Path(music_path).resolve()),
                    "-filter_complex",
                    (
                        f"[1:a]aformat=sample_rates=48000:channel_layouts=stereo,apad=whole_dur={cursor_sec:.3f},volume=1.15[vo];"
                        f"[2:a]aformat=sample_rates=48000:channel_layouts=stereo,atrim=0:{cursor_sec:.3f},volume={music_volume:.3f}[bgm];"
                        f"[bgm][vo]sidechaincompress=threshold=0.025:ratio=5:attack=15:release=260[duck];"
                        f"[vo][duck]amix=inputs=2:duration=first:dropout_transition=0:normalize=0[aout]"
                    ),
                    "-map",
                    "0:v:0",
                    "-map",
                    "[aout]",
                    "-c:v",
                    "copy",
                    "-ar",
                    "48000",
                    "-ac",
                    "2",
                    "-c:a",
                    "aac",
                    "-b:a",
                    "320k",
                    "-shortest",
                    str(output_path),
                ],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                check=True,
            )
        elif voiceover_path or music_path:
            single_aud = Path(voiceover_path or music_path).resolve()
            subprocess.run(
                [
                    ffmpeg_bin,
                    "-y",
                    "-i",
                    str(video_stage),
                    "-i",
                    str(single_aud),
                    "-map",
                    "0:v:0",
                    "-map",
                    "1:a:0",
                    "-c:v",
                    "copy",
                    "-ar",
                    "48000",
                    "-ac",
                    "2",
                    "-c:a",
                    "aac",
                    "-b:a",
                    "320k",
                    "-shortest",
                    str(output_path),
                ],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                check=True,
            )
        else:
            shutil.copy2(video_stage, output_path)

        return {
            "output_path": str(output_path),
            "resolution": f"{out_w}x{out_h}",
            "fps": out_fps,
            "scenes_rendered": len(scenes),
            "captions_rendered": len(valid_caps),
            "duration_sec": round(cursor_sec, 2),
            "encoder_used": encoder_used,
            "size_mb": round(output_path.stat().st_size / (1024 * 1024), 2),
        }
    finally:
        shutil.rmtree(work_dir, ignore_errors=True)


# ==============================================================================
# FAST VIRAL TIKTOK ASS RENDERER (UPGRADED WITH BUNDLED FONTS + MEDIACODEC)
# ==============================================================================

import os


def _ass_ts(sec: float) -> str:
    sec = max(0.0, sec)
    h = int(sec // 3600)
    m = int((sec % 3600) // 60)
    s = sec % 60
    return f"{h}:{m:02d}:{s:05.2f}"


def _hex_to_ass_bgr(hex_color: str) -> str:
    c = hex_color.lstrip("#")
    if len(c) != 6:
        return "&H00FFFFFF"
    r, g, b = c[0:2], c[2:4], c[4:6]
    return f"&H00{b.upper()}{g.upper()}{r.upper()}"


def _write_tiktok_ass(ass_path: Path, captions: list[dict], width: int = 1080, height: int = 1920) -> None:
    header = f"""[Script Info]
ScriptType: v4.00+
PlayResX: {width}
PlayResY: {height}
WrapStyle: 0
ScaledBorderAndShadow: yes

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: TikTokPop,Outfit Bold,64,&H00FAFFF5,&H00F8B48A,&H000A0806,&H96000000,-1,0,0,0,100,100,0,0,1,4,2,2,72,110,340,1
Style: TopBadge,JetBrains Mono SemiBold,32,&H00FAA88A,&H00FFFFFF,&H000A0806,&HB4080A10,-1,0,0,0,100,100,0,0,3,14,0,8,72,110,175,1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""
    lines = [header]
    for cap in captions:
        st = _ass_ts(float(cap["start_sec"]))
        en = _ass_ts(float(cap["end_sec"]))
        txt = str(cap["text"]).replace("\n", r"\N")
        accent = _hex_to_ass_bgr(cap.get("highlight_hex", "#8AB4F8"))
        highlight_word = cap.get("highlight_word", "")
        if highlight_word and highlight_word in txt:
            txt = txt.replace(highlight_word, f"{{\\c{accent}}}{highlight_word}{{\\c&H00FAFFF5&}}", 1)
        style = "TopBadge" if cap.get("position") == "top" else "TikTokPop"
        pop = r"{\fscx88\fscy88\t(0,85,\fscx105\fscy105)\t(85,165,\fscx100\fscy100)}"
        lines.append(f"Dialogue: 1,{st},{en},{style},,0,0,0,,{pop}{txt}")
    ass_path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def render_viral_tiktok(ffmpeg_bin: str, args: dict) -> dict:
    segments = args["segments"]
    output_path = Path(args["output_path"]).resolve()
    output_path.parent.mkdir(parents=True, exist_ok=True)
    ar_map = {"9:16": (1080, 1920), "16:9": (1920, 1080), "1:1": (1080, 1080), "4:5": (1080, 1350)}
    def_w, def_h = ar_map.get(str(args.get("aspect_ratio", "9:16")).strip(), (1080, 1920))
    out_w = int(args.get("width", def_w))
    out_h = int(args.get("height", def_h))
    out_fps = int(args.get("fps", 60))
    use_hw_accel = bool(args.get("use_hw_accel", True))
    captions = args.get("captions", [])
    voiceover_path = args.get("voiceover_path")
    music_path = args.get("music_path")
    music_volume = float(args.get("music_volume", 0.26))

    work_dir = output_path.parent / f".agy_vid_tmp_{uuid.uuid4().hex[:8]}"
    work_dir.mkdir(parents=True, exist_ok=True)

    try:
        seg_files = []
        timeline_cursor = 0.0
        encoder_used = "libx264"

        for idx, seg in enumerate(segments):
            src = Path(seg["source"]).resolve()
            start_s = float(seg.get("start_sec", 0.0))
            end_s = float(seg["end_sec"])
            speed = max(0.25, min(6.0, float(seg.get("speed", 1.0))))
            zoom = max(1.0, min(2.8, float(seg.get("zoom", 1.0))))
            fx = max(0.0, min(1.0, float(seg.get("focus_x", 0.5))))
            fy = max(0.0, min(1.0, float(seg.get("focus_y", 0.5))))

            dur_in = max(0.1, end_s - start_s)
            timeline_cursor += dur_in / speed

            scaled_w = int(round(out_w * zoom))
            scaled_h = int(round(out_h * zoom))
            crop_x = int(round((scaled_w - out_w) * fx))
            crop_y = int(round((scaled_h - out_h) * fy))

            vf = (
                f"setpts=PTS/{speed:.4f},fps={out_fps},"
                f"scale={out_w}:{out_h}:force_original_aspect_ratio=decrease,"
                f"pad={out_w}:{out_h}:(ow-iw)/2:(oh-ih)/2:color=#050608,"
                f"scale={scaled_w}:{scaled_h},crop={out_w}:{out_h}:{crop_x}:{crop_y},setsar=1"
            )

            seg_out = work_dir / f"seg_{idx:03d}.mp4"
            cmd = [ffmpeg_bin, "-y", "-ss", f"{start_s:.3f}", "-to", f"{end_s:.3f}", "-i", str(src), "-vf", vf, "-an"]
            encoder_used = _run_ffmpeg_with_hw_fallback(ffmpeg_bin, cmd, seg_out, use_hw_accel=use_hw_accel, fps=out_fps)
            seg_files.append(seg_out)

        concat_txt = work_dir / "concat.txt"
        concat_txt.write_text("\n".join(f"file '{sf.as_posix()}'" for sf in seg_files) + "\n", encoding="utf-8")
        merged_video = work_dir / "merged_video.mp4"
        subprocess.run(
            [ffmpeg_bin, "-y", "-f", "concat", "-safe", "0", "-i", str(concat_txt), "-c", "copy", str(merged_video)],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            check=True,
        )

        video_stage = merged_video
        if captions:
            ass_file = work_dir / "captions.ass"
            _write_tiktok_ass(ass_file, captions, out_w, out_h)
            subbed_video = work_dir / "subbed_video.mp4"
            ass_escaped = ass_file.as_posix().replace(":", r"\:")
            fonts_escaped = FONTS_DIR.as_posix().replace(":", r"\:")
            sub_cmd = [
                ffmpeg_bin,
                "-y",
                "-i",
                str(merged_video),
                "-vf",
                f"ass='{ass_escaped}':fontsdir='{fonts_escaped}'",
                "-an",
            ]
            encoder_used = _run_ffmpeg_with_hw_fallback(ffmpeg_bin, sub_cmd, subbed_video, use_hw_accel=use_hw_accel, fps=out_fps)
            video_stage = subbed_video

        final_cmd = [ffmpeg_bin, "-y", "-i", str(video_stage)]
        if voiceover_path and music_path:
            final_cmd += [
                "-i",
                str(Path(voiceover_path).resolve()),
                "-i",
                str(Path(music_path).resolve()),
                "-filter_complex",
                (
                    f"[1:a]aresample=48000,volume=1.06[vo];"
                    f"[2:a]aresample=48000,volume={music_volume:.3f}[bgm];"
                    f"[bgm][vo]sidechaincompress=threshold=0.03:ratio=5:attack=15:release=240[ducked];"
                    f"[vo][ducked]amix=inputs=2:duration=first:dropout_transition=0[aout]"
                ),
                "-map",
                "0:v:0",
                "-map",
                "[aout]",
                "-c:v",
                "copy",
                "-c:a",
                "aac",
                "-b:a",
                "256k",
                "-shortest",
                str(output_path),
            ]
            subprocess.run(final_cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True)
        elif voiceover_path or music_path:
            aud = Path(voiceover_path or music_path).resolve()
            final_cmd += [
                "-i",
                str(aud),
                "-map",
                "0:v:0",
                "-map",
                "1:a:0",
                "-c:v",
                "copy",
                "-c:a",
                "aac",
                "-b:a",
                "256k",
                "-shortest",
                str(output_path),
            ]
            subprocess.run(final_cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True)
        else:
            shutil.copy2(video_stage, output_path)

        return {
            "output_path": str(output_path),
            "duration_sec": round(timeline_cursor, 2),
            "encoder_used": encoder_used,
            "size_mb": round(output_path.stat().st_size / (1024 * 1024), 2),
        }
    finally:
        shutil.rmtree(work_dir, ignore_errors=True)
