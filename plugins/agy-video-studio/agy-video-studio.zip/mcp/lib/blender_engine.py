"""
Native Android ARM64 Bare-Metal Blender 5.0 Headless Engine (Cycles + OpenImageDenoise + GPU h264_mediacodec).
Supports:
  1. Full unrestricted `bpy` Python scene generation, `.blend` / `.glb` export, and agentic keyframe preview QA.
  2. Studio 3D Procedural Presets inspired by viral Claude Fable + Blender workflows:
     - 'voxel_coder_laptop': 3D beveled laptop + dynamic code/chat screen texture + articulated glowing-eye Voxel Mascot.
     - 'voxel_backrooms_loop': 3D yellow Backrooms maze with 'retry()' wallpaper, 'ATTEMPT N' 3D wall text, CONTEXT bar, ghost clones & 'break;' portal.
     - 'studio_pedestal_3d': 3-point area-lit cyclorama showcase with 3D extruded typography & .glb import or hero sculpture.
"""

from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import tempfile
import time
from pathlib import Path

from .code_screen_engine import render_code_screen
from .env_utils import PLUGIN_ROOT, resolve_font_path, select_video_encoder_args


def find_blender_bin() -> str | None:
    env_b = os.environ.get("AGY_BLENDER_BIN")
    if env_b and os.path.isfile(env_b) and os.access(env_b, os.X_OK):
        return env_b
    prefix = os.environ.get("PREFIX", "/data/user/0/com.agy/files/usr")
    for candidate in (
        os.path.join(prefix, "bin", "blender-headless"),
        shutil.which("blender-headless"),
        shutil.which("blender"),
    ):
        if candidate and os.path.isfile(candidate) and os.access(candidate, os.X_OK):
            return candidate
    return None


def _get_available_ram_mb() -> int | None:
    try:
        with open("/proc/meminfo", encoding="utf-8") as f:
            for line in f:
                if line.startswith("MemAvailable:"):
                    parts = line.split()
                    return int(parts[1]) // 1024
    except Exception:
        pass
    return None


def get_blender_status() -> dict:
    b_bin = find_blender_bin()
    prefix = os.environ.get("PREFIX", "/data/user/0/com.agy/files/usr")
    rootfs = Path(prefix) / "opt" / "blender-rootfs"
    version_str = None
    oidn_ready = (rootfs / "usr" / "lib").is_dir() and any((rootfs / "usr" / "lib").glob("libOpenImageDenoise*"))

    if b_bin:
        try:
            proc = subprocess.run([b_bin, "--version"], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=10)
            if proc.returncode == 0 and proc.stdout:
                version_str = proc.stdout.splitlines()[0].strip()
        except Exception as exc:
            version_str = f"error: {exc}"

    return {
        "blender_ready": bool(b_bin and version_str and not version_str.startswith("error:")),
        "blender_bin": b_bin,
        "blender_version": version_str,
        "rootfs_dir": str(rootfs),
        "cycles_oidn_denoiser": oidn_ready,
        "available_ram_mb": _get_available_ram_mb(),
        "builtin_3d_presets": ["voxel_coder_laptop", "voxel_backrooms_loop", "studio_pedestal_3d", "custom_bpy"],
        "setup_script": str(PLUGIN_ROOT / "mcp" / "bin" / "agy-blender-setup"),
    }


def run_blender_setup() -> dict:
    setup_sh = PLUGIN_ROOT / "mcp" / "bin" / "agy-blender-setup"
    if not setup_sh.is_file():
        raise RuntimeError(f"Setup script missing at {setup_sh}")
    proc = subprocess.run(
        ["/system/bin/sh", str(setup_sh)],
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        timeout=600,
    )
    status = get_blender_status()
    status["setup_exit_code"] = proc.returncode
    status["setup_log_tail"] = "\n".join(proc.stdout.splitlines()[-25:])
    if proc.returncode != 0 or not status["blender_ready"]:
        raise RuntimeError(f"Blender setup failed (code {proc.returncode}):\n{status['setup_log_tail']}")
    return status


def _generate_backrooms_wallpaper_png(dest_png: Path, wallpaper_label: str = "retry()  ↻") -> Path:
    """Create a crisp 1024x1024 damp yellow Backrooms wallpaper texture tiled with 'retry() ↻'."""
    from PIL import Image, ImageDraw, ImageFont  # type: ignore

    w, h = 1024, 1024
    img = Image.new("RGB", (w, h), (194, 169, 92))
    draw = ImageDraw.Draw(img)

    # Subtle vertical wallpaper stripes
    for x in range(0, w, 32):
        draw.rectangle([(x, 0), (x + 12, h)], fill=(185, 159, 82))

    fp = resolve_font_path("mono_semibold")
    font = ImageFont.truetype(str(fp), size=34) if (fp and fp.is_file()) else ImageFont.load_default()

    row_idx = 0
    for y in range(24, h, 88):
        x_off = 24 if (row_idx % 2 == 0) else -90
        for x in range(x_off, w, 260):
            draw.text((x, y), wallpaper_label, font=font, fill=(142, 118, 52))
        row_idx += 1

    dest_png.parent.mkdir(parents=True, exist_ok=True)
    img.save(dest_png, format="PNG")
    return dest_png


# ==============================================================================
# EMBEDDED BLENDER 5.0 BPY SCENE GENERATOR SCRIPT
# ==============================================================================

_BPY_DRIVER_TEMPLATE = r'''
import bpy
import bmesh
import json
import math
import os
import random
import sys
from mathutils import Vector, Euler

CFG = json.loads(os.environ["AGY_BLENDER_CFG_JSON"])

def clear_scene():
    bpy.ops.wm.read_factory_settings(use_empty=True)

def set_bsdf(bsdf, names, value):
    for n in names:
        if n in bsdf.inputs:
            bsdf.inputs[n].default_value = value
            return

def make_mat(name, base_rgba=(0.8, 0.8, 0.8, 1.0), roughness=0.35, metallic=0.0, emission_rgba=None, emission_strength=0.0):
    mat = bpy.data.materials.new(name=name)
    mat.use_nodes = True
    nt = mat.node_tree
    bsdf = nt.nodes.get("Principled BSDF")
    if not bsdf:
        bsdf = nt.nodes.new("ShaderNodeBsdfPrincipled")
    set_bsdf(bsdf, ["Base Color"], base_rgba)
    set_bsdf(bsdf, ["Roughness"], roughness)
    set_bsdf(bsdf, ["Metallic"], metallic)
    if emission_rgba is not None and emission_strength > 0.0:
        set_bsdf(bsdf, ["Emission Color", "Emission"], emission_rgba)
        set_bsdf(bsdf, ["Emission Strength"], emission_strength)
    return mat

def make_screen_mat(name, media_path, total_frames, strength=2.3):
    mat = bpy.data.materials.new(name=name)
    mat.use_nodes = True
    nt = mat.node_tree
    nt.nodes.clear()
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    em = nt.nodes.new("ShaderNodeEmission")
    em.inputs["Strength"].default_value = strength
    nt.links.new(em.outputs["Emission"], out.inputs["Surface"])

    if media_path and os.path.isfile(media_path):
        tex = nt.nodes.new("ShaderNodeTexImage")
        img = bpy.data.images.load(media_path, check_existing=True)
        ext = os.path.splitext(media_path)[1].lower()
        if ext in (".mp4", ".mov", ".mkv", ".webm"):
            img.source = "MOVIE"
            tex.image = img
            tex.image_user.use_auto_refresh = True
            tex.image_user.frame_duration = max(1, int(total_frames))
            tex.image_user.frame_start = 1
            tex.image_user.frame_offset = 0
            tex.image_user.use_cyclic = True
        else:
            tex.image = img
        tex.extension = "EXTEND"
        nt.links.new(tex.outputs["Color"], em.inputs["Color"])
    else:
        em.inputs["Color"].default_value = (0.04, 0.08, 0.16, 1.0)
    return mat

def make_tiled_image_mat(name, img_path, scale_xy=(6.0, 3.0), roughness=0.82):
    mat = bpy.data.materials.new(name=name)
    mat.use_nodes = True
    nt = mat.node_tree
    bsdf = nt.nodes.get("Principled BSDF")
    set_bsdf(bsdf, ["Roughness"], roughness)
    if img_path and os.path.isfile(img_path):
        coord = nt.nodes.new("ShaderNodeTexCoord")
        mapping = nt.nodes.new("ShaderNodeMapping")
        mapping.inputs["Scale"].default_value = (scale_xy[0], scale_xy[1], 1.0)
        tex = nt.nodes.new("ShaderNodeTexImage")
        tex.image = bpy.data.images.load(img_path, check_existing=True)
        nt.links.new(coord.outputs["UV"], mapping.inputs["Vector"])
        nt.links.new(mapping.outputs["Vector"], tex.inputs["Vector"])
        nt.links.new(tex.outputs["Color"], bsdf.inputs["Base Color"])
    return mat

def create_beveled_box_mesh(name, sx, sy, sz, bevel_amt=0.008, segments=2):
    mesh = bpy.data.meshes.new(name)
    bm = bmesh.new()
    bmesh.ops.create_cube(bm, size=1.0)
    for v in bm.verts:
        v.co.x *= sx
        v.co.y *= sy
        v.co.z *= sz
    if bevel_amt > 0:
        bmesh.ops.bevel(bm, geom=list(bm.edges), offset=bevel_amt, segments=segments, affect='EDGES')
    bmesh.ops.recalc_face_normals(bm, faces=list(bm.faces))
    bm.to_mesh(mesh)
    bm.free()
    for poly in mesh.polygons:
        poly.use_smooth = True
    return mesh

def add_mesh_obj(name, mesh, mat, loc=(0,0,0), rot=(0,0,0), parent=None):
    obj = bpy.data.objects.new(name, mesh)
    obj.location = loc
    obj.rotation_euler = rot
    if mat:
        if len(obj.data.materials) == 0:
            obj.data.materials.append(mat)
        else:
            obj.object_material = mat
    bpy.context.collection.objects.link(obj)
    if parent is not None:
        obj.parent = parent
    return obj

def build_voxel_mascot(prefix, location=(0,0,0), rotation_z=0.0, scale=1.0, body_rgba=(0.82, 0.36, 0.19, 1.0), eye_rgba=(1.0, 0.78, 0.52, 1.0), eye_strength=16.0):
    """Construct the iconic beveled multi-cube Voxel Mascot with glowing emissive eyes, arms & 4 legs."""
    root = bpy.data.objects.new(f"{prefix}_Root", None)
    root.location = location
    root.rotation_euler = (0.0, 0.0, rotation_z)
    root.scale = (scale, scale, scale)
    bpy.context.collection.objects.link(root)

    step = 0.072
    c_sz = 0.068
    mat_body = make_mat(f"{prefix}_BodyMat", base_rgba=body_rgba, roughness=0.34, metallic=0.04)
    mat_foot = make_mat(f"{prefix}_FootMat", base_rgba=(0.95, 0.95, 0.98, 1.0), roughness=0.25, emission_rgba=(1.0, 0.95, 0.9, 1.0), emission_strength=2.5)
    mat_eye = make_mat(f"{prefix}_EyeMat", base_rgba=eye_rgba, roughness=0.15, emission_rgba=eye_rgba, emission_strength=eye_strength)

    # Build torso multi-voxel single mesh for ultra-fast raytracing with individual beveled cube seams!
    torso_mesh = bpy.data.meshes.new(f"{prefix}_TorsoMesh")
    bm = bmesh.new()

    nx, ny, nz = 11, 6, 8  # width (X), depth (Y), height (Z)
    for ix in range(nx):
        for iy in range(ny):
            for iz in range(nz):
                # Hollow interior optimization: skip invisible inner core cubes!
                if 0 < ix < nx - 1 and 0 < iy < ny - 1 and 0 < iz < nz - 1:
                    continue
                # Leave front eye sockets open on front face (iy == 0)
                if iy == 0 and iz in (3, 4, 5) and (ix in (2, 3) or ix in (7, 8)):
                    continue
                res = bmesh.ops.create_cube(bm, size=c_sz)
                cx = (ix - (nx - 1) / 2.0) * step
                cy = (iy - (ny - 1) / 2.0) * step
                cz = (iz + 2.5) * step
                bmesh.ops.translate(bm, verts=res["verts"], vec=(cx, cy, cz))

    bmesh.ops.bevel(bm, geom=list(bm.edges), offset=0.0065, segments=2, affect='EDGES')
    bmesh.ops.recalc_face_normals(bm, faces=list(bm.faces))
    bm.to_mesh(torso_mesh)
    bm.free()
    for p in torso_mesh.polygons:
        p.use_smooth = True

    torso_obj = add_mesh_obj(f"{prefix}_Torso", torso_mesh, mat_body, (0, 0, 0), parent=root)

    # Glowing Voxel Eyes (separate objects so we can animate expressions: normal, squint, wide, blink!)
    eye_mesh = create_beveled_box_mesh(f"{prefix}_EyeBlock", step * 1.92, step * 0.85, step * 2.85, bevel_amt=0.008)
    front_y = -(ny - 1) / 2.0 * step - 0.004
    eye_z = (4.0 + 2.5) * step
    left_eye = add_mesh_obj(f"{prefix}_EyeL", eye_mesh, mat_eye, (-2.5 * step, front_y, eye_z), parent=root)
    right_eye = add_mesh_obj(f"{prefix}_EyeR", eye_mesh, mat_eye, (2.5 * step, front_y, eye_z), parent=root)

    # Articulated Voxel Arms (2x3x3 blocks on left/right)
    arm_mesh = create_beveled_box_mesh(f"{prefix}_ArmMesh", step * 1.85, step * 2.7, step * 2.7, bevel_amt=0.008)
    arm_x = ((nx - 1) / 2.0 + 1.35) * step
    arm_z = (3.8 + 2.5) * step
    left_arm = add_mesh_obj(f"{prefix}_ArmL", arm_mesh, mat_body, (-arm_x, 0.0, arm_z), parent=root)
    right_arm = add_mesh_obj(f"{prefix}_ArmR", arm_mesh, mat_body, (arm_x, 0.0, arm_z), parent=root)

    # 4 Articulated Legs with bright tip toes
    leg_mesh = create_beveled_box_mesh(f"{prefix}_LegMesh", step * 1.75, step * 1.75, step * 2.2, bevel_amt=0.007)
    toe_mesh = create_beveled_box_mesh(f"{prefix}_ToeMesh", step * 0.85, step * 0.85, step * 0.65, bevel_amt=0.004)
    legs = []
    for lx_s, ly_s, tag in ((-3.2, -1.5, "FL"), (3.2, -1.5, "FR"), (-3.2, 1.5, "BL"), (3.2, 1.5, "BR")):
        leg = add_mesh_obj(f"{prefix}_Leg_{tag}", leg_mesh, mat_body, (lx_s * step, ly_s * step, 1.3 * step), parent=root)
        if tag in ("FL", "FR"):
            add_mesh_obj(f"{prefix}_Toe_{tag}", toe_mesh, mat_foot, (0.3 * step, -0.4 * step, -0.95 * step), parent=leg)
        legs.append(leg)

    return {
        "root": root,
        "torso": torso_obj,
        "eye_l": left_eye,
        "eye_r": right_eye,
        "arm_l": left_arm,
        "arm_r": right_arm,
        "legs": legs,
        "mat_body": mat_body,
    }

def animate_mascot(m, total_frames, fps, action="typing_bounce", eye_expr="normal"):
    root = m["root"]
    eye_l, eye_r = m["eye_l"], m["eye_r"]
    arm_l, arm_r = m["arm_l"], m["arm_r"]
    legs = m["legs"]
    base_loc = Vector(root.location)
    base_rot = Euler(root.rotation_euler)

    # Set initial eye expression scale
    ez_scale = 1.0
    if eye_expr == "squint":
        ez_scale = 0.28
    elif eye_expr == "confident":
        ez_scale = 0.62
    elif eye_expr == "wide_shock":
        ez_scale = 1.28

    for f in range(1, total_frames + 1):
        t = (f - 1) / float(max(1, fps))
        prog = (f - 1) / float(max(1, total_frames - 1))

        if action == "typing_bounce":
            hop = abs(math.sin(t * 9.5)) * 0.045
            tilt = math.sin(t * 9.5) * 0.06
            root.location = (base_loc.x, base_loc.y, base_loc.z + hop)
            root.rotation_euler = (base_rot.x + 0.04, base_rot.y + tilt, base_rot.z)
            arm_l.rotation_euler = (math.sin(t * 18.0) * 0.45, 0, 0)
            arm_r.rotation_euler = (-math.sin(t * 18.0) * 0.45, 0, 0)
            for idx, lg in enumerate(legs):
                lg.location.z = 0.093 + (0.022 * math.sin(t * 18.0 + idx * 1.5))
        elif action == "retry_panic":
            shake_x = math.sin(t * 28.0) * 0.035
            hop = abs(math.sin(t * 14.0)) * 0.07
            root.location = (base_loc.x + shake_x, base_loc.y, base_loc.z + hop)
            arm_l.rotation_euler = (0, 0, 0.55 + math.sin(t * 26.0) * 0.55)
            arm_r.rotation_euler = (0, 0, -0.55 - math.sin(t * 26.0) * 0.55)
        elif action == "walk_forward":
            walk_dist = float(CFG.get("walk_distance", 1.35))
            # Move along mascot's facing direction (-Y local)
            ang = base_rot.z
            dx = -math.sin(ang) * walk_dist * prog
            dy = -math.cos(ang) * walk_dist * prog
            bob = abs(math.sin(t * 7.5)) * 0.042
            root.location = (base_loc.x + dx, base_loc.y + dy, base_loc.z + bob)
            root.rotation_euler = (base_rot.x, math.sin(t * 7.5) * 0.05, base_rot.z)
            for idx, lg in enumerate(legs):
                phase = 0.0 if idx in (0, 3) else math.pi
                lg.rotation_euler = (math.sin(t * 7.5 + phase) * 0.42, 0, 0)
        elif action == "look_screen_then_camera":
            # Turns from facing laptop screen (rot_z ~ pi) to facing camera (rot_z ~ 0)
            turn_p = max(0.0, min(1.0, (prog - 0.25) / 0.35))
            smooth = turn_p * turn_p * (3.0 - 2.0 * turn_p)
            root.rotation_euler = (base_rot.x, 0.0, base_rot.z * (1.0 - smooth))
            root.location = (base_loc.x, base_loc.y, base_loc.z + math.sin(smooth * math.pi) * 0.06)
        else:
            # Gentle idle breathing
            root.location = (base_loc.x, base_loc.y, base_loc.z + math.sin(t * 3.2) * 0.015)

        # Natural blink around 45% of clip
        blink = 0.10 if (0.44 <= prog <= 0.49) else ez_scale
        eye_l.scale = (1.0, 1.0, blink)
        eye_r.scale = (1.0, 1.0, blink)

        root.keyframe_insert(data_path="location", frame=f)
        root.keyframe_insert(data_path="rotation_euler", frame=f)
        arm_l.keyframe_insert(data_path="rotation_euler", frame=f)
        arm_r.keyframe_insert(data_path="rotation_euler", frame=f)
        eye_l.keyframe_insert(data_path="scale", frame=f)
        eye_r.keyframe_insert(data_path="scale", frame=f)
        for lg in legs:
            lg.keyframe_insert(data_path="location", frame=f)
            lg.keyframe_insert(data_path="rotation_euler", frame=f)

    # Optional white glitch dissolve at tail (like 00:20-00:22 of reference TikTok)
    if bool(CFG.get("glitch_dissolve_end", False)):
        bsdf = m["mat_body"].node_tree.nodes.get("Principled BSDF")
        if bsdf and "Emission Strength" in bsdf.inputs:
            g_frame = max(1, int(total_frames * 0.72))
            set_bsdf(bsdf, ["Emission Color", "Emission"], (1.0, 1.0, 1.0, 1.0))
            bsdf.inputs["Emission Strength"].default_value = 0.0
            bsdf.inputs["Emission Strength"].keyframe_insert(data_path="default_value", frame=g_frame)
            bsdf.inputs["Emission Strength"].default_value = 24.0
            bsdf.inputs["Emission Strength"].keyframe_insert(data_path="default_value", frame=total_frames)

def add_area_light(name, loc, rot_deg, energy, size=1.8, color=(1.0, 1.0, 1.0)):
    ldata = bpy.data.lights.new(name=name, type='AREA')
    ldata.energy = energy
    ldata.size = size
    ldata.color = color
    lobj = bpy.data.objects.new(name, ldata)
    lobj.location = loc
    lobj.rotation_euler = tuple(math.radians(a) for a in rot_deg)
    bpy.context.collection.objects.link(lobj)
    return lobj

def add_3d_text(name, text_str, loc, rot_deg=(90, 0, 0), size=0.22, extrude=0.018, mat=None, align_x='CENTER'):
    curve = bpy.data.curves.new(type="FONT", name=f"{name}_Curve")
    curve.body = text_str
    curve.size = size
    curve.extrude = extrude
    curve.bevel_depth = 0.003
    curve.align_x = align_x
    font_path = CFG.get("font_bold_path")
    if font_path and os.path.isfile(font_path):
        try:
            curve.font = bpy.data.fonts.load(font_path)
        except Exception:
            pass
    tobj = bpy.data.objects.new(name, curve)
    tobj.location = loc
    tobj.rotation_euler = tuple(math.radians(a) for a in rot_deg)
    if mat:
        tobj.data.materials.append(mat)
    bpy.context.collection.objects.link(tobj)
    return tobj

def build_scene_voxel_coder_laptop(total_frames, fps):
    # Dark starry world
    world = bpy.data.worlds.new("StudioWorld")
    bpy.context.scene.world = world
    world.use_nodes = True
    bg = world.node_tree.nodes.get("Background")
    if bg:
        bg.inputs[0].default_value = (0.005, 0.006, 0.010, 1.0)
        bg.inputs[1].default_value = 0.6

    # Warm dark wooden/carbon studio desk
    mat_desk = make_mat("DeskMat", base_rgba=(0.055, 0.036, 0.024, 1.0), roughness=0.28, metallic=0.05)
    desk_mesh = create_beveled_box_mesh("DeskMesh", 9.0, 7.0, 0.12, bevel_amt=0.01)
    add_mesh_obj("Desk", desk_mesh, mat_desk, (0, 0.4, -0.06))

    # Sleek space-black aluminum Laptop Base + Beveled Keycaps + Trackpad
    mat_alu = make_mat("LaptopAlu", base_rgba=(0.045, 0.048, 0.058, 1.0), roughness=0.26, metallic=0.82)
    mat_key = make_mat("KeycapMat", base_rgba=(0.022, 0.024, 0.030, 1.0), roughness=0.38, metallic=0.25)
    mat_pad = make_mat("TrackpadMat", base_rgba=(0.065, 0.070, 0.082, 1.0), roughness=0.18, metallic=0.70)

    base_w, base_d, base_h = 2.55, 1.72, 0.075
    base_mesh = create_beveled_box_mesh("LaptopBaseMesh", base_w, base_d, base_h, bevel_amt=0.014, segments=3)
    add_mesh_obj("LaptopBase", base_mesh, mat_alu, (0, 0, base_h / 2.0))

    pad_mesh = create_beveled_box_mesh("PadMesh", 0.78, 0.46, 0.012, bevel_amt=0.004)
    add_mesh_obj("Trackpad", pad_mesh, mat_pad, (0, -0.50, base_h + 0.002))

    # Build keyboard keycap grid as 1 fast beveled mesh
    kb_mesh = bpy.data.meshes.new("KeyboardKeysMesh")
    bm = bmesh.new()
    cols, rows = 14, 5
    kw, kd, kh = 0.142, 0.132, 0.024
    for r in range(rows):
        for c in range(cols):
            res = bmesh.ops.create_cube(bm, size=1.0)
            for v in res["verts"]:
                v.co.x *= kw
                v.co.y *= kd
                v.co.z *= kh
            kx = (c - (cols - 1) / 2.0) * 0.158
            ky = 0.02 + r * 0.150
            kz = base_h + kh / 2.0
            bmesh.ops.translate(bm, verts=res["verts"], vec=(kx, ky, kz))
    bmesh.ops.bevel(bm, geom=list(bm.edges), offset=0.004, segments=2, affect='EDGES')
    bmesh.ops.recalc_face_normals(bm, faces=list(bm.faces))
    bm.to_mesh(kb_mesh)
    bm.free()
    for p in kb_mesh.polygons:
        p.use_smooth = True
    add_mesh_obj("KeyboardKeys", kb_mesh, mat_key, (0, 0, 0))

    # Tilted Laptop Screen Lid + Emissive Screen Plane
    lid_pivot = bpy.data.objects.new("LidPivot", None)
    lid_pivot.location = (0, base_d / 2.0 - 0.04, base_h)
    lid_pivot.rotation_euler = (math.radians(-14.0), 0, 0)  # Tilted slightly backward (104 deg open)
    bpy.context.collection.objects.link(lid_pivot)

    scr_h = 1.62
    lid_mesh = create_beveled_box_mesh("LidMesh", base_w, 0.045, scr_h, bevel_amt=0.012, segments=2)
    add_mesh_obj("LaptopLid", lid_mesh, mat_alu, (0, 0, scr_h / 2.0), parent=lid_pivot)

    # Emissive Screen Plane with clean UVs
    scr_w_inner = base_w - 0.14
    scr_h_inner = scr_h - 0.14
    bpy.ops.mesh.primitive_plane_add(size=1.0, location=(0, -0.026, scr_h / 2.0), rotation=(math.radians(90), 0, 0))
    scr_plane = bpy.context.active_object
    scr_plane.name = "LaptopScreen"
    scr_plane.scale = (scr_w_inner, scr_h_inner, 1.0)
    scr_plane.parent = lid_pivot
    scr_mat = make_screen_mat("ScreenEmissiveMat", CFG.get("screen_media_path"), total_frames, strength=float(CFG.get("screen_emission", 2.1)))
    scr_plane.data.materials.append(scr_mat)

    # Coffee Mug prop on desk right
    bpy.ops.mesh.primitive_cylinder_add(vertices=32, radius=0.22, depth=0.46, location=(1.78, 0.32, 0.23))
    mug = bpy.context.active_object
    mug.data.materials.append(make_mat("MugMat", base_rgba=(0.03, 0.032, 0.04, 1.0), roughness=0.14, metallic=0.3))
    for p in mug.data.polygons:
        p.use_smooth = True

    # Background Bokeh Star Particles
    rng = random.Random(42)
    star_mat = make_mat("StarMat", emission_rgba=(0.88, 0.92, 1.0, 1.0), emission_strength=9.0)
    star_mesh = create_beveled_box_mesh("StarMesh", 0.035, 0.035, 0.035, bevel_amt=0.008)
    for idx in range(36):
        sx = rng.uniform(-4.5, 4.5)
        sy = rng.uniform(2.0, 5.5)
        sz = rng.uniform(0.2, 2.8)
        add_mesh_obj(f"Star_{idx}", star_mesh, star_mat, (sx, sy, sz))

    # Optional Floating 3D Title Text (e.g. "This is how Claude debugs.")
    floating_title = str(CFG.get("floating_title", "")).strip()
    if floating_title:
        t_mat = make_mat("TitleMat", emission_rgba=(0.98, 0.98, 1.0, 1.0), emission_strength=4.5)
        add_3d_text("FloatingTitle", floating_title, loc=(0.65, 0.55, 1.25), rot_deg=(84, 0, -14), size=0.145, extrude=0.006, mat=t_mat)

    # Voxel Mascot standing on the keyboard!
    v_col = CFG.get("voxel_rgba") or [0.83, 0.36, 0.19, 1.0]
    face_screen = bool(CFG.get("mascot_face_screen", False))
    rot_z = math.pi if face_screen else math.radians(float(CFG.get("mascot_rot_deg", -14.0)))
    mascot = build_voxel_mascot("ClaudeVoxel", location=(0.05, 0.15, base_h + 0.022), rotation_z=rot_z, scale=0.72, body_rgba=tuple(v_col))
    animate_mascot(
        mascot,
        total_frames=total_frames,
        fps=fps,
        action=str(CFG.get("action", "typing_bounce")),
        eye_expr=str(CFG.get("eye_expression", "normal")),
    )

    # Studio 3-Point Lighting (Warm amber key + cool screen fill + crisp rim light)
    add_area_light("KeyLight", loc=(-2.2, -2.4, 2.4), rot_deg=(54, 0, -38), energy=95.0, size=2.2, color=(1.0, 0.88, 0.76))
    add_area_light("RimLight", loc=(2.4, 1.8, 2.2), rot_deg=(58, 0, 142), energy=75.0, size=1.8, color=(0.72, 0.84, 1.0))
    add_area_light("MascotFill", loc=(0.2, -1.6, 0.9), rot_deg=(75, 0, 6), energy=22.0, size=1.2, color=(1.0, 0.78, 0.62))

    # Camera Choreography
    cam_data = bpy.data.cameras.new("MainCam")
    cam_obj = bpy.data.objects.new("MainCam", cam_data)
    bpy.context.collection.objects.link(cam_obj)
    bpy.context.scene.camera = cam_obj

    shot = str(CFG.get("camera_shot", "wide_push_in"))
    aspect = CFG["width"] / float(max(1, CFG["height"]))
    cam_data.lens = 36.0 if aspect >= 1.0 else 28.0
    cam_data.dof.use_dof = True
    cam_data.dof.aperture_fstop = 2.8

    target = bpy.data.objects.new("CamTarget", None)
    bpy.context.collection.objects.link(target)
    track = cam_obj.constraints.new(type='TRACK_TO')
    track.target = target
    track.track_axis = 'TRACK_NEGATIVE_Z'
    track.up_axis = 'UP_Y'

    for f in range(1, total_frames + 1):
        p = (f - 1) / float(max(1, total_frames - 1))
        sp = p * p * (3.0 - 2.0 * p)
        if shot == "close_hero":
            cam_obj.location = (0.32 - 0.18 * sp, -1.35 + 0.22 * sp, 0.56 + 0.04 * sp)
            target.location = (0.04, 0.20, 0.44)
            cam_data.dof.focus_distance = 1.45
        elif shot == "over_shoulder_screen":
            cam_obj.location = (0.18 - 0.12 * sp, -1.55 + 0.25 * sp, 0.68 + 0.10 * sp)
            target.location = (0.0, 0.82, 0.82)
            cam_data.dof.focus_distance = 2.15
        else:
            # wide_push_in (matches 00:00-00:04 iconic opening angle!)
            dist_mult = 1.0 if aspect >= 1.0 else 1.32
            cam_obj.location = ((-1.55 + 0.35 * sp) * dist_mult, (-2.85 + 0.55 * sp) * dist_mult, 1.18 - 0.16 * sp)
            target.location = (0.08, 0.32, 0.66)
            cam_data.dof.focus_distance = (cam_obj.location - target.location).length

        cam_obj.keyframe_insert(data_path="location", frame=f)
        target.keyframe_insert(data_path="location", frame=f)


def build_scene_voxel_backrooms(total_frames, fps):
    world = bpy.data.worlds.new("BackroomsWorld")
    bpy.context.scene.world = world
    world.use_nodes = True
    bg = world.node_tree.nodes.get("Background")
    if bg:
        bg.inputs[0].default_value = (0.18, 0.15, 0.07, 1.0)

    mat_wall = make_tiled_image_mat("WallpaperMat", CFG.get("wallpaper_png"), scale_xy=(5.0, 2.5), roughness=0.86)
    mat_floor = make_mat("CarpetMat", base_rgba=(0.48, 0.41, 0.24, 1.0), roughness=0.95)
    mat_ceil = make_mat("CeilMat", base_rgba=(0.76, 0.73, 0.58, 1.0), roughness=0.85)
    mat_lamp = make_mat("FluorescentMat", emission_rgba=(1.0, 0.98, 0.86, 1.0), emission_strength=14.0)
    mat_trim = make_mat("BaseboardMat", base_rgba=(0.24, 0.18, 0.09, 1.0), roughness=0.7)

    # Floor & Ceiling
    bpy.ops.mesh.primitive_plane_add(size=14.0, location=(0, 1.5, 0.0))
    fl = bpy.context.active_object
    fl.data.materials.append(mat_floor)

    bpy.ops.mesh.primitive_plane_add(size=14.0, location=(0, 1.5, 2.95), rotation=(math.pi, 0, 0))
    ce = bpy.context.active_object
    ce.data.materials.append(mat_ceil)

    # Ceiling Fluorescent Panels + Real Area Lights
    panel_mesh = create_beveled_box_mesh("LampPanel", 0.85, 0.45, 0.03, bevel_amt=0.004)
    for lx in (-1.8, 0.0, 1.8):
        for ly in (-0.4, 2.0):
            add_mesh_obj(f"Lamp_{lx}_{ly}", panel_mesh, mat_lamp, (lx, ly, 2.93))
            add_area_light(f"CeilArea_{lx}_{ly}", (lx, ly, 2.86), rot_deg=(0, 0, 0), energy=38.0, size=0.85, color=(1.0, 0.95, 0.78))

    # Backrooms Multi-Doorway Walls (UV-mapped boxes)
    def add_uv_wall(name, sx, sy, sz, loc):
        bpy.ops.mesh.primitive_cube_add(size=1.0, location=loc)
        w = bpy.context.active_object
        w.name = name
        w.scale = (sx, sy, sz)
        bpy.ops.object.transform_apply(scale=True)
        w.data.materials.append(mat_wall)
        return w

    # Center pillar wall ("ATTEMPT 44") flanked by left & right open doorways!
    break_door = bool(CFG.get("break_door", False))
    if not break_door:
        add_uv_wall("CenterWall", 2.35, 0.25, 2.95, (0.0, 2.8, 1.475))
    else:
        # Carve an open glowing white portal doorway in CenterWall!
        add_uv_wall("CenterWallL", 0.68, 0.25, 2.95, (-0.83, 2.8, 1.475))
        add_uv_wall("CenterWallR", 0.68, 0.25, 2.95, (0.83, 2.8, 1.475))
        add_uv_wall("CenterWallTop", 1.00, 0.25, 1.45, (0.0, 2.8, 2.225))
        portal_mat = make_mat("PortalGlow", emission_rgba=(1.0, 1.0, 1.0, 1.0), emission_strength=32.0)
        portal_mesh = create_beveled_box_mesh("PortalMesh", 0.96, 0.08, 1.48, bevel_amt=0.005)
        add_mesh_obj("BreakPortal", portal_mesh, portal_mat, (0.0, 2.86, 0.74))
        brk_mat = make_mat("BreakTextMat", emission_rgba=(1.0, 1.0, 1.0, 1.0), emission_strength=12.0)
        add_3d_text("BreakLabel", "break;", loc=(0.0, 2.65, 1.66), rot_deg=(90, 0, 0), size=0.22, extrude=0.015, mat=brk_mat)

    add_uv_wall("LeftFarWall", 1.6, 0.25, 2.95, (-2.95, 2.8, 1.475))
    add_uv_wall("RightFarWall", 1.6, 0.25, 2.95, (2.95, 2.8, 1.475))
    add_uv_wall("BackDeepWall", 9.0, 0.25, 2.95, (0.0, 5.2, 1.475))
    add_uv_wall("SideWallL", 0.25, 8.0, 2.95, (-3.7, 1.5, 1.475))
    add_uv_wall("SideWallR", 0.25, 8.0, 2.95, (3.7, 1.5, 1.475))

    # Extruded 3D Wall Text ("ATTEMPT 44") + Red CONTEXT Progress Bar + Green EXIT Sign
    wall_text = str(CFG.get("wall_text", "ATTEMPT 44"))
    mat_gold = make_mat("WallTextMat", base_rgba=(0.36, 0.27, 0.09, 1.0), roughness=0.45)
    text_z = 2.38 if break_door else 1.72
    add_3d_text("AttemptText", wall_text, loc=(0.0, 2.66, text_z), rot_deg=(90, 0, 0), size=0.23, extrude=0.025, mat=mat_gold)

    # CONTEXT red progress bar
    ctx_fill = max(0.08, min(1.0, float(CFG.get("context_fill", 0.46))))
    bar_bg = create_beveled_box_mesh("CtxBg", 1.10, 0.03, 0.11, bevel_amt=0.004)
    bar_fg = create_beveled_box_mesh("CtxFg", 1.06 * ctx_fill, 0.04, 0.085, bevel_amt=0.004)
    add_mesh_obj("ContextBarBg", bar_bg, mat_trim, (0.12, 2.67, text_z + 0.36))
    mat_red_glow = make_mat("CtxRed", emission_rgba=(1.0, 0.28, 0.22, 1.0), emission_strength=6.5)
    add_mesh_obj("ContextBarFg", bar_fg, mat_red_glow, (0.12 - 0.53 * (1.0 - ctx_fill), 2.66, text_z + 0.36))

    # Glowing green EXIT -> sign over right doorway
    exit_mat = make_mat("ExitGreen", emission_rgba=(0.22, 0.95, 0.48, 1.0), emission_strength=7.5)
    exit_box = create_beveled_box_mesh("ExitBox", 0.46, 0.05, 0.18, bevel_amt=0.006)
    add_mesh_obj("ExitSign", exit_box, exit_mat, (1.65, 2.66, 2.35))

    # Gray Ghost Clones from failed attempts!
    ghost_count = int(CFG.get("ghost_clones", 4))
    rng = random.Random(77)
    for g_idx in range(ghost_count):
        gx = rng.uniform(-2.4, 2.4)
        gy = rng.uniform(0.6, 2.3)
        if abs(gx) < 0.65 and gy < 1.5:
            gx += 1.15
        g_m = build_voxel_mascot(
            f"Ghost_{g_idx}",
            location=(gx, gy, 0.0),
            rotation_z=rng.uniform(-math.pi, math.pi),
            scale=0.62,
            body_rgba=(0.42, 0.41, 0.38, 1.0),
            eye_rgba=(0.92, 0.95, 1.0, 1.0),
            eye_strength=8.0,
        )
        animate_mascot(g_m, total_frames, fps, action="idle", eye_expr="normal")

    # Hero Terracotta Voxel Mascot
    hero_rot = math.pi if break_door else math.radians(float(CFG.get("mascot_rot_deg", 12.0)))
    hero_act = "walk_forward" if break_door else str(CFG.get("action", "idle"))
    hero = build_voxel_mascot("HeroVoxel", location=(0.0, 0.85, 0.0), rotation_z=hero_rot, scale=0.68)
    animate_mascot(hero, total_frames, fps, action=hero_act, eye_expr=str(CFG.get("eye_expression", "wide_shock" if not break_door else "squint")))

    # Low wide-angle Backrooms camera
    cam_data = bpy.data.cameras.new("BackroomsCam")
    cam_data.lens = 24.0 if (CFG["width"] >= CFG["height"]) else 20.0
    cam_obj = bpy.data.objects.new("BackroomsCam", cam_data)
    bpy.context.collection.objects.link(cam_obj)
    bpy.context.scene.camera = cam_obj

    target = bpy.data.objects.new("BrTarget", None)
    bpy.context.collection.objects.link(target)
    track = cam_obj.constraints.new(type='TRACK_TO')
    track.target = target
    track.track_axis = 'TRACK_NEGATIVE_Z'
    track.up_axis = 'UP_Y'

    for f in range(1, total_frames + 1):
        p = (f - 1) / float(max(1, total_frames - 1))
        sp = p * p * (3.0 - 2.0 * p)
        cam_obj.location = (0.15 * math.sin(p * 3.14), -1.65 + 0.55 * sp, 0.48 + 0.06 * sp)
        target.location = (0.0, 1.85, 0.85 if break_door else 1.05)
        cam_obj.keyframe_insert(data_path="location", frame=f)
        target.keyframe_insert(data_path="location", frame=f)


def build_scene_studio_pedestal(total_frames, fps):
    world = bpy.data.worlds.new("PedestalWorld")
    bpy.context.scene.world = world
    world.use_nodes = True
    bg = world.node_tree.nodes.get("Background")
    if bg:
        bg.inputs[0].default_value = (0.012, 0.014, 0.022, 1.0)

    mat_floor = make_mat("StudioFloor", base_rgba=(0.03, 0.035, 0.048, 1.0), roughness=0.18, metallic=0.35)
    bpy.ops.mesh.primitive_plane_add(size=16.0, location=(0, 0, 0))
    bpy.context.active_object.data.materials.append(mat_floor)

    bpy.ops.mesh.primitive_cylinder_add(vertices=64, radius=0.95, depth=0.18, location=(0, 0, 0.09))
    ped = bpy.context.active_object
    ped.data.materials.append(make_mat("PedestalMat", base_rgba=(0.06, 0.065, 0.085, 1.0), roughness=0.22, metallic=0.75))

    glb_path = CFG.get("glb_path")
    if glb_path and os.path.isfile(glb_path):
        bpy.ops.import_scene.gltf(filepath=glb_path)
    else:
        hero = build_voxel_mascot("PedestalHero", location=(0, 0, 0.18), rotation_z=0.0, scale=0.88)
        for f in range(1, total_frames + 1):
            p = (f - 1) / float(max(1, total_frames - 1))
            hero["root"].rotation_euler = (0, 0, p * math.pi * 2.0)
            hero["root"].keyframe_insert(data_path="rotation_euler", frame=f)

    title = str(CFG.get("floating_title", "")).strip()
    if title:
        tmat = make_mat("PedTitleMat", emission_rgba=(0.85, 0.92, 1.0, 1.0), emission_strength=4.0)
        add_3d_text("PedTitle", title, loc=(0, 1.35, 1.45), rot_deg=(90, 0, 0), size=0.24, extrude=0.015, mat=tmat)

    add_area_light("PedKey", (-2.4, -2.4, 2.8), (52, 0, -42), 120.0, 2.4, (1.0, 0.92, 0.84))
    add_area_light("PedRim", (2.4, 2.0, 2.4), (56, 0, 140), 95.0, 2.0, (0.65, 0.82, 1.0))

    cam_data = bpy.data.cameras.new("PedCam")
    cam_data.lens = 40.0 if CFG["width"] >= CFG["height"] else 30.0
    cam_obj = bpy.data.objects.new("PedCam", cam_data)
    cam_obj.location = (0, -3.4, 1.25)
    cam_obj.rotation_euler = (math.radians(74), 0, 0)
    bpy.context.collection.objects.link(cam_obj)
    bpy.context.scene.camera = cam_obj


# --- MAIN EXECUTION ---
clear_scene()
fps = int(CFG["fps"])
total_frames = int(CFG["total_frames"])
preset = CFG["preset"]

if preset == "custom_bpy":
    custom_code = CFG["custom_bpy_code"]
    exec(compile(custom_code, "<custom_bpy_script>", "exec"), globals(), globals())
elif preset == "voxel_backrooms_loop":
    build_scene_voxel_backrooms(total_frames, fps)
elif preset == "studio_pedestal_3d":
    build_scene_studio_pedestal(total_frames, fps)
else:
    build_scene_voxel_coder_laptop(total_frames, fps)

scene = bpy.context.scene
scene.render.engine = 'CYCLES'
scene.cycles.device = 'CPU'
scene.cycles.samples = int(CFG["samples"])
scene.cycles.use_adaptive_sampling = True
scene.cycles.adaptive_threshold = 0.05
scene.cycles.use_denoising = bool(CFG.get("use_denoising", True))
if scene.cycles.use_denoising:
    scene.cycles.denoiser = 'OPENIMAGEDENOISE'
    if hasattr(scene.cycles, "denoising_prefilter"):
        scene.cycles.denoising_prefilter = 'FAST'
scene.cycles.max_bounces = 3
scene.cycles.diffuse_bounces = 1
scene.cycles.glossy_bounces = 2
scene.cycles.transmission_bounces = 2
scene.cycles.volume_bounces = 0
scene.render.use_persistent_data = True

scene.render.resolution_x = int(CFG["width"])
scene.render.resolution_y = int(CFG["height"])
scene.render.resolution_percentage = 100
scene.render.fps = fps
scene.frame_start = 1
scene.frame_end = total_frames
scene.render.image_settings.file_format = 'PNG'
scene.render.image_settings.color_mode = 'RGB'

if CFG.get("save_blend_path"):
    os.makedirs(os.path.dirname(CFG["save_blend_path"]), exist_ok=True)
    bpy.ops.wm.save_as_mainfile(filepath=CFG["save_blend_path"])

if CFG.get("export_glb_path"):
    os.makedirs(os.path.dirname(CFG["export_glb_path"]), exist_ok=True)
    bpy.ops.export_scene.gltf(filepath=CFG["export_glb_path"], export_format='GLB')

render_mode = CFG["render_mode"]
frames_dir = CFG["frames_dir"]
os.makedirs(frames_dir, exist_ok=True)

rendered_files = []
if render_mode == "preview_stills":
    for f_num in CFG["preview_frames"]:
        f_clamped = max(1, min(total_frames, int(f_num)))
        scene.frame_set(f_clamped)
        out_p = os.path.join(frames_dir, f"preview_{f_clamped:04d}.png")
        scene.render.filepath = out_p
        bpy.ops.render.render(write_still=True)
        rendered_files.append(out_p)
elif render_mode == "animation":
    scene.render.filepath = os.path.join(frames_dir, "frame_")
    bpy.ops.render.render(animation=True)
    rendered_files = sorted(
        os.path.join(frames_dir, fn) for fn in os.listdir(frames_dir) if fn.startswith("frame_") and fn.endswith(".png")
    )

print("AGY_BLENDER_RESULT_JSON:" + json.dumps({"rendered_count": len(rendered_files), "first_files": rendered_files[:4]}))
'''


def render_blender_scene(ffmpeg_bin: str, args: dict) -> dict:
    """Build and render a 3D Blender 5.0 scene (preset or custom bpy script) into keyframe PNGs, .mp4 GPU video, and/or .glb."""
    b_bin = find_blender_bin()
    if not b_bin:
        setup_res = run_blender_setup()
        b_bin = setup_res.get("blender_bin")
        if not b_bin:
            raise RuntimeError("Blender 5.0 Headless is not installed. Call 'blender_setup' first.")

    preset = str(args.get("preset", "voxel_coder_laptop"))
    render_mode = str(args.get("render_mode", "preview_stills")).lower()  # 'preview_stills' | 'animation' | 'model_only'
    aspect_ratio = str(args.get("aspect_ratio", "9:16"))

    if "width" in args and "height" in args:
        width = int(args["width"])
        height = int(args["height"])
    elif aspect_ratio == "16:9":
        width, height = 854, 480
    elif aspect_ratio == "1:1":
        width, height = 640, 640
    else:
        # Mobile-optimized crisp 9:16 default (fast Cycles + upscaled/encoded cleanly via GPU)
        width, height = 540, 960

    width = max(240, width - (width % 2))
    height = max(240, height - (height % 2))

    fps = max(8, min(60, int(args.get("fps", 16))))
    duration_sec = max(0.5, min(60.0, float(args.get("duration_sec", 3.5))))
    total_frames = max(1, int(round(duration_sec * fps)))
    samples = max(4, min(128, int(args.get("samples", 12 if render_mode == "animation" else 18))))
    threads = max(1, min(8, int(args.get("threads", 6))))

    out_path = Path(args["output_path"]).resolve() if args.get("output_path") else None
    work_dir = (
        out_path.parent / f".blender_work_{out_path.stem}"
        if out_path
        else Path(tempfile.mkdtemp(prefix="agy_blender_", dir=os.environ.get("TMPDIR", "/data/user/0/com.agy/files/usr/tmp")))
    )
    work_dir.mkdir(parents=True, exist_ok=True)
    frames_dir = work_dir / "frames"
    if frames_dir.is_dir():
        shutil.rmtree(frames_dir, ignore_errors=True)
    frames_dir.mkdir(parents=True, exist_ok=True)

    # Auto-generate crisp laptop screen texture if preset == 'voxel_coder_laptop' and no screen_media_path was supplied
    screen_media_path = args.get("screen_media_path")
    if preset == "voxel_coder_laptop" and not screen_media_path:
        auto_scr_mp4 = work_dir / "auto_laptop_screen.mp4"
        scr_cfg = dict(args.get("screen_config") or {})
        scr_cfg.setdefault("output_path", str(auto_scr_mp4))
        scr_cfg.setdefault("duration_sec", duration_sec)
        scr_cfg.setdefault("fps", fps)
        scr_res = render_code_screen(ffmpeg_bin, scr_cfg)
        screen_media_path = scr_res["output_path"]

    wallpaper_png = None
    if preset == "voxel_backrooms_loop":
        wallpaper_png = str(_generate_backrooms_wallpaper_png(work_dir / "backrooms_wallpaper.png", str(args.get("wallpaper_label", "retry()  ↻"))))

    custom_bpy_code = ""
    if preset == "custom_bpy":
        if args.get("bpy_script_path"):
            custom_bpy_code = Path(args["bpy_script_path"]).read_text(encoding="utf-8")
        else:
            custom_bpy_code = str(args.get("bpy_script", ""))
        if not custom_bpy_code.strip():
            raise ValueError("For preset='custom_bpy', provide 'bpy_script' or 'bpy_script_path'.")

    preview_frames = args.get("preview_frames") or [1, max(1, total_frames // 2), total_frames]
    # Deduplicate while preserving order
    seen_f: set[int] = set()
    clean_previews: list[int] = []
    for pf in preview_frames:
        iv = max(1, min(total_frames, int(pf)))
        if iv not in seen_f:
            seen_f.add(iv)
            clean_previews.append(iv)

    font_bold = resolve_font_path("display_bold")
    cfg = {
        "preset": preset,
        "render_mode": render_mode,
        "width": width,
        "height": height,
        "fps": fps,
        "total_frames": total_frames,
        "samples": samples,
        "use_denoising": bool(args.get("use_denoising", True)),
        "frames_dir": str(frames_dir),
        "preview_frames": clean_previews,
        "screen_media_path": str(screen_media_path) if screen_media_path else None,
        "screen_emission": float(args.get("screen_emission", 2.1)),
        "floating_title": args.get("floating_title", ""),
        "voxel_rgba": args.get("voxel_rgba"),
        "mascot_face_screen": bool(args.get("mascot_face_screen", False)),
        "mascot_rot_deg": float(args.get("mascot_rot_deg", -14.0)),
        "action": str(args.get("action", "typing_bounce")),
        "eye_expression": str(args.get("eye_expression", "normal")),
        "camera_shot": str(args.get("camera_shot", "wide_push_in")),
        "glitch_dissolve_end": bool(args.get("glitch_dissolve_end", False)),
        "wallpaper_png": wallpaper_png,
        "wall_text": str(args.get("wall_text", "ATTEMPT 44")),
        "context_fill": float(args.get("context_fill", 0.46)),
        "ghost_clones": int(args.get("ghost_clones", 4)),
        "break_door": bool(args.get("break_door", False)),
        "walk_distance": float(args.get("walk_distance", 1.55)),
        "glb_path": args.get("glb_path"),
        "save_blend_path": str(Path(args["save_blend_path"]).resolve()) if args.get("save_blend_path") else None,
        "export_glb_path": str(Path(args["export_glb_path"]).resolve()) if args.get("export_glb_path") else None,
        "font_bold_path": str(font_bold) if font_bold else None,
        "custom_bpy_code": custom_bpy_code,
    }

    driver_py = work_dir / "agy_blender_driver.py"
    driver_py.write_text(_BPY_DRIVER_TEMPLATE, encoding="utf-8")

    env = os.environ.copy()
    env["AGY_BLENDER_CFG_JSON"] = json.dumps(cfg)

    t0 = time.time()
    proc = subprocess.run(
        [b_bin, "-b", "--factory-startup", "--threads", str(threads), "-P", str(driver_py)],
        env=env,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        timeout=int(args.get("timeout_sec", 900)),
    )
    elapsed_blender = round(time.time() - t0, 2)

    if proc.returncode != 0:
        tail = "\n".join(proc.stdout.splitlines()[-35:])
        raise RuntimeError(f"Blender 5.0 render failed (exit {proc.returncode}):\n{tail}")

    if render_mode == "preview_stills":
        stills = sorted(str(p) for p in frames_dir.glob("preview_*.png"))
        return {
            "status": "ok",
            "render_mode": "preview_stills",
            "preset": preset,
            "preview_stills": stills,
            "width": width,
            "height": height,
            "samples": samples,
            "blender_elapsed_sec": elapsed_blender,
            "save_blend_path": cfg["save_blend_path"],
            "export_glb_path": cfg["export_glb_path"],
            "qa_hint": "Inspect 'preview_stills' with read_file to verify framing, lighting, and text before rendering full animation.",
        }

    if render_mode == "model_only":
        return {
            "status": "ok",
            "render_mode": "model_only",
            "preset": preset,
            "save_blend_path": cfg["save_blend_path"],
            "export_glb_path": cfg["export_glb_path"],
            "blender_elapsed_sec": elapsed_blender,
        }

    # Animation mode: encode rendered PNG sequence -> MP4 via Android GPU h264_mediacodec (+ optional target FPS interpolation & audio mux!)
    if not out_path:
        raise ValueError("'output_path' (.mp4) is required when render_mode='animation'.")
    out_path.parent.mkdir(parents=True, exist_ok=True)

    png_files = sorted(frames_dir.glob("frame_*.png"))
    if not png_files:
        tail = "\n".join(proc.stdout.splitlines()[-30:])
        raise RuntimeError(f"No animation frames generated by Blender:\n{tail}")

    target_video_fps = int(args.get("output_fps", 30))
    use_hw = bool(args.get("use_hw_accel", True))
    enc_args, enc_name = select_video_encoder_args(ffmpeg_bin, use_hw_accel=use_hw, bitrate_mbps=10.0, crf=18)

    vf_parts = []
    if args.get("upscale_width") and args.get("upscale_height"):
        uw = int(args["upscale_width"]) - (int(args["upscale_width"]) % 2)
        uh = int(args["upscale_height"]) - (int(args["upscale_height"]) % 2)
        vf_parts.append(f"scale={uw}:{uh}:flags=lanczos")
    if target_video_fps > fps and bool(args.get("smooth_fps_blend", True)):
        vf_parts.append(f"framerate=fps={target_video_fps}:interp_start=0:interp_end=255:scene=8.2")

    audio_path = args.get("audio_path")
    ff_cmd = [
        ffmpeg_bin,
        "-y",
        "-framerate",
        str(fps),
        "-i",
        str(frames_dir / "frame_%04d.png"),
    ]
    if audio_path and os.path.isfile(str(audio_path)):
        ff_cmd.extend(["-i", str(audio_path)])
    if vf_parts:
        ff_cmd.extend(["-vf", ",".join(vf_parts)])
    ff_cmd.extend(enc_args)
    if audio_path and os.path.isfile(str(audio_path)):
        ff_cmd.extend(["-c:a", "aac", "-b:a", "192k", "-shortest"])
    ff_cmd.extend(["-movflags", "+faststart", str(out_path)])

    ff_proc = subprocess.run(ff_cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    if ff_proc.returncode != 0 and enc_name != "libx264":
        # Safe software fallback
        enc_args_sw, enc_name = select_video_encoder_args(ffmpeg_bin, use_hw_accel=False, crf=18)
        ff_cmd_sw = [
            ffmpeg_bin,
            "-y",
            "-framerate",
            str(fps),
            "-i",
            str(frames_dir / "frame_%04d.png"),
        ]
        if audio_path and os.path.isfile(str(audio_path)):
            ff_cmd_sw.extend(["-i", str(audio_path)])
        if vf_parts:
            ff_cmd_sw.extend(["-vf", ",".join(vf_parts)])
        ff_cmd_sw.extend(enc_args_sw)
        if audio_path and os.path.isfile(str(audio_path)):
            ff_cmd_sw.extend(["-c:a", "aac", "-b:a", "192k", "-shortest"])
        ff_cmd_sw.extend(["-movflags", "+faststart", str(out_path)])
        ff_proc = subprocess.run(ff_cmd_sw, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)

    if ff_proc.returncode != 0:
        raise RuntimeError(f"FFmpeg MP4 encode failed: {ff_proc.stderr[-600:]}")

    # Copy 2 representative keyframes next to output before cleaning temp frames
    kf_first = out_path.with_suffix(".kf1.png")
    kf_mid = out_path.with_suffix(".kf2.png")
    shutil.copy2(png_files[0], kf_first)
    shutil.copy2(png_files[len(png_files) // 2], kf_mid)

    if not bool(args.get("keep_raw_frames", False)):
        shutil.rmtree(work_dir, ignore_errors=True)

    return {
        "status": "ok",
        "render_mode": "animation",
        "preset": preset,
        "output_path": str(out_path),
        "keyframe_previews": [str(kf_first), str(kf_mid)],
        "rendered_frames": len(png_files),
        "blender_fps": fps,
        "output_fps": target_video_fps if vf_parts else fps,
        "width": width,
        "height": height,
        "samples": samples,
        "encoder": enc_name,
        "blender_elapsed_sec": elapsed_blender,
        "save_blend_path": cfg["save_blend_path"],
        "export_glb_path": cfg["export_glb_path"],
    }
