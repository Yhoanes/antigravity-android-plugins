"""
Neural TTS Voiceover (ES/EN/PT) + Character Voice DSP ('cute_voxel_bot', 'backrooms_echo', 'deep_ai') +
Multi-Line Timed Dialogue + Procedural Stereo SFX ('mech_typing', 'error_buzz', 'white_glitch', 'portal_flash', 'success_chime') +
Copyright-Free Ambient & Dark Slowed-Synth Score Synthesizer (v3.0.0).
"""

from __future__ import annotations

import array
import asyncio
import math
import random
import re
import shutil
import subprocess
import wave
from pathlib import Path

VOICE_PRESETS = {
    "es": "es-US-AlonsoNeural",
    "es-mx": "es-MX-JorgeNeural",
    "es-es": "es-ES-AlvaroNeural",
    "es-f": "es-MX-DaliaNeural",
    "en": "en-US-AndrewNeural",
    "en-f": "en-US-AvaNeural",
    "pt": "pt-BR-AntonioNeural",
}

# Warm Google Gemini / DeepMind Keynote chord progression: Fmaj9 -> Dm9 -> Bbmaj9 -> C13sus4
KEYNOTE_CHORDS_HZ = [
    (87.31, [174.61, 220.00, 261.63, 329.63, 392.00]),  # F2 + Fmaj9
    (73.42, [146.83, 220.00, 261.63, 329.63, 349.23]),  # D2 + Dm9
    (58.27, [116.54, 174.61, 220.00, 261.63, 293.66]),  # Bb1 + Bbmaj9
    (65.41, [130.81, 196.00, 220.00, 261.63, 349.23]),  # C2 + C11
]

# Nostalgic Dark Synth Slowed progression (D minor -> Bb major -> F major -> C major, slowed atmospheric vibe)
DARK_SYNTH_CHORDS_HZ = [
    (73.42, [146.83, 220.00, 261.63, 329.63]),
    (58.27, [116.54, 174.61, 233.08, 293.66]),
    (87.31, [174.61, 220.00, 261.63, 349.23]),
    (65.41, [130.81, 196.00, 246.94, 293.66]),
]


def _parse_vtt_to_captions(vtt_text: str) -> list[dict]:
    captions = []
    pattern = re.compile(
        r"(\d{2}):(\d{2}):(\d{2})[.,](\d{3})\s*-->\s*(\d{2}):(\d{2}):(\d{2})[.,](\d{3})\s*\n(.+?)(?=\n\n|\Z)",
        re.DOTALL,
    )
    for m in pattern.finditer(vtt_text.strip() + "\n\n"):
        s_sec = int(m.group(1)) * 3600 + int(m.group(2)) * 60 + int(m.group(3)) + int(m.group(4)) / 1000.0
        e_sec = int(m.group(5)) * 3600 + int(m.group(6)) * 60 + int(m.group(7)) + int(m.group(8)) / 1000.0
        txt = " ".join(m.group(9).strip().split())
        if txt:
            captions.append({"start_sec": round(s_sec, 3), "end_sec": round(max(s_sec + 0.25, e_sec), 3), "text": txt})
    return captions


def _group_words_into_phrases(words: list[dict], max_words: int = 7, max_chars: int = 44) -> list[dict]:
    if not words:
        return []
    phrases = []
    cur_words: list[str] = []
    cur_start = words[0]["start_sec"]
    cur_end = words[0]["end_sec"]

    for w in words:
        token = w["text"]
        gap = w["start_sec"] - cur_end if cur_words else 0.0
        projected_len = sum(len(x) for x in cur_words) + len(cur_words) + len(token)

        should_flush = bool(
            cur_words
            and (
                len(cur_words) >= max_words
                or projected_len > max_chars
                or gap > 0.42
                or cur_words[-1].endswith((".", "?", "!", ":", ";"))
            )
        )
        if should_flush:
            phrases.append(
                {
                    "start_sec": round(cur_start, 3),
                    "end_sec": round(max(cur_start + 0.35, cur_end + 0.06), 3),
                    "text": " ".join(cur_words),
                }
            )
            cur_words = [token]
            cur_start = w["start_sec"]
            cur_end = w["end_sec"]
        else:
            if not cur_words:
                cur_start = w["start_sec"]
            cur_words.append(token)
            cur_end = w["end_sec"]

    if cur_words:
        phrases.append(
            {
                "start_sec": round(cur_start, 3),
                "end_sec": round(max(cur_start + 0.4, cur_end + 0.1), 3),
                "text": " ".join(cur_words),
            }
        )
    return phrases


async def _synthesize_edge_tts_async(
    text: str,
    voice: str,
    rate: str,
    pitch: str,
    out_mp3: Path,
) -> list[dict]:
    import edge_tts  # type: ignore

    comm = edge_tts.Communicate(text, voice, rate=rate, pitch=pitch)
    word_events: list[dict] = []
    sentence_events: list[dict] = []

    with open(out_mp3, "wb") as audio_f:
        async for chunk in comm.stream():
            ctype = chunk.get("type")
            if ctype == "audio":
                audio_f.write(chunk["data"])
            elif ctype == "WordBoundary":
                st = float(chunk["offset"]) / 10_000_000.0
                dur = float(chunk["duration"]) / 10_000_000.0
                word_events.append(
                    {
                        "start_sec": st,
                        "end_sec": st + max(0.08, dur),
                        "text": str(chunk["text"]).strip(),
                    }
                )
            elif ctype == "SentenceBoundary":
                st = float(chunk["offset"]) / 10_000_000.0
                dur = float(chunk["duration"]) / 10_000_000.0
                sentence_events.append(
                    {
                        "start_sec": round(st, 3),
                        "end_sec": round(st + max(0.35, dur), 3),
                        "text": " ".join(str(chunk["text"]).strip().split()),
                    }
                )

    if word_events:
        return _group_words_into_phrases(word_events)
    return sentence_events


def _voice_for_effect(lang: str, explicit_voice: str | None, effect: str) -> str:
    if explicit_voice:
        return explicit_voice
    if effect in ("cute_voxel_bot", "backrooms_echo"):
        return "es-MX-DaliaNeural" if lang.lower().startswith("es") else "en-US-AvaNeural"
    return VOICE_PRESETS.get(lang.lower(), "es-US-AlonsoNeural")


def apply_voice_effect_ffmpeg(ffmpeg_bin: str, in_audio: Path, out_wav: Path, effect: str) -> Path:
    """Apply character DSP filter ('cute_voxel_bot', 'backrooms_echo', 'deep_ai', 'radio_glitch', or 'natural')."""
    eff = (effect or "natural").lower()
    if eff == "cute_voxel_bot":
        # Adorable crisp mini-voxel character voice (formant/pitch shifted + clean high-pass)
        af = "aformat=sample_rates=48000:channel_layouts=stereo,asetrate=48000*1.27,aresample=48000,atempo=0.85,highpass=f=185,volume=1.25"
    elif eff == "backrooms_echo":
        # Cute voxel bot + eerie empty hallway reflections
        af = "aformat=sample_rates=48000:channel_layouts=stereo,asetrate=48000*1.24,aresample=48000,atempo=0.86,aecho=0.85:0.78:65|135:0.34|0.22,volume=1.25"
    elif eff == "deep_ai":
        af = "aformat=sample_rates=48000:channel_layouts=stereo,asetrate=48000*0.83,aresample=48000,atempo=1.15,lowpass=f=6500,volume=1.2"
    elif eff == "radio_glitch":
        af = "aformat=sample_rates=48000:channel_layouts=stereo,highpass=f=350,lowpass=f=3600,acrusher=bits=8:mix=0.38,volume=1.2"
    else:
        af = "aformat=sample_rates=48000:channel_layouts=stereo,volume=1.05"

    subprocess.run(
        [ffmpeg_bin, "-y", "-i", str(in_audio), "-af", af, "-ar", "48000", "-ac", "2", "-c:a", "pcm_s16le", str(out_wav)],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        check=True,
    )
    return out_wav


def generate_neural_voiceover(
    text: str,
    out_mp3: Path,
    lang: str = "es",
    voice: str | None = None,
    rate: str = "+2%",
    pitch: str = "-1Hz",
) -> tuple[Path, list[dict], str]:
    chosen_voice = voice or VOICE_PRESETS.get(lang.lower(), "es-US-AlonsoNeural")
    out_mp3.parent.mkdir(parents=True, exist_ok=True)

    try:
        import edge_tts  # noqa: F401  # type: ignore

        captions = asyncio.run(_synthesize_edge_tts_async(text, chosen_voice, rate, pitch, out_mp3))
        return out_mp3, captions, chosen_voice
    except ImportError:
        pass

    cli = shutil.which("edge-tts")
    if cli:
        vtt_path = out_mp3.with_suffix(".vtt")
        subprocess.run(
            [
                cli,
                "--voice",
                chosen_voice,
                f"--rate={rate}",
                f"--pitch={pitch}",
                "--text",
                text,
                "--write-media",
                str(out_mp3),
                "--write-subtitles",
                str(vtt_path),
            ],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            check=True,
        )
        captions = _parse_vtt_to_captions(vtt_path.read_text(encoding="utf-8", errors="ignore")) if vtt_path.is_file() else []
        vtt_path.unlink(missing_ok=True)
        return out_mp3, captions, chosen_voice

    raise RuntimeError(
        "edge-tts is not installed. Run 'agy-video-setup' (or 'pip install edge-tts') to enable neural voiceover."
    )


def synthesize_sfx_timeline_wav(out_wav: Path, duration_sec: float, sfx_events: list[dict], sample_rate: int = 48000) -> Path:
    """Synthesize procedural stereo sound effects ('mech_typing', 'error_buzz', 'white_glitch', 'portal_flash', 'success_chime', 'footsteps')."""
    import numpy as np  # type: ignore

    n_samples = max(100, int(duration_sec * sample_rate))
    left = np.zeros(n_samples, dtype=np.float32)
    right = np.zeros(n_samples, dtype=np.float32)
    rng = random.Random(2026)
    np_rng = np.random.default_rng(2026)

    for ev in sfx_events:
        at_s = max(0.0, float(ev.get("at_sec", 0.0)))
        kind = str(ev.get("sfx", "mech_typing")).lower()
        ev_dur = float(ev.get("duration", 1.2 if kind == "mech_typing" else 0.45))
        vol = float(ev.get("volume", 0.55))

        s0 = int(at_s * sample_rate)
        if s0 >= n_samples:
            continue

        if kind == "mech_typing":
            t_cur = at_s
            while t_cur < min(duration_sec - 0.05, at_s + ev_dur):
                ks = int(t_cur * sample_rate)
                k_len = int(0.028 * sample_rate)
                ke = min(n_samples, ks + k_len)
                if ke > ks:
                    tk = np.arange(ke - ks, dtype=np.float32) / sample_rate
                    click = (
                        np_rng.normal(0.0, 0.55, ke - ks).astype(np.float32) * np.exp(-tk * 190.0)
                        + 0.45 * np.sin(2.0 * np.pi * rng.uniform(1650.0, 2450.0) * tk) * np.exp(-tk * 140.0)
                    ) * vol * 0.45
                    pan = rng.uniform(0.35, 0.65)
                    left[ks:ke] += click * (1.0 - pan * 0.4)
                    right[ks:ke] += click * (0.6 + pan * 0.4)
                t_cur += rng.uniform(0.065, 0.145)

        elif kind == "error_buzz":
            elen = min(n_samples - s0, int(max(0.22, ev_dur) * sample_rate))
            te = np.arange(elen, dtype=np.float32) / sample_rate
            env = np.exp(-te * 7.5)
            # Punchy dual-tone terminal fail buzz
            sig = (0.65 * np.tanh(3.2 * np.sin(2.0 * np.pi * 118.0 * te)) + 0.35 * np.sin(2.0 * np.pi * 88.5 * te)) * env * vol * 0.55
            left[s0 : s0 + elen] += sig
            right[s0 : s0 + elen] += sig

        elif kind == "white_glitch":
            glen = min(n_samples - s0, int(max(0.35, ev_dur) * sample_rate))
            tg = np.arange(glen, dtype=np.float32) / sample_rate
            norm_g = tg / max(0.05, glen / float(sample_rate))
            stutter = (np.sin(2.0 * np.pi * 22.0 * tg) > -0.25).astype(np.float32)
            sweep = np.sin(2.0 * np.pi * (240.0 + 1800.0 * (norm_g**2)) * tg)
            noise = np_rng.normal(0.0, 0.5, glen).astype(np.float32)
            sig = (0.55 * noise * stutter + 0.45 * sweep) * np.minimum(1.0, norm_g * 2.5) * vol * 0.55
            left[s0 : s0 + elen if "elen" in locals() and False else s0 + glen] += sig
            right[s0 : s0 + glen] += sig * 0.92

        elif kind == "portal_flash":
            plen = min(n_samples - s0, int(max(0.65, ev_dur) * sample_rate))
            tp = np.arange(plen, dtype=np.float32) / sample_rate
            sub = np.sin(2.0 * np.pi * (95.0 * np.exp(-tp * 2.8) + 38.0) * tp) * np.exp(-tp * 3.2)
            shimmer = (
                0.4 * np.sin(2.0 * np.pi * 523.25 * tp) + 0.35 * np.sin(2.0 * np.pi * 783.99 * tp)
            ) * np.exp(-tp * 2.4)
            sig = (0.65 * sub + 0.35 * shimmer) * vol * 0.60
            left[s0 : s0 + plen] += sig
            right[s0 : s0 + plen] += sig

        elif kind == "success_chime":
            clen = min(n_samples - s0, int(0.85 * sample_rate))
            tc = np.arange(clen, dtype=np.float32) / sample_rate
            n1 = np.sin(2.0 * np.pi * 587.33 * tc) * np.exp(-tc * 5.5)
            n2 = np.where(tc >= 0.11, np.sin(2.0 * np.pi * 880.0 * np.maximum(0.0, tc - 0.11)) * np.exp(-np.maximum(0.0, tc - 0.11) * 3.6), 0.0)
            sig = (0.5 * n1 + 0.6 * n2) * vol * 0.5
            left[s0 : s0 + clen] += sig
            right[s0 : s0 + clen] += sig

        elif kind == "footsteps":
            t_cur = at_s
            while t_cur < min(duration_sec - 0.05, at_s + ev_dur):
                fs = int(t_cur * sample_rate)
                fe = min(n_samples, fs + int(0.055 * sample_rate))
                if fe > fs:
                    tf = np.arange(fe - fs, dtype=np.float32) / sample_rate
                    thud = np.sin(2.0 * np.pi * 135.0 * np.exp(-tf * 30.0) * tf) * np.exp(-tf * 45.0) * vol * 0.45
                    left[fs:fe] += thud
                    right[fs:fe] += thud
                t_cur += 0.28

    stereo = np.empty(n_samples * 2, dtype=np.int16)
    stereo[0::2] = np.clip(left * 32767.0, -32767, 32767).astype(np.int16)
    stereo[1::2] = np.clip(right * 32767.0, -32767, 32767).astype(np.int16)
    out_wav.parent.mkdir(parents=True, exist_ok=True)
    with wave.open(str(out_wav), "wb") as wf:
        wf.setnchannels(2)
        wf.setsampwidth(2)
        wf.setframerate(sample_rate)
        wf.writeframes(stereo.tobytes())
    return out_wav


def synthesize_keynote_ambient_wav(
    out_wav: Path,
    duration_sec: float,
    style: str = "gemini_keynote",
    bpm: float = 90.0,
    sample_rate: int = 44100,
) -> Path:
    """Synthesize copyright-free ambient music ('gemini_keynote', 'dark_synth_slowed', 'lofi_vlog', 'cinematic_epic', 'deep_tech_pulse', 'minimal_pad')."""
    out_wav.parent.mkdir(parents=True, exist_ok=True)
    dur = max(2.0, min(300.0, float(duration_sec)))
    n_samples = int(dur * sample_rate)
    eff_bpm = 74.0 if (style == "dark_synth_slowed" and bpm == 90.0) else bpm
    bar_sec = (60.0 / max(45.0, min(160.0, eff_bpm))) * 4.0
    chords = DARK_SYNTH_CHORDS_HZ if style == "dark_synth_slowed" else KEYNOTE_CHORDS_HZ

    try:
        import numpy as np  # type: ignore

        left = np.zeros(n_samples, dtype=np.float32)
        right = np.zeros(n_samples, dtype=np.float32)

        t_bar_count = int(math.ceil(dur / bar_sec))
        for bar_idx in range(t_bar_count):
            b_start = int(bar_idx * bar_sec * sample_rate)
            b_end = min(n_samples, int((bar_idx + 1.45) * bar_sec * sample_rate))
            if b_end <= b_start:
                continue
            length = b_end - b_start
            t_local = np.arange(length, dtype=np.float32) / float(sample_rate)

            bass_hz, notes_hz = chords[bar_idx % len(chords)]

            norm_phase = np.clip(t_local / max(0.5, float(bar_sec * 1.35)), 0.0, 1.0)
            cello_env = np.maximum(0.0, np.sin(np.pi * norm_phase)) ** 1.25
            if style == "dark_synth_slowed":
                # Warm detuned analog Reese sub-bass + dreamy slowed chorus pad
                cello = (
                    0.55 * np.sin(2.0 * np.pi * bass_hz * t_local)
                    + 0.28 * np.sin(2.0 * np.pi * (bass_hz * 1.004) * t_local)
                    + 0.17 * np.tanh(1.8 * np.sin(2.0 * np.pi * (bass_hz * 2.0) * t_local))
                ) * cello_env * 0.26
            else:
                cello = (
                    0.78 * np.sin(2.0 * np.pi * bass_hz * t_local)
                    + 0.22 * np.sin(2.0 * np.pi * (bass_hz * 2.0) * t_local)
                ) * cello_env * 0.22
            left[b_start:b_end] += cello
            right[b_start:b_end] += cello * 0.96

            beat_sec = bar_sec / 4.0
            for n_idx, freq in enumerate(notes_hz):
                note_offset_s = (n_idx * 0.5) * beat_sec if style not in ("minimal_pad", "dark_synth_slowed") else (n_idx * 0.25) * beat_sec
                ns = int((bar_idx * bar_sec + note_offset_s) * sample_rate)
                ne = min(n_samples, ns + int(3.8 * sample_rate))
                if ne <= ns or ns >= n_samples:
                    continue
                tn = np.arange(ne - ns, dtype=np.float32) / float(sample_rate)
                attack = np.minimum(1.0, tn / (0.32 if style == "dark_synth_slowed" else (0.18 if style == "cinematic_epic" else 0.024)))
                decay_rate = 0.48 if style in ("minimal_pad", "cinematic_epic", "dark_synth_slowed") else (1.55 if style == "lofi_vlog" else 1.25)
                decay = np.exp(-tn * decay_rate)
                vibrato = (1.0 + 0.0032 * np.sin(2.0 * np.pi * 3.4 * tn)) if style in ("lofi_vlog", "dark_synth_slowed") else 1.0
                tone = (
                    0.76 * np.sin(2.0 * np.pi * (freq * vibrato) * tn)
                    + 0.18 * np.sin(2.0 * np.pi * (freq * 1.005) * tn)
                    + 0.06 * np.sin(2.0 * np.pi * (freq * 2.0) * tn) * np.exp(-tn * 2.2)
                ) * attack * decay * 0.115

                pan = 0.28 + 0.44 * (n_idx / max(1, len(notes_hz) - 1))
                left[ns:ne] += tone * (1.0 - pan * 0.45)
                right[ns:ne] += tone * (0.55 + pan * 0.45)

            if style in ("deep_tech_pulse", "lofi_vlog", "dark_synth_slowed"):
                for beat in range(4):
                    if style == "dark_synth_slowed" and beat not in (0, 2):
                        continue
                    swing = (0.04 * beat_sec) if (style == "lofi_vlog" and beat % 2 == 1) else 0.0
                    ps = int((bar_idx * bar_sec + beat * beat_sec + swing) * sample_rate)
                    pe = min(n_samples, ps + int(0.32 * sample_rate))
                    if pe <= ps or ps >= n_samples:
                        continue
                    tp = np.arange(pe - ps, dtype=np.float32) / float(sample_rate)
                    kick_freq = 48.0 + 44.0 * np.exp(-tp * 24.0)
                    gain_k = 0.11 if style in ("lofi_vlog", "dark_synth_slowed") else 0.14
                    pulse = np.sin(2.0 * np.pi * kick_freq * tp) * np.exp(-tp * 14.0) * gain_k
                    left[ps:pe] += pulse
                    right[ps:pe] += pulse

        fi = min(n_samples, int(0.6 * sample_rate))
        fo = min(n_samples, int(1.6 * sample_rate))
        if fi > 0:
            ramp_in = np.linspace(0.0, 1.0, fi, dtype=np.float32)
            left[:fi] *= ramp_in
            right[:fi] *= ramp_in
        if fo > 0:
            ramp_out = np.linspace(1.0, 0.0, fo, dtype=np.float32)
            left[-fo:] *= ramp_out
            right[-fo:] *= ramp_out

        peak = float(max(np.max(np.abs(left)), np.max(np.abs(right)), 1e-5))
        gain = min(1.0, 0.85 / peak)
        stereo = np.empty(n_samples * 2, dtype=np.int16)
        stereo[0::2] = np.clip(left * gain * 32767.0, -32767, 32767).astype(np.int16)
        stereo[1::2] = np.clip(right * gain * 32767.0, -32767, 32767).astype(np.int16)

        with wave.open(str(out_wav), "wb") as wf:
            wf.setnchannels(2)
            wf.setsampwidth(2)
            wf.setframerate(sample_rate)
            wf.writeframes(stereo.tobytes())
        return out_wav

    except ImportError:
        sr = 22050
        total = int(dur * sr)
        pcm = array.array("h", [0] * (total * 2))
        two_pi = 2.0 * math.pi
        for i in range(total):
            t = i / float(sr)
            bar_idx = int(t / bar_sec)
            bass_hz, notes_hz = chords[bar_idx % len(chords)]
            t_in_bar = t - bar_idx * bar_sec
            env = math.sin(math.pi * min(1.0, t_in_bar / bar_sec))
            val = 0.16 * env * math.sin(two_pi * bass_hz * t)
            for f in notes_hz[:3]:
                val += 0.06 * env * math.sin(two_pi * f * t)
            fade = min(1.0, t / 0.6, max(0.0, (dur - t) / 1.4))
            sample = max(-32000, min(32000, int(val * fade * 30000)))
            pcm[i * 2] = sample
            pcm[i * 2 + 1] = sample
        with wave.open(str(out_wav), "wb") as wf:
            wf.setnchannels(2)
            wf.setsampwidth(2)
            wf.setframerate(sr)
            wf.writeframes(pcm.tobytes())
        return out_wav


def _probe_audio_duration(ffmpeg_bin: str, path: Path) -> float:
    proc = subprocess.run([ffmpeg_bin, "-hide_banner", "-i", str(path)], stderr=subprocess.PIPE, text=True)
    m = re.search(r"Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)", proc.stderr)
    if not m:
        return 0.0
    return int(m.group(1)) * 3600 + int(m.group(2)) * 60 + float(m.group(3))


def audio_studio_generate(ffmpeg_bin: str, args: dict) -> dict:
    """
    Generate neural voiceover OR multi-line timed character dialogue ('cute_voxel_bot', 'backrooms_echo', etc.) +
    procedural stereo SFX ('mech_typing', 'error_buzz', 'white_glitch', 'portal_flash', 'success_chime') +
    copyright-free score ('dark_synth_slowed', 'gemini_keynote', etc.) + broadcast sidechain-ducked master WAV.
    """
    out_dir = Path(args["output_dir"]).resolve()
    out_dir.mkdir(parents=True, exist_ok=True)

    script_text = str(args.get("script_text", "")).strip()
    dialogue_lines = args.get("dialogue_lines") or []
    sfx_events = args.get("sfx_events") or []
    lang = str(args.get("lang", "es")).strip()
    voice = args.get("voice")
    voice_effect = str(args.get("voice_effect", "natural")).strip()
    rate = str(args.get("rate", "+2%"))
    pitch = str(args.get("pitch", "-1Hz"))
    music_style = str(args.get("music_style", "gemini_keynote"))
    bpm = float(args.get("bpm", 90.0))
    music_volume = float(args.get("music_volume", 0.26))
    extra_tail_sec = max(0.5, float(args.get("tail_sec", 1.5)))

    vo_path: Path | None = None
    captions: list[dict] = []
    used_voice: str | None = None
    vo_dur = 0.0

    # Mode A: Multi-line timed character dialogue (ideal for 3D character skits & Backrooms stories!)
    if isinstance(dialogue_lines, list) and len(dialogue_lines) > 0:
        line_wavs: list[tuple[float, Path]] = []
        max_end_sec = 0.0
        for idx, item in enumerate(dialogue_lines):
            txt = str(item.get("text", "")).strip()
            if not txt:
                continue
            at_s = max(0.0, float(item.get("at_sec", idx * 2.0)))
            l_lang = str(item.get("lang", lang))
            l_eff = str(item.get("effect", voice_effect))
            l_voice = _voice_for_effect(l_lang, item.get("voice") or voice, l_eff)
            used_voice = l_voice

            raw_mp3 = out_dir / f"_dlg_{idx:02d}_raw.mp3"
            proc_wav = out_dir / f"_dlg_{idx:02d}.wav"
            generate_neural_voiceover(txt, raw_mp3, lang=l_lang, voice=l_voice, rate=str(item.get("rate", rate)), pitch=str(item.get("pitch", pitch)))
            apply_voice_effect_ffmpeg(ffmpeg_bin, raw_mp3, proc_wav, l_eff)
            raw_mp3.unlink(missing_ok=True)

            ldur = max(0.35, _probe_audio_duration(ffmpeg_bin, proc_wav))
            end_s = at_s + ldur
            max_end_sec = max(max_end_sec, end_s)
            line_wavs.append((at_s, proc_wav))
            captions.append({"start_sec": round(at_s, 3), "end_sec": round(end_s + 0.12, 3), "text": txt})

        vo_dur = max_end_sec
        target_dur = float(args.get("duration_sec", 0.0)) or (vo_dur + extra_tail_sec)
        vo_combined = out_dir / "voiceover.wav"

        if line_wavs:
            in_flags: list[str] = []
            fc_parts: list[str] = []
            mix_labels: list[str] = []
            for idx, (at_s, lwav) in enumerate(line_wavs):
                in_flags.extend(["-i", str(lwav)])
                ms = int(round(at_s * 1000.0))
                fc_parts.append(f"[{idx}:a]adelay={ms}|{ms},apad=whole_dur={target_dur:.3f}[d{idx}]")
                mix_labels.append(f"[d{idx}]")
            fc_parts.append(f"{''.join(mix_labels)}amix=inputs={len(line_wavs)}:duration=first:normalize=0[vout]")
            subprocess.run(
                [ffmpeg_bin, "-y", *in_flags, "-filter_complex", ";".join(fc_parts), "-map", "[vout]", "-ar", "48000", "-ac", "2", str(vo_combined)],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                check=True,
            )
            for _, lwav in line_wavs:
                lwav.unlink(missing_ok=True)
            vo_path = vo_combined

    # Mode B: Standard continuous narration script
    elif script_text:
        chosen_v = _voice_for_effect(lang, voice, voice_effect)
        vo_mp3 = out_dir / "voiceover_raw.mp3"
        _, captions, used_voice = generate_neural_voiceover(
            text=script_text,
            out_mp3=vo_mp3,
            lang=lang,
            voice=chosen_v,
            rate=rate,
            pitch=pitch,
        )
        if voice_effect.lower() != "natural":
            vo_wav = out_dir / "voiceover.wav"
            old_dur = max(0.1, _probe_audio_duration(ffmpeg_bin, vo_mp3))
            apply_voice_effect_ffmpeg(ffmpeg_bin, vo_mp3, vo_wav, voice_effect)
            vo_mp3.unlink(missing_ok=True)
            vo_path = vo_wav
            vo_dur = _probe_audio_duration(ffmpeg_bin, vo_path)
            ratio = (vo_dur / old_dur) if old_dur > 0 else 1.0
            for c in captions:
                c["start_sec"] = round(c["start_sec"] * ratio, 3)
                c["end_sec"] = round(c["end_sec"] * ratio, 3)
        else:
            final_mp3 = out_dir / "voiceover.mp3"
            vo_mp3.replace(final_mp3)
            vo_path = final_mp3
            vo_dur = _probe_audio_duration(ffmpeg_bin, vo_path)
        if captions and vo_dur <= 0.0:
            vo_dur = captions[-1]["end_sec"]

    target_dur = float(args.get("duration_sec", 0.0))
    if target_dur <= 0.0:
        target_dur = (vo_dur + extra_tail_sec) if vo_dur > 0 else 15.0

    music_wav = out_dir / "ambient_keynote_music.wav"
    synthesize_keynote_ambient_wav(music_wav, duration_sec=target_dur, style=music_style, bpm=bpm)

    sfx_wav: Path | None = None
    if isinstance(sfx_events, list) and len(sfx_events) > 0:
        sfx_wav = out_dir / "sfx_track.wav"
        synthesize_sfx_timeline_wav(sfx_wav, duration_sec=target_dur, sfx_events=sfx_events)

    master_wav = out_dir / "master_audio.wav"
    if vo_path and vo_path.is_file():
        inputs = ["-i", str(vo_path), "-i", str(music_wav)]
        if sfx_wav and sfx_wav.is_file():
            inputs.extend(["-i", str(sfx_wav)])
            fc = (
                f"[0:a]aformat=sample_rates=48000:channel_layouts=stereo,apad=whole_dur={target_dur:.3f},volume=1.18[vo];"
                f"[1:a]aformat=sample_rates=48000:channel_layouts=stereo,atrim=0:{target_dur:.3f},volume={music_volume:.3f}[bgm];"
                f"[2:a]aformat=sample_rates=48000:channel_layouts=stereo,atrim=0:{target_dur:.3f},volume=0.95[sfx];"
                f"[bgm][vo]sidechaincompress=threshold=0.025:ratio=4.5:attack=15:release=260[duck];"
                f"[vo][duck][sfx]amix=inputs=3:duration=first:dropout_transition=0:normalize=0,alimiter=limit=0.95[out]"
            )
        else:
            fc = (
                f"[0:a]aformat=sample_rates=48000:channel_layouts=stereo,apad=whole_dur={target_dur:.3f},volume=1.15[vo];"
                f"[1:a]aformat=sample_rates=48000:channel_layouts=stereo,atrim=0:{target_dur:.3f},volume={music_volume:.3f}[bgm];"
                f"[bgm][vo]sidechaincompress=threshold=0.025:ratio=5:attack=15:release=280[duck];"
                f"[vo][duck]amix=inputs=2:duration=longest:dropout_transition=0:normalize=0,alimiter=limit=0.95[out]"
            )
        subprocess.run(
            [ffmpeg_bin, "-y", *inputs, "-filter_complex", fc, "-map", "[out]", "-ar", "48000", "-ac", "2", "-c:a", "pcm_s16le", str(master_wav)],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            check=True,
        )
    elif sfx_wav and sfx_wav.is_file():
        fc = (
            f"[0:a]aformat=sample_rates=48000:channel_layouts=stereo,atrim=0:{target_dur:.3f},volume={music_volume:.3f}[bgm];"
            f"[1:a]aformat=sample_rates=48000:channel_layouts=stereo,atrim=0:{target_dur:.3f},volume=0.95[sfx];"
            f"[bgm][sfx]amix=inputs=2:duration=first:normalize=0,alimiter=limit=0.95[out]"
        )
        subprocess.run(
            [ffmpeg_bin, "-y", "-i", str(music_wav), "-i", str(sfx_wav), "-filter_complex", fc, "-map", "[out]", "-ar", "48000", "-ac", "2", "-c:a", "pcm_s16le", str(master_wav)],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            check=True,
        )
    else:
        shutil.copy2(music_wav, master_wav)

    return {
        "output_dir": str(out_dir),
        "voice_used": used_voice,
        "voice_effect": voice_effect,
        "voiceover_path": str(vo_path) if vo_path else None,
        "sfx_path": str(sfx_wav) if sfx_wav else None,
        "music_path": str(music_wav),
        "master_audio_path": str(master_wav),
        "duration_sec": round(target_dur, 2),
        "voiceover_duration_sec": round(vo_dur, 2),
        "captions": captions,
    }
