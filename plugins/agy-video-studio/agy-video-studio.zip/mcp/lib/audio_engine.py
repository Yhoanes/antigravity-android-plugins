"""Neural TTS Voiceover (ES/EN) + Phrase Auto-Captioner + Minimalist Google Keynote Score Synthesizer."""

from __future__ import annotations

import array
import asyncio
import math
import re
import shutil
import subprocess
import wave
from pathlib import Path

VOICE_PRESETS = {
    "es": "es-US-AlonsoNeural",
    "es-mx": "es-MX-JorgeNeural",
    "es-es": "es-ES-AlvaroNeural",
    "es-f": "es-MX-DaliaNeural",
    "en": "en-US-AndrewNeural",
    "en-f": "en-US-AvaNeural",
    "pt": "pt-BR-AntonioNeural",
}

# Warm Google Gemini / DeepMind Keynote chord progression: Fmaj9 -> Dm9 -> Bbmaj9 -> C13sus4
KEYNOTE_CHORDS_HZ = [
    (87.31, [174.61, 220.00, 261.63, 329.63, 392.00]),  # F2 + Fmaj9
    (73.42, [146.83, 220.00, 261.63, 329.63, 349.23]),  # D2 + Dm9
    (58.27, [116.54, 174.61, 220.00, 261.63, 293.66]),  # Bb1 + Bbmaj9
    (65.41, [130.81, 196.00, 220.00, 261.63, 349.23]),  # C2 + C11
]


def _parse_vtt_to_captions(vtt_text: str) -> list[dict]:
    captions = []
    pattern = re.compile(
        r"(\d{2}):(\d{2}):(\d{2})[.,](\d{3})\s*-->\s*(\d{2}):(\d{2}):(\d{2})[.,](\d{3})\s*\n(.+?)(?=\n\n|\Z)",
        re.DOTALL,
    )
    for m in pattern.finditer(vtt_text.strip() + "\n\n"):
        s_sec = int(m.group(1)) * 3600 + int(m.group(2)) * 60 + int(m.group(3)) + int(m.group(4)) / 1000.0
        e_sec = int(m.group(5)) * 3600 + int(m.group(6)) * 60 + int(m.group(7)) + int(m.group(8)) / 1000.0
        txt = " ".join(m.group(9).strip().split())
        if txt:
            captions.append({"start_sec": round(s_sec, 3), "end_sec": round(max(s_sec + 0.25, e_sec), 3), "text": txt})
    return captions


def _group_words_into_phrases(words: list[dict], max_words: int = 7, max_chars: int = 44) -> list[dict]:
    if not words:
        return []
    phrases = []
    cur_words: list[str] = []
    cur_start = words[0]["start_sec"]
    cur_end = words[0]["end_sec"]

    for idx, w in enumerate(words):
        token = w["text"]
        gap = w["start_sec"] - cur_end if cur_words else 0.0
        projected_len = sum(len(x) for x in cur_words) + len(cur_words) + len(token)

        should_flush = bool(
            cur_words
            and (
                len(cur_words) >= max_words
                or projected_len > max_chars
                or gap > 0.42
                or cur_words[-1].endswith((".", "?", "!", ":", ";"))
            )
        )
        if should_flush:
            phrases.append(
                {
                    "start_sec": round(cur_start, 3),
                    "end_sec": round(max(cur_start + 0.35, cur_end + 0.06), 3),
                    "text": " ".join(cur_words),
                }
            )
            cur_words = [token]
            cur_start = w["start_sec"]
            cur_end = w["end_sec"]
        else:
            if not cur_words:
                cur_start = w["start_sec"]
            cur_words.append(token)
            cur_end = w["end_sec"]

    if cur_words:
        phrases.append(
            {
                "start_sec": round(cur_start, 3),
                "end_sec": round(max(cur_start + 0.4, cur_end + 0.1), 3),
                "text": " ".join(cur_words),
            }
        )
    return phrases


async def _synthesize_edge_tts_async(
    text: str,
    voice: str,
    rate: str,
    pitch: str,
    out_mp3: Path,
) -> list[dict]:
    import edge_tts  # type: ignore

    comm = edge_tts.Communicate(text, voice, rate=rate, pitch=pitch)
    word_events: list[dict] = []
    sentence_events: list[dict] = []

    with open(out_mp3, "wb") as audio_f:
        async for chunk in comm.stream():
            ctype = chunk.get("type")
            if ctype == "audio":
                audio_f.write(chunk["data"])
            elif ctype == "WordBoundary":
                st = float(chunk["offset"]) / 10_000_000.0
                dur = float(chunk["duration"]) / 10_000_000.0
                word_events.append(
                    {
                        "start_sec": st,
                        "end_sec": st + max(0.08, dur),
                        "text": str(chunk["text"]).strip(),
                    }
                )
            elif ctype == "SentenceBoundary":
                st = float(chunk["offset"]) / 10_000_000.0
                dur = float(chunk["duration"]) / 10_000_000.0
                sentence_events.append(
                    {
                        "start_sec": round(st, 3),
                        "end_sec": round(st + max(0.35, dur), 3),
                        "text": " ".join(str(chunk["text"]).strip().split()),
                    }
                )

    if word_events:
        return _group_words_into_phrases(word_events)
    return sentence_events


def generate_neural_voiceover(
    text: str,
    out_mp3: Path,
    lang: str = "es",
    voice: str | None = None,
    rate: str = "+2%",
    pitch: str = "-1Hz",
) -> tuple[Path, list[dict], str]:
    chosen_voice = voice or VOICE_PRESETS.get(lang.lower(), "es-US-AlonsoNeural")
    out_mp3.parent.mkdir(parents=True, exist_ok=True)

    # Path 1: Python edge_tts module
    try:
        import edge_tts  # noqa: F401  # type: ignore

        captions = asyncio.run(_synthesize_edge_tts_async(text, chosen_voice, rate, pitch, out_mp3))
        return out_mp3, captions, chosen_voice
    except ImportError:
        pass

    # Path 2: edge-tts CLI binary
    cli = shutil.which("edge-tts")
    if cli:
        vtt_path = out_mp3.with_suffix(".vtt")
        subprocess.run(
            [
                cli,
                "--voice",
                chosen_voice,
                f"--rate={rate}",
                f"--pitch={pitch}",
                "--text",
                text,
                "--write-media",
                str(out_mp3),
                "--write-subtitles",
                str(vtt_path),
            ],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            check=True,
        )
        captions = _parse_vtt_to_captions(vtt_path.read_text(encoding="utf-8", errors="ignore")) if vtt_path.is_file() else []
        vtt_path.unlink(missing_ok=True)
        return out_mp3, captions, chosen_voice

    raise RuntimeError(
        "edge-tts is not installed. Run 'agy-video-setup' (or 'pip install edge-tts') to enable neural voiceover."
    )


def synthesize_keynote_ambient_wav(
    out_wav: Path,
    duration_sec: float,
    style: str = "gemini_keynote",
    bpm: float = 90.0,
    sample_rate: int = 44100,
) -> Path:
    """Synthesize a clean, copyright-free minimalist Google Gemini / DeepMind felt-piano & sub-cello score."""
    out_wav.parent.mkdir(parents=True, exist_ok=True)
    dur = max(2.0, min(300.0, float(duration_sec)))
    n_samples = int(dur * sample_rate)
    bar_sec = (60.0 / max(50.0, min(160.0, bpm))) * 4.0

    try:
        import numpy as np  # type: ignore

        left = np.zeros(n_samples, dtype=np.float32)
        right = np.zeros(n_samples, dtype=np.float32)

        t_bar_Count = int(math.ceil(dur / bar_sec))
        for bar_idx in range(t_bar_Count):
            b_start = int(bar_idx * bar_sec * sample_rate)
            b_end = min(n_samples, int((bar_idx + 1.35) * bar_sec * sample_rate))
            if b_end <= b_start:
                continue
            length = b_end - b_start
            t_local = np.arange(length, dtype=np.float32) / float(sample_rate)

            bass_hz, notes_hz = KEYNOTE_CHORDS_HZ[bar_idx % len(KEYNOTE_CHORDS_HZ)]

            # Warm sub-cello swell (NaN-safe clamped envelope)
            norm_phase = np.clip(t_local / max(0.5, float(bar_sec * 1.25)), 0.0, 1.0)
            cello_env = np.maximum(0.0, np.sin(np.pi * norm_phase)) ** 1.3
            cello = (
                0.78 * np.sin(2.0 * np.pi * bass_hz * t_local)
                + 0.22 * np.sin(2.0 * np.pi * (bass_hz * 2.0) * t_local)
            ) * cello_env * 0.22
            left[b_start:b_end] += cello
            right[b_start:b_end] += cello

            # Soft arpeggiated felt-piano notes across beats
            beat_sec = bar_sec / 4.0
            for n_idx, freq in enumerate(notes_hz):
                note_offset_s = (n_idx * 0.5) * beat_sec if style != "minimal_pad" else 0.0
                ns = int((bar_idx * bar_sec + note_offset_s) * sample_rate)
                ne = min(n_samples, ns + int(3.2 * sample_rate))
                if ne <= ns or ns >= n_samples:
                    continue
                tn = np.arange(ne - ns, dtype=np.float32) / float(sample_rate)
                # Soft electric Rhodes / Lo-Fi or Cinematic Strings / Felt-Piano tone
                attack = np.minimum(1.0, tn / (0.18 if style == "cinematic_epic" else 0.024))
                decay_rate = 0.55 if style in ("minimal_pad", "cinematic_epic") else (1.55 if style == "lofi_vlog" else 1.25)
                decay = np.exp(-tn * decay_rate)
                vibrato = (1.0 + 0.0022 * np.sin(2.0 * np.pi * 4.8 * tn)) if style == "lofi_vlog" else 1.0
                tone = (
                    0.82 * np.sin(2.0 * np.pi * (freq * vibrato) * tn)
                    + 0.14 * np.sin(2.0 * np.pi * (freq * 2.0) * tn) * np.exp(-tn * 2.8)
                    + 0.04 * np.sin(2.0 * np.pi * (freq * 3.0) * tn) * np.exp(-tn * 4.5)
                ) * attack * decay * 0.11

                pan = 0.32 + 0.36 * (n_idx / max(1, len(notes_hz) - 1))
                left[ns:ne] += tone * (1.0 - pan * 0.45)
                right[ns:ne] += tone * (0.55 + pan * 0.45)

            # Subtle groove heartbeat for deep_tech_pulse or lofi_vlog
            if style in ("deep_tech_pulse", "lofi_vlog"):
                for beat in range(4):
                    swing = (0.04 * beat_sec) if (style == "lofi_vlog" and beat % 2 == 1) else 0.0
                    ps = int((bar_idx * bar_sec + beat * beat_sec + swing) * sample_rate)
                    pe = min(n_samples, ps + int(0.28 * sample_rate))
                    if pe <= ps or ps >= n_samples:
                        continue
                    tp = np.arange(pe - ps, dtype=np.float32) / float(sample_rate)
                    kick_freq = 52.0 + 48.0 * np.exp(-tp * 26.0)
                    gain_k = 0.10 if style == "lofi_vlog" else 0.14
                    pulse = np.sin(2.0 * np.pi * kick_freq * tp) * np.exp(-tp * 15.0) * gain_k
                    left[ps:pe] += pulse
                    right[ps:pe] += pulse

        # Smooth fade-in (0.6s) and fade-out (1.6s)
        fi = min(n_samples, int(0.6 * sample_rate))
        fo = min(n_samples, int(1.6 * sample_rate))
        if fi > 0:
            ramp_in = np.linspace(0.0, 1.0, fi, dtype=np.float32)
            left[:fi] *= ramp_in
            right[:fi] *= ramp_in
        if fo > 0:
            ramp_out = np.linspace(1.0, 0.0, fo, dtype=np.float32)
            left[-fo:] *= ramp_out
            right[-fo:] *= ramp_out

        peak = float(max(np.max(np.abs(left)), np.max(np.abs(right)), 1e-5))
        gain = min(1.0, 0.85 / peak)
        stereo = np.empty(n_samples * 2, dtype=np.int16)
        stereo[0::2] = np.clip(left * gain * 32767.0, -32767, 32767).astype(np.int16)
        stereo[1::2] = np.clip(right * gain * 32767.0, -32767, 32767).astype(np.int16)

        with wave.open(str(out_wav), "wb") as wf:
            wf.setnchannels(2)
            wf.setsampwidth(2)
            wf.setframerate(sample_rate)
            wf.writeframes(stereo.tobytes())
        return out_wav

    except ImportError:
        # Pure stdlib fallback (zero dependencies!) using 22050 Hz mono-to-stereo array
        sr = 22050
        total = int(dur * sr)
        pcm = array.array("h", [0] * (total * 2))
        two_pi = 2.0 * math.pi
        for i in range(total):
            t = i / float(sr)
            bar_idx = int(t / bar_sec)
            bass_hz, notes_hz = KEYNOTE_CHORDS_HZ[bar_idx % len(KEYNOTE_CHORDS_HZ)]
            t_in_bar = t - bar_idx * bar_sec
            env = math.sin(math.pi * min(1.0, t_in_bar / bar_sec))
            val = 0.16 * env * math.sin(two_pi * bass_hz * t)
            for f in notes_hz[:3]:
                val += 0.06 * env * math.sin(two_pi * f * t)
            fade = min(1.0, t / 0.6, max(0.0, (dur - t) / 1.4))
            sample = max(-32000, min(32000, int(val * fade * 30000)))
            pcm[i * 2] = sample
            pcm[i * 2 + 1] = sample
        with wave.open(str(out_wav), "wb") as wf:
            wf.setnchannels(2)
            wf.setsampwidth(2)
            wf.setframerate(sr)
            wf.writeframes(pcm.tobytes())
        return out_wav


def _probe_audio_duration(ffmpeg_bin: str, path: Path) -> float:
    proc = subprocess.run([ffmpeg_bin, "-hide_banner", "-i", str(path)], stderr=subprocess.PIPE, text=True)
    m = re.search(r"Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)", proc.stderr)
    if not m:
        return 0.0
    return int(m.group(1)) * 3600 + int(m.group(2)) * 60 + float(m.group(3))


def audio_studio_generate(ffmpeg_bin: str, args: dict) -> dict:
    """Generate neural voiceover + aligned captions + Google Keynote ambient music + broadcast sidechain-ducked master WAV."""
    out_dir = Path(args["output_dir"]).resolve()
    out_dir.mkdir(parents=True, exist_ok=True)

    script_text = str(args.get("script_text", "")).strip()
    lang = str(args.get("lang", "es")).strip()
    voice = args.get("voice")
    rate = str(args.get("rate", "+2%"))
    pitch = str(args.get("pitch", "-1Hz"))
    music_style = str(args.get("music_style", "gemini_keynote"))
    bpm = float(args.get("bpm", 90.0))
    music_volume = float(args.get("music_volume", 0.24))
    extra_tail_sec = max(0.5, float(args.get("tail_sec", 2.0)))

    vo_path: Path | None = None
    captions: list[dict] = []
    used_voice: str | None = None
    vo_dur = 0.0

    if script_text:
        vo_mp3 = out_dir / "voiceover.mp3"
        vo_path, captions, used_voice = generate_neural_voiceover(
            text=script_text,
            out_mp3=vo_mp3,
            lang=lang,
            voice=voice,
            rate=rate,
            pitch=pitch,
        )
        vo_dur = _probe_audio_duration(ffmpeg_bin, vo_path)
        if captions and vo_dur <= 0.0:
            vo_dur = captions[-1]["end_sec"]

    target_dur = float(args.get("duration_sec", 0.0))
    if target_dur <= 0.0:
        target_dur = (vo_dur + extra_tail_sec) if vo_dur > 0 else 15.0

    music_wav = out_dir / "ambient_keynote_music.wav"
    synthesize_keynote_ambient_wav(music_wav, duration_sec=target_dur, style=music_style, bpm=bpm)

    master_wav = out_dir / "master_audio.wav"
    if vo_path and vo_path.is_file():
        mix_cmd = [
            ffmpeg_bin,
            "-y",
            "-i",
            str(vo_path),
            "-i",
            str(music_wav),
            "-filter_complex",
            (
                f"[0:a]aformat=sample_rates=48000:channel_layouts=stereo,apad=whole_dur={target_dur:.3f},volume=1.15[vo];"
                f"[1:a]aformat=sample_rates=48000:channel_layouts=stereo,atrim=0:{target_dur:.3f},volume={music_volume:.3f}[bgm];"
                f"[bgm][vo]sidechaincompress=threshold=0.025:ratio=5:attack=15:release=280[duck];"
                f"[vo][duck]amix=inputs=2:duration=longest:dropout_transition=0:normalize=0,alimiter=limit=0.95[out]"
            ),
            "-map",
            "[out]",
            "-ar",
            "48000",
            "-ac",
            "2",
            "-c:a",
            "pcm_s16le",
            str(master_wav),
        ]
        subprocess.run(mix_cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True)
    else:
        shutil.copy2(music_wav, master_wav)

    return {
        "output_dir": str(out_dir),
        "voice_used": used_voice,
        "voiceover_path": str(vo_path) if vo_path else None,
        "music_path": str(music_wav),
        "master_audio_path": str(master_wav),
        "duration_sec": round(target_dur, 2),
        "voiceover_duration_sec": round(vo_dur, 2),
        "captions": captions,
    }
