"""Shizuku (rish) Android UI Automation, Hardware Screenrecord, MediaStore & App Intent Bridge."""

from __future__ import annotations

import os
import re
import shlex
import shutil
import time
import xml.etree.ElementTree as ET
from pathlib import Path

from .env_utils import rish_status, run_rish

KEYEVENT_MAP = {
    "HOME": 3,
    "BACK": 4,
    "DPAD_UP": 19,
    "DPAD_DOWN": 20,
    "DPAD_LEFT": 21,
    "DPAD_RIGHT": 22,
    "DPAD_CENTER": 23,
    "VOLUME_UP": 24,
    "VOLUME_DOWN": 25,
    "POWER": 26,
    "SPACE": 62,
    "ENTER": 66,
    "DEL": 67,
    "BACKSPACE": 67,
    "MEDIA_PLAY_PAUSE": 85,
    "ESCAPE": 111,
    "APP_SWITCH": 187,
    "RECENTS": 187,
}

APP_ALIASES = {
    "capcut": "com.lemon.lvoverseas",
    "capcut_cn": "com.lemon.lv",
    "vn": "com.frontrow.vlog",
    "alight": "com.alightcreative.motion",
    "tiktok": "com.zhiliaoapp.musically",
    "tiktok_latam": "com.ss.android.ugc.trill",
    "instagram": "com.instagram.android",
    "youtube": "com.google.android.youtube",
}

RECORD_STATE_FILE = "/sdcard/Download/.agy_screenrecord_state.json"


def _require_shizuku() -> None:
    ok, info = rish_status()
    if not ok:
        raise RuntimeError(
            f"Shizuku (rish) is required for Android system bridge, but is currently inactive: {info}. "
            "Open the Shizuku app on Android, start the service (Wireless Debugging), and retry."
        )


def _parse_bounds(bounds_str: str) -> tuple[list[int], list[int]] | None:
    m = re.match(r"\[(\d+),(\d+)\]\[(\d+),(\d+)\]", bounds_str or "")
    if not m:
        return None
    x1, y1, x2, y2 = int(m.group(1)), int(m.group(2)), int(m.group(3)), int(m.group(4))
    if x2 <= x1 or y2 <= y1:
        return None
    return [x1, y1, x2, y2], [(x1 + x2) // 2, (y1 + y2) // 2]


def android_screen_record(args: dict) -> dict:
    """Manage Android hardware screenrecord via Shizuku: 'timed', 'start' (background), 'stop' (clean SIGINT), or 'status'."""
    _require_shizuku()
    mode = str(args.get("mode", "timed")).lower()
    out_path = str(args.get("output_path", f"/sdcard/Movies/AGY_Studio/rec_{int(time.time())}.mp4"))
    duration = max(1, min(180, int(args.get("duration_sec", 30))))
    bitrate = max(4, min(40, int(args.get("bitrate_mbps", 18)))) * 1_000_000
    size_arg = str(args.get("size", "")).strip()  # Optional e.g. "1080x2400"

    parent_dir = str(Path(out_path).parent).replace("\\", "/")
    size_flag = f"--size {shlex.quote(size_arg)} " if re.match(r"^\d{3,4}x\d{3,4}$", size_arg) else ""

    if mode == "status":
        proc = run_rish("pidof screenrecord || true")
        pids = proc.stdout.strip().split()
        return {"recording": bool(pids), "pids": pids}

    if mode == "stop":
        # Send SIGINT (-2) so screenrecord finalizes the MP4 moov atom cleanly!
        proc = run_rish("pidof screenrecord || true")
        pids = proc.stdout.strip().split()
        if not pids:
            return {"stopped": False, "message": "No active screenrecord process found."}
        run_rish("kill -2 $(pidof screenrecord) 2>/dev/null || true")
        for _ in range(15):
            time.sleep(0.25)
            chk = run_rish("pidof screenrecord || true")
            if not chk.stdout.strip():
                break
        return {"stopped": True, "pids_signaled": pids, "note": "MP4 moov header finalized cleanly via SIGINT."}

    if mode == "start":
        run_rish(f"mkdir -p {shlex.quote(parent_dir)}")
        cmd = (
            f"nohup screenrecord {size_flag}--bit-rate {bitrate} --time-limit {duration} "
            f"{shlex.quote(out_path)} >/dev/null 2>&1 & echo $!"
        )
        proc = run_rish(cmd, timeout=6.0)
        pid = proc.stdout.strip().splitlines()[-1] if proc.stdout.strip() else None
        time.sleep(0.4)
        return {
            "mode": "background_recording_started",
            "pid": pid,
            "output_path": out_path,
            "max_duration_sec": duration,
            "stop_instruction": "Call android_screen_record with mode='stop' when finished to flush MP4 cleanly.",
        }

    # Default: blocking timed capture
    run_rish(f"mkdir -p {shlex.quote(parent_dir)}")
    cmd = f"screenrecord {size_flag}--bit-rate {bitrate} --time-limit {duration} {shlex.quote(out_path)}"
    run_rish(cmd, timeout=float(duration + 12))
    return {"mode": "timed_completed", "output_path": out_path, "duration_sec": duration}


def android_ui_inspect(args: dict) -> dict:
    """Dump and parse live foreground Android UI tree via Shizuku uiautomator."""
    _require_shizuku()
    only_interactive = bool(args.get("only_interactive", False))
    filter_query = str(args.get("query", "")).strip().lower()
    max_nodes = max(10, min(300, int(args.get("max_nodes", 120))))

    dump_path = "/sdcard/Download/.agy_ui_dump.xml"
    cmd = (
        f"uiautomator dump {dump_path} >/dev/null 2>&1 && cat {dump_path}; "
        f"rm -f {dump_path} >/dev/null 2>&1 || true"
    )
    proc = run_rish(cmd, timeout=15.0)
    xml_text = proc.stdout.strip()
    xml_start = xml_text.find("<?xml")
    if xml_start < 0:
        xml_start = xml_text.find("<hierarchy")
    if xml_start < 0:
        raise RuntimeError(f"Failed to dump Android UI hierarchy via uiautomator: {proc.stderr or xml_text[:200]}")

    root = ET.fromstring(xml_text[xml_start:])

    # Also grab current foreground window package
    fg_proc = run_rish("dumpsys window | grep -E 'mCurrentFocus|mFocusedApp' | head -n 3 || true", timeout=5.0)
    foreground_hint = " | ".join(line.strip() for line in fg_proc.stdout.splitlines() if line.strip())

    elements = []
    for node in root.iter("node"):
        text = (node.attrib.get("text") or "").strip()
        desc = (node.attrib.get("content-desc") or "").strip()
        res_id = (node.attrib.get("resource-id") or "").strip()
        cls_name = (node.attrib.get("class") or "").strip()
        clickable = node.attrib.get("clickable") == "true"
        scrollable = node.attrib.get("scrollable") == "true"
        selected = node.attrib.get("selected") == "true"
        parsed = _parse_bounds(node.attrib.get("bounds", ""))
        if not parsed:
            continue
        bounds, center = parsed

        has_label = bool(text or desc)
        if only_interactive and not (clickable or scrollable or has_label):
            continue
        if not (has_label or clickable or scrollable or res_id):
            continue

        short_id = res_id.split(":id/", 1)[-1] if ":id/" in res_id else res_id
        short_cls = cls_name.rsplit(".", 1)[-1] if "." in cls_name else cls_name

        if filter_query:
            haystack = f"{text} {desc} {short_id} {short_cls}".lower()
            if filter_query not in haystack:
                continue

        elements.append(
            {
                "index": len(elements),
                "text": text,
                "content_desc": desc,
                "id": short_id,
                "class": short_cls,
                "clickable": clickable,
                "scrollable": scrollable,
                "selected": selected,
                "bounds": bounds,
                "center": center,
            }
        )
        if len(elements) >= max_nodes:
            break

    return {
        "foreground": foreground_hint,
        "element_count": len(elements),
        "elements": elements,
    }


def android_ui_action(args: dict) -> dict:
    """Execute touch/keyboard/app actions on Android via Shizuku: tap, tap_text, swipe, text, keyevent, launch_app."""
    _require_shizuku()
    action = str(args["action"]).strip().lower()
    wait_ms = max(0, min(5000, int(args.get("wait_after_ms", 450))))

    if action == "tap":
        x, y = int(args["x"]), int(args["y"])
        run_rish(f"input tap {x} {y}")
        res = {"action": "tap", "x": x, "y": y}

    elif action == "tap_text":
        target = str(args["text"]).strip()
        if not target:
            raise ValueError("'text' is required for action='tap_text'")
        ui = android_ui_inspect({"query": target, "max_nodes": 50})
        matches = ui["elements"]
        if not matches:
            raise RuntimeError(f"UI element matching '{target}' not found on current Android screen.")
        # Prefer exact case-insensitive text/desc match, then clickable
        target_low = target.lower()
        matches.sort(
            key=lambda el: (
                0 if (el["text"].lower() == target_low or el["content_desc"].lower() == target_low) else 1,
                0 if el["clickable"] else 1,
            )
        )
        chosen = matches[0]
        cx, cy = chosen["center"]
        run_rish(f"input tap {cx} {cy}")
        res = {"action": "tap_text", "matched_element": chosen, "tapped": [cx, cy]}

    elif action == "swipe":
        x1, y1 = int(args["x"]), int(args["y"])
        x2, y2 = int(args["x2"]), int(args["y2"])
        dur = max(60, min(4000, int(args.get("duration_ms", 320))))
        run_rish(f"input swipe {x1} {y1} {x2} {y2} {dur}")
        res = {"action": "swipe", "from": [x1, y1], "to": [x2, y2], "duration_ms": dur}

    elif action == "text":
        raw_text = str(args["text"])
        # Android input text requires spaces encoded as %s
        escaped = raw_text.replace(" ", "%s")
        run_rish(f"input text {shlex.quote(escaped)}")
        res = {"action": "text", "typed": raw_text}

    elif action == "keyevent":
        k_raw = str(args.get("key", "BACK")).strip().upper()
        code = KEYEVENT_MAP.get(k_raw, k_raw)
        run_rish(f"input keyevent {shlex.quote(str(code))}")
        res = {"action": "keyevent", "key": k_raw, "code": code}

    elif action == "launch_app":
        raw_pkg = str(args["package"]).strip()
        pkg = APP_ALIASES.get(raw_pkg.lower(), raw_pkg)
        proc = run_rish(f"monkey -p {shlex.quote(pkg)} -c android.intent.category.LAUNCHER 1", timeout=8.0)
        if proc.returncode != 0:
            raise RuntimeError(f"Failed to launch package '{pkg}': {proc.stderr or proc.stdout}")
        res = {"action": "launch_app", "package": pkg}

    else:
        raise ValueError(f"Unsupported action '{action}'. Use tap, tap_text, swipe, text, keyevent, or launch_app.")

    if wait_ms > 0:
        time.sleep(wait_ms / 1000.0)
    return res


def _resolve_mediastore_content_uri(public_path: str) -> str | None:
    """Query Android MediaStore via Shizuku to obtain a content://media/external/video/media/<id> URI."""
    norm_paths = {public_path}
    if public_path.startswith("/sdcard/"):
        norm_paths.add("/storage/emulated/0/" + public_path[len("/sdcard/") :])
    elif public_path.startswith("/storage/emulated/0/"):
        norm_paths.add("/sdcard/" + public_path[len("/storage/emulated/0/") :])

    for p in norm_paths:
        safe_p = p.replace("'", "''")
        q_cmd = (
            "content query --uri content://media/external/video/media "
            f"--projection _id --where \"_data='{safe_p}'\""
        )
        proc = run_rish(q_cmd, timeout=6.0)
        m = re.search(r"_id=(\d+)", proc.stdout)
        if m:
            return f"content://media/external/video/media/{m.group(1)}"
    return None


def android_media_and_intent(args: dict) -> dict:
    """Stage video in public Movies folder, scan into Android Gallery (MediaStore), and optionally share/open in CapCut, VN, or TikTok."""
    _require_shizuku()
    raw_path = str(args["media_path"]).strip()
    open_in = str(args.get("open_in", "")).strip().lower()

    # If file lives inside app-private /data/user/0/..., stage it into /storage/emulated/0/Movies/AGY_Studio/
    public_dir = "/storage/emulated/0/Movies/AGY_Studio"
    if raw_path.startswith("/data/"):
        src = Path(raw_path)
        if not src.is_file():
            raise FileNotFoundError(f"Media file not found: {raw_path}")
        run_rish(f"mkdir -p {shlex.quote(public_dir)}")
        staged_path = f"{public_dir}/{src.name}"
        # Copy directly if /storage/emulated/0 is writable by AGY, else via rish cat
        try:
            os.makedirs(public_dir, exist_ok=True)
            shutil.copy2(str(src), staged_path)
        except Exception:
            with open(src, "rb") as f_in:
                import subprocess
                from .env_utils import find_rish

                subprocess.run([find_rish() or "rish", "-c", f"cat > {shlex.quote(staged_path)}"], input=f_in.read(), check=True)
        public_path = staged_path
    elif raw_path.startswith("/sdcard/"):
        public_path = "/storage/emulated/0/" + raw_path[len("/sdcard/") :]
    else:
        public_path = raw_path

    # Trigger Android MediaScanner broadcast so Gallery / TikTok / CapCut see the video immediately
    file_uri = f"file://{public_path}"
    run_rish(f"am broadcast -a android.intent.action.MEDIA_SCANNER_SCAN_FILE -d {shlex.quote(file_uri)}", timeout=8.0)
    time.sleep(0.6)
    content_uri = _resolve_mediastore_content_uri(public_path)

    launched_intent = None
    if open_in:
        if open_in == "gallery":
            uri_to_use = content_uri or file_uri
            run_rish(
                f"am start -a android.intent.action.VIEW -d {shlex.quote(uri_to_use)} -t video/mp4 "
                "--grant-read-uri-permission",
                timeout=8.0,
            )
            launched_intent = {"target": "gallery", "uri": uri_to_use}
        else:
            pkg = APP_ALIASES.get(open_in, open_in)
            # Detect fallback TikTok LatAm/Asia package if global isn't installed
            if open_in == "tiktok":
                chk = run_rish(f"pm path {pkg} || true")
                if "package:" not in chk.stdout:
                    pkg = "com.ss.android.ugc.trill"

            share_uri = content_uri or file_uri
            send_cmd = (
                f"am start -a android.intent.action.SEND -t video/mp4 "
                f"--eu android.intent.extra.STREAM {shlex.quote(share_uri)} "
                f"--grant-read-uri-permission -p {shlex.quote(pkg)}"
            )
            proc = run_rish(send_cmd, timeout=8.0)
            if proc.returncode != 0 or "Error:" in proc.stderr or "Error:" in proc.stdout:
                # Fallback: launch app directly so user finds the freshly scanned clip #1 in Recent Gallery
                run_rish(f"monkey -p {shlex.quote(pkg)} -c android.intent.category.LAUNCHER 1", timeout=8.0)
                launched_intent = {"target": pkg, "mode": "launcher_fallback_after_mediascan"}
            else:
                launched_intent = {"target": pkg, "mode": "android_intent_send_stream", "uri": share_uri}

    return {
        "public_path": public_path,
        "mediastore_scanned": True,
        "content_uri": content_uri,
        "launched_intent": launched_intent,
    }
