"""
CapCut Desktop & Rootless CapCut Android (Shizuku rish) Multi-Track Draft Bridge.
Solves Android 11-16 UID / Room DB sandboxing without root by:
  1. Staging private /data/user/0/... media into /storage/emulated/0/Movies/AGY_Studio/
  2. Force-stopping CapCut's cached state via rish ('am force-stop')
  3. Hot-patching an existing CapCut Android draft while preserving its SQLite-registered draft_id!
"""

from __future__ import annotations

import json
import os
import re
import shlex
import shutil
import subprocess
import time
import uuid
from pathlib import Path

from .autocut_engine import probe_video_extended
from .env_utils import find_rish, is_android, rish_status, run_rish

CAPCUT_ANDROID_PACKAGES = ("com.lemon.lvoverseas", "com.lemon.lv")


def _uid_hex() -> str:
    return str(uuid.uuid4()).upper()


def _sanitize_name(name: str) -> str:
    clean = re.sub(r"[^a-zA-Z0-9_\-. ]+", "", name).strip().replace(" ", "_")
    return clean or f"AGY_Draft_{int(time.time())}"


def list_capcut_drafts() -> dict:
    """List existing CapCut projects on Android (via Shizuku rish) or Windows/macOS Desktop."""
    if not is_android():
        cc_root = Path(os.path.expandvars(r"%LOCALAPPDATA%\CapCut\User Data\Projects\com.lveditor.draft"))
        drafts = []
        if cc_root.is_dir():
            for d in sorted(cc_root.iterdir(), key=lambda p: p.stat().st_mtime, reverse=True):
                if not d.is_dir() or d.name.startswith("."):
                    continue
                meta_f = d / "draft_meta_info.json"
                info = {"folder_name": d.name, "folder_path": str(d), "modified_ts": int(d.stat().st_mtime)}
                if meta_f.is_file():
                    try:
                        m = json.loads(meta_f.read_text(encoding="utf-8", errors="ignore"))
                        info["draft_id"] = m.get("draft_id", "")
                        info["draft_name"] = m.get("draft_name", d.name)
                        info["duration_sec"] = round(float(m.get("tm_duration", 0)) / 1_000_000.0, 2)
                    except Exception:
                        pass
                drafts.append(info)
        return {"platform": "desktop", "capcut_root": str(cc_root), "count": len(drafts), "drafts": drafts[:40]}

    # Android via Shizuku rish
    ok, shz_msg = rish_status()
    if not ok:
        raise RuntimeError(f"Shizuku (rish) is required on Android to inspect CapCut drafts: {shz_msg}")

    drafts_out = []
    for pkg in CAPCUT_ANDROID_PACKAGES:
        base_dir = f"/storage/emulated/0/Android/data/{pkg}/files/projects/drafts"
        ls_cmd = (
            f"if [ -d {shlex.quote(base_dir)} ]; then "
            f"ls -1dt {shlex.quote(base_dir)}/* 2>/dev/null | head -n 30; "
            "fi"
        )
        proc = run_rish(ls_cmd, timeout=8.0)
        folders = [ln.strip() for ln in proc.stdout.splitlines() if ln.strip()]
        for folder in folders:
            fname = folder.rsplit("/", 1)[-1]
            if fname.startswith("."):
                continue
            read_cmd = (
                f"if [ -f {shlex.quote(folder + '/draft_meta_info.json')} ]; then "
                f"cat {shlex.quote(folder + '/draft_meta_info.json')}; "
                f"elif [ -f {shlex.quote(folder + '/draft_info.json')} ]; then "
                f"head -c 4096 {shlex.quote(folder + '/draft_info.json')}; "
                "fi"
            )
            m_proc = run_rish(read_cmd, timeout=5.0)
            bak_proc = run_rish(f"[ -f {shlex.quote(folder + '/draft_content.agy_bak.json')} ] && echo YES || echo NO")
            item = {
                "package": pkg,
                "folder_name": fname,
                "folder_path": folder,
                "draft_id": "",
                "draft_name": fname,
                "duration_sec": 0.0,
                "has_agy_backup": "YES" in bak_proc.stdout,
            }
            raw_json = m_proc.stdout.strip()
            if raw_json.startswith("{"):
                try:
                    parsed = json.loads(raw_json)
                    item["draft_id"] = parsed.get("draft_id") or parsed.get("id") or ""
                    item["draft_name"] = parsed.get("draft_name") or parsed.get("name") or fname
                    dur_us = parsed.get("tm_duration") or parsed.get("duration") or 0
                    item["duration_sec"] = round(float(dur_us) / 1_000_000.0, 2)
                except Exception:
                    pass
            drafts_out.append(item)

    return {
        "platform": "android",
        "count": len(drafts_out),
        "drafts": drafts_out,
        "hint": (
            "Pass target_draft_folder (or android_mode='patch_latest') to capcut_export_draft to rootlessly inject "
            "a multi-track timeline into an existing CapCut Mobile project."
            if drafts_out
            else "Open CapCut Android once and tap 'New Project' (even with any 1s image/clip) so CapCut registers a draft_id in its Room DB, then run capcut_export_draft!"
        ),
    }


def _stage_media_for_capcut_android(src_path: str, project_slug: str) -> str:
    """Ensure media lives in /storage/emulated/0/Movies/AGY_Studio/<slug>/ so CapCut Android UID can read it."""
    if not is_android():
        return str(Path(src_path).resolve())

    if src_path.startswith("/sdcard/"):
        return "/storage/emulated/0/" + src_path[len("/sdcard/") :]
    if src_path.startswith("/storage/emulated/0/"):
        return src_path

    p = Path(src_path)
    if not p.is_file():
        return src_path

    public_dir = f"/storage/emulated/0/Movies/AGY_Studio/{project_slug}"
    dest = f"{public_dir}/{p.name}"
    try:
        os.makedirs(public_dir, exist_ok=True)
        shutil.copy2(str(p), dest)
        return dest
    except Exception:
        r = find_rish()
        if r:
            run_rish(f"mkdir -p {shlex.quote(public_dir)}")
            with open(p, "rb") as fin:
                subprocess.run([r, "-c", f"cat > {shlex.quote(dest)}"], stdin=fin, timeout=120, check=True)
            return dest
    return str(p.resolve())


def restore_capcut_android_backup(target_draft_folder: str) -> dict:
    ok, msg = rish_status()
    if not ok:
        raise RuntimeError(f"Shizuku required: {msg}")
    pkg = "com.lemon.lvoverseas" if "lvoverseas" in target_draft_folder else "com.lemon.lv"
    run_rish(f"am force-stop {pkg} || true")
    cmd = (
        f"if [ -f {shlex.quote(target_draft_folder + '/draft_content.agy_bak.json')} ]; then "
        f"cp -f {shlex.quote(target_draft_folder + '/draft_content.agy_bak.json')} {shlex.quote(target_draft_folder + '/draft_content.json')}; "
        f"cp -f {shlex.quote(target_draft_folder + '/draft_content.agy_bak.json')} {shlex.quote(target_draft_folder + '/draft_info.json')}; "
        f"[ -f {shlex.quote(target_draft_folder + '/draft_meta_info.agy_bak.json')} ] && "
        f"cp -f {shlex.quote(target_draft_folder + '/draft_meta_info.agy_bak.json')} {shlex.quote(target_draft_folder + '/draft_meta_info.json')}; "
        "echo RESTORED; else echo NO_BACKUP; fi"
    )
    proc = run_rish(cmd)
    return {"restored": "RESTORED" in proc.stdout, "target_draft_folder": target_draft_folder}


def export_capcut_draft(ffmpeg_bin: str | None, args: dict) -> dict:
    """
    Generate an editable multi-track CapCut project (draft_content.json + draft_info.json + draft_meta_info.json).
    On Android: supports rootless Draft Hijack ('patch_latest' or 'target_draft_folder') preserving CapCut's SQLite draft_id!
    """
    if args.get("restore_backup") and args.get("target_draft_folder"):
        return restore_capcut_android_backup(str(args["target_draft_folder"]))

    project_name = str(args.get("project_name", f"AGY_Project_{int(time.time())}"))
    project_slug = _sanitize_name(project_name)
    segments = args["segments"]
    captions = args.get("captions", [])
    audio_tracks = args.get("audio_tracks", [])
    aspect_ratio = str(args.get("aspect_ratio", "9:16")).strip()
    ratio_dims = {"9:16": (1080, 1920), "16:9": (1920, 1080), "1:1": (1080, 1080), "4:5": (1080, 1350), "4:3": (1440, 1080)}
    def_w, def_h = ratio_dims.get(aspect_ratio, (1080, 1920))
    width = int(args.get("width", def_w))
    height = int(args.get("height", def_h))
    if width > height and aspect_ratio == "9:16":
        aspect_ratio = "16:9"
    elif width == height and aspect_ratio == "9:16":
        aspect_ratio = "1:1"
    fps = float(args.get("fps", 60.0))
    keep_clip_audio = bool(args.get("keep_clip_audio", True))
    android_mode = str(args.get("android_mode", "patch_latest")).lower()  # "patch_latest", "new_folder", "stage_only"
    target_draft_folder = str(args.get("target_draft_folder", "")).strip()
    launch_capcut = bool(args.get("launch_capcut", False))

    now_us = int(time.time() * 1_000_000)
    draft_id = _uid_hex()
    existing_meta: dict = {}

    # If on Android and patching an existing CapCut draft, locate target folder & preserve its SQLite draft_id!
    resolved_android_target: str | None = None
    resolved_android_pkg: str = "com.lemon.lvoverseas"

    if is_android() and android_mode != "stage_only":
        ok, _ = rish_status()
        if ok:
            if target_draft_folder:
                resolved_android_target = target_draft_folder
                if "com.lemon.lv/" in target_draft_folder:
                    resolved_android_pkg = "com.lemon.lv"
            elif android_mode == "patch_latest":
                listing = list_capcut_drafts()
                if listing["drafts"]:
                    top = listing["drafts"][0]
                    resolved_android_target = top["folder_path"]
                    resolved_android_pkg = top["package"]
                    if top.get("draft_id"):
                        draft_id = top["draft_id"]

            if resolved_android_target:
                meta_proc = run_rish(
                    f"cat {shlex.quote(resolved_android_target + '/draft_meta_info.json')} 2>/dev/null || true"
                )
                if meta_proc.stdout.strip().startswith("{"):
                    try:
                        existing_meta = json.loads(meta_proc.stdout.strip())
                        if existing_meta.get("draft_id"):
                            draft_id = str(existing_meta["draft_id"])
                    except Exception:
                        existing_meta = {}

    videos_mat = []
    speeds_mat = []
    canvases_mat = []
    texts_mat = []
    audios_mat = []
    video_segments = []

    cursor_us = 0
    for seg in segments:
        raw_src = str(Path(seg["source"]).resolve()) if os.path.exists(str(seg["source"])) else str(seg["source"])
        staged_src = _stage_media_for_capcut_android(raw_src, project_slug)

        start_us = int(round(float(seg.get("start_sec", 0.0)) * 1_000_000))
        end_us = int(round(float(seg["end_sec"]) * 1_000_000))
        speed = float(seg.get("speed", 1.0))
        zoom = float(seg.get("zoom", 1.0))
        src_dur_us = max(100_000, end_us - start_us)
        tgt_dur_us = int(round(src_dur_us / speed))

        v_id = _uid_hex()
        s_id = _uid_hex()
        c_id = _uid_hex()

        src_w, src_h, full_dur_us = width, height, max(end_us, src_dur_us)
        probe_candidate = raw_src if os.path.isfile(raw_src) else staged_src
        if ffmpeg_bin and os.path.isfile(probe_candidate):
            try:
                pr = probe_video_extended(
                    ffmpeg_bin, probe_candidate, scene_threshold=0.98, min_freeze_sec=99.0, min_silence_sec=99.0
                )
                src_w = pr["width"] or width
                src_h = pr["height"] or height
                full_dur_us = max(end_us, int(round(pr["duration_sec"] * 1_000_000)))
            except Exception:
                pass

        videos_mat.append(
            {
                "id": v_id,
                "type": "video",
                "path": staged_src,
                "material_name": Path(staged_src).name,
                "width": src_w,
                "height": src_h,
                "duration": full_dur_us,
                "crop": {
                    "lower_left_x": 0.0,
                    "lower_left_y": 1.0,
                    "lower_right_x": 1.0,
                    "lower_right_y": 1.0,
                    "upper_left_x": 0.0,
                    "upper_left_y": 0.0,
                    "upper_right_x": 1.0,
                    "upper_right_y": 0.0,
                },
                "crop_ratio": "free",
                "crop_scale": 1.0,
                "has_audio": True,
                "category_name": "local",
            }
        )
        speeds_mat.append({"id": s_id, "type": "speed", "mode": 0, "speed": speed, "curve_speed": None})
        canvases_mat.append({"id": c_id, "type": "canvas_color", "color": "#05060A", "blur": 0.0})

        video_segments.append(
            {
                "id": _uid_hex(),
                "material_id": v_id,
                "extra_material_refs": [s_id, c_id],
                "source_timerange": {"start": start_us, "duration": src_dur_us},
                "target_timerange": {"start": cursor_us, "duration": tgt_dur_us},
                "speed": speed,
                "volume": float(seg.get("volume", 1.0 if keep_clip_audio else 0.0)),
                "visible": True,
                "clip": {
                    "alpha": 1.0,
                    "flip": {"horizontal": False, "vertical": False},
                    "rotation": 0.0,
                    "scale": {"x": zoom, "y": zoom},
                    "transform": {
                        "x": float(seg.get("pan_x", 0.0)),
                        "y": float(seg.get("pan_y", 0.0)),
                    },
                },
                "common_keyframes": [],
                "render_index": 0,
            }
        )
        cursor_us += tgt_dur_us

    text_segments = []
    for cap in captions:
        t_id = _uid_hex()
        c_start = int(round(float(cap["start_sec"]) * 1_000_000))
        c_dur = max(100_000, int(round((float(cap["end_sec"]) - float(cap["start_sec"])) * 1_000_000)))
        txt_str = str(cap["text"])
        content_json = json.dumps(
            {
                "text": txt_str,
                "styles": [
                    {
                        "fill": {"content": {"solid": {"color": [0.97, 0.98, 0.99]}}},
                        "size": 10.5,
                        "bold": True,
                        "strokes": [{"content": {"solid": {"color": [0.03, 0.04, 0.06]}}, "width": 0.06}],
                        "range": [0, len(txt_str)],
                    }
                ],
            }
        )
        texts_mat.append(
            {
                "id": t_id,
                "type": "text",
                "content": content_json,
                "alignment": 1,
                "font_size": 10.5,
                "text_color": "#F8F9FA",
            }
        )
        text_segments.append(
            {
                "id": _uid_hex(),
                "material_id": t_id,
                "extra_material_refs": [],
                "source_timerange": None,
                "target_timerange": {"start": c_start, "duration": c_dur},
                "speed": 1.0,
                "volume": 1.0,
                "visible": True,
                "clip": {
                    "alpha": 1.0,
                    "flip": {"horizontal": False, "vertical": False},
                    "rotation": 0.0,
                    "scale": {"x": 1.0, "y": 1.0},
                    "transform": {"x": 0.0, "y": -0.58},
                },
                "render_index": 14000,
            }
        )

    audio_track_objs = []
    for at in audio_tracks:
        raw_a = str(Path(at["source"]).resolve()) if os.path.exists(str(at["source"])) else str(at["source"])
        staged_a = _stage_media_for_capcut_android(raw_a, project_slug)
        a_id = _uid_hex()
        a_dur = cursor_us
        probe_a = raw_a if os.path.isfile(raw_a) else staged_a
        if ffmpeg_bin and os.path.isfile(probe_a):
            try:
                pr = probe_video_extended(ffmpeg_bin, probe_a, scene_threshold=0.99, min_freeze_sec=99.0, min_silence_sec=99.0)
                if pr["duration_sec"] > 0:
                    a_dur = min(cursor_us, int(round(pr["duration_sec"] * 1_000_000)))
            except Exception:
                pass
        audios_mat.append(
            {
                "id": a_id,
                "type": "extract_music",
                "path": staged_a,
                "name": Path(staged_a).name,
                "duration": a_dur,
                "category_name": "local",
            }
        )
        audio_track_objs.append(
            {
                "id": _uid_hex(),
                "type": "audio",
                "attribute": 0,
                "flag": 0,
                "segments": [
                    {
                        "id": _uid_hex(),
                        "material_id": a_id,
                        "extra_material_refs": [],
                        "source_timerange": {"start": 0, "duration": a_dur},
                        "target_timerange": {"start": 0, "duration": a_dur},
                        "speed": 1.0,
                        "volume": float(at.get("volume", 1.0)),
                        "visible": True,
                    }
                ],
            }
        )

    tracks = [{"id": _uid_hex(), "type": "video", "attribute": 0, "flag": 0, "segments": video_segments}]
    if text_segments:
        tracks.append({"id": _uid_hex(), "type": "text", "attribute": 0, "flag": 0, "segments": text_segments})
    tracks.extend(audio_track_objs)

    draft_content = {
        "id": draft_id,
        "name": project_name,
        "version": 360000,
        "new_version": "110.0.0",
        "duration": cursor_us,
        "create_time": int(now_us // 1_000_000),
        "update_time": int(now_us // 1_000_000),
        "fps": fps,
        "color_space": 0,
        "canvas_config": {"width": width, "height": height, "ratio": aspect_ratio},
        "config": {"maintrack_adsorb": True},
        "keyframes": {k: [] for k in ("adjusts", "audios", "effects", "filters", "handwrites", "stickers", "texts", "videos")},
        "materials": {
            "videos": videos_mat,
            "speeds": speeds_mat,
            "canvases": canvases_mat,
            "texts": texts_mat,
            "audios": audios_mat,
            "transitions": [],
            "effects": [],
            "video_effects": [],
            "stickers": [],
            "audio_fades": [],
            "material_animations": [],
        },
        "tracks": tracks,
        "platform": {
            "os": "android" if is_android() else "windows",
            "app_source": "cc",
            "app_version": "12.4.0",
        },
    }

    # Local staging folder
    custom_dir = args.get("output_draft_dir")
    if custom_dir:
        out_dir = Path(custom_dir).resolve() / project_slug
    elif not is_android():
        cc_root = Path(os.path.expandvars(r"%LOCALAPPDATA%\CapCut\User Data\Projects\com.lveditor.draft"))
        out_dir = (cc_root if cc_root.is_dir() else Path.cwd() / "capcut_drafts") / project_slug
    else:
        out_dir = Path("/storage/emulated/0/Download/AGY_CapCut_Drafts") / project_slug

    try:
        out_dir.mkdir(parents=True, exist_ok=True)
        (out_dir / "Resources").mkdir(exist_ok=True)
    except OSError:
        out_dir = Path(os.environ.get("TMPDIR", "/tmp")) / "AGY_CapCut_Drafts" / project_slug
        out_dir.mkdir(parents=True, exist_ok=True)
        (out_dir / "Resources").mkdir(exist_ok=True)

    final_fold_path = resolved_android_target or str(out_dir)
    final_root_path = str(Path(final_fold_path).parent).replace("\\", "/")

    draft_meta = dict(existing_meta)
    draft_meta.update(
        {
            "draft_id": draft_id,
            "draft_name": project_name,
            "draft_fold_path": final_fold_path,
            "draft_root_path": final_root_path,
            "tm_draft_create": existing_meta.get("tm_draft_create", now_us),
            "tm_draft_modified": now_us,
            "tm_duration": cursor_us,
        }
    )

    content_text = json.dumps(draft_content, indent=2)
    meta_text = json.dumps(draft_meta, indent=2)

    (out_dir / "draft_content.json").write_text(content_text, encoding="utf-8")
    (out_dir / "draft_info.json").write_text(content_text, encoding="utf-8")
    (out_dir / "draft_meta_info.json").write_text(meta_text, encoding="utf-8")

    android_injection_mode = "none"
    injected_target = None

    if is_android() and android_mode != "stage_only":
        ok, _ = rish_status()
        if ok:
            r_bin = find_rish() or "rish"
            if resolved_android_target:
                # ROOTLESS HIJACK: Force-stop CapCut so RAM cache doesn't overwrite our injected JSON, backup once, and patch via stdin!
                run_rish(f"am force-stop {shlex.quote(resolved_android_pkg)} || true")
                backup_cmd = (
                    f"if [ -f {shlex.quote(resolved_android_target + '/draft_content.json')} ] && "
                    f"[ ! -f {shlex.quote(resolved_android_target + '/draft_content.agy_bak.json')} ]; then "
                    f"cp -f {shlex.quote(resolved_android_target + '/draft_content.json')} "
                    f"{shlex.quote(resolved_android_target + '/draft_content.agy_bak.json')}; "
                    f"[ -f {shlex.quote(resolved_android_target + '/draft_meta_info.json')} ] && "
                    f"cp -f {shlex.quote(resolved_android_target + '/draft_meta_info.json')} "
                    f"{shlex.quote(resolved_android_target + '/draft_meta_info.agy_bak.json')}; "
                    "fi; true"
                )
                run_rish(backup_cmd, timeout=10.0)
                ok_write = True
                for fname, payload in (
                    ("draft_content.json", content_text),
                    ("draft_info.json", content_text),
                    ("draft_meta_info.json", meta_text),
                ):
                    res = subprocess.run(
                        [r_bin, "-c", f"cat > {shlex.quote(resolved_android_target + '/' + fname)}"],
                        input=payload,
                        text=True,
                        timeout=15.0,
                    )
                    if res.returncode != 0:
                        ok_write = False
                        break
                if ok_write:
                    android_injection_mode = "rootless_draft_hijack_patched"
                    injected_target = resolved_android_target
            else:
                # Fallback if user hasn't created any initial draft in CapCut yet
                for pkg in CAPCUT_ANDROID_PACKAGES:
                    chk = run_rish(f"pm path {pkg} || true")
                    if "package:" in chk.stdout:
                        resolved_android_pkg = pkg
                        new_dir = f"/storage/emulated/0/Android/data/{pkg}/files/projects/drafts/{project_slug}"
                        run_rish(f"mkdir -p {shlex.quote(new_dir + '/Resources')}")
                        for fname, payload in (
                            ("draft_content.json", content_text),
                            ("draft_info.json", content_text),
                            ("draft_meta_info.json", meta_text),
                        ):
                            subprocess.run(
                                [r_bin, "-c", f"cat > {shlex.quote(new_dir + '/' + fname)}"],
                                input=payload,
                                text=True,
                                timeout=15.0,
                            )
                        android_injection_mode = "new_folder_copied_create_blank_draft_for_sqlite_index"
                        injected_target = new_dir
                        break

            if launch_capcut:
                run_rish(f"monkey -p {shlex.quote(resolved_android_pkg)} -c android.intent.category.LAUNCHER 1", timeout=8.0)

    return {
        "staged_draft_dir": str(out_dir),
        "project_name": project_name,
        "draft_id": draft_id,
        "duration_sec": round(cursor_us / 1_000_000.0, 2),
        "android_injection_mode": android_injection_mode,
        "android_target_folder": injected_target,
        "capcut_launched": launch_capcut,
    }
