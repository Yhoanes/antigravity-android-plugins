"""Environment, FFmpeg hardware acceleration, bundled fonts, and Shizuku (rish) helpers."""

from __future__ import annotations

import importlib.util
import os
import platform
import re
import shutil
import subprocess
from pathlib import Path

PLUGIN_ROOT = Path(__file__).resolve().parent.parent.parent
FONTS_DIR = PLUGIN_ROOT / "assets" / "fonts"

ANDROID_KNOWN_APPS = [
    ("com.lemon.lvoverseas", "CapCut Global", "editor"),
    ("com.lemon.lv", "CapCut CN (JianYing)", "editor"),
    ("com.frontrow.vlog", "VN Video Editor", "editor"),
    ("com.alightcreative.motion", "Alight Motion", "editor"),
    ("com.nexstreaming.app.kinemasterfree", "KineMaster", "editor"),
    ("com.zhiliaoapp.musically", "TikTok Global", "social"),
    ("com.ss.android.ugc.trill", "TikTok Asia/LatAm", "social"),
    ("com.instagram.android", "Instagram", "social"),
    ("com.google.android.youtube", "YouTube", "social"),
]

_ENCODER_CACHE: dict[str, set[str]] = {}


def is_android() -> bool:
    return (
        os.path.exists("/system/build.prop")
        or os.path.exists("/system/bin/linker64")
        or "ANDROID_ROOT" in os.environ
        or str(PLUGIN_ROOT).startswith("/data/")
    )


def find_ffmpeg() -> str | None:
    env_ff = os.environ.get("AGY_FFMPEG_BIN")
    if env_ff and os.path.isfile(env_ff):
        return env_ff
    found = shutil.which("ffmpeg")
    if found:
        return found
    try:
        import imageio_ffmpeg  # type: ignore

        return imageio_ffmpeg.get_ffmpeg_exe()
    except Exception:
        return None


def get_ffmpeg_encoders(ffmpeg_bin: str | None) -> set[str]:
    if not ffmpeg_bin:
        return set()
    if ffmpeg_bin in _ENCODER_CACHE:
        return _ENCODER_CACHE[ffmpeg_bin]
    try:
        proc = subprocess.run(
            [ffmpeg_bin, "-hide_banner", "-encoders"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=8,
        )
        encs: set[str] = set()
        for line in proc.stdout.splitlines():
            m = re.match(r"^\s*[A-Z\.]{6}\s+([a-zA-Z0-9_]+)\s+", line)
            if m:
                encs.add(m.group(1))
        _ENCODER_CACHE[ffmpeg_bin] = encs
        return encs
    except Exception:
        return set()


def select_video_encoder_args(
    ffmpeg_bin: str,
    use_hw_accel: bool = True,
    bitrate_mbps: float = 10.0,
    crf: int = 18,
    preset: str = "veryfast",
) -> tuple[list[str], str]:
    """Return FFmpeg video codec CLI flags and selected encoder name, preferring Android h264_mediacodec when requested."""
    encs = get_ffmpeg_encoders(ffmpeg_bin)
    if use_hw_accel and is_android() and "h264_mediacodec" in encs:
        br = f"{max(2.0, min(35.0, bitrate_mbps)):.1f}M"
        return ["-c:v", "h264_mediacodec", "-b:v", br, "-g", "120", "-pix_fmt", "nv12"], "h264_mediacodec"
    return ["-c:v", "libx264", "-preset", preset, "-crf", str(crf), "-pix_fmt", "yuv420p"], "libx264"


def find_rish() -> str | None:
    env_r = os.environ.get("AGY_RISH_BIN")
    if env_r and os.path.isfile(env_r):
        return env_r
    return shutil.which("rish")


def run_rish(cmd: str, timeout: float = 15.0) -> subprocess.CompletedProcess[str]:
    r = find_rish()
    if not r:
        raise RuntimeError("Shizuku 'rish' binary not found in PATH.")
    return subprocess.run(
        [r, "-c", cmd],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        timeout=timeout,
    )


def rish_status() -> tuple[bool, str]:
    if not find_rish():
        return False, "rish not found in PATH"
    try:
        proc = run_rish("id", timeout=5.0)
        if proc.returncode == 0 and "uid=" in proc.stdout:
            return True, proc.stdout.strip()
        detail = (proc.stderr or proc.stdout).strip()
        return False, detail or "Shizuku service inactive (start Shizuku app on Android)"
    except Exception as exc:
        return False, str(exc)


def get_android_screen_size() -> dict[str, int] | None:
    ok, _ = rish_status()
    if not ok:
        return None
    try:
        proc = run_rish("wm size", timeout=5.0)
        m = re.search(r"(\d{3,5})x(\d{3,5})", proc.stdout)
        if m:
            return {"width": int(m.group(1)), "height": int(m.group(2))}
    except Exception:
        pass
    return None


def detect_installed_apps() -> dict:
    result: dict = {"android_editors": [], "android_social": [], "desktop_capcut_drafts": None}
    if is_android():
        ok, _ = rish_status()
        if ok:
            # Single fast call to pm list packages instead of 9 separate invocations
            try:
                proc = run_rish("pm list packages", timeout=8.0)
                installed_pkgs = {
                    line.split("package:", 1)[1].strip()
                    for line in proc.stdout.splitlines()
                    if line.startswith("package:")
                }
            except Exception:
                installed_pkgs = set()
            for pkg, label, kind in ANDROID_KNOWN_APPS:
                if pkg in installed_pkgs:
                    key = "android_editors" if kind == "editor" else "android_social"
                    result[key].append({"package": pkg, "name": label})
    else:
        cc_win = Path(os.path.expandvars(r"%LOCALAPPDATA%\CapCut\User Data\Projects\com.lveditor.draft"))
        if cc_win.is_dir():
            result["desktop_capcut_drafts"] = str(cc_win)
    return result


def check_python_capabilities() -> dict[str, bool]:
    return {
        "pillow": importlib.util.find_spec("PIL") is not None,
        "numpy": importlib.util.find_spec("numpy") is not None,
        "edge_tts": importlib.util.find_spec("edge_tts") is not None or shutil.which("edge-tts") is not None,
    }


def resolve_font_path(role: str = "display_bold") -> Path | None:
    mapping = {
        "display_bold": "Outfit-Bold.ttf",
        "display_regular": "Outfit-Regular.ttf",
        "sans_semibold": "PlusJakartaSans-SemiBold.ttf",
        "mono_semibold": "JetBrainsMono-SemiBold.ttf",
    }
    fname = mapping.get(role, role)
    candidate = FONTS_DIR / fname
    if candidate.is_file():
        return candidate
    for fallback in (
        "/system/fonts/Roboto-Bold.ttf",
        "/system/fonts/Roboto-Regular.ttf",
        r"C:\Windows\Fonts\segoeuib.ttf",
        r"C:\Windows\Fonts\arialbd.ttf",
    ):
        if os.path.isfile(fallback):
            return Path(fallback)
    return None


def get_full_environment_status() -> dict:
    ff = find_ffmpeg()
    encs = get_ffmpeg_encoders(ff)
    shz_ok, shz_info = rish_status()
    py_caps = check_python_capabilities()
    bundled_fonts = sorted(p.name for p in FONTS_DIR.glob("*.ttf")) if FONTS_DIR.is_dir() else []

    missing_hints = []
    if not ff:
        missing_hints.append("Run 'agy-video-setup' to install native ARM64 ffmpeg.")
    if not py_caps["pillow"]:
        missing_hints.append("Run 'agy-video-setup' to install Pillow for Google Keynote 3D frame rendering.")
    if not py_caps["edge_tts"]:
        missing_hints.append("Run 'agy-video-setup' to install edge-tts for neural ES/EN voiceovers.")

    return {
        "server_version": "2.1.3",
        "platform": "android-arm64" if is_android() else platform.system().lower(),
        "machine": platform.machine(),
        "ffmpeg_available": bool(ff),
        "ffmpeg_path": ff,
        "hardware_encoders": {
            "h264_mediacodec": "h264_mediacodec" in encs,
            "hevc_mediacodec": "hevc_mediacodec" in encs,
        },
        "python_modules": py_caps,
        "bundled_google_fonts": bundled_fonts,
        "shizuku_active": shz_ok,
        "shizuku_info": shz_info,
        "android_screen": get_android_screen_size() if shz_ok else None,
        "detected_apps": detect_installed_apps(),
        "setup_hint": " ".join(missing_hints) if missing_hints else None,
    }
