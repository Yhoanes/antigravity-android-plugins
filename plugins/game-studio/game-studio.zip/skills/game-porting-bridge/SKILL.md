---
name: game-porting-bridge
description: End-to-end workflow combining Craft Anything + Ghidra ARM64 (binary/archive reverse engineering) with Game Studio 2D/3D (asset optimization, touch UI redesign, Godot 4 / native SDL3 reconstruction, and Shizuku FPS profiling) to port PC or console games to native Android ARM64.
---

# Hybrid Game Porting Pipeline (`Craft Anything` + `Game Studio`)

Use this skill when the user wants to **port an existing PC, console, or legacy game to native Android ARM64** (using legally owned game assets). The two plugins operate as a clean two-stage relay with zero overlap:

## Stage 1 — Reverse Engineering & Extraction (`craft-anything` + `ghidra-arm64`)

1. **Triage Originals (Read-Only):**
   - Inspect binaries (`.exe`, `.dll`, `.so`) with `core_target_open`, `core_target_triage`, and Ghidra decompilation (`native_function_pseudocode`) to recover exact game constants, damage/movement formulas, file headers, and state machines.
   - Inspect game archives (`.pak`, `.mpq`, Unity bundles, IoStore) using `game_archives_list`, `game_pak_list` / `game_pak_extract`, or `game_unity_asset_export`.
2. **Document Exact Specs:** Record recovered formulas, unit tables, and binary chunk layouts before writing new engine code.

## Stage 2 — Mobile Asset Conversion (`game-studio`)

PC assets will bottleneck mobile RAM/VRAM if copied raw. Convert them systematically:
1. **3D Models (`.mdx` / `.fbx` / `.obj` -> `.glb`):** Convert to glTF 2.0 `.glb`, inspect with `model3d_inspect_glb`, and run `model3d_optimize_glb` (`max_texture_size: 1024`, `simplify_ratio: 0.5`, `webp_textures: true`) using the built-in Rust spatial LOD decimator for RTS/crowd scenes.
2. **2D UI & Sprites (`.dds` / `.tga` / `.webp` -> Atlas PNG/WebP + Normal Maps):** Pass PC `.dds` and `.tga` textures directly into `sprite_pack_atlas` (`padding: 2`, `power_of_two: true`) and generate dynamic 2D lighting maps with `sprite_process` (`generate_normal_map`).
3. **Audio & Voice Packs:** Run WAV SFX/BGM through `audio_sfx_master` (`trim_silence: true`, `normalize_peak: true`, `seamless_loop_fade_ms: 80` for BGM loops) and compress `.ogg`/`.opus` via `game-studio-setup` FFmpeg.
4. **Combat & Economy Verification:** Verify that your ported combat formulas match the original game's TTK using `gamedata_balance_sim`.

## Stage 3 — Native Android Engine & Touch Ergonomics

Choose the right runtime architecture for the target game:
- **Modern Remake / Rapid Iteration:** Scaffold a **Godot 4 Android** project (`godot_scaffold_project`) importing the optimized `.glb`, `.tres` atlases, JSON unit tables, and custom touch HUD.
- **Direct Legacy Archive Runner (C++/SDL3/Vulkan NDK or Java/Kotlin LibGDX):** Build a native `arm64-v8a` APK that parses the user's original archive files in place from `/storage/emulated/0/Documents/...` with a custom touch overlay.

## Stage 4 — On-Device 60–120 FPS QA (`Shizuku`)

Install and launch the build on device, then run `android_game_profiler` during heavy scenes (e.g. 100+ active units) to verify `p95 < 16.6 ms`, zero native crashes, and safe battery thermals.
