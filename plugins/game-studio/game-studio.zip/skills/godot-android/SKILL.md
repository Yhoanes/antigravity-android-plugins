---
name: godot-android
description: Build, edit, compile native ARM64 GDExtensions (C/C++/Rust), generate Vulkan .gdshader & MultiMesh worlds, export/install signed Android APKs 100% locally offline, and debug live 120-144 FPS Godot 4.x games on Android (`godot_scaffold_project`, `godot_gdextension_build`, `godot_shader_and_world`, `godot_apk_build_deploy`, `android_game_profiler`).
---

# Godot 4.x AAA Native Android ARM64 Studio (`v2.0.0` — `GDExtension` + Zero-Cloud Local `.apk`)

Use this skill whenever creating, optimizing, or porting **Godot 4.x 2D and 3D** games on Android.

## 1. Two Ways to Run & Test Locally (Zero Cloud Needed)

1. **Instant Split-Screen Playtest (`org.godotengine.editor.v4`):**
   - Store projects under **`/storage/emulated/0/Documents/Games/<ProjectName>`** so the Godot 4 Android Editor app can open and edit scenes visually.
2. **Standalone Signed `.apk` + Native `GDExtension` `.so` (`godot_apk_build_deploy`):**
   - Android 10–15 mounts `/storage/emulated/0` with SELinux `noexec`, which blocks `dlopen` on loose `.so` files in shared storage.
   - `godot_apk_build_deploy` solves this completely offline in ~3–5 seconds: it runs patched headless `godot-bin` (`4.7.x`), bundles `libgodot_android.so` + every `[libraries]` `android.*.arm64` `.so` inside `lib/arm64-v8a/` of a signed `.apk`, installs via `rish`, and launches the standalone game at up to **144 Hz**!

## 2. End-to-End AAA Workflow

1. **One-Time Toolchain Setup (`godot_toolchain_setup`):**
   - Ensures headless `godot` (`31-byte` patched `godot-bin`), dumps `gdextension_interface.h`, creates `debug.keystore` + `editor_settings-4.7.tres`, and downloads **only** the Android APK export template via HTTP Range (skipping >1 GB of desktop templates).
2. **Scaffold 144 Hz Vulkan PBR Project (`godot_scaffold_project`):**
   - Pass `dimension: "3d"` (or `"2d"`) and `with_gdextension: true` (`gdextension_language: "cpp"` or `"rust"`) to get a playable project with `Engine.max_fps = 144`, ACES tonemapping + Glow, touch HUD, and a compiled `NativeMobaCore` `GDExtension` `.so`.
3. **Add Native C++/Rust Speed (`godot_gdextension_build`):**
   - Write hot loops (100–5,000 RTS/MOBA units, Fog of War, pathfinding, voxel generation, custom archive parsers) in C (`clang -std=c11 -O3 -march=armv8.1-a`) or Rust (`rustc --crate-type cdylib -O3`).
   - Both `android.*.arm64` and `linux.*.arm64` entries are written in `<module>.gdextension`, so you can even test the `.so` in `<0.5s` via headless CLI before exporting the `.apk`!
4. **Vulkan Shaders & `MultiMesh` GPU Instancing (`godot_shader_and_world`):**
   - Use `preset: "rts_splatmap_fog"`, `"stylized_water"`, `"neon_pbr_emissive"`, `"toon_cel_outline"`, or `"multimesh_crowd"` (`multimesh_instance_count: 500`) to draw hundreds/thousands of 3D objects in 1 GPU draw call.
5. **Validate, Export `.apk` & Debug Live (`godot_validate_project` -> `godot_apk_build_deploy` -> `android_game_profiler`):**
   - Always inspect `android_game_profiler` after launching the APK to verify `godot_errors_count == 0`, `NativeMobaCore` log output in `godot_recent_logs`, and `120–144 FPS` frame pacing.
