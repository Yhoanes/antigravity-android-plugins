---
name: godot-android
description: Build, edit, validate, and test Godot 4.x 2D and 3D games natively on Android ARM64, including .tscn/.tres scene authoring, Vulkan Mobile optimization, custom shaders, and launching projects in Godot 4 Android Editor.
---

# Godot 4 Native Android Studio Workflow

Use this skill whenever creating or editing **Godot 4.x** projects on Android.

## 1. Shared Storage Workspace Convention

The official **Godot 4 Android Editor** (`org.godotengine.editor.v4`) accesses shared storage (`/storage/emulated/0/...`), NOT Antigravity's private internal `/data/user/0/com.agy` sandbox.
- Always scaffold Godot projects under **`/storage/emulated/0/Documents/Games/<ProjectName>`** so the user can open and playtest them side-by-side in split-screen with Godot 4 Android!

## 2. Rapid Project & Scene Authoring

1. **Bootstrap:** Call `godot_scaffold_project` (`dimension: "2d"` or `"3d"`) to generate `project.godot` (`config_version=5`, `renderer/rendering_method="mobile"`, `import_etc2_astc=true`), `export_presets.cfg` (`arm64-v8a`), `GameManager`, `TouchControls`, and a playable `main.tscn`.
2. **Add Entities & Levels:** Use `godot_create_scene` or write clean `.tscn` / `.gd` files directly:
   - Keep `load_steps` accurate (`1 + ext_resources + sub_resources`).
   - Always place `[ext_resource ...]` first, `[sub_resource ...]` second, `[node ...]` third, and `[connection ...]` last.
3. **Pack 2D Art into Godot `AtlasTexture`s:** Pass `godot_project_dir` to `sprite_pack_atlas` to generate individual `.tres` `AtlasTexture` resources automatically referencing your packed PNG.
4. **Validate Before Playtest:** Always run `godot_validate_project` after creating or refactoring scenes/scripts to guarantee zero broken `res://` links.
5. **Launch & Profile on Device:** Use `android_godot_launch` to open Godot 4 Editor (or your exported APK) and `android_game_profiler` to inspect live `gfxinfo` p50/p95/p99 frame times and PSS memory.

## 3. Optional Live WebSocket Bridge (`godot-mcp` Addon)

If the user wants live in-editor node manipulation while Godot 4 Android Editor is open in split-screen:
- Add an `@tool` `EditorPlugin` script under `addons/studio_bridge/plugin.gd` listening on `TCPServer` / `WebSocketPeer` (`127.0.0.1:6550`) to hot-reload scenes and capture live viewport screenshots on command.
