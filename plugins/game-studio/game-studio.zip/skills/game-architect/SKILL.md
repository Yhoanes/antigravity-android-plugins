---
name: game-architect
description: Studio-grade 2D and 3D game architecture on Android ARM64 covering genre patterns (Action RPG, Platformer, RTS, Shooter, Puzzle), mobile GPU/CPU 60-120 FPS budgets, touch-first HUD/controls, object pooling, state machines, and Monte Carlo combat balancing.
---

# AAA 2D & 3D Game Architecture (Android ARM64)

Use this skill when designing, structuring, or scaling any **2D or 3D video game** on Android so the codebase, controls, and frame pacing behave like a commercial studio release.

## 1. Mobile Hardware Frame & Memory Budgets (60–120 FPS)

Target **8.3 ms/frame (120 FPS)** or **16.6 ms/frame (60 FPS)** sustained without thermal throttling:

| Metric | 2D Game Budget | 3D Mobile (Vulkan Mobile) Budget |
| :--- | :--- | :--- |
| **Draw Calls / Frame** | `< 60` (use `sprite_pack_atlas`) | `< 120–180` (batch static meshes, GPU instancing `MultiMesh`) |
| **Active Triangles** | N/A | `100k – 350k` visible triangles total (`1.5k–6k` per unit, `8k–15k` hero) |
| **Texture Resolution** | `1024x1024` or `2048x2048` POT atlases | Max `1024x1024` per prop/character (`ASTC` / `ETC2` VRAM compressed) |
| **Dynamic Shadows** | 2D CanvasModulate / baked blobs | 1 `DirectionalLight3D` shadow + cheap blob decals for units |
| **GC / Allocations** | Zero per-frame heap allocations; pool projectiles, damage numbers, and hit VFX |

Always run `model3d_inspect_glb` and `model3d_optimize_glb` before importing heavy PC `.glb` models.

## 2. Touch-First Control Design by Genre

Never copy desktop tiny mouse buttons onto mobile screens. Apply genre-proven touch ergonomics:

- **Action RPG / 3D Adventure / Twin-Stick:** Floating left-thumb virtual joystick (`deadzone = 0.12`) + right-half screen drag for camera orbit + arc of thumb-reachable primary/skill buttons in bottom-right (`min 96x96 dp` hitboxes).
- **2D Platformer / Metroidvania:** Fixed horizontal left/right zones or crisp D-pad + **Coyote Time (`100 ms`)** + **Jump Buffer (`120 ms`)** so touch jumps never feel dropped.
- **RTS / Strategy (e.g. Warcraft-style mobile adaptation):**
  - Single-finger drag on empty ground = pan camera; two-finger pinch = zoom.
  - Double-tap unit = select all of same type on screen; hold-and-drag = selection lasso box (`SelectionBox`).
  - Context-sensitive smart right-click replacement: single tap on ground = Move, tap on enemy = Attack-Move, tap on gold/tree with worker = Harvest.
  - Radial wheel or large bottom command card (`4x3` thumb grid) + top-left control group pills (`1`, `2`, `3`).

## 3. Clean Decoupled Code Architecture

Organize every project into 4 decoupled layers:
1. **`core/` (Autoloads / Systems):** `GameManager`, `EventBus` (signals), `AudioPool` (pre-allocated `AudioStreamPlayer` ring buffer so rapid gunshots/hits never cut off), `SaveSystem`.
2. **`data/` (Data-Driven Stats):** Keep unit HP, weapon damage, cooldowns, wave spawns, dialogue trees, and loot weights in JSON or Godot custom `Resource` (`.tres`) files — never hardcode numbers inside movement scripts. Verify matchups with `gamedata_balance_sim`.
3. **`entities/` (Modular Composition):** Compose characters out of reusable child components (`HealthComponent`, `HitboxComponent`, `HurtboxComponent`, `StateMachine`) instead of 2,000-line monolithic player scripts.
4. **`ui/` (Safe-Area Responsive HUD):** Anchor HUD controls to screen corners (`anchors_preset`) respecting Android camera cutouts/notches.

## 4. Zero-Latency Audio Feel ("Game Juice")

- Every jump, sword slash, UI click, and footstep **must have `0 ms` leading silence**. Always pass raw or generated WAV/OGG effects through `audio_sfx_master` (`trim_silence: true`).
- Randomize `pitch_scale` slightly (`0.93` to `1.07`) on repeated SFX (footsteps, hits, gunfire) to eliminate robotic ear fatigue.
