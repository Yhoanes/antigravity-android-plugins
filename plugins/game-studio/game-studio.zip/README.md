# Game Studio 2D/3D (`v2.0.0`) — Motor Nativo en Rust ARM64 + `GDExtension` + Compilador Local de `.apk`

Plugin oficial nativo **ARM64 (`aarch64` + `LSE` + `Rayon` multinúcleo)** para **Antigravity for Android** que convierte tu teléfono o tablet en un estudio AAA **100 % local y sin nube** para desarrollar y *portear* videojuegos **2D y 3D a 120–144 FPS** sobre **Godot 4.7 Vulkan**.

> [!TIP]
> **Novedades de `v2.0.0` (Potencia Nivel Unity `IL2CPP` / C++ 100 % Offline en tu Android):**
> - **Motor `GDExtension` Nativo ARM64 (`godot_gdextension_build`):** Compila en **~1 segundo** librerías `.so` (`arm64-v8a` Bionic) en **C/C++ (`clang -O3 -march=armv8.1-a`)** o **Rust (`rustc cdylib -O3`)** registradas directamente en `ClassDB` de Godot 4 para mover cientos o miles de unidades RTS/MOBA, *Fog of War* o física pesada a velocidad de código máquina.
> - **Compilación e Instalación Local de `.apk` en Segundos (`godot_apk_build_deploy`):** Usa **`godot 4.7` headless parcheado** + extractor inteligente HTTP-Range (descarga solo ~120 MB de plantilla Android ahorrando **>1 GB**) + firma `apksigner` v2 e inyección automática de tus `.so` en `lib/arm64-v8a/` para instalar y jugar al instante vía `rish` sin tocar la nube.
> - **Shaders Vulkan (`.gdshader`) + `MultiMesh` GPU Instancing (`godot_shader_and_world`):** Terreno *splatmap* multicapa con *Fog of War* en GPU, agua estilizada, *toon/cel-shading*, PBR neón con *glow* y escenas `MultiMeshInstance3D` capaces de dibujar **500–5,000 unidades 3D en 1 solo *draw call***.
> - **Live Debugger 144 Hz (`android_game_profiler`):** Detecta la tasa real de pantalla (`SurfaceFlinger` 60/120/144 Hz) y captura en vivo `logcat -s godot` (errores `GDScript`, trazas de `GDExtension`, Vulkan y RAM `PSS`).

---

## Las 16 Herramientas MCP Nativas en Rust

| Herramienta | Departamento | Función Nativa ARM64 |
| :--- | :--- | :--- |
| `studio_status` | Diagnóstico | Verifica motores Rust (`Rayon`, `GLB`, `WAV DSP`, `DDS/TGA`), `godot-bin` 4.7 headless, compiladores `GDExtension` (`clang`/`rustc`), plantillas APK y conexión `rish`. |
| `godot_toolchain_setup` | Auto-Instalador | Instala y parchea `godot 4.7` (`31-byte prefix`), extrae `gdextension_interface.h`, configura SDK/Keystore Android y descarga solo la plantilla Android vía HTTP Range (ahorra >1 GB). |
| `godot_scaffold_project` | Motor 2D/3D | Genera proyectos **Godot 4.7 (Vulkan PBR + Glow, 120–144 Hz)** 2D/3D con HUD táctil, preset APK válido y módulo opcional `GDExtension` (`with_gdextension: true`). |
| `godot_gdextension_build` | Núcleo C++/Rust | Compila librerías nativas `lib*.android.arm64.so` en **C/C++ o Rust** (`~1s`) y escribe `<mod>.gdextension` compatible tanto con consola local como con `.apk` Android. |
| `godot_shader_and_world` | Vulkan & GPU | Crea shaders `.gdshader` + `.tres` (`rts_splatmap_fog`, `stylized_water`, `neon_pbr_emissive`, `toon_cel_outline`) y enjambres `MultiMeshInstance3D` (1 *draw call*). |
| `godot_apk_build_deploy` | Build APK 0-Cloud | Exporta en local el `.apk` firmado `arm64-v8a` (con `libgodot_android.so` + tus `.so` de `GDExtension`), lo instala con `pm install` y lanza el juego en pantalla vía `rish`. |
| `godot_create_scene` | Escenas `.tscn` | Genera escenas `.tscn` válidas (personajes, enemigos, proyectiles, UI) con colisiones y scripts `.gd`. |
| `godot_validate_project` | QA Estático | Audita referencias `res://` rotas en `.tscn/.tres/.gd/.gdextension` y detecta texturas móviles mayores a `2048px`. |
| `sprite_pack_atlas` | Arte 2D Multinúcleo | Empaqueta en paralelo con `Rayon` sprites `.png`, `.webp`, `.tga`, `.dds`, `.bmp` y `.jpg` en un **Sprite Atlas RGBA** + `AtlasTexture` (`.tres`). |
| `sprite_process` | Pixel Art y Luz 2D | Escalado *Nearest-Neighbor*, recorte alfa, *colorkey*, **Mapas Normales 2D Sobel (`generate_normal_map`)**, corte de *spritesheets* e iconos Android. |
| `model3d_inspect_glb` | Pipeline 3D | Inspector binario `glTF 2.0` (`.glb/.gltf`): mallas, vértices, triángulos, *draw calls*, huesos (`joints`), animaciones y texturas embebidas. |
| `model3d_optimize_glb` | Pipeline 3D + LODs | Reduce texturas 2K/4K embebidas en `.glb` (PNG/JPEG/WebP) y ejecuta **decimación espacial 3D nativa de triángulos (`simplify_ratio`)**. |
| `audio_sfx_master` | Audio DSP 0-Delay | Motor DSP Rust (`hound`) para WAV de 8/16/24/32 bits: recorta silencio inicial (`0 ms` attack), normaliza a `-1.0 dBFS` y crea **bucles BGM sin clics**. |
| `gamedata_balance_sim` | Game Design | Simulador Monte Carlo ultrarrápido (hasta `100,000` duelos en ms) para *Time-To-Kill*, DPS efectivo, armadura estilo Warcraft/DotA y críticos. |
| `android_game_profiler` | Live Debugger | Perfila juegos a **60–144 Hz** vía `rish`: FPS reales, `SurfaceFlinger` Hz, `gfxinfo`, RAM `PSS`, temperatura y logs en vivo de **`logcat -s godot`**. |
| `android_godot_launch` | Lanzador | Abre **Godot 4 Android Editor** (`org.godotengine.editor.v4`) o cualquier APK compilado directamente en pantalla vía `rish`. |

---

## Comandos Rápidos en Terminal (`agy-game-studio`)

```bash
# 1. Preparar compilador local de APK (Godot 4.7 headless + plantilla Android por HTTP Range):
agy-game-studio setup

# 2. Compilar GDExtension nativo ARM64 (C/C++ o Rust) dentro de un proyecto:
agy-game-studio gdext /storage/emulated/0/Documents/Games/MiJuego cpp

# 3. Exportar APK firmado en segundos, instalar y lanzar en pantalla:
agy-game-studio export-apk /storage/emulated/0/Documents/Games/MiJuego
```
