# Game Studio 2D/3D (`game-studio` v1.1.0) — Native Rust ARM64

Estudio completo de desarrollo y *porting* de videojuegos **2D y 3D** compilado en **Rust nativo para Android ARM64 (`aarch64` / `armv8.1-a` LSE + Rayon multinúcleo)**.

Arranca en milisegundos con **`<15 MB` de RAM** sin depender de JVM ni de servidores externos, y permite activar códecs multimedia adicionales bajo demanda (`FFmpeg`, `ImageMagick`, `@gltf-transform/cli`) ejecutando `game-studio-setup`.

## Herramientas MCP Nativas en Rust (12 herramientas)

| Herramienta | Departamento | Función Nativa en Rust ARM64 |
| :--- | :--- | :--- |
| `studio_status` | Diagnóstico | Verifica motores Rust integrados (`Rayon`, `GLB`, `WAV DSP`, `DDS/TGA/WebP`), conexión en vivo con **Shizuku (`rish`)**, **Godot 4 Android** y puente con **Craft Anything + Ghidra**. |
| `godot_scaffold_project` | Motor 2D/3D | Crea proyectos completos **Godot 4.x (Vulkan Mobile, 60–120 FPS)** 2D o 3D con controles táctiles (joystick virtual + cámara táctil + botones), `GameManager` y preset Android `arm64-v8a`. |
| `godot_create_scene` | Motor 2D/3D | Genera escenas `.tscn` válidas (personajes, enemigos, proyectiles, UI) con colisiones y scripts `.gd`. |
| `godot_validate_project` | QA Estático | Audita referencias `res://` rotas en `.tscn/.tres/.gd` y detecta texturas móviles mayores a `2048px`. |
| `sprite_pack_atlas` | Arte 2D Multinúcleo | Decodifica en paralelo con `Rayon` sprites `.png`, `.webp`, `.tga`, `.dds`, `.bmp` y `.jpg` en un **Sprite Atlas RGBA** (PNG + WebP opcional), mapa `.json` y recursos `AtlasTexture` (`.tres`) para Godot 4. |
| `sprite_process` | Pixel Art e Iluminación 2D | Escalado *Nearest-Neighbor* exacto, recorte alfa, *colorkey* transparente, **generador Sobel 3x3 de Mapas Normales 2D (`generate_normal_map`)** para luz dinámica, corte por grilla e iconos Android (`mdpi`–`xxxhdpi` + `512px`). |
| `model3d_inspect_glb` | Pipeline 3D | Inspector binario `glTF 2.0` (`.glb/.gltf`): mallas, vértices, triángulos, *draw calls*, huesos (`joints`), animaciones, dimensiones de texturas embebidas y alertas de GPU móvil. |
| `model3d_optimize_glb` | Pipeline 3D + LODs | Reempaqueta binarios `.glb` reduciendo texturas 2K/4K (PNG/JPEG/WebP) **y ejecuta decimación espacial 3D nativa de triángulos (`simplify_ratio`)** para crear *LODs* móviles sin herramientas externas. |
| `audio_sfx_master` | Audio DSP 0-Delay | Motor DSP Rust (`hound`) para WAV PCM/Float de 8/16/24/32 bits: recorta silencio inicial (`0 ms` de latencia), normaliza a `-1.0 dBFS`, **crea bucles BGM sin clics (`seamless_loop_fade_ms`)** y delega `.ogg/.opus` a `FFmpeg`. |
| `gamedata_balance_sim` | Game Design | Simulador Monte Carlo ultrarrápido (hasta `100,000` combates en milisegundos) para *Time-To-Kill*, DPS efectivo, mitigación de armadura y críticos. |
| `android_game_profiler` | QA en Vivo | Perfila cualquier juego corriendo en tu Android vía **Shizuku (`rish`)**: tiempos de cuadro GPU/CPU (`p50/p90/p95/p99`), FPS reales, *jank*, memoria RAM (`PSS`), temperatura y *crashes*. |
| `android_godot_launch` | Lanzador | Abre **Godot 4 Android Editor** o tu APK compilado directamente en pantalla vía Shizuku. |

## Potenciador Multimedia Opcional

Para habilitar compresión de audio `.ogg/.opus/.mp3` (`FFmpeg`), `ImageMagick` y simplificación de mallas animadas (`@gltf-transform/cli`), ejecuta en terminal:

```bash
game-studio-setup
```
