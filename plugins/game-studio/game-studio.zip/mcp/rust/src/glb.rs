use crate::godot::{opt_bool, opt_f64, opt_i64, req_str};
use crate::system::{find_bin, round2};
use image::imageops::FilterType;
use image::{DynamicImage, GenericImageView, ImageFormat};
use serde_json::{json, Value};
use std::collections::HashMap;
use std::fs;
use std::io::Cursor;
use std::path::PathBuf;
use std::process::Command;

struct GlbBinary {
    json: Value,
    bin: Option<Vec<u8>>,
}

pub fn inspect_glb(args: &Value) -> Result<Value, String> {
    let path = PathBuf::from(req_str(args, "input_path")?);
    let raw = fs::read(&path).map_err(|e| format!("{}: {e}", path.display()))?;

    let is_gltf_text = path
        .extension()
        .and_then(|s| s.to_str())
        .map(|s| s.eq_ignore_ascii_case("gltf"))
        .unwrap_or(false);

    let parsed = if is_gltf_text {
        let j: Value = serde_json::from_slice(&raw).map_err(|e| e.to_string())?;
        GlbBinary { json: j, bin: None }
    } else {
        parse_glb(&raw)?
    };

    let gltf = &parsed.json;
    let empty = Vec::new();
    let meshes = gltf.get("meshes").and_then(|v| v.as_array()).unwrap_or(&empty);
    let accessors = gltf.get("accessors").and_then(|v| v.as_array()).unwrap_or(&empty);
    let skins = gltf.get("skins").and_then(|v| v.as_array()).unwrap_or(&empty);
    let animations = gltf.get("animations").and_then(|v| v.as_array()).unwrap_or(&empty);
    let materials = gltf.get("materials").and_then(|v| v.as_array()).unwrap_or(&empty);
    let images = gltf.get("images").and_then(|v| v.as_array()).unwrap_or(&empty);
    let bviews = gltf.get("bufferViews").and_then(|v| v.as_array()).unwrap_or(&empty);

    let mut total_verts: u64 = 0;
    let mut total_tris: u64 = 0;
    let mut draw_calls: usize = 0;

    for m in meshes {
        if let Some(prims) = m.get("primitives").and_then(|v| v.as_array()) {
            for pr in prims {
                draw_calls += 1;
                let mut v_count = 0u64;
                if let Some(pos_idx) = pr
                    .get("attributes")
                    .and_then(|a| a.get("POSITION"))
                    .and_then(|x| x.as_u64())
                {
                    if let Some(acc) = accessors.get(pos_idx as usize) {
                        v_count = acc.get("count").and_then(|c| c.as_u64()).unwrap_or(0);
                        total_verts += v_count;
                    }
                }
                if let Some(idx_acc) = pr.get("indices").and_then(|x| x.as_u64()) {
                    if let Some(acc) = accessors.get(idx_acc as usize) {
                        let ic = acc.get("count").and_then(|c| c.as_u64()).unwrap_or(0);
                        total_tris += ic / 3;
                    }
                } else {
                    total_tris += v_count / 3;
                }
            }
        }
    }

    let total_joints: usize = skins
        .iter()
        .map(|s| s.get("joints").and_then(|j| j.as_array()).map(|a| a.len()).unwrap_or(0))
        .sum();

    let mut anim_list = Vec::new();
    for a in animations {
        let name = a.get("name").and_then(|s| s.as_str()).unwrap_or("unnamed");
        let mut dur = 0.0f64;
        if let Some(samps) = a.get("samplers").and_then(|v| v.as_array()) {
            for sp in samps {
                if let Some(in_idx) = sp.get("input").and_then(|x| x.as_u64()) {
                    if let Some(acc) = accessors.get(in_idx as usize) {
                        if let Some(mx) = acc
                            .get("max")
                            .and_then(|m| m.as_array())
                            .and_then(|arr| arr.first())
                            .and_then(|v| v.as_f64())
                        {
                            dur = dur.max(mx);
                        }
                    }
                }
            }
        }
        anim_list.push(json!({ "name": name, "duration_sec": round2(dur) }));
    }

    let mut tex_list = Vec::new();
    let mut warnings = Vec::new();
    for (i, im) in images.iter().enumerate() {
        let mime = im.get("mimeType").and_then(|s| s.as_str()).unwrap_or("unknown");
        let mut dims = "external".to_string();
        let mut blen = 0usize;
        if let (Some(bin), Some(bv_idx)) = (&parsed.bin, im.get("bufferView").and_then(|x| x.as_u64())) {
            if let Some(bv) = bviews.get(bv_idx as usize) {
                let off = bv.get("byteOffset").and_then(|x| x.as_u64()).unwrap_or(0) as usize;
                blen = bv.get("byteLength").and_then(|x| x.as_u64()).unwrap_or(0) as usize;
                if off + blen <= bin.len() {
                    if let Ok(img) = image::load_from_memory(&bin[off..off + blen]) {
                        let (w, h) = img.dimensions();
                        dims = format!("{w}x{h}");
                        if w > 2048 || h > 2048 {
                            warnings.push(format!(
                                "Embedded texture #{i} is {w}x{h} (>2K); run model3d_optimize_glb to reduce mobile VRAM."
                            ));
                        }
                    }
                }
            }
        }
        tex_list.push(json!({
            "index": i,
            "mime": mime,
            "dimensions": dims,
            "bytes": blen
        }));
    }

    if total_tris > 35_000 {
        warnings.push(format!(
            "High triangle count ({total_tris}) for mobile GPU; pass simplify_ratio (e.g. 0.5) to model3d_optimize_glb for LODs."
        ));
    }
    if draw_calls > 12 {
        warnings.push(format!(
            "Model uses {draw_calls} draw calls; combine static primitives/materials for 60-120 FPS."
        ));
    }

    Ok(json!({
        "file": path.to_string_lossy(),
        "file_size_kb": raw.len() / 1024,
        "meshes": meshes.len(),
        "draw_calls": draw_calls,
        "vertices": total_verts,
        "triangles": total_tris,
        "skeleton_joints": total_joints,
        "materials": materials.len(),
        "animations": anim_list,
        "textures": tex_list,
        "mobile_gpu_warnings": warnings
    }))
}

pub fn optimize_glb(args: &Value) -> Result<Value, String> {
    let mut in_path = PathBuf::from(req_str(args, "input_path")?);
    let out_path = PathBuf::from(req_str(args, "output_path")?);
    let max_tex = opt_i64(args, "max_texture_size", 1024).max(64) as u32;
    let simplify_ratio = opt_f64(args, "simplify_ratio", 1.0).clamp(0.05, 1.0);
    let convert_webp = opt_bool(args, "webp_textures", false);

    if let Some(parent) = out_path.parent() {
        fs::create_dir_all(parent).map_err(|e| e.to_string())?;
    }
    let orig_bytes = fs::metadata(&in_path).map_err(|e| e.to_string())?.len();
    let mut used_external_gltf = false;

    if simplify_ratio < 0.999 {
        if let Some(gt_bin) = find_bin("gltf-transform") {
            let status = Command::new(gt_bin)
                .args([
                    "simplify",
                    &in_path.to_string_lossy(),
                    &out_path.to_string_lossy(),
                    "--ratio",
                    &format!("{simplify_ratio:.2}"),
                ])
                .status();
            if status.map(|s| s.success()).unwrap_or(false) && out_path.exists() {
                in_path = out_path.clone();
                used_external_gltf = true;
            }
        }
    }

    let raw = fs::read(&in_path).map_err(|e| e.to_string())?;
    let mut parsed = parse_glb(&raw)?;
    let mut resized_textures = 0usize;
    let mut decimated_tris_before = 0usize;
    let mut decimated_tris_after = 0usize;

    if let Some(bin) = parsed.bin.take() {
        let mut replacements: HashMap<usize, Vec<u8>> = HashMap::new();

        // 1. Native Rust spatial vertex-clustering LOD decimator if simplify_ratio < 1.0 and gltf-transform wasn't used
        if simplify_ratio < 0.999 && !used_external_gltf {
            decimate_static_meshes_in_place(
                &mut parsed.json,
                &bin,
                simplify_ratio,
                &mut replacements,
                &mut decimated_tris_before,
                &mut decimated_tris_after,
            );
        }

        // 2. Native Rust embedded texture downscaler & optional WebP encoder
        let bviews_snapshot = parsed
            .json
            .get("bufferViews")
            .and_then(|v| v.as_array())
            .cloned()
            .unwrap_or_default();

        if let Some(images) = parsed.json.get_mut("images").and_then(|v| v.as_array_mut()) {
            for im in images.iter_mut() {
                if let Some(bv_idx) = im.get("bufferView").and_then(|x| x.as_u64()) {
                    let idx = bv_idx as usize;
                    if let Some(bv) = bviews_snapshot.get(idx) {
                        let off = bv.get("byteOffset").and_then(|x| x.as_u64()).unwrap_or(0) as usize;
                        let len = bv.get("byteLength").and_then(|x| x.as_u64()).unwrap_or(0) as usize;
                        if off + len <= bin.len() {
                            if let Ok(decoded) = image::load_from_memory(&bin[off..off + len]) {
                                let (w, h) = decoded.dimensions();
                                let needs_resize = w > max_tex || h > max_tex;
                                if needs_resize || convert_webp {
                                    let target_img: DynamicImage = if needs_resize {
                                        let scale = (max_tex as f64) / (w.max(h) as f64);
                                        let nw = ((w as f64 * scale).round() as u32).max(1);
                                        let nh = ((h as f64 * scale).round() as u32).max(1);
                                        decoded.resize_exact(nw, nh, FilterType::Lanczos3)
                                    } else {
                                        decoded
                                    };
                                    let mut buf = Cursor::new(Vec::new());
                                    if convert_webp {
                                        target_img.write_to(&mut buf, ImageFormat::WebP).map_err(|e| e.to_string())?;
                                        im["mimeType"] = json!("image/webp");
                                    } else {
                                        let cur_mime = im.get("mimeType").and_then(|s| s.as_str()).unwrap_or("image/png");
                                        let fmt = if cur_mime.contains("jpeg") { ImageFormat::Jpeg } else { ImageFormat::Png };
                                        target_img.write_to(&mut buf, fmt).map_err(|e| e.to_string())?;
                                    }
                                    replacements.insert(idx, buf.into_inner());
                                    resized_textures += 1;
                                }
                            }
                        }
                    }
                }
            }
        }

        if !replacements.is_empty() {
            let mut new_bin = Vec::with_capacity(bin.len());
            if let Some(bviews) = parsed.json.get_mut("bufferViews").and_then(|v| v.as_array_mut()) {
                for (i, bv) in bviews.iter_mut().enumerate() {
                    let old_off = bv.get("byteOffset").and_then(|x| x.as_u64()).unwrap_or(0) as usize;
                    let old_len = bv.get("byteLength").and_then(|x| x.as_u64()).unwrap_or(0) as usize;
                    while new_bin.len() % 4 != 0 {
                        new_bin.push(0);
                    }
                    let new_off = new_bin.len();
                    if let Some(rep) = replacements.get(&i) {
                        new_bin.extend_from_slice(rep);
                        bv["byteOffset"] = json!(new_off);
                        bv["byteLength"] = json!(rep.len());
                    } else if old_off + old_len <= bin.len() {
                        new_bin.extend_from_slice(&bin[old_off..old_off + old_len]);
                        bv["byteOffset"] = json!(new_off);
                        bv["byteLength"] = json!(old_len);
                    }
                }
            }
            if let Some(buf0) = parsed
                .json
                .get_mut("buffers")
                .and_then(|v| v.as_array_mut())
                .and_then(|a| a.first_mut())
            {
                buf0["byteLength"] = json!(new_bin.len());
            }
            write_glb(&out_path, &parsed.json, Some(&new_bin))?;
        } else if in_path != out_path {
            fs::copy(&in_path, &out_path).map_err(|e| e.to_string())?;
        }
    } else if in_path != out_path {
        fs::copy(&in_path, &out_path).map_err(|e| e.to_string())?;
    }

    let new_bytes = fs::metadata(&out_path).map_err(|e| e.to_string())?.len();
    let saved = if orig_bytes > 0 {
        round2((1.0 - (new_bytes as f64 / orig_bytes as f64)) * 100.0)
    } else {
        0.0
    };

    Ok(json!({
        "status": "optimized",
        "engine": if used_external_gltf { "gltf_transform_plus_rust" } else { "rust_arm64_native" },
        "output_path": out_path.to_string_lossy(),
        "textures_optimized": resized_textures,
        "max_texture_size": max_tex,
        "triangles_before_lod": decimated_tris_before,
        "triangles_after_lod": decimated_tris_after,
        "original_bytes": orig_bytes,
        "optimized_bytes": new_bytes,
        "saved_percent": saved
    }))
}

/// Pure-Rust 3D spatial grid vertex-clustering LOD simplifier for indexed float32 VEC3 triangle meshes.
fn decimate_static_meshes_in_place(
    gltf: &mut Value,
    bin: &[u8],
    ratio: f64,
    replacements: &mut HashMap<usize, Vec<u8>>,
    tris_before: &mut usize,
    tris_after: &mut usize,
) {
    let bviews = match gltf.get("bufferViews").and_then(|v| v.as_array()) {
        Some(v) => v.clone(),
        None => return,
    };
    let mut accessors = match gltf.get("accessors").and_then(|v| v.as_array()) {
        Some(v) => v.clone(),
        None => return,
    };
    let meshes = match gltf.get("meshes").and_then(|v| v.as_array()) {
        Some(v) => v.clone(),
        None => return,
    };

    for m in &meshes {
        let prims = match m.get("primitives").and_then(|v| v.as_array()) {
            Some(p) => p,
            None => continue,
        };
        for pr in prims {
            // Skip skinned meshes with JOINTS_0 so rig weights stay intact unless using gltf-transform
            if pr.get("attributes").and_then(|a| a.get("JOINTS_0")).is_some() {
                continue;
            }
            let pos_acc_idx = match pr
                .get("attributes")
                .and_then(|a| a.get("POSITION"))
                .and_then(|x| x.as_u64())
            {
                Some(i) => i as usize,
                None => continue,
            };
            let idx_acc_idx = match pr.get("indices").and_then(|x| x.as_u64()) {
                Some(i) => i as usize,
                None => continue,
            };

            let pos_acc = match accessors.get(pos_acc_idx) {
                Some(a) => a,
                None => continue,
            };
            let idx_acc = match accessors.get(idx_acc_idx) {
                Some(a) => a,
                None => continue,
            };

            if pos_acc.get("componentType").and_then(|c| c.as_u64()) != Some(5126)
                || pos_acc.get("type").and_then(|s| s.as_str()) != Some("VEC3")
                || pos_acc.get("byteOffset").and_then(|o| o.as_u64()).unwrap_or(0) != 0
                || idx_acc.get("byteOffset").and_then(|o| o.as_u64()).unwrap_or(0) != 0
            {
                continue;
            }

            let pos_bv = match pos_acc.get("bufferView").and_then(|x| x.as_u64()) {
                Some(i) => i as usize,
                None => continue,
            };
            let idx_bv = match idx_acc.get("bufferView").and_then(|x| x.as_u64()) {
                Some(i) => i as usize,
                None => continue,
            };
            if pos_bv == idx_bv || bviews.get(pos_bv).and_then(|b| b.get("byteStride")).is_some() {
                continue;
            }

            let v_count = pos_acc.get("count").and_then(|c| c.as_u64()).unwrap_or(0) as usize;
            let p_off = bviews[pos_bv].get("byteOffset").and_then(|x| x.as_u64()).unwrap_or(0) as usize;
            let p_len = bviews[pos_bv].get("byteLength").and_then(|x| x.as_u64()).unwrap_or(0) as usize;
            if v_count < 12 || p_len < v_count * 12 || p_off + p_len > bin.len() {
                continue;
            }

            let idx_comp = idx_acc.get("componentType").and_then(|c| c.as_u64()).unwrap_or(0);
            let idx_count = idx_acc.get("count").and_then(|c| c.as_u64()).unwrap_or(0) as usize;
            let i_off = bviews[idx_bv].get("byteOffset").and_then(|x| x.as_u64()).unwrap_or(0) as usize;
            let i_len = bviews[idx_bv].get("byteLength").and_then(|x| x.as_u64()).unwrap_or(0) as usize;
            if idx_count < 12 || i_off + i_len > bin.len() {
                continue;
            }

            let mut verts = Vec::with_capacity(v_count);
            let mut min_b = [f32::INFINITY; 3];
            let mut max_b = [f32::NEG_INFINITY; 3];
            for v in 0..v_count {
                let base = p_off + v * 12;
                let x = f32::from_le_bytes(bin[base..base + 4].try_into().unwrap());
                let y = f32::from_le_bytes(bin[base + 4..base + 8].try_into().unwrap());
                let z = f32::from_le_bytes(bin[base + 8..base + 12].try_into().unwrap());
                for k in 0..3 {
                    let val = [x, y, z][k];
                    min_b[k] = min_b[k].min(val);
                    max_b[k] = max_b[k].max(val);
                }
                verts.push([x, y, z]);
            }

            let mut indices = Vec::with_capacity(idx_count);
            match idx_comp {
                5123 if i_len >= idx_count * 2 => {
                    for i in 0..idx_count {
                        let b = i_off + i * 2;
                        indices.push(u16::from_le_bytes([bin[b], bin[b + 1]]) as u32);
                    }
                }
                5125 if i_len >= idx_count * 4 => {
                    for i in 0..idx_count {
                        let b = i_off + i * 4;
                        indices.push(u32::from_le_bytes(bin[b..b + 4].try_into().unwrap()));
                    }
                }
                _ => continue,
            }

            let grid_res = ((v_count as f64 * ratio).cbrt().round() as i32).clamp(4, 256) as f32;
            let span = [
                (max_b[0] - min_b[0]).max(1e-5),
                (max_b[1] - min_b[1]).max(1e-5),
                (max_b[2] - min_b[2]).max(1e-5),
            ];

            let mut cell_rep: HashMap<(i32, i32, i32), u32> = HashMap::new();
            let mut remap = vec![0u32; v_count];
            for (vi, p) in verts.iter().enumerate() {
                let key = (
                    (((p[0] - min_b[0]) / span[0]) * grid_res) as i32,
                    (((p[1] - min_b[1]) / span[1]) * grid_res) as i32,
                    (((p[2] - min_b[2]) / span[2]) * grid_res) as i32,
                );
                let rep = *cell_rep.entry(key).or_insert(vi as u32);
                remap[vi] = rep;
            }

            let orig_tris = indices.len() / 3;
            let mut new_indices = Vec::with_capacity(indices.len());
            for tri in indices.chunks_exact(3) {
                let a = remap.get(tri[0] as usize).copied().unwrap_or(tri[0]);
                let b = remap.get(tri[1] as usize).copied().unwrap_or(tri[1]);
                let c = remap.get(tri[2] as usize).copied().unwrap_or(tri[2]);
                if a != b && b != c && a != c {
                    new_indices.extend_from_slice(&[a, b, c]);
                }
            }

            if !new_indices.is_empty() && new_indices.len() < indices.len() {
                *tris_before += orig_tris;
                *tris_after += new_indices.len() / 3;
                let mut ibuf = Vec::new();
                if idx_comp == 5123 {
                    for &id in &new_indices {
                        ibuf.extend_from_slice(&(id as u16).to_le_bytes());
                    }
                } else {
                    for &id in &new_indices {
                        ibuf.extend_from_slice(&id.to_le_bytes());
                    }
                }
                replacements.insert(idx_bv, ibuf);
                accessors[idx_acc_idx]["count"] = json!(new_indices.len());
            }
        }
    }
    gltf["accessors"] = Value::Array(accessors);
}

fn parse_glb(raw: &[u8]) -> Result<GlbBinary, String> {
    if raw.len() < 20 {
        return Err("Invalid GLB: shorter than 20-byte header".into());
    }
    let magic = u32::from_le_bytes(raw[0..4].try_into().unwrap());
    let ver = u32::from_le_bytes(raw[4..8].try_into().unwrap());
    if magic != 0x4654_6C67 || ver != 2 {
        return Err("Unsupported GLB header (expected glTF 2.0 binary)".into());
    }
    let json_len = u32::from_le_bytes(raw[12..16].try_into().unwrap()) as usize;
    let json_type = u32::from_le_bytes(raw[16..20].try_into().unwrap());
    if json_type != 0x4E4F_534A || 20 + json_len > raw.len() {
        return Err("Malformed GLB JSON chunk".into());
    }
    let json_val: Value = serde_json::from_slice(&raw[20..20 + json_len]).map_err(|e| e.to_string())?;

    let mut pos = 20 + json_len;
    let mut bin_chunk = None;
    if pos + 8 <= raw.len() {
        let bin_len = u32::from_le_bytes(raw[pos..pos + 4].try_into().unwrap()) as usize;
        let bin_type = u32::from_le_bytes(raw[pos + 4..pos + 8].try_into().unwrap());
        pos += 8;
        if bin_type == 0x004E_4942 && pos + bin_len <= raw.len() {
            bin_chunk = Some(raw[pos..pos + bin_len].to_vec());
        }
    }

    Ok(GlbBinary {
        json: json_val,
        bin: bin_chunk,
    })
}

fn write_glb(out: &PathBuf, json_val: &Value, bin: Option<&[u8]>) -> Result<(), String> {
    let mut jbytes = serde_json::to_vec(json_val).map_err(|e| e.to_string())?;
    while jbytes.len() % 4 != 0 {
        jbytes.push(0x20);
    }

    let mut bpad = 0usize;
    let blen = if let Some(b) = bin {
        bpad = (4 - (b.len() % 4)) % 4;
        b.len() + bpad
    } else {
        0
    };

    let total_len = 12 + 8 + jbytes.len() + if bin.is_some() { 8 + blen } else { 0 };
    let mut out_buf = Vec::with_capacity(total_len);
    out_buf.extend_from_slice(&0x4654_6C67u32.to_le_bytes());
    out_buf.extend_from_slice(&2u32.to_le_bytes());
    out_buf.extend_from_slice(&(total_len as u32).to_le_bytes());

    out_buf.extend_from_slice(&(jbytes.len() as u32).to_le_bytes());
    out_buf.extend_from_slice(&0x4E4F_534Au32.to_le_bytes());
    out_buf.extend_from_slice(&jbytes);

    if let Some(b) = bin {
        out_buf.extend_from_slice(&(blen as u32).to_le_bytes());
        out_buf.extend_from_slice(&0x004E_4942u32.to_le_bytes());
        out_buf.extend_from_slice(b);
        for _ in 0..bpad {
            out_buf.push(0);
        }
    }

    fs::write(out, out_buf).map_err(|e| e.to_string())
}
