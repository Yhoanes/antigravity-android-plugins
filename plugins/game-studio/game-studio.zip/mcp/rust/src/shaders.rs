use crate::godot::{opt_i64, opt_str, req_str};
use serde_json::{json, Value};
use std::fs;
use std::path::PathBuf;

/// Generates production-ready Godot 4 Vulkan Mobile `.gdshader` shaders, `.tres` ShaderMaterials,
/// and optional `MultiMeshInstance3D` GPU-instanced crowd/world scenes (500–5,000 instances in 1 draw call).
pub fn shader_and_world(args: &Value) -> Result<Value, String> {
    let project_dir = PathBuf::from(req_str(args, "project_dir")?);
    if !project_dir.join("project.godot").is_file() {
        return Err(format!("project.godot not found in {}", project_dir.display()));
    }

    let preset = opt_str(args, "preset", "rts_splatmap_fog").to_lowercase();
    let base_name: String = opt_str(args, "name", &preset)
        .chars()
        .filter(|c| c.is_ascii_alphanumeric() || *c == '_')
        .collect();
    let base_name = if base_name.is_empty() { "custom_effect".to_string() } else { base_name };

    let shaders_dir = project_dir.join("assets/shaders");
    fs::create_dir_all(&shaders_dir).map_err(|e| e.to_string())?;

    let mut created_files = Vec::new();
    let shader_rel = format!("assets/shaders/{base_name}.gdshader");
    let mat_rel = format!("assets/shaders/{base_name}_mat.tres");
    let shader_path = project_dir.join(&shader_rel);
    let mat_path = project_dir.join(&mat_rel);

    let (shader_code, mat_params) = match preset.as_str() {
        "rts_splatmap_fog" => (
            r#"shader_type spatial;
render_mode blend_mix, depth_draw_opaque, cull_back, diffuse_burley, specular_schlick_ggx;

// Warcraft/MOBA 4-biome terrain splatmap + live GPU Fog-of-War mask
uniform vec4 grass_color : source_color = vec4(0.16, 0.42, 0.18, 1.0);
uniform vec4 dirt_color : source_color = vec4(0.38, 0.27, 0.16, 1.0);
uniform vec4 rock_color : source_color = vec4(0.28, 0.30, 0.34, 1.0);
uniform vec4 river_color : source_color = vec4(0.08, 0.34, 0.52, 1.0);
uniform float tile_scale : hint_range(1.0, 64.0) = 12.0;
uniform vec2 vision_center = vec2(0.0, 0.0);
uniform float vision_radius : hint_range(2.0, 80.0) = 18.0;
uniform float fog_darkness : hint_range(0.0, 0.95) = 0.72;

varying vec3 v_world_pos;

float hash21(vec2 p) {
	p = fract(p * vec2(123.34, 456.21));
	p += dot(p, p + 45.32);
	return fract(p.x * p.y);
}

void vertex() {
	v_world_pos = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz;
}

void fragment() {
	vec2 uv_tiled = UV * tile_scale;
	float n = hash21(floor(uv_tiled)) * 0.35 + 0.65;
	float lane_mask = smoothstep(3.5, 1.2, abs(v_world_pos.x - v_world_pos.z));
	float river_mask = smoothstep(2.8, 0.8, abs(v_world_pos.x + v_world_pos.z));

	vec3 col = mix(grass_color.rgb * n, dirt_color.rgb, lane_mask);
	col = mix(col, rock_color.rgb, clamp(v_world_pos.y * 0.35, 0.0, 1.0));
	col = mix(col, river_color.rgb, river_mask);

	// Smooth GPU Fog of War around active hero/unit vision center
	float dist = distance(v_world_pos.xz, vision_center);
	float fog = smoothstep(vision_radius * 0.78, vision_radius, dist);
	ALBEDO = mix(col, col * (1.0 - fog_darkness), fog);
	ROUGHNESS = mix(0.85, 0.22, river_mask);
	METALLIC = river_mask * 0.25;
}
"#
            .to_string(),
            "shader_parameter/vision_radius = 18.0\nshader_parameter/fog_darkness = 0.72\n".to_string(),
        ),
        "stylized_water" => (
            r#"shader_type spatial;
render_mode blend_mix, depth_draw_always, cull_back, specular_schlick_ggx;

uniform vec4 shallow_color : source_color = vec4(0.08, 0.68, 0.78, 0.82);
uniform vec4 deep_color : source_color = vec4(0.03, 0.20, 0.42, 0.94);
uniform float wave_speed : hint_range(0.1, 6.0) = 1.6;
uniform float wave_height : hint_range(0.0, 0.8) = 0.09;

void vertex() {
	float w1 = sin(VERTEX.x * 1.4 + TIME * wave_speed);
	float w2 = cos(VERTEX.z * 1.7 + TIME * wave_speed * 0.85);
	VERTEX.y += (w1 + w2) * 0.5 * wave_height;
}

void fragment() {
	float ripple = sin(UV.x * 42.0 + TIME * wave_speed * 2.0) * cos(UV.y * 42.0 - TIME * wave_speed * 1.5);
	float foam = smoothstep(0.65, 0.95, ripple);
	vec3 base = mix(deep_color.rgb, shallow_color.rgb, 0.55 + 0.35 * ripple);
	ALBEDO = mix(base, vec3(0.92, 0.98, 1.0), foam * 0.45);
	ROUGHNESS = 0.08;
	METALLIC = 0.15;
	ALPHA = shallow_color.a;
}
"#
            .to_string(),
            "shader_parameter/wave_speed = 1.6\nshader_parameter/wave_height = 0.09\n".to_string(),
        ),
        "toon_cel_outline" => (
            r#"shader_type spatial;
render_mode diffuse_toon, specular_toon, cull_back;

uniform vec4 base_color : source_color = vec4(0.22, 0.62, 0.98, 1.0);
uniform vec4 rim_color : source_color = vec4(0.65, 0.90, 1.0, 1.0);
uniform float rim_power : hint_range(0.5, 8.0) = 3.2;

void fragment() {
	float fresnel = pow(1.0 - clamp(dot(NORMAL, VIEW), 0.0, 1.0), rim_power);
	ALBEDO = base_color.rgb;
	EMISSION = rim_color.rgb * fresnel * 0.55;
	ROUGHNESS = 0.45;
}
"#
            .to_string(),
            "shader_parameter/rim_power = 3.2\n".to_string(),
        ),
        _ => (
            r#"shader_type spatial;
render_mode blend_mix, depth_draw_opaque, cull_back, specular_schlick_ggx;

uniform vec4 albedo_color : source_color = vec4(0.08, 0.85, 1.0, 1.0);
uniform vec4 glow_color : source_color = vec4(0.15, 0.95, 1.0, 1.0);
uniform float glow_energy : hint_range(0.0, 12.0) = 2.8;
uniform float pulse_speed : hint_range(0.0, 10.0) = 2.4;

void fragment() {
	float fresnel = pow(1.0 - clamp(dot(NORMAL, VIEW), 0.0, 1.0), 2.4);
	float pulse = 0.78 + 0.22 * sin(TIME * pulse_speed);
	ALBEDO = albedo_color.rgb;
	EMISSION = glow_color.rgb * (0.35 + fresnel * 0.95) * glow_energy * pulse;
	METALLIC = 0.35;
	ROUGHNESS = 0.22;
}
"#
            .to_string(),
            "shader_parameter/glow_energy = 2.8\nshader_parameter/pulse_speed = 2.4\n".to_string(),
        ),
    };

    let custom_code = opt_str(args, "custom_gdshader", "");
    let final_shader = if custom_code.trim().is_empty() { shader_code } else { custom_code };
    fs::write(&shader_path, &final_shader).map_err(|e| e.to_string())?;
    created_files.push(shader_path.to_string_lossy().to_string());

    let mat_tres = format!(
        "[gd_resource type=\"ShaderMaterial\" load_steps=2 format=3]\n\n\
         [ext_resource type=\"Shader\" path=\"res://{shader_rel}\" id=\"1_shd\"]\n\n\
         [resource]\n\
         shader = ExtResource(\"1_shd\")\n\
         {mat_params}"
    );
    fs::write(&mat_path, mat_tres).map_err(|e| e.to_string())?;
    created_files.push(mat_path.to_string_lossy().to_string());

    let mut crowd_scene_out = Value::Null;
    if preset == "multimesh_crowd" || opt_i64(args, "multimesh_instance_count", 0) > 0 {
        let count = opt_i64(args, "multimesh_instance_count", 400).clamp(16, 10_000);
        let scenes_dir = project_dir.join("scenes/entities");
        let scripts_dir = project_dir.join("scripts/entities");
        fs::create_dir_all(&scenes_dir).map_err(|e| e.to_string())?;
        fs::create_dir_all(&scripts_dir).map_err(|e| e.to_string())?;

        let mm_gd_rel = format!("scripts/entities/{base_name}_swarm.gd");
        let mm_tscn_rel = format!("scenes/entities/{base_name}_swarm.tscn");

        let mm_gd = format!(
            "extends MultiMeshInstance3D\n\
             ## GPU-Instanced Swarm ({count} 3D units in 1 single Vulkan draw call).\n\
             ## Automatically uses NativeMobaCore GDExtension (ARM64 C++/Rust) when loaded!\n\n\
             @export var instance_count: int = {count}\n\
             @export var arena_radius: float = 24.0\n\n\
             var _native_core: Object = null\n\
             var _positions: PackedVector3Array = PackedVector3Array()\n\
             var _velocities: PackedVector3Array = PackedVector3Array()\n\
             var last_sim_usec: float = 0.0\n\n\
             func _ready() -> void:\n\
             \tmultimesh.transform_format = MultiMesh.TRANSFORM_3D\n\
             \tmultimesh.instance_count = instance_count\n\
             \t_positions.resize(instance_count)\n\
             \t_velocities.resize(instance_count)\n\
             \tfor i in range(instance_count):\n\
             \t\tvar ang := float(i) * 0.381966\n\
             \t\tvar r := 2.5 + sqrt(float(i) / float(instance_count)) * arena_radius\n\
             \t\tvar p := Vector3(cos(ang) * r, 0.55, sin(ang) * r)\n\
             \t\t_positions[i] = p\n\
             \t\t_velocities[i] = Vector3(-sin(ang), 0.0, cos(ang)) * 4.2\n\
             \t\tmultimesh.set_instance_transform(i, Transform3D(Basis.IDENTITY, p))\n\
             \tif ClassDB.class_exists(&\"NativeMobaCore\"):\n\
             \t\t_native_core = ClassDB.instantiate(&\"NativeMobaCore\")\n\
             \t\tprint(\"[GameStudio] NativeMobaCore GDExtension active: \", _native_core.call(\"get_backend_info\"))\n\n\
             func _process(delta: float) -> void:\n\
             \tvar t0 := Time.get_ticks_usec()\n\
             \tif _native_core != null:\n\
             \t\tlast_sim_usec = float(_native_core.call(\"step_moba_simulation\", instance_count, delta))\n\
             \tfor i in range(instance_count):\n\
             \t\tvar p := _positions[i] + _velocities[i] * delta\n\
             \t\tif Vector2(p.x, p.z).length() > arena_radius:\n\
             \t\t\t_velocities[i] = -_velocities[i]\n\
             \t\t\tp = _positions[i] + _velocities[i] * delta\n\
             \t\t_positions[i] = p\n\
             \t\tmultimesh.set_instance_transform(i, Transform3D(Basis.IDENTITY, p))\n\
             \tif _native_core == null:\n\
             \t\tlast_sim_usec = float(Time.get_ticks_usec() - t0)\n\n\
             func _exit_tree() -> void:\n\
             \tif _native_core != null:\n\
             \t\t_native_core.free()\n\
             \t\t_native_core = null\n"
        );
        fs::write(project_dir.join(&mm_gd_rel), mm_gd).map_err(|e| e.to_string())?;
        created_files.push(project_dir.join(&mm_gd_rel).to_string_lossy().to_string());

        let mm_tscn = format!(
            "[gd_scene load_steps=5 format=3]\n\n\
             [ext_resource type=\"Material\" path=\"res://{mat_rel}\" id=\"1_mat\"]\n\
             [ext_resource type=\"Script\" path=\"res://{mm_gd_rel}\" id=\"2_scr\"]\n\n\
             [sub_resource type=\"CapsuleMesh\" id=\"UnitMesh_1\"]\n\
             radius = 0.32\n\
             height = 1.1\n\
             material = ExtResource(\"1_mat\")\n\n\
             [sub_resource type=\"MultiMesh\" id=\"SwarmMM_1\"]\n\
             transform_format = 1\n\
             mesh = SubResource(\"UnitMesh_1\")\n\n\
             [node name=\"SwarmMultiMesh\" type=\"MultiMeshInstance3D\"]\n\
             multimesh = SubResource(\"SwarmMM_1\")\n\
             script = ExtResource(\"2_scr\")\n"
        );
        fs::write(project_dir.join(&mm_tscn_rel), mm_tscn).map_err(|e| e.to_string())?;
        created_files.push(project_dir.join(&mm_tscn_rel).to_string_lossy().to_string());

        crowd_scene_out = json!({
            "scene_res": format!("res://{mm_tscn_rel}"),
            "script_res": format!("res://{mm_gd_rel}"),
            "instance_count": count
        });
    }

    Ok(json!({
        "status": "ok",
        "preset": preset,
        "shader_res": format!("res://{shader_rel}"),
        "material_res": format!("res://{mat_rel}"),
        "multimesh_swarm": crowd_scene_out,
        "files_created": created_files
    }))
}
