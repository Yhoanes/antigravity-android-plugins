use crate::godot::{opt_bool, opt_f64, opt_i64, opt_str, req_str};
use image::imageops::{self, FilterType};
use image::{DynamicImage, GenericImage, Rgba, RgbaImage};
use rayon::prelude::*;
use serde_json::{json, Map, Value};
use std::fs;
use std::path::{Path, PathBuf};

struct PackedSprite {
    name: String,
    img: RgbaImage,
    orig_w: u32,
    orig_h: u32,
    trim_x: u32,
    trim_y: u32,
    px: u32,
    py: u32,
}

pub fn pack_atlas(args: &Value) -> Result<Value, String> {
    let in_dir = PathBuf::from(req_str(args, "input_dir")?);
    let out_png = PathBuf::from(req_str(args, "output_atlas_png")?);
    let padding = opt_i64(args, "padding", 2).max(0) as u32;
    let trim = opt_bool(args, "trim_alpha", true);
    let pot = opt_bool(args, "power_of_two", true);
    let export_webp = opt_bool(args, "also_export_webp", false);
    let godot_proj = opt_str(args, "godot_project_dir", "");

    if !in_dir.is_dir() {
        return Err(format!("input_dir does not exist: {}", in_dir.display()));
    }

    let mut paths: Vec<PathBuf> = fs::read_dir(&in_dir)
        .map_err(|e| e.to_string())?
        .flatten()
        .map(|e| e.path())
        .filter(|p| p.is_file() && p != &out_png && is_supported_img(p))
        .collect();
    paths.sort();

    if paths.is_empty() {
        return Err(format!("No supported sprite images found in {}", in_dir.display()));
    }

    // Parallel decode & alpha-trim across ARM64 cores via rayon
    let decoded: Vec<Result<PackedSprite, String>> = paths
        .par_iter()
        .map(|p| {
            let dyn_img = image::open(p).map_err(|e| format!("{}: {e}", p.display()))?;
            let rgba = dyn_img.to_rgba8();
            let (orig_w, orig_h) = rgba.dimensions();
            let stem = p
                .file_stem()
                .and_then(|s| s.to_str())
                .unwrap_or("sprite")
                .to_string();
            let (trim_x, trim_y, cropped) = if trim {
                let (bx, by, bw, bh) = alpha_bounds(&rgba);
                (bx, by, imageops::crop_imm(&rgba, bx, by, bw, bh).to_image())
            } else {
                (0, 0, rgba)
            };
            Ok(PackedSprite {
                name: stem,
                img: cropped,
                orig_w,
                orig_h,
                trim_x,
                trim_y,
                px: 0,
                py: 0,
            })
        })
        .collect();

    let mut sprites = Vec::with_capacity(decoded.len());
    for item in decoded {
        sprites.push(item?);
    }

    sprites.sort_by(|a, b| b.img.height().cmp(&a.img.height()));

    let mut total_area: u64 = 0;
    let mut max_w: u32 = 1;
    for s in &sprites {
        let w = s.img.width() + padding * 2;
        let h = s.img.height() + padding * 2;
        max_w = max_w.max(w);
        total_area += (w as u64) * (h as u64);
    }

    let mut target_w = max_w.max(((total_area as f64) * 1.15).sqrt().ceil() as u32);
    if pot {
        target_w = target_w.next_power_of_two();
    }

    let mut cur_x = padding;
    let mut cur_y = padding;
    let mut shelf_h = 0u32;
    let mut used_w = 1u32;

    for s in &mut sprites {
        let sw = s.img.width();
        let sh = s.img.height();
        if cur_x + sw + padding > target_w {
            cur_x = padding;
            cur_y += shelf_h + padding;
            shelf_h = 0;
        }
        s.px = cur_x;
        s.py = cur_y;
        cur_x += sw + padding;
        shelf_h = shelf_h.max(sh);
        used_w = used_w.max(cur_x);
    }

    let final_w = if pot { used_w.next_power_of_two() } else { used_w.max(1) };
    let raw_h = (cur_y + shelf_h + padding).max(1);
    let final_h = if pot { raw_h.next_power_of_two() } else { raw_h };

    let mut atlas = RgbaImage::new(final_w, final_h);
    let mut frames_map = Map::new();

    for s in &sprites {
        atlas.copy_from(&s.img, s.px, s.py).map_err(|e| e.to_string())?;
        frames_map.insert(
            s.name.clone(),
            json!({
                "frame": { "x": s.px, "y": s.py, "w": s.img.width(), "h": s.img.height() },
                "spriteSourceSize": { "x": s.trim_x, "y": s.trim_y, "w": s.img.width(), "h": s.img.height() },
                "sourceSize": { "w": s.orig_w, "h": s.orig_h }
            }),
        );
    }

    if let Some(parent) = out_png.parent() {
        fs::create_dir_all(parent).map_err(|e| e.to_string())?;
    }
    atlas.save(&out_png).map_err(|e| e.to_string())?;

    let mut webp_out_str = None;
    if export_webp {
        let webp_path = out_png.with_extension("webp");
        DynamicImage::ImageRgba8(atlas.clone())
            .save(&webp_path)
            .map_err(|e| e.to_string())?;
        webp_out_str = Some(webp_path.to_string_lossy().to_string());
    }

    let json_path = out_png.with_extension("json");
    let meta_doc = json!({
        "meta": {
            "generator": "Antigravity Game Studio Rust ARM64",
            "image": out_png.file_name().and_then(|s| s.to_str()).unwrap_or("atlas.png"),
            "size": { "w": final_w, "h": final_h }
        },
        "frames": frames_map
    });
    fs::write(
        &json_path,
        serde_json::to_string_pretty(&meta_doc).map_err(|e| e.to_string())?,
    )
    .map_err(|e| e.to_string())?;

    let mut tres_count = 0usize;
    if !godot_proj.is_empty() {
        let groot = PathBuf::from(&godot_proj);
        if let Ok(rel) = out_png.strip_prefix(&groot) {
            let res_atlas = format!("res://{}", rel.to_string_lossy().replace('\\', "/"));
            let tres_dir = out_png.parent().unwrap_or(Path::new(".")).join("atlas_frames");
            fs::create_dir_all(&tres_dir).map_err(|e| e.to_string())?;
            for s in &sprites {
                let tres = format!(
                    "[gd_resource type=\"AtlasTexture\" load_steps=2 format=3]\n\n\
                     [ext_resource type=\"Texture2D\" path=\"{res_atlas}\" id=\"1_atl\"]\n\n\
                     [resource]\n\
                     atlas = ExtResource(\"1_atl\")\n\
                     region = Rect2({x}, {y}, {w}, {h})\n",
                    x = s.px,
                    y = s.py,
                    w = s.img.width(),
                    h = s.img.height()
                );
                fs::write(tres_dir.join(format!("{}.tres", s.name)), tres).map_err(|e| e.to_string())?;
                tres_count += 1;
            }
        }
    }

    Ok(json!({
        "status": "packed",
        "engine": "rust_rayon_arm64",
        "sprites_packed": sprites.len(),
        "atlas_png": out_png.to_string_lossy(),
        "atlas_webp": webp_out_str,
        "atlas_json": json_path.to_string_lossy(),
        "dimensions": format!("{final_w}x{final_h}"),
        "godot_tres_generated": tres_count
    }))
}

pub fn process_sprite(args: &Value) -> Result<Value, String> {
    let op = req_str(args, "operation")?;
    let in_path = PathBuf::from(req_str(args, "input_path")?);
    let out_path = PathBuf::from(req_str(args, "output_path")?);

    let dyn_img = image::open(&in_path).map_err(|e| format!("Cannot open {}: {e}", in_path.display()))?;
    let src = dyn_img.to_rgba8();
    let (sw, sh) = src.dimensions();

    match op.as_str() {
        "scale_pixel_art" => {
            let factor = opt_i64(args, "scale_factor", 4).clamp(1, 32) as u32;
            let nw = sw * factor;
            let nh = sh * factor;
            let dst = imageops::resize(&src, nw, nh, FilterType::Nearest);
            ensure_parent(&out_path)?;
            dst.save(&out_path).map_err(|e| e.to_string())?;
            Ok(json!({
                "operation": op,
                "input_size": format!("{sw}x{sh}"),
                "output_size": format!("{nw}x{nh}"),
                "output_path": out_path.to_string_lossy()
            }))
        }
        "trim_alpha" => {
            let (bx, by, bw, bh) = alpha_bounds(&src);
            let dst = imageops::crop_imm(&src, bx, by, bw, bh).to_image();
            ensure_parent(&out_path)?;
            dst.save(&out_path).map_err(|e| e.to_string())?;
            Ok(json!({
                "operation": op,
                "trim_offset": { "x": bx, "y": by },
                "output_size": format!("{bw}x{bh}"),
                "output_path": out_path.to_string_lossy()
            }))
        }
        "remove_colorkey" => {
            let hex = opt_str(args, "colorkey_hex", "auto");
            let tol = opt_i64(args, "tolerance", 18).clamp(0, 255) as i32;
            let (kr, kg, kb) = if hex.eq_ignore_ascii_case("auto") {
                let p = src.get_pixel(0, 0);
                (p[0] as i32, p[1] as i32, p[2] as i32)
            } else {
                parse_hex_rgb(&hex)?
            };
            let mut dst = src.clone();
            let mut cleared = 0usize;
            for p in dst.pixels_mut() {
                if (p[0] as i32 - kr).abs() <= tol
                    && (p[1] as i32 - kg).abs() <= tol
                    && (p[2] as i32 - kb).abs() <= tol
                {
                    *p = Rgba([0, 0, 0, 0]);
                    cleared += 1;
                }
            }
            ensure_parent(&out_path)?;
            dst.save(&out_path).map_err(|e| e.to_string())?;
            Ok(json!({
                "operation": op,
                "transparent_pixels": cleared,
                "output_path": out_path.to_string_lossy()
            }))
        }
        "generate_normal_map" => {
            // 3x3 Sobel height-to-normal filter for Godot 4 CanvasTexture dynamic 2D lighting
            let strength = opt_f64(args, "normal_strength", 2.5).clamp(0.1, 20.0) as f32;
            let mut dst = RgbaImage::new(sw, sh);
            let luma_at = |x: i32, y: i32| -> f32 {
                let cx = x.clamp(0, sw as i32 - 1) as u32;
                let cy = y.clamp(0, sh as i32 - 1) as u32;
                let p = src.get_pixel(cx, cy);
                let a = p[3] as f32 / 255.0;
                ((0.299 * p[0] as f32 + 0.587 * p[1] as f32 + 0.114 * p[2] as f32) / 255.0) * a
            };

            for y in 0..sh as i32 {
                for x in 0..sw as i32 {
                    let alpha = src.get_pixel(x as u32, y as u32)[3];
                    if alpha == 0 {
                        dst.put_pixel(x as u32, y as u32, Rgba([128, 128, 255, 0]));
                        continue;
                    }
                    let tl = luma_at(x - 1, y - 1);
                    let l = luma_at(x - 1, y);
                    let bl = luma_at(x - 1, y + 1);
                    let tr = luma_at(x + 1, y - 1);
                    let r = luma_at(x + 1, y);
                    let br = luma_at(x + 1, y + 1);
                    let t = luma_at(x, y - 1);
                    let b = luma_at(x, y + 1);

                    let dx = ((tr + 2.0 * r + br) - (tl + 2.0 * l + bl)) * strength;
                    let dy = ((bl + 2.0 * b + br) - (tl + 2.0 * t + tr)) * strength;
                    let nx = -dx;
                    let ny = -dy;
                    let nz = 1.0f32;
                    let inv_len = 1.0 / (nx * nx + ny * ny + nz * nz).sqrt();
                    let nr = (((nx * inv_len) * 0.5 + 0.5) * 255.0).clamp(0.0, 255.0) as u8;
                    let ng = (((ny * inv_len) * 0.5 + 0.5) * 255.0).clamp(0.0, 255.0) as u8;
                    let nb = (((nz * inv_len) * 0.5 + 0.5) * 255.0).clamp(0.0, 255.0) as u8;
                    dst.put_pixel(x as u32, y as u32, Rgba([nr, ng, nb, alpha]));
                }
            }
            ensure_parent(&out_path)?;
            dst.save(&out_path).map_err(|e| e.to_string())?;
            Ok(json!({
                "operation": op,
                "normal_strength": strength,
                "output_size": format!("{sw}x{sh}"),
                "output_path": out_path.to_string_lossy()
            }))
        }
        "slice_grid" => {
            let cols = opt_i64(args, "columns", 4).max(1) as u32;
            let rows = opt_i64(args, "rows", 1).max(1) as u32;
            let fw = (sw / cols).max(1);
            let fh = (sh / rows).max(1);
            fs::create_dir_all(&out_path).map_err(|e| e.to_string())?;
            let mut files = Vec::new();
            let mut idx = 0usize;
            for r in 0..rows {
                for c in 0..cols {
                    let cell = imageops::crop_imm(&src, c * fw, r * fh, fw, fh).to_image();
                    let fpath = out_path.join(format!("frame_{idx:03}.png"));
                    cell.save(&fpath).map_err(|e| e.to_string())?;
                    files.push(fpath.to_string_lossy().to_string());
                    idx += 1;
                }
            }
            Ok(json!({
                "operation": op,
                "frame_size": format!("{fw}x{fh}"),
                "frames_exported": files.len(),
                "files": files
            }))
        }
        "generate_android_icons" => {
            fs::create_dir_all(&out_path).map_err(|e| e.to_string())?;
            let specs = [
                ("mipmap-mdpi", 48u32),
                ("mipmap-hdpi", 72),
                ("mipmap-xhdpi", 96),
                ("mipmap-xxhdpi", 144),
                ("mipmap-xxxhdpi", 192),
                ("playstore-512", 512),
            ];
            let mut written = Vec::new();
            for (folder, sz) in specs {
                let scaled = imageops::resize(&src, sz, sz, FilterType::Lanczos3);
                let dir = out_path.join(folder);
                fs::create_dir_all(&dir).map_err(|e| e.to_string())?;
                let target = dir.join("ic_launcher.png");
                scaled.save(&target).map_err(|e| e.to_string())?;
                written.push(target.to_string_lossy().to_string());
            }
            Ok(json!({ "operation": op, "generated_icons": written }))
        }
        _ => Err(format!("Unsupported sprite operation: {op}")),
    }
}

fn is_supported_img(p: &Path) -> bool {
    matches!(
        p.extension()
            .and_then(|s| s.to_str())
            .unwrap_or("")
            .to_ascii_lowercase()
            .as_str(),
        "png" | "jpg" | "jpeg" | "webp" | "tga" | "bmp" | "dds"
    )
}

fn alpha_bounds(img: &RgbaImage) -> (u32, u32, u32, u32) {
    let (w, h) = img.dimensions();
    let mut min_x = w;
    let mut min_y = h;
    let mut max_x = 0u32;
    let mut max_y = 0u32;
    let mut any = false;
    for (x, y, p) in img.enumerate_pixels() {
        if p[3] > 0 {
            any = true;
            min_x = min_x.min(x);
            min_y = min_y.min(y);
            max_x = max_x.max(x);
            max_y = max_y.max(y);
        }
    }
    if !any {
        return (0, 0, 1, 1);
    }
    (min_x, min_y, max_x - min_x + 1, max_y - min_y + 1)
}

fn parse_hex_rgb(hex: &str) -> Result<(i32, i32, i32), String> {
    let h = hex.trim().trim_start_matches('#');
    if h.len() != 6 {
        return Err("colorkey_hex must be 6 hex digits like '#FF00FF' or 'auto'".into());
    }
    let v = u32::from_str_radix(h, 16).map_err(|e| e.to_string())?;
    Ok((((v >> 16) & 0xFF) as i32, ((v >> 8) & 0xFF) as i32, (v & 0xFF) as i32))
}

fn ensure_parent(p: &Path) -> Result<(), String> {
    if let Some(parent) = p.parent() {
        fs::create_dir_all(parent).map_err(|e| e.to_string())?;
    }
    Ok(())
}
