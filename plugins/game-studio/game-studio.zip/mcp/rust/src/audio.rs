use crate::godot::{opt_bool, opt_f64, opt_i64, req_str};
use crate::system::{find_bin, round2};
use hound::{SampleFormat, WavReader, WavSpec, WavWriter};
use serde_json::{json, Value};
use std::fs;
use std::path::PathBuf;
use std::process::Command;

pub fn master_audio(args: &Value) -> Result<Value, String> {
    let in_path = PathBuf::from(req_str(args, "input_path")?);
    let out_path = PathBuf::from(req_str(args, "output_path")?);
    let trim_silence = opt_bool(args, "trim_silence", true);
    let threshold_db = opt_f64(args, "threshold_db", -42.0);
    let normalize_peak = opt_bool(args, "normalize_peak", true);
    let loop_fade_ms = opt_i64(args, "seamless_loop_fade_ms", 0).max(0) as usize;

    if let Some(parent) = out_path.parent() {
        fs::create_dir_all(parent).map_err(|e| e.to_string())?;
    }

    let in_ext = in_path
        .extension()
        .and_then(|s| s.to_str())
        .unwrap_or("")
        .to_ascii_lowercase();
    let out_ext = out_path
        .extension()
        .and_then(|s| s.to_str())
        .unwrap_or("")
        .to_ascii_lowercase();

    // If non-WAV codec requested (.ogg / .opus / .mp3), delegate to native ARM64 FFmpeg when installed
    if in_ext != "wav" || out_ext != "wav" {
        let ffmpeg = find_bin("ffmpeg").ok_or_else(|| {
            format!(
                "Codec .{out_ext} requested while FFmpeg is not installed yet. Run `game-studio-setup` in terminal to unlock .ogg/.opus/.mp3, or use .wav for the built-in Rust DSP engine."
            )
        })?;

        let mut filters = Vec::new();
        if trim_silence {
            filters.push(format!(
                "silenceremove=start_periods=1:start_duration=0.002:start_threshold={threshold_db:.1}dB,areverse,silenceremove=start_periods=1:start_duration=0.01:start_threshold={threshold_db:.1}dB,areverse"
            ));
        }
        if normalize_peak {
            filters.push("dynaudnorm=f=150:g=15".to_string());
        }

        let mut cmd = Command::new(ffmpeg);
        cmd.args(["-y", "-hide_banner", "-loglevel", "error", "-i"])
            .arg(&in_path);
        if !filters.is_empty() {
            cmd.arg("-af").arg(filters.join(","));
        }
        cmd.arg(&out_path);

        let res = cmd.output().map_err(|e| e.to_string())?;
        if !res.status.success() {
            return Err(format!(
                "FFmpeg failed: {}",
                String::from_utf8_lossy(&res.stderr)
            ));
        }
        let bytes = fs::metadata(&out_path).map(|m| m.len()).unwrap_or(0);
        return Ok(json!({
            "engine": "ffmpeg_arm64",
            "input_path": in_path.to_string_lossy(),
            "output_path": out_path.to_string_lossy(),
            "output_bytes": bytes,
            "zero_latency_trimmed": trim_silence
        }));
    }

    // Native Rust DSP engine (8/16/24/32-bit int & float32 WAV + 0ms silence strip + peak norm + seamless crossfade loop)
    let mut reader = WavReader::open(&in_path).map_err(|e| format!("WAV read error: {e}"))?;
    let spec = reader.spec();
    let ch = spec.channels.max(1) as usize;
    let sr = spec.sample_rate;

    let samples_f32: Vec<f32> = match spec.sample_format {
        SampleFormat::Float => reader
            .samples::<f32>()
            .collect::<Result<Vec<_>, _>>()
            .map_err(|e| e.to_string())?,
        SampleFormat::Int => {
            let max_val = ((1i64 << (spec.bits_per_sample - 1)) as f32).max(1.0);
            reader
                .samples::<i32>()
                .map(|s| s.map(|v| (v as f32) / max_val))
                .collect::<Result<Vec<_>, _>>()
                .map_err(|e| e.to_string())?
        }
    };

    let total_frames = samples_f32.len() / ch;
    if total_frames == 0 {
        return Err("Audio file contains 0 frames".into());
    }

    let lin_thresh = 10.0f32.powf((threshold_db as f32) / 20.0);
    let frame_peak = |f: usize| -> f32 {
        let base = f * ch;
        samples_f32[base..base + ch]
            .iter()
            .fold(0.0f32, |acc, &x| acc.max(x.abs()))
    };

    let mut first = 0usize;
    let mut last = total_frames - 1;
    if trim_silence {
        while first < total_frames && frame_peak(first) < lin_thresh {
            first += 1;
        }
        while last > first && frame_peak(last) < lin_thresh {
            last -= 1;
        }
    }
    if first >= total_frames {
        first = 0;
        last = total_frames - 1;
    }

    let mut trimmed: Vec<f32> = samples_f32[first * ch..=(last * ch + ch - 1)].to_vec();

    // Optional click-free seamless loop crossfade (overlap-adds tail onto head)
    let fade_frames = ((sr as usize) * loop_fade_ms) / 1000;
    let cur_frames = trimmed.len() / ch;
    let applied_loop_fade = if fade_frames > 8 && cur_frames > fade_frames * 3 {
        let out_frames = cur_frames - fade_frames;
        let mut looped = vec![0.0f32; out_frames * ch];
        for f in 0..out_frames {
            for c in 0..ch {
                if f < fade_frames {
                    let t = (f as f32) / (fade_frames as f32);
                    let head = trimmed[f * ch + c] * t;
                    let tail = trimmed[(out_frames + f) * ch + c] * (1.0 - t);
                    looped[f * ch + c] = head + tail;
                } else {
                    looped[f * ch + c] = trimmed[f * ch + c];
                }
            }
        }
        trimmed = looped;
        true
    } else {
        false
    };

    let max_peak = trimmed.iter().fold(1e-6f32, |a, &x| a.max(x.abs()));
    let gain = if normalize_peak { 0.891_25 / max_peak } else { 1.0 }; // -1.0 dBFS

    let out_spec = WavSpec {
        channels: spec.channels,
        sample_rate: sr,
        bits_per_sample: 16,
        sample_format: SampleFormat::Int,
    };
    let mut writer = WavWriter::create(&out_path, out_spec).map_err(|e| e.to_string())?;
    for &s in &trimmed {
        let v = (s * gain * 32767.0).round().clamp(-32768.0, 32767.0) as i16;
        writer.write_sample(v).map_err(|e| e.to_string())?;
    }
    writer.finalize().map_err(|e| e.to_string())?;

    let final_frames = trimmed.len() / ch;
    Ok(json!({
        "engine": "rust_dsp_arm64_native",
        "sample_rate": sr,
        "channels": ch,
        "leading_silence_removed_ms": round2((first as f64 * 1000.0) / sr as f64),
        "duration_ms": round2((final_frames as f64 * 1000.0) / sr as f64),
        "seamless_loop_applied": applied_loop_fade,
        "applied_gain": round2(gain as f64),
        "output_path": out_path.to_string_lossy()
    }))
}
