use crate::gdext_apk::{detect_godot_xyz_version, export_templates_dir, gdext_header_path, home_dir, patched_godot_path, prefix_dir};
use crate::godot::{opt_bool, opt_f64, opt_i64, opt_str, req_str};
use serde_json::{json, Value};
use std::env;
use std::fs;
use std::os::unix::fs::PermissionsExt;
use std::path::PathBuf;
use std::process::Command;

pub fn ensure_cli_wrapper() {
    let home = home_dir();
    let pfx = prefix_dir();
    let bin_dir = pfx.join("bin");
    let _ = fs::create_dir_all(&bin_dir);
    let mcp_bin = home.join(".gemini/config/plugins/game-studio/mcp/bin/game-studio-mcp");
    let target = bin_dir.join("agy-game-studio");
    let script = format!(
        "#!/system/bin/sh\nexport HOME=\"{}\"\nexport PREFIX=\"{}\"\nexport TMPDIR=\"{}/tmp\"\nexport LD_LIBRARY_PATH=\"{}/lib${{LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}}\"\nexport PATH=\"{}/bin:{}/runtime/bin:/system/bin\"\nexec \"{}\" \"$@\"\n",
        home.display(),
        pfx.display(),
        pfx.display(),
        pfx.display(),
        pfx.display(),
        home.display(),
        mcp_bin.display()
    );
    if fs::read_to_string(&target).ok().as_deref() == Some(script.as_str()) {
        return;
    }
    let tmp = target.with_extension(format!("tmp.{}", std::process::id()));
    if fs::write(&tmp, script).is_ok() {
        let _ = fs::set_permissions(&tmp, fs::Permissions::from_mode(0o755));
        let _ = fs::rename(&tmp, &target);
    }
}

pub fn studio_status() -> Result<Value, String> {
    let rish = find_bin("rish");
    let mut shizuku_live = false;
    let mut godot_pkgs = Vec::new();

    if let Some(ref rish_bin) = rish {
        if let Ok(out) = Command::new(rish_bin).args(["-c", "pm list packages godot"]).output() {
            if out.status.success() {
                shizuku_live = true;
                let txt = String::from_utf8_lossy(&out.stdout);
                for line in txt.lines() {
                    if let Some(pkg) = line.strip_prefix("package:") {
                        godot_pkgs.push(pkg.trim().to_string());
                    }
                }
            }
        }
    }

    let has_ffmpeg = find_bin("ffmpeg").is_some();
    let has_magick = find_bin("magick").is_some() || find_bin("convert").is_some();
    let has_gltf = find_bin("gltf-transform").is_some();

    let godot_ver = detect_godot_xyz_version();
    let tpl_ready = godot_ver
        .as_deref()
        .map(|v| export_templates_dir(v).join("android_debug.apk").is_file())
        .unwrap_or(false);

    let mut recs = Vec::new();
    if !patched_godot_path().is_file() || !tpl_ready {
        recs.push("Call `godot_toolchain_setup` (or run `agy-game-studio setup`) to unlock 100% offline headless Godot 4.7 APK compilation + GDExtension headers.");
    }
    if !has_ffmpeg {
        recs.push("Run `game-studio-setup` in terminal whenever you want FFmpeg (.ogg/.opus/MP3 encoding).");
    }
    if !shizuku_live {
        recs.push("Enable AGY ADB Bridge or Shizuku to unlock live 144 Hz `android_game_profiler` + `logcat -s godot` debugging and 1-click APK installation.");
    }

    Ok(json!({
        "plugin": "game-studio",
        "version": "2.0.0",
        "runtime": "native_rust_arm64_lse_v2",
        "arch": env::consts::ARCH,
        "godot_arm64_engine": {
            "headless_godot_installed": find_bin("godot").is_some(),
            "patched_godot_bin_ready": patched_godot_path().is_file(),
            "godot_version": godot_ver,
            "gdextension_header_ready": gdext_header_path().is_file(),
            "android_export_templates_ready": tpl_ready,
            "gdextension_c_clang_ready": find_bin("clang").is_some(),
            "gdextension_rust_ready": find_bin("rustc").is_some(),
            "local_apksigner_ready": find_bin("apksigner").is_some()
        },
        "builtin_rust_engines": {
            "2d_formats": ["png", "jpeg", "webp", "tga", "bmp", "dds"],
            "2d_normal_map_generator": true,
            "3d_glb_inspector_and_lod_decimator": true,
            "vulkan_gdshader_and_multimesh_generator": true,
            "audio_pcm_float_wav_and_loop_crossfader": true,
            "multicore_rayon_threads": rayon::current_num_threads()
        },
        "external_tools": {
            "ffmpeg": has_ffmpeg,
            "imagemagick": has_magick,
            "gltf_transform": has_gltf,
            "rish_adb_bridge": rish.is_some(),
            "ghidra_headless": find_bin("analyzeHeadless").is_some(),
            "craft_anything_cli": find_bin("craft-anything-cli").is_some()
        },
        "shizuku_live_connected": shizuku_live,
        "installed_godot_packages": godot_pkgs,
        "recommendations": recs
    }))
}

pub fn balance_sim(args: &Value) -> Result<Value, String> {
    let a_hp = opt_f64(args, "attacker_hp", 500.0);
    let a_dmg = opt_f64(args, "attacker_dmg", 25.0);
    let a_aps = opt_f64(args, "attacker_aps", 1.0).max(0.05);
    let a_arm = opt_f64(args, "attacker_armor", 2.0);
    let a_crit = opt_f64(args, "attacker_crit_chance", 0.0).clamp(0.0, 1.0);

    let b_hp = opt_f64(args, "defender_hp", 500.0);
    let b_dmg = opt_f64(args, "defender_dmg", 25.0);
    let b_aps = opt_f64(args, "defender_aps", 1.0).max(0.05);
    let b_arm = opt_f64(args, "defender_armor", 2.0);
    let b_crit = opt_f64(args, "defender_crit_chance", 0.0).clamp(0.0, 1.0);

    let runs = opt_i64(args, "iterations", 2000).clamp(10, 100_000) as usize;
    let a_mit = armor_mult(b_arm);
    let b_mit = armor_mult(a_arm);

    let mut state: u64 = 0x9E37_79B9_7F4A_7C15;
    let mut next_f64 = || -> f64 {
        state ^= state >> 12;
        state ^= state << 25;
        state ^= state >> 27;
        let x = state.wrapping_mul(0x2545_F491_4F6C_DD1D);
        ((x >> 11) as f64) * (1.0 / ((1u64 << 53) as f64))
    };

    let mut a_wins = 0usize;
    let mut b_wins = 0usize;
    let mut total_t = 0.0;
    let mut total_hp_left = 0.0;

    for _ in 0..runs {
        let mut hp_a = a_hp;
        let mut hp_b = b_hp;
        let mut next_a = 1.0 / a_aps;
        let mut next_b = 1.0 / b_aps;
        let mut t = 0.0;
        while hp_a > 0.0 && hp_b > 0.0 && t < 600.0 {
            if next_a <= next_b {
                t = next_a;
                let crit = if next_f64() < a_crit { 2.0 } else { 1.0 };
                let roll = 0.92 + next_f64() * 0.16;
                hp_b -= a_dmg * crit * roll * a_mit;
                next_a += 1.0 / a_aps;
            } else {
                t = next_b;
                let crit = if next_f64() < b_crit { 2.0 } else { 1.0 };
                let roll = 0.92 + next_f64() * 0.16;
                hp_a -= b_dmg * crit * roll * b_mit;
                next_b += 1.0 / b_aps;
            }
        }
        total_t += t;
        if hp_a > 0.0 {
            a_wins += 1;
            total_hp_left += hp_a;
        } else {
            b_wins += 1;
            total_hp_left += hp_b.max(0.0);
        }
    }

    let win_pct = (a_wins as f64 * 100.0) / runs as f64;
    let verdict = if (45.0..=55.0).contains(&win_pct) {
        "Symmetric / Balanced matchup"
    } else if win_pct > 55.0 {
        "Attacker favored"
    } else {
        "Defender favored"
    };

    Ok(json!({
        "iterations": runs,
        "attacker_win_rate_pct": round2(win_pct),
        "defender_win_rate_pct": round2((b_wins as f64 * 100.0) / runs as f64),
        "average_ttk_seconds": round2(total_t / runs as f64),
        "average_winner_remaining_hp": round2(total_hp_left / runs as f64),
        "effective_dps_attacker": round2(a_dmg * a_aps * (1.0 + a_crit) * a_mit),
        "effective_dps_defender": round2(b_dmg * b_aps * (1.0 + b_crit) * b_mit),
        "balance_verdict": verdict
    }))
}

/// Live on-device 60–144+ Hz profiler & `logcat -s godot` debugger via `rish`.
pub fn android_profiler(args: &Value) -> Result<Value, String> {
    let pkg: String = req_str(args, "package_name")?
        .chars()
        .filter(|c| c.is_ascii_alphanumeric() || *c == '_' || *c == '.')
        .collect();
    let reset = opt_bool(args, "reset_stats", false);
    let max_logs = opt_i64(args, "max_log_lines", 100).clamp(20, 500);
    let rish = find_bin("rish").ok_or("rish binary not found in PATH")?;

    let cmd = format!(
        "pidof {pkg} || true; echo '===GFX==='; dumpsys gfxinfo {pkg}{rst}; echo '===MEM==='; dumpsys meminfo {pkg} | grep -E 'TOTAL PSS:|Graphics:|Native Heap:'; echo '===HZ==='; dumpsys SurfaceFlinger | grep -iE 'refresh-rate|cur-config' | head -n 6; echo '===TEMP==='; dumpsys battery | grep temperature; echo '===GODOT_LOG==='; logcat -d -s godot:V GodotEngine:V AndroidRuntime:E DEBUG:F -t {max_logs}",
        rst = if reset { " reset" } else { "" }
    );

    let out = Command::new(rish)
        .args(["-c", &cmd])
        .output()
        .map_err(|e| e.to_string())?;
    if !out.status.success() {
        return Err(format!(
            "rish failed — ensure AGY ADB Bridge or Shizuku is active: {}",
            String::from_utf8_lossy(&out.stderr)
        ));
    }

    let text = String::from_utf8_lossy(&out.stdout);
    let pid_line = text.lines().next().unwrap_or("").trim().to_string();
    let total_frames: i64 = find_after(&text, "Total frames rendered:").parse().unwrap_or(0);
    let janky = find_after(&text, "Janky frames:");
    let p50: f64 = find_ms(&text, "50th percentile:");
    let p90: f64 = find_ms(&text, "90th percentile:");
    let p95: f64 = find_ms(&text, "95th percentile:");
    let p99: f64 = find_ms(&text, "99th percentile:");
    let pss_kb: f64 = find_first_num(&text, "TOTAL PSS:");
    let temp_raw: f64 = find_first_num(&text, "temperature:");

    let hz_sec = text
        .split("===HZ===")
        .nth(1)
        .and_then(|s| s.split("===TEMP===").next())
        .unwrap_or("")
        .trim();
    let display_hz = parse_refresh_hz(hz_sec);
    let max_cap = if display_hz > 60.0 { display_hz } else { 144.0 };
    let fps = if p50 > 0.1 { (1000.0 / p50).min(max_cap) } else { 0.0 };

    let godot_raw = text.split("===GODOT_LOG===").nth(1).unwrap_or("").trim();
    let mut godot_logs = Vec::new();
    let mut errors = Vec::new();
    for line in godot_raw.lines() {
        let l = line.trim();
        if l.is_empty() || l.starts_with("--------- beginning") {
            continue;
        }
        if l.contains("SCRIPT ERROR") || l.contains("USER ERROR") || l.contains("ERROR:") || l.contains("FATAL") {
            errors.push(l.to_string());
        }
        godot_logs.push(l.to_string());
    }

    Ok(json!({
        "package_name": pkg,
        "running_pid": if pid_line.is_empty() { Value::Null } else { Value::String(pid_line) },
        "display_refresh_hz": round2(display_hz),
        "total_frames_sampled": total_frames,
        "janky_frames": janky,
        "frame_time_ms": { "p50": p50, "p90": p90, "p95": p95, "p99": p99 },
        "estimated_median_fps": round2(fps),
        "total_pss_ram_mb": round2(pss_kb / 1024.0),
        "battery_temp_celsius": round2(temp_raw / 10.0),
        "godot_errors_count": errors.len(),
        "godot_errors": errors,
        "godot_recent_logs": godot_logs
    }))
}

pub fn android_launch(args: &Value) -> Result<Value, String> {
    let pkg: String = opt_str(args, "package_name", "org.godotengine.editor.v4")
        .chars()
        .filter(|c| c.is_ascii_alphanumeric() || *c == '_' || *c == '.')
        .collect();
    let proj = opt_str(args, "project_dir", "");
    if !proj.is_empty() && !PathBuf::from(&proj).join("project.godot").exists() {
        return Err(format!("No project.godot found inside {proj}"));
    }
    let rish = find_bin("rish").ok_or("rish binary not found in PATH")?;
    let out = Command::new(rish)
        .args(["-c", &format!("monkey -p {pkg} -c android.intent.category.LAUNCHER 1")])
        .output()
        .map_err(|e| e.to_string())?;
    Ok(json!({
        "launched_package": pkg,
        "exit_code": out.status.code().unwrap_or(-1),
        "output": format!("{}{}", String::from_utf8_lossy(&out.stdout), String::from_utf8_lossy(&out.stderr)).trim()
    }))
}

pub fn find_bin(name: &str) -> Option<PathBuf> {
    let path_var = env::var_os("PATH")?;
    for dir in env::split_paths(&path_var) {
        let candidate = dir.join(name);
        if fs::metadata(&candidate).map(|m| m.is_file()).unwrap_or(false) {
            return Some(candidate);
        }
    }
    None
}

fn parse_refresh_hz(s: &str) -> f64 {
    // e.g. "refresh-rate : 144.00 Hz" or "120.000008 fps"
    for tok in s.split(|c: char| !c.is_ascii_digit() && c != '.') {
        if let Ok(v) = tok.parse::<f64>() {
            if (59.0..=240.0).contains(&v) {
                return v;
            }
        }
    }
    120.0
}

fn armor_mult(armor: f64) -> f64 {
    if armor >= 0.0 {
        1.0 - ((0.06 * armor) / (1.0 + 0.06 * armor))
    } else {
        2.0 - 0.94f64.powf(-armor)
    }
}

fn find_after(text: &str, label: &str) -> String {
    text.lines()
        .find_map(|l| l.find(label).map(|i| l[i + label.len()..].trim().to_string()))
        .unwrap_or_default()
}

fn find_ms(text: &str, label: &str) -> f64 {
    let s = find_after(text, label);
    s.trim_end_matches("ms").trim().parse().unwrap_or(0.0)
}

fn find_first_num(text: &str, label: &str) -> f64 {
    let s = find_after(text, label);
    s.split_whitespace().next().unwrap_or("0").parse().unwrap_or(0.0)
}

pub fn round2(v: f64) -> f64 {
    (v * 100.0).round() / 100.0
}
