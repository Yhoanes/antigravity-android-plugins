mod audio;
mod glb;
mod godot;
mod sprites;
mod system;

use serde_json::{json, Value};
use std::env;
use std::io::{self, BufRead, BufReader, BufWriter, Write};

const SERVER_NAME: &str = "game-studio";
const SERVER_VERSION: &str = "1.1.0";
const DEFAULT_PROTO: &str = "2024-11-05";

fn main() {
    let args: Vec<String> = env::args().collect();
    if args.iter().any(|a| a == "--selftest") {
        match system::studio_status() {
            Ok(v) => println!("{}", serde_json::to_string_pretty(&v).unwrap_or_default()),
            Err(e) => {
                eprintln!("{e}");
                std::process::exit(1);
            }
        }
        return;
    }

    let stdin = io::stdin();
    let stdout = io::stdout();
    let mut reader = BufReader::new(stdin.lock());
    let mut writer = BufWriter::new(stdout.lock());
    let mut use_content_length = false;

    loop {
        let payload = match read_next_message(&mut reader, &mut use_content_length) {
            Ok(Some(msg)) => msg,
            Ok(None) => break,
            Err(_) => break,
        };

        let trimmed = payload.trim();
        if trimmed.is_empty() {
            continue;
        }

        if let Some(resp) = handle_rpc(trimmed) {
            if let Ok(bytes) = serde_json::to_vec(&resp) {
                if use_content_length {
                    let _ = write!(writer, "Content-Length: {}\r\n\r\n", bytes.len());
                    let _ = writer.write_all(&bytes);
                } else {
                    let _ = writer.write_all(&bytes);
                    let _ = writer.write_all(b"\n");
                }
                let _ = writer.flush();
            }
        }
    }
}

fn read_next_message<R: BufRead>(
    reader: &mut R,
    use_content_length: &mut bool,
) -> io::Result<Option<String>> {
    loop {
        let mut line = String::new();
        let n = reader.read_line(&mut line)?;
        if n == 0 {
            return Ok(None);
        }
        let t = line.trim();
        if t.is_empty() {
            continue;
        }
        if t.len() >= 15 && t[..15].eq_ignore_ascii_case("content-length:") {
            *use_content_length = true;
            let len: usize = t[15..].trim().parse().unwrap_or(0);
            loop {
                let mut hdr = String::new();
                if reader.read_line(&mut hdr)? == 0 || hdr.trim().is_empty() {
                    break;
                }
            }
            let mut body = vec![0u8; len];
            reader.read_exact(&mut body)?;
            return Ok(Some(String::from_utf8_lossy(&body).to_string()));
        }
        return Ok(Some(t.to_string()));
    }
}

fn handle_rpc(raw: &str) -> Option<Value> {
    let req: Value = match serde_json::from_str(raw) {
        Ok(v) => v,
        Err(_) => {
            return Some(json!({
                "jsonrpc": "2.0",
                "id": Value::Null,
                "error": { "code": -32700, "message": "Parse error" }
            }));
        }
    };

    // JSON-RPC notifications omit `id` and must not receive a response
    let id = req.get("id")?.clone();
    let method = req.get("method").and_then(|m| m.as_str()).unwrap_or("");
    let params = req.get("params").cloned().unwrap_or_else(|| json!({}));

    match method {
        "initialize" => {
            let proto = params
                .get("protocolVersion")
                .and_then(|p| p.as_str())
                .filter(|s| !s.is_empty())
                .unwrap_or(DEFAULT_PROTO);
            Some(json!({
                "jsonrpc": "2.0",
                "id": id,
                "result": {
                    "protocolVersion": proto,
                    "capabilities": { "tools": {} },
                    "serverInfo": { "name": SERVER_NAME, "version": SERVER_VERSION }
                }
            }))
        }
        "ping" => Some(json!({ "jsonrpc": "2.0", "id": id, "result": {} })),
        "resources/list" => Some(json!({ "jsonrpc": "2.0", "id": id, "result": { "resources": [] } })),
        "prompts/list" => Some(json!({ "jsonrpc": "2.0", "id": id, "result": { "prompts": [] } })),
        "tools/list" => Some(json!({
            "jsonrpc": "2.0",
            "id": id,
            "result": { "tools": tools_catalog() }
        })),
        "tools/call" => {
            let name = params.get("name").and_then(|n| n.as_str()).unwrap_or("");
            let args = params.get("arguments").cloned().unwrap_or_else(|| json!({}));
            let outcome = match name {
                "studio_status" => system::studio_status(),
                "godot_scaffold_project" => godot::scaffold_project(&args),
                "godot_create_scene" => godot::create_scene(&args),
                "godot_validate_project" => godot::validate_project(&args),
                "sprite_pack_atlas" => sprites::pack_atlas(&args),
                "sprite_process" => sprites::process_sprite(&args),
                "model3d_inspect_glb" => glb::inspect_glb(&args),
                "model3d_optimize_glb" => glb::optimize_glb(&args),
                "audio_sfx_master" => audio::master_audio(&args),
                "gamedata_balance_sim" => system::balance_sim(&args),
                "android_game_profiler" => system::android_profiler(&args),
                "android_godot_launch" => system::android_launch(&args),
                _ => Err(format!("Unknown tool: {name}")),
            };
            match outcome {
                Ok(val) => Some(json!({
                    "jsonrpc": "2.0",
                    "id": id,
                    "result": {
                        "content": [{ "type": "text", "text": serde_json::to_string_pretty(&val).unwrap_or_default() }],
                        "isError": false
                    }
                })),
                Err(err) => Some(json!({
                    "jsonrpc": "2.0",
                    "id": id,
                    "result": {
                        "content": [{ "type": "text", "text": serde_json::to_string_pretty(&json!({ "error": err, "tool": name })).unwrap_or(err) }],
                        "isError": true
                    }
                })),
            }
        }
        _ => Some(json!({
            "jsonrpc": "2.0",
            "id": id,
            "error": { "code": -32601, "message": format!("Method not found: {method}") }
        })),
    }
}

fn tools_catalog() -> Value {
    json!([
        {
            "name": "studio_status",
            "description": "Inspect the native Rust ARM64 Game Studio engine (PNG/JPEG/WebP/TGA/DDS/BMP, 3D GLB LODs, zero-latency WAV DSP, multi-core Rayon), external codecs (FFmpeg), Shizuku (rish) live telemetry, Godot 4 Android Editor, and Craft Anything + Ghidra bridge.",
            "inputSchema": { "type": "object", "properties": {}, "additionalProperties": false }
        },
        {
            "name": "godot_scaffold_project",
            "description": "Create a complete, Android-optimized Godot 4.x (Vulkan Mobile, 60-120 FPS) 2D or 3D game project with modular touch controls (virtual thumbstick + touch camera + action buttons), playable starter scene, and Android ARM64 export preset.",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "project_dir": { "type": "string", "description": "Absolute path for the new Godot 4 project (e.g. /storage/emulated/0/Documents/Games/MyGame)." },
                    "project_name": { "type": "string", "description": "Human-readable title of the game." },
                    "dimension": { "type": "string", "enum": ["2d", "3d"], "description": "Game dimension mode ('2d' or '3d')." },
                    "genre_preset": { "type": "string", "enum": ["action_rpg", "platformer", "rts_strategy", "shooter", "sandbox"], "description": "Starter genre preset." },
                    "viewport_width": { "type": "integer", "description": "Base viewport width (default 1280)." },
                    "viewport_height": { "type": "integer", "description": "Base viewport height (default 720)." }
                },
                "required": ["project_dir", "project_name", "dimension"],
                "additionalProperties": false
            }
        },
        {
            "name": "godot_create_scene",
            "description": "Generate a valid Godot 4 .tscn scene file (and optional companion GDScript .gd) for entities, levels, enemies, projectiles, or UI menus.",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "project_dir": { "type": "string", "description": "Root folder of the Godot 4 project." },
                    "scene_rel_path": { "type": "string", "description": "Relative path ending in .tscn (e.g. scenes/enemies/orc.tscn)." },
                    "root_type": { "type": "string", "description": "Godot 4 root node class (e.g. CharacterBody2D, CharacterBody3D, Area3D, Control)." },
                    "root_name": { "type": "string", "description": "Root node identifier." },
                    "with_collision": { "type": "boolean", "description": "Attach CollisionShape2D/3D automatically (default true)." },
                    "with_visual_placeholder": { "type": "boolean", "description": "Attach visible placeholder mesh/rect (default true)." },
                    "script_template": { "type": "string", "description": "Optional GDScript code to attach." }
                },
                "required": ["project_dir", "scene_rel_path", "root_type", "root_name"],
                "additionalProperties": false
            }
        },
        {
            "name": "godot_validate_project",
            "description": "Audit a Godot 4 project directory for broken res:// paths in .tscn/.tres/.gd files and oversized mobile textures (>2048px).",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "project_dir": { "type": "string", "description": "Root directory of the Godot 4 project." }
                },
                "required": ["project_dir"],
                "additionalProperties": false
            }
        },
        {
            "name": "sprite_pack_atlas",
            "description": "Multi-core ARM64 Sprite Atlas packer supporting PNG, JPEG, WebP, TGA, BMP, and DDS inputs -> RGBA PNG (+ optional WebP), JSON frame map, and Godot 4 AtlasTexture (.tres) resources.",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "input_dir": { "type": "string", "description": "Directory containing sprite images (.png, .webp, .tga, .dds, .bmp, .jpg)." },
                    "output_atlas_png": { "type": "string", "description": "Destination path for the packed RGBA .png atlas." },
                    "padding": { "type": "integer", "description": "Pixel padding between sprites (default 2)." },
                    "trim_alpha": { "type": "boolean", "description": "Trim transparent borders before packing (default true)." },
                    "power_of_two": { "type": "boolean", "description": "Round atlas size to power-of-two (default true)." },
                    "also_export_webp": { "type": "boolean", "description": "Also write a compressed .webp copy next to the .png (default false)." },
                    "godot_project_dir": { "type": "string", "description": "Optional Godot 4 root directory to emit .tres AtlasTextures." }
                },
                "required": ["input_dir", "output_atlas_png"],
                "additionalProperties": false
            }
        },
        {
            "name": "sprite_process",
            "description": "Native Rust 2D sprite processor: crisp nearest-neighbor pixel-art scaling, alpha border trimming, color-key transparency removal, Sobel 2D normal-map generation for dynamic lighting, grid spritesheet slicing, and Android mipmap icons.",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "operation": {
                        "type": "string",
                        "enum": ["scale_pixel_art", "trim_alpha", "remove_colorkey", "generate_normal_map", "slice_grid", "generate_android_icons"],
                        "description": "2D operation to execute."
                    },
                    "input_path": { "type": "string", "description": "Source image (.png, .webp, .tga, .dds, .bmp, .jpg)." },
                    "output_path": { "type": "string", "description": "Output file path (or directory for slice_grid / generate_android_icons)." },
                    "scale_factor": { "type": "integer", "description": "Integer multiplier for scale_pixel_art (default 4)." },
                    "colorkey_hex": { "type": "string", "description": "Hex color '#RRGGBB' or 'auto' for remove_colorkey." },
                    "tolerance": { "type": "integer", "description": "Color tolerance 0..255 for remove_colorkey (default 18)." },
                    "normal_strength": { "type": "number", "description": "Bump depth strength for generate_normal_map (default 2.5)." },
                    "columns": { "type": "integer", "description": "Columns for slice_grid." },
                    "rows": { "type": "integer", "description": "Rows for slice_grid." }
                },
                "required": ["operation", "input_path", "output_path"],
                "additionalProperties": false
            }
        },
        {
            "name": "model3d_inspect_glb",
            "description": "Deep binary inspector for 3D glTF 2.0 (.glb / .gltf) models: meshes, draw calls, vertices, triangles, skeleton joints, animations, embedded texture dimensions, and mobile GPU bottleneck warnings.",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "input_path": { "type": "string", "description": "Path to .glb or .gltf model." }
                },
                "required": ["input_path"],
                "additionalProperties": false
            }
        },
        {
            "name": "model3d_optimize_glb",
            "description": "Native Rust 3D .glb optimizer for 60-120 FPS mobile GPUs: downscales/converts embedded 2K/4K textures (PNG/JPEG/WebP) AND performs built-in 3D spatial LOD triangle decimation.",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "input_path": { "type": "string", "description": "Source .glb model." },
                    "output_path": { "type": "string", "description": "Destination optimized .glb model." },
                    "max_texture_size": { "type": "integer", "description": "Max embedded texture width/height in pixels (default 1024)." },
                    "simplify_ratio": { "type": "number", "description": "Target LOD mesh complexity ratio 0.05..1.0 (default 1.0)." },
                    "webp_textures": { "type": "boolean", "description": "Re-encode embedded textures to lossless/compact WebP inside the GLB (default false)." }
                },
                "required": ["input_path", "output_path"],
                "additionalProperties": false
            }
        },
        {
            "name": "audio_sfx_master",
            "description": "Zero-latency Rust DSP audio processor: strips leading/trailing silence natively on 8/16/24/32-bit int & float WAV (0-ms attack), normalizes peak to -1 dBFS, builds click-free crossfaded BGM loops, and uses FFmpeg when installed for .ogg/.opus.",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "input_path": { "type": "string", "description": "Input audio (.wav natively, or .ogg/.opus/.mp3 with FFmpeg)." },
                    "output_path": { "type": "string", "description": "Output audio path." },
                    "trim_silence": { "type": "boolean", "description": "Strip leading/trailing silence below threshold_db (default true)." },
                    "threshold_db": { "type": "number", "description": "Silence gate threshold in dBFS (default -42.0)." },
                    "normalize_peak": { "type": "boolean", "description": "Normalize peak to -1.0 dBFS (default true)." },
                    "seamless_loop_fade_ms": { "type": "integer", "description": "Overlap-crossfade tail onto head in ms for seamless looping BGM (default 0 = off)." }
                },
                "required": ["input_path", "output_path"],
                "additionalProperties": false
            }
        },
        {
            "name": "gamedata_balance_sim",
            "description": "Fast Monte Carlo combat TTK, DPS, armor mitigation, and crit balance simulator (up to 100,000 duels in milliseconds).",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "attacker_hp": { "type": "number" },
                    "attacker_dmg": { "type": "number" },
                    "attacker_aps": { "type": "number" },
                    "attacker_armor": { "type": "number" },
                    "attacker_crit_chance": { "type": "number" },
                    "defender_hp": { "type": "number" },
                    "defender_dmg": { "type": "number" },
                    "defender_aps": { "type": "number" },
                    "defender_armor": { "type": "number" },
                    "defender_crit_chance": { "type": "number" },
                    "iterations": { "type": "integer", "description": "Simulated duels 10..100000 (default 2000)." }
                },
                "required": ["attacker_hp", "attacker_dmg", "attacker_aps", "defender_hp", "defender_dmg", "defender_aps"],
                "additionalProperties": false
            }
        },
        {
            "name": "android_game_profiler",
            "description": "Live on-device Android game profiler via Shizuku (rish): captures gfxinfo p50/p90/p95/p99 frame times, FPS, jank, PSS RAM MB, battery temperature, and crash logs.",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "package_name": { "type": "string", "description": "Android package name to profile." },
                    "reset_stats": { "type": "boolean", "description": "Reset gfxinfo frame counters after reading (default false)." }
                },
                "required": ["package_name"],
                "additionalProperties": false
            }
        },
        {
            "name": "android_godot_launch",
            "description": "Launch Godot 4 Android Editor or a compiled Android game APK directly on device via Shizuku.",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "package_name": { "type": "string", "description": "Package to launch (defaults to org.godotengine.editor.v4)." },
                    "project_dir": { "type": "string", "description": "Optional Godot project directory to verify." }
                },
                "additionalProperties": false
            }
        }
    ])
}
