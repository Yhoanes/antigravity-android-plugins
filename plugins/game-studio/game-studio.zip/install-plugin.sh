#!/system/bin/sh
# install-plugin.sh - Instala y configura Game Studio 2D/3D (v1.1.0, Native Rust ARM64) en Antigravity Android.
set -eu

SRC_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
case "$SRC_DIR" in
    */.gemini/*) HOME="${SRC_DIR%%/.gemini/*}" ;;
    *) HOME="${HOME:-/data/user/0/com.agy/files}" ;;
esac
PREFIX="${PREFIX:-$HOME/usr}"
CONFIG_DIR="$HOME/.gemini/config"
TARGET_DIR="$CONFIG_DIR/plugins/game-studio"

mkdir -p "$CONFIG_DIR/plugins" "$PREFIX/tmp"

if [ "$SRC_DIR" != "$TARGET_DIR" ]; then
    rm -rf "$TARGET_DIR"
    mkdir -p "$TARGET_DIR"
    cp -Rf "$SRC_DIR"/. "$TARGET_DIR"/
fi

chmod 0755 \
    "$TARGET_DIR/install-plugin.sh" \
    "$TARGET_DIR/mcp/bin/start-mcp.sh" \
    "$TARGET_DIR/mcp/bin/game-studio-mcp" \
    "$TARGET_DIR/mcp/bin/game-studio-setup"

# Evitar binarios duplicados en $PREFIX/bin y registrar wrappers limpios en $HOME/runtime/bin
rm -f "$PREFIX/bin/game-studio-mcp" "$PREFIX/bin/game-studio-setup" 2>/dev/null || true
mkdir -p "$HOME/runtime/bin" 2>/dev/null || true
for tool in game-studio-mcp game-studio-setup; do
    rm -f "$HOME/runtime/bin/$tool" 2>/dev/null || true
    cat > "$HOME/runtime/bin/$tool" <<EOF
#!/system/bin/sh
export HOME="$HOME"
export PREFIX="$PREFIX"
export LD_LIBRARY_PATH="$PREFIX/lib\${LD_LIBRARY_PATH:+:\$LD_LIBRARY_PATH}"
export PATH="$PREFIX/bin:$HOME/runtime/bin:/system/bin"
export TMPDIR="\${TMPDIR:-$PREFIX/tmp}"
exec "$TARGET_DIR/mcp/bin/$tool" "\$@"
EOF
    chmod 0755 "$HOME/runtime/bin/$tool"
done

echo "============================================================"
echo " Plugin Game Studio 2D/3D v1.1.0 (Native Rust ARM64) activo"
echo " Ruta: $TARGET_DIR"
echo "============================================================"
