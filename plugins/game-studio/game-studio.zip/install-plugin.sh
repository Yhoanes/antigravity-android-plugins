#!/system/bin/sh
# install-plugin.sh - Installs and configures Game Studio 2D/3D (v2.0.0, Native Rust ARM64 + GDExtension + Local APK)
set -eu

SRC_DIR="$(CDPATH= cd -- "$(/system/bin/dirname -- "$0")" && pwd)"
case "$SRC_DIR" in
    */.gemini/*) HOME="${SRC_DIR%%/.gemini/*}" ;;
    *) HOME="${HOME:-/data/user/0/com.agy/files}" ;;
esac
PREFIX="${PREFIX:-$HOME/usr}"
CONFIG_DIR="$HOME/.gemini/config"
TARGET_DIR="$CONFIG_DIR/plugins/game-studio"

/system/bin/mkdir -p "$CONFIG_DIR/plugins" "$PREFIX/tmp" "$PREFIX/bin"

if [ "$SRC_DIR" != "$TARGET_DIR" ]; then
    /system/bin/rm -rf "$TARGET_DIR"
    /system/bin/mkdir -p "$TARGET_DIR"
    /system/bin/cp -Rf "$SRC_DIR"/. "$TARGET_DIR"/
fi

/system/bin/chmod 0755 \
    "$TARGET_DIR/install-plugin.sh" \
    "$TARGET_DIR/mcp/bin/start-mcp.sh" \
    "$TARGET_DIR/mcp/bin/game-studio-mcp" \
    "$TARGET_DIR/mcp/bin/game-studio-setup"

# Register clean wrappers exclusively in $PREFIX/bin (never touch $HOME/runtime/bin)
for tool in game-studio-setup; do
    cat > "$PREFIX/bin/$tool" <<EOF
#!/system/bin/sh
export HOME="$HOME"
export PREFIX="$PREFIX"
export LD_LIBRARY_PATH="$PREFIX/lib\${LD_LIBRARY_PATH:+:\$LD_LIBRARY_PATH}"
export PATH="$PREFIX/bin:$HOME/runtime/bin:/system/bin"
export TMPDIR="\${TMPDIR:-$PREFIX/tmp}"
exec "$TARGET_DIR/mcp/bin/$tool" "\$@"
EOF
    /system/bin/chmod 0755 "$PREFIX/bin/$tool"
done

cat > "$PREFIX/bin/agy-game-studio" <<EOF
#!/system/bin/sh
export HOME="$HOME"
export PREFIX="$PREFIX"
export LD_LIBRARY_PATH="$PREFIX/lib\${LD_LIBRARY_PATH:+:\$LD_LIBRARY_PATH}"
export PATH="$PREFIX/bin:$HOME/runtime/bin:/system/bin"
export TMPDIR="\${TMPDIR:-$PREFIX/tmp}"
exec "$TARGET_DIR/mcp/bin/game-studio-mcp" "\$@"
EOF
/system/bin/chmod 0755 "$PREFIX/bin/agy-game-studio"

"$TARGET_DIR/mcp/bin/game-studio-mcp" status >/dev/null 2>&1 || true

echo "============================================================"
echo " Plugin Game Studio 2D/3D v2.0.0 (Native Rust ARM64) active"
echo " Path: $TARGET_DIR"
echo "============================================================"
