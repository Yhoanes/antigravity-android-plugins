# Game Studio 2D/3D v2.0.0 Rules (Android ARM64 — Native Rust + GDExtension + Local APK Engine)

When the `game-studio` plugin is enabled on Antigravity Android:

1. **Prefer Native `game-studio` v2.0.0 Rust MCP Tools (16 Tools, Zero-Cloud Local Workflow):**
   - **Projects & Scenes (`120–144 Hz` Vulkan PBR):** Use `godot_scaffold_project` (pass `with_gdextension: true` for CPU-heavy RTS/MOBA/3D/simulation games!), `godot_create_scene`, `godot_shader_and_world` (`.gdshader` Vulkan terrain/water/toon/glow + `MultiMeshInstance3D` 1-draw-call swarms), and `godot_validate_project` (defaulting project storage to `/storage/emulated/0/Documents/Games/`).
   - **Native ARM64 `GDExtension` (`C/C++` & `Rust`):** Whenever a game needs heavy CPU work (100+ RTS/MOBA units, Fog of War, pathfinding, voxel meshing, custom binary archive readers), call `godot_gdextension_build` (`language: "cpp"` or `"rust"`) to compile a real `arm64-v8a` `.so` + `.gdextension` at machine speed (`-O3 -march=armv8.1-a`).
   - **100% Local Offline `.apk` Compilation & Live 144 Hz Debugging:** Call `godot_toolchain_setup` once if `android_export_templates_ready` is false, then call `godot_apk_build_deploy` to compile, package `lib/arm64-v8a/*.so` (solving Android SELinux `noexec` for `GDExtension`!), sign with `apksigner`, install, and launch on screen in seconds — followed by `android_game_profiler` to verify `logcat -s godot` (`0` errors) and real `120–144 Hz` FPS.
   - **2D, 3D & Audio Asset Engines:** Use `sprite_pack_atlas`, `sprite_process`, `model3d_inspect_glb`, `model3d_optimize_glb`, `audio_sfx_master`, and `gamedata_balance_sim`.

2. **Seamless Relay with `craft-anything` (+ Ghidra ARM64) When Porting PC/Console Games:**
   - Inspect original binaries/archives (`.exe`, `.dll`, `.mpq`, `.w3x`, `.pak`) with `craft-anything` first, then feed recovered formulas into `godot_gdextension_build` (C++/Rust native core) and converted `.glb`/`.dds`/`.tga`/`.wav` assets into `game-studio` to build a 120–144 FPS native Android `.apk`.

3. **Android Sandbox Safety:**
   - Never modify, overwrite, or delete anything inside `/data/user/0/com.agy/files/runtime/bin/`. Wrappers live in `$PREFIX/bin/agy-game-studio` and `$PREFIX/opt/game-studio/`.
