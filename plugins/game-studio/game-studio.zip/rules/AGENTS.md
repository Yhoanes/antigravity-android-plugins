# Game Studio 2D/3D Rules (Android ARM64 — Native Rust Engine)

When the `game-studio` plugin is enabled on Antigravity Android:

1. **Prefer Native `game-studio` Rust MCP Tools for Game Projects & Assets:**
   - Use `godot_scaffold_project`, `godot_create_scene`, and `godot_validate_project` when creating or modifying Godot 4 games on Android (defaulting project storage to `/storage/emulated/0/Documents/Games/` so the native Godot 4 Android Editor app can open them directly).
   - Use `sprite_pack_atlas` (multi-core Rayon supporting PNG, JPEG, WebP, TGA, BMP, and DDS inputs -> RGBA PNG + WebP + Godot `.tres`) and `sprite_process` (`scale_pixel_art`, `trim_alpha`, `remove_colorkey`, `generate_normal_map` Sobel 2D lighting, `slice_grid`, and `generate_android_icons`).
   - Use `model3d_inspect_glb` and `model3d_optimize_glb` to inspect triangle/bone/draw-call budgets, compress oversized embedded `.glb` textures (PNG/JPEG/WebP), and generate native 3D spatial LOD triangle decimations (`simplify_ratio`).
   - Use `audio_sfx_master` for native Rust 8/16/24/32-bit PCM & float WAV zero-latency silence stripping (`0 ms` attack), `-1.0 dBFS` peak normalization, and click-free BGM loop crossfades (`seamless_loop_fade_ms`), `gamedata_balance_sim` for Monte Carlo combat balancing, and `android_game_profiler` (via Shizuku `rish`) to measure live FPS, frame jank, and PSS RAM on device.

2. **Seamless Relay with `craft-anything` (+ Ghidra ARM64) When Porting Games:**
   - For **brand-new games**, use `game-studio` directly (+ `gemini-api` when generating concept art, music, or voice lines).
   - For **porting existing PC/Console/Mobile games**, use `craft-anything` + `ghidra-arm64` first to inspect binaries (`.exe`, `.dll`, `.so`, `.pak`, Unity/Unreal archives) and extract raw assets/formulas, then pass the extracted assets (including PC `.dds`/`.tga` textures, `.glb` meshes, and `.wav` SFX) directly into `game-studio` to build the native 60–120 FPS Android version.

3. **Zero-Dependency Native Rust Core + On-Demand Multimedia Power-Up:**
   - All 12 `game-studio` MCP tools run natively via the compiled ARM64 Rust binary (`game-studio-mcp`, `-C target-cpu=armv8.1-a`) with `<15 MB` RAM and instant startup.
   - Whenever the user needs `.ogg`/`.opus`/`.mp3` audio transcoding (`FFmpeg`) or skinned-mesh `meshoptimizer` simplification (`@gltf-transform/cli`) and `studio_status` reports `ffmpeg: false` or `gltf_transform: false`, offer to run `game-studio-setup` in terminal.
