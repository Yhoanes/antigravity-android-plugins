---
name: artex-audit
description: Structured authorized security auditing using ARTEX Global's Dual-Graph architecture (Asset Graph + Exploration Graph), multi-round Planner todolist, worker trace sharing, PreToolUse Guard, and the local 127.0.0.1:8787 Mini-Dashboard in native Rust ARM64 + SQLite.
---

# ARTEX Audit Core & Dual-Graph Skill

This skill ports the core multi-agent orchestration model of [`jiwoochris/artex-global`](https://github.com/jiwoochris/artex-global) (AGPL-3.0) to **Antigravity Android ARM64** with **zero Docker and zero PostgreSQL**, backed by a native Rust MCP binary (`artex-audit-mcp`) and a shared SQLite WAL database (`~/.gemini/artex/artex.db`).

## 1. Safety & Scope Boundary

- **Authorized Environments Only:** Always verify that the target is a local dev server (`localhost` / `127.0.0.1`), a local repository/APK, or an explicitly authorized environment registered with `artex_scope_configure` (`action: "upsert_company"`).
- **Non-Destructive Verification:** Confirm vulnerabilities using read-only inspection, code review, headers/config checks, or benign boundary checks — never destructive payloads (`DROP`, `rm -rf`, DoS, or credential stuffing).

## 2. Dual-Graph Methodology

ARTEX separates **what the target surface is** from **how far it has been audited**:

1. **Asset Graph (`artex_asset_upsert`, `artex_asset_dsl_search`):**
   - Hierarchy: `root_domain` → `subdomain` → `ip` → `service` → `app` → `endpoint`.
   - Query with ARTEX DSL: `type=endpoint status=200 value~/api/v1 tech~express`.
2. **Exploration Graph (`artex_graph_record`, `artex_graph_overview`):**
   - Nodes: `goal`, `intent`, `fact`, `hint` (+ `finding` created automatically by `artex_finding_manage`).
   - Lineage edges: `goal --spawns--> intent --yields--> fact --derived_from--> intent --proves--> finding`.
   - Pin every `intent`, `fact`, and `finding` to concrete `asset_ids` so `artex_graph_overview` tracks uninspected surface (`unanchored_assets_count`).
3. **Planner Shared Todolist (`artex_task_manage`):**
   - Store ordered multi-step audit chains in `todolist_json` so subagents execute prerequisite discovery before deeper verification without duplicating work.
4. **Cross-Worker Process Traces (`artex_worker_trace`):**
   - When spawning Antigravity subagents (`invoke_subagent` or `swarm`), each worker records notable headers, error codes, or auth patterns (`action: "record"`), and sibling workers query them (`action: "search"`, `exclude_intent_id`).

## 3. Reporting & Live Mini-Dashboard (`127.0.0.1:8787`)

- **Archive Evidence:** Call `artex_evidence_archive` to store sanitized HTTP request/response excerpts with a deterministic fingerprint linked to `finding_id`.
- **Export Reports:** Call `artex_report_export` (`format: "markdown"` or `"csv"`, `lang: "es"` or `"en"`).
- **Open Web Console:** Call `artex_dashboard_server` (`action: "start"`, `open_browser: true`) to launch the dark-mode **ARTEX Global Console** on `http://127.0.0.1:8787` featuring the live SVG Dual-Graph, Severity filters, Guard audit log, and 1-click CSV/Markdown downloads.
