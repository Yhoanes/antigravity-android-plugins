// dashboard.rs — Native Rust HTTP Mini-Dashboard for ARTEX Global (127.0.0.1:8787)
// Zero Node.js/Docker dependency; queries SQLite WAL directly per request.

use crate::json::{n_i64, s, JsonVal};
use crate::sqlite::{Db, SqlParam};
use std::io::{Read, Write};
use std::net::{TcpListener, TcpStream};
use std::path::Path;
use std::time::Duration;

pub fn build_markdown_report(db: &Db, task_id: Option<i64>, lang: &str) -> Result<String, String> {
    let is_es = !lang.eq_ignore_ascii_case("en");
    let tasks = if let Some(tid) = task_id {
        db.query_rows(
            "SELECT id, title, target, status, lang, todolist_json, datetime(created_at,'unixepoch') AS created FROM tasks WHERE id = ?1;",
            &[SqlParam::Int(tid)],
        )?
    } else {
        db.query_rows(
            "SELECT id, title, target, status, lang, todolist_json, datetime(created_at,'unixepoch') AS created FROM tasks ORDER BY id DESC;",
            &[],
        )?
    };

    let assets = db.query_rows(
        "SELECT id, asset_type, value, host, port, http_status, title, tech_stack FROM assets ORDER BY id ASC LIMIT 200;",
        &[],
    )?;

    let findings = if let Some(tid) = task_id {
        db.query_rows(
            "SELECT f.id, f.task_id, f.title, f.severity, f.status, f.cwe, f.cvss, f.description, f.reproduction, f.remediation, COALESCE(a.value,'-') AS asset_val FROM findings f LEFT JOIN assets a ON a.id = f.asset_id WHERE f.task_id = ?1 ORDER BY CASE f.severity WHEN 'critical' THEN 1 WHEN 'high' THEN 2 WHEN 'medium' THEN 3 WHEN 'low' THEN 4 ELSE 5 END, f.id DESC;",
            &[SqlParam::Int(tid)],
        )?
    } else {
        db.query_rows(
            "SELECT f.id, f.task_id, f.title, f.severity, f.status, f.cwe, f.cvss, f.description, f.reproduction, f.remediation, COALESCE(a.value,'-') AS asset_val FROM findings f LEFT JOIN assets a ON a.id = f.asset_id ORDER BY CASE f.severity WHEN 'critical' THEN 1 WHEN 'high' THEN 2 WHEN 'medium' THEN 3 WHEN 'low' THEN 4 ELSE 5 END, f.id DESC;",
            &[],
        )?
    };

    let mut md = String::with_capacity(4096);
    if is_es {
        md.push_str("# Informe de Auditoría de Seguridad — ARTEX Global (Android ARM64)\n\n");
        md.push_str("> Generado únicamente sobre objetivos autorizados bajo control de alcance (`artex-guard`).\n\n");
        md.push_str("## 1. Resumen Ejecutivo\n\n");
        md.push_str(&format!(
            "- **Tareas evaluadas:** {}\n- **Activos en Grafo (Asset Graph):** {}\n- **Hallazgos registrados:** {}\n\n",
            tasks.len(),
            assets.len(),
            findings.len()
        ));
    } else {
        md.push_str("# Security Assessment Report — ARTEX Global (Android ARM64)\n\n");
        md.push_str("> Generated strictly for authorized targets under `artex-guard` scope enforcement.\n\n");
        md.push_str("## 1. Executive Summary\n\n");
        md.push_str(&format!(
            "- **Evaluated Tasks:** {}\n- **Asset Graph Nodes:** {}\n- **Recorded Findings:** {}\n\n",
            tasks.len(),
            assets.len(),
            findings.len()
        ));
    }

    md.push_str(if is_es { "## 2. Tareas\n\n" } else { "## 2. Tasks\n\n" });
    if tasks.is_empty() {
        md.push_str(if is_es { "_Sin tareas registradas._\n\n" } else { "_No tasks recorded._\n\n" });
    } else {
        md.push_str("| ID | Título / Title | Objetivo / Target | Estado / Status | Fecha |\n|---|---|---|---|---|\n");
        for t in &tasks {
            md.push_str(&format!(
                "| #{} | {} | `{}` | `{}` | {} |\n",
                t.get_i64("id").unwrap_or(0),
                t.get_str("title").unwrap_or("-"),
                t.get_str("target").unwrap_or("-"),
                t.get_str("status").unwrap_or("-"),
                t.get_str("created").unwrap_or("-")
            ));
        }
        md.push('\n');
    }

    md.push_str(if is_es { "## 3. Superficie de Activos (Asset Graph)\n\n" } else { "## 3. Asset Graph Surface\n\n" });
    if assets.is_empty() {
        md.push_str(if is_es { "_Sin activos descubiertos aún._\n\n" } else { "_No assets discovered yet._\n\n" });
    } else {
        md.push_str("| ID | Tipo | Valor | HTTP | Stack |\n|---|---|---|---|---|\n");
        for a in &assets {
            md.push_str(&format!(
                "| A{} | `{}` | `{}` | {} | {} |\n",
                a.get_i64("id").unwrap_or(0),
                a.get_str("asset_type").unwrap_or("-"),
                a.get_str("value").unwrap_or("-"),
                a.get_i64("http_status").unwrap_or(0),
                a.get_str("tech_stack").unwrap_or("-")
            ));
        }
        md.push('\n');
    }

    md.push_str(if is_es { "## 4. Hallazgos de Seguridad (Findings)\n\n" } else { "## 4. Security Findings\n\n" });
    if findings.is_empty() {
        md.push_str(if is_es { "_No se han registrado vulnerabilidades._\n" } else { "_No findings recorded._\n" });
    } else {
        for f in &findings {
            let fid = f.get_i64("id").unwrap_or(0);
            let sev = f.get_str("severity").unwrap_or("info").to_uppercase();
            let title = f.get_str("title").unwrap_or("Untitled");
            let status = f.get_str("status").unwrap_or("open");
            let cwe = f.get_str("cwe").unwrap_or("-");
            let cvss = f.get_f64("cvss").unwrap_or(0.0);
            let asset_val = f.get_str("asset_val").unwrap_or("-");
            md.push_str(&format!(
                "### [F-{}] [{}] {}\n- **Estado:** `{}` | **Activo:** `{}` | **CWE:** `{}` | **CVSS:** `{:.1}`\n\n",
                fid, sev, title, status, asset_val, cwe, cvss
            ));
            let desc = f.get_str("description").unwrap_or("");
            if !desc.is_empty() {
                md.push_str(&format!("**Descripción:**\n{}\n\n", desc));
            }
            let repro = f.get_str("reproduction").unwrap_or("");
            if !repro.is_empty() {
                md.push_str(&format!("**Evidencia / Verificación:**\n```text\n{}\n```\n\n", repro));
            }
            let rem = f.get_str("remediation").unwrap_or("");
            if !rem.is_empty() {
                md.push_str(&format!("**Mitigación Recomendada:**\n{}\n\n", rem));
            }
            md.push_str("---\n\n");
        }
    }
    Ok(md)
}

pub fn build_findings_csv(db: &Db, task_id: Option<i64>) -> Result<String, String> {
    let rows = if let Some(tid) = task_id {
        db.query_rows(
            "SELECT f.id, f.task_id, f.severity, f.status, f.title, f.cwe, f.cvss, COALESCE(a.value,'') AS asset, f.remediation, datetime(f.created_at,'unixepoch') AS created_at FROM findings f LEFT JOIN assets a ON a.id = f.asset_id WHERE f.task_id = ?1 ORDER BY f.id DESC;",
            &[SqlParam::Int(tid)],
        )?
    } else {
        db.query_rows(
            "SELECT f.id, f.task_id, f.severity, f.status, f.title, f.cwe, f.cvss, COALESCE(a.value,'') AS asset, f.remediation, datetime(f.created_at,'unixepoch') AS created_at FROM findings f LEFT JOIN assets a ON a.id = f.asset_id ORDER BY f.id DESC;",
            &[],
        )?
    };
    let mut csv = String::from("id,task_id,severity,status,title,cwe,cvss,asset,remediation,created_at\n");
    let esc = |v: &str| -> String {
        let cleaned = v.replace('"', "\"\"").replace('\n', " ").replace('\r', " ");
        format!("\"{}\"", cleaned)
    };
    for r in rows {
        csv.push_str(&format!(
            "{},{},{},{},{},{},{:.1},{},{},{}\n",
            r.get_i64("id").unwrap_or(0),
            r.get_i64("task_id").unwrap_or(0),
            esc(r.get_str("severity").unwrap_or("")),
            esc(r.get_str("status").unwrap_or("")),
            esc(r.get_str("title").unwrap_or("")),
            esc(r.get_str("cwe").unwrap_or("")),
            r.get_f64("cvss").unwrap_or(0.0),
            esc(r.get_str("asset").unwrap_or("")),
            esc(r.get_str("remediation").unwrap_or("")),
            esc(r.get_str("created_at").unwrap_or("")),
        ));
    }
    Ok(csv)
}

fn api_snapshot_json(db: &Db) -> Result<JsonVal, String> {
    let mut out = JsonVal::obj();
    let mut stats = JsonVal::obj();
    stats.insert("tasks", n_i64(db.query_i64("SELECT COUNT(*) FROM tasks;", &[])));
    stats.insert("assets", n_i64(db.query_i64("SELECT COUNT(*) FROM assets;", &[])));
    stats.insert(
        "exploration_nodes",
        n_i64(db.query_i64("SELECT COUNT(*) FROM exploration_nodes;", &[])),
    );
    stats.insert("findings", n_i64(db.query_i64("SELECT COUNT(*) FROM findings;", &[])));
    stats.insert(
        "critical_high",
        n_i64(db.query_i64(
            "SELECT COUNT(*) FROM findings WHERE severity IN ('critical','high');",
            &[],
        )),
    );
    stats.insert(
        "guard_events",
        n_i64(db.query_i64("SELECT COUNT(*) FROM guard_audit;", &[])),
    );
    stats.insert(
        "guard_blocked",
        n_i64(db.query_i64("SELECT COUNT(*) FROM guard_audit WHERE action IN ('deny','ask');", &[])),
    );
    out.insert("stats", stats);

    out.insert(
        "companies",
        JsonVal::Arr(db.query_rows(
            "SELECT id, name, scope_patterns, authorized_note FROM companies ORDER BY id ASC;",
            &[],
        )?),
    );
    out.insert(
        "tasks",
        JsonVal::Arr(db.query_rows(
            "SELECT id, company_id, title, target, status, lang, todolist_json, datetime(updated_at,'unixepoch') AS updated FROM tasks ORDER BY id DESC LIMIT 50;",
            &[],
        )?),
    );
    out.insert(
        "assets",
        JsonVal::Arr(db.query_rows(
            "SELECT id, parent_id, asset_type, value, host, port, protocol, http_status, title, tech_stack FROM assets ORDER BY id ASC LIMIT 200;",
            &[],
        )?),
    );
    out.insert(
        "nodes",
        JsonVal::Arr(db.query_rows(
            "SELECT id, task_id, node_type, title, content, status, severity, owner_worker FROM exploration_nodes ORDER BY id ASC LIMIT 250;",
            &[],
        )?),
    );
    out.insert(
        "edges",
        JsonVal::Arr(db.query_rows(
            "SELECT id, task_id, from_node_id, to_node_id, edge_type FROM exploration_edges ORDER BY id ASC LIMIT 400;",
            &[],
        )?),
    );
    out.insert(
        "anchors",
        JsonVal::Arr(db.query_rows(
            "SELECT node_id, asset_id FROM exploration_anchors LIMIT 400;",
            &[],
        )?),
    );
    out.insert(
        "findings",
        JsonVal::Arr(db.query_rows(
            "SELECT f.id, f.task_id, f.title, f.severity, f.status, f.cwe, f.cvss, f.description, f.remediation, COALESCE(a.value,'-') AS asset_value, datetime(f.created_at,'unixepoch') AS created FROM findings f LEFT JOIN assets a ON a.id = f.asset_id ORDER BY f.id DESC LIMIT 150;",
            &[],
        )?),
    );
    out.insert(
        "traces",
        JsonVal::Arr(db.query_rows(
            "SELECT id, task_id, intent_id, worker_name, step_no, summary, datetime(created_at,'unixepoch') AS created FROM worker_traces ORDER BY id DESC LIMIT 40;",
            &[],
        )?),
    );
    out.insert(
        "guard_audit",
        JsonVal::Arr(db.query_rows(
            "SELECT id, datetime(ts,'unixepoch') AS time, tool_name, action, reason, command FROM guard_audit ORDER BY id DESC LIMIT 60;",
            &[],
        )?),
    );
    out.insert(
        "intercept_rules",
        JsonVal::Arr(db.query_rows(
            "SELECT id, name, pattern, action, reason, enabled FROM intercept_rules ORDER BY id ASC;",
            &[],
        )?),
    );
    Ok(out)
}

fn send_http(stream: &mut TcpStream, status: &str, content_type: &str, extra_hdr: &str, body: &[u8]) {
    let hdr = format!(
        "HTTP/1.1 {}\r\nContent-Type: {}\r\nContent-Length: {}\r\nCache-Control: no-store\r\nConnection: close\r\n{}\r\n",
        status,
        content_type,
        body.len(),
        extra_hdr
    );
    let _ = stream.write_all(hdr.as_bytes());
    let _ = stream.write_all(body);
    let _ = stream.flush();
}

fn handle_client(mut stream: TcpStream, db_path: &Path) {
    let _ = stream.set_read_timeout(Some(Duration::from_secs(3)));
    let _ = stream.set_write_timeout(Some(Duration::from_secs(5)));
    let mut buf = [0u8; 4096];
    let n = match stream.read(&mut buf) {
        Ok(n) if n > 0 => n,
        _ => return,
    };
    let req_line = String::from_utf8_lossy(&buf[..n]);
    let first_line = req_line.lines().next().unwrap_or("");
    let mut parts = first_line.split_whitespace();
    let _method = parts.next().unwrap_or("GET");
    let full_path = parts.next().unwrap_or("/");
    let path = full_path.split('?').next().unwrap_or("/");

    match path {
        "/healthz" => {
            send_http(&mut stream, "200 OK", "application/json; charset=utf-8", "", b"{\"ok\":true,\"service\":\"artex-dashboard\"}");
        }
        "/api/snapshot" => match Db::open(db_path).and_then(|db| api_snapshot_json(&db)) {
            Ok(jv) => {
                let s_body = jv.to_json_string();
                send_http(&mut stream, "200 OK", "application/json; charset=utf-8", "", s_body.as_bytes());
            }
            Err(e) => {
                let mut err = JsonVal::obj();
                err.insert("ok", JsonVal::Bool(false));
                err.insert("error", s(&e));
                send_http(&mut stream, "500 Internal Server Error", "application/json; charset=utf-8", "", err.to_json_string().as_bytes());
            }
        },
        "/api/findings.csv" => match Db::open(db_path).and_then(|db| build_findings_csv(&db, None)) {
            Ok(csv) => {
                send_http(
                    &mut stream,
                    "200 OK",
                    "text/csv; charset=utf-8",
                    "Content-Disposition: attachment; filename=\"artex-findings.csv\"\r\n",
                    csv.as_bytes(),
                );
            }
            Err(e) => send_http(&mut stream, "500 Internal Server Error", "text/plain; charset=utf-8", "", e.as_bytes()),
        },
        "/api/report.md" => match Db::open(db_path).and_then(|db| build_markdown_report(&db, None, "es")) {
            Ok(md) => {
                send_http(
                    &mut stream,
                    "200 OK",
                    "text/markdown; charset=utf-8",
                    "Content-Disposition: attachment; filename=\"artex-report.md\"\r\n",
                    md.as_bytes(),
                );
            }
            Err(e) => send_http(&mut stream, "500 Internal Server Error", "text/plain; charset=utf-8", "", e.as_bytes()),
        },
        "/" | "/index.html" => {
            send_http(&mut stream, "200 OK", "text/html; charset=utf-8", "", DASHBOARD_HTML.as_bytes());
        }
        _ => {
            send_http(&mut stream, "404 Not Found", "text/plain; charset=utf-8", "", b"Not Found");
        }
    }
}

pub fn serve_blocking(bind_addr: &str, db_path: &Path) -> Result<(), String> {
    let listener = TcpListener::bind(bind_addr)
        .map_err(|e| format!("Failed to bind {}: {}", bind_addr, e))?;
    for incoming in listener.incoming() {
        if let Ok(stream) = incoming {
            handle_client(stream, db_path);
        }
    }
    Ok(())
}

const DASHBOARD_HTML: &str = r##"<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>ARTEX Global — Android ARM64 Console</title>
<style>
:root {
  --bg: #090d16; --panel: #111827; --panel2: #1a2333; --border: #26334d;
  --fg: #e5eefb; --muted: #8ea0be; --accent: #38bdf8; --emerald: #10b981;
  --amber: #f59e0b; --rose: #f43f5e; --violet: #a78bfa;
}
* { box-sizing: border-box; margin: 0; padding: 0; }
body { font-family: system-ui, -apple-system, sans-serif; background: var(--bg); color: var(--fg); line-height: 1.5; }
header { display: flex; flex-wrap: wrap; align-items: center; justify-content: space-between; gap: 12px; padding: 14px 20px; background: #0c1322; border-bottom: 1px solid var(--border); position: sticky; top: 0; z-index: 20; }
.brand { display: flex; align-items: center; gap: 10px; font-weight: 700; font-size: 1.05rem; letter-spacing: 0.3px; }
.badge-pill { font-size: 0.72rem; padding: 2px 8px; border-radius: 999px; background: rgba(56,189,248,0.15); color: var(--accent); border: 1px solid rgba(56,189,248,0.35); }
.tabs { display: flex; flex-wrap: wrap; gap: 6px; padding: 12px 20px; border-bottom: 1px solid var(--border); background: #0d1424; }
.tab-btn { background: transparent; color: var(--muted); border: 1px solid transparent; padding: 7px 13px; border-radius: 8px; cursor: pointer; font-size: 0.86rem; font-weight: 600; }
.tab-btn.active { background: var(--panel2); color: var(--fg); border-color: var(--border); }
.actions { display: flex; gap: 8px; align-items: center; }
.btn { background: var(--panel2); color: var(--fg); border: 1px solid var(--border); padding: 6px 12px; border-radius: 7px; font-size: 0.8rem; cursor: pointer; text-decoration: none; display: inline-flex; align-items: center; gap: 5px; }
.btn:hover { border-color: var(--accent); }
main { max-width: 1280px; margin: 0 auto; padding: 18px 20px 48px; }
.grid-kpi { display: grid; grid-template-columns: repeat(auto-fit, minmax(170px, 1fr)); gap: 12px; margin-bottom: 18px; }
.card { background: var(--panel); border: 1px solid var(--border); border-radius: 12px; padding: 15px; margin-bottom: 16px; }
.kpi-label { font-size: 0.76rem; color: var(--muted); text-transform: uppercase; letter-spacing: 0.5px; }
.kpi-val { font-size: 1.75rem; font-weight: 800; margin-top: 4px; }
h2 { font-size: 1rem; margin-bottom: 10px; color: var(--accent); }
table { width: 100%; border-collapse: collapse; font-size: 0.84rem; }
th, td { text-align: left; padding: 9px 10px; border-bottom: 1px solid var(--border); vertical-align: top; }
th { color: var(--muted); font-weight: 600; font-size: 0.76rem; text-transform: uppercase; }
.sev { padding: 2px 8px; border-radius: 6px; font-weight: 700; font-size: 0.72rem; text-transform: uppercase; display: inline-block; }
.sev-critical { background: rgba(244,63,94,0.22); color: #fda4af; border: 1px solid #f43f5e; }
.sev-high { background: rgba(245,158,11,0.22); color: #fcd34d; border: 1px solid #f59e0b; }
.sev-medium { background: rgba(56,189,248,0.18); color: #7dd3fc; border: 1px solid #38bdf8; }
.sev-low, .sev-info { background: rgba(142,160,190,0.16); color: #cbd5e1; border: 1px solid #475569; }
.hidden { display: none !important; }
code { font-family: ui-monospace, monospace; background: #090e1a; padding: 2px 5px; border-radius: 4px; font-size: 0.8rem; color: #93c5fd; }
.graph-wrap { width: 100%; overflow-x: auto; background: #070b13; border: 1px solid var(--border); border-radius: 10px; padding: 10px; }
.attack-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap: 10px; }
.attack-tile { background: var(--panel2); border-left: 4px solid var(--emerald); border-radius: 8px; padding: 11px; }
.attack-tile.med { border-left-color: var(--amber); }
</style>
</head>
<body>
<header>
  <div class="brand">
    <svg width="24" height="24" viewBox="0 0 64 64" fill="none"><rect x="6" y="6" width="52" height="52" rx="12" fill="#0f172a" stroke="#38bdf8" stroke-width="3"/><circle cx="22" cy="24" r="5" fill="#10b981"/><circle cx="42" cy="24" r="5" fill="#38bdf8"/><circle cx="32" cy="43" r="5" fill="#f43f5e"/><path d="M26 26L38 25M24 28L30 39M40 28L34 39" stroke="#94a3b8" stroke-width="2.2" stroke-dasharray="3 2"/></svg>
    <span>ARTEX Global</span>
    <span class="badge-pill">Rust ARM64 + SQLite WAL</span>
  </div>
  <div class="actions">
    <a class="btn" href="/api/findings.csv">⬇ CSV</a>
    <a class="btn" href="/api/report.md">⬇ Markdown</a>
    <button class="btn" id="langBtn" onclick="toggleLang()">ES / EN</button>
    <button class="btn" onclick="loadSnapshot()">↻ Sync</button>
  </div>
</header>
<nav class="tabs">
  <button class="tab-btn active" onclick="showTab('overview',this)" data-i18n="tab_overview">Resumen</button>
  <button class="tab-btn" onclick="showTab('graph',this)" data-i18n="tab_graph">Grafo Dual</button>
  <button class="tab-btn" onclick="showTab('findings',this)" data-i18n="tab_findings">Hallazgos</button>
  <button class="tab-btn" onclick="showTab('guard',this)" data-i18n="tab_guard">Guardia & Alcance</button>
  <button class="tab-btn" onclick="showTab('defense',this)" data-i18n="tab_defense">Defensa ATT&CK</button>
</nav>
<main>
  <section id="sec-overview">
    <div class="grid-kpi">
      <div class="card"><div class="kpi-label" data-i18n="kpi_tasks">Tareas</div><div class="kpi-val" id="k-tasks">0</div></div>
      <div class="card"><div class="kpi-label" data-i18n="kpi_assets">Nodos Asset Graph</div><div class="kpi-val" id="k-assets" style="color:var(--accent)">0</div></div>
      <div class="card"><div class="kpi-label" data-i18n="kpi_exp">Nodos Exploración</div><div class="kpi-val" id="k-exp" style="color:var(--violet)">0</div></div>
      <div class="card"><div class="kpi-label" data-i18n="kpi_findings">Hallazgos (Crít/Alt)</div><div class="kpi-val" id="k-findings" style="color:var(--rose)">0</div></div>
      <div class="card"><div class="kpi-label" data-i18n="kpi_guard">Eventos Guard (Bloq)</div><div class="kpi-val" id="k-guard" style="color:var(--emerald)">0</div></div>
    </div>
    <div class="card">
      <h2 data-i18n="h_tasks">Tareas Activas & Todolist del Planner</h2>
      <div style="overflow-x:auto"><table id="tbl-tasks"><thead><tr><th>ID</th><th>Título</th><th>Objetivo</th><th>Estado</th><th>Actualizado</th></tr></thead><tbody></tbody></table></div>
    </div>
    <div class="card">
      <h2 data-i18n="h_traces">Intercambio de Trazas entre Workers (Process Traces)</h2>
      <div style="overflow-x:auto"><table id="tbl-traces"><thead><tr><th>Intent</th><th>Worker</th><th>Paso</th><th>Resumen</th><th>Hora</th></tr></thead><tbody></tbody></table></div>
    </div>
  </section>

  <section id="sec-graph" class="hidden">
    <div class="card">
      <h2 data-i18n="h_dualgraph">Grafo Dual ARTEX: Cadena de Exploración ⇄ Grafo Global de Activos</h2>
      <p style="color:var(--muted);font-size:0.82rem;margin-bottom:10px" data-i18n="p_dualgraph">Izquierda: Exploration Graph (goal → intent → fact → finding). Derecha: Asset Graph (root_domain → subdomain → service → endpoint). Líneas punteadas: exploration_anchors.</p>
      <div class="graph-wrap" id="svg-box"></div>
    </div>
    <div class="card">
      <h2>Inventario Asset Graph</h2>
      <div style="overflow-x:auto"><table id="tbl-assets"><thead><tr><th>ID</th><th>Tipo</th><th>Valor</th><th>HTTP</th><th>Título / Tech Stack</th></tr></thead><tbody></tbody></table></div>
    </div>
  </section>

  <section id="sec-findings" class="hidden">
    <div class="card">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px;flex-wrap:wrap;gap:8px">
        <h2 style="margin:0" data-i18n="h_findings">Hallazgos Confirmados & Evidencia</h2>
        <select id="sevFilter" onchange="renderFindings()" class="btn">
          <option value="all">Todas las severidades / All</option>
          <option value="critical">Critical</option>
          <option value="high">High</option>
          <option value="medium">Medium</option>
          <option value="low">Low / Info</option>
        </select>
      </div>
      <div style="overflow-x:auto"><table id="tbl-findings"><thead><tr><th>ID</th><th>Severidad</th><th>Estado</th><th>Título & Descripción</th><th>Activo</th><th>CWE / CVSS</th></tr></thead><tbody></tbody></table></div>
    </div>
  </section>

  <section id="sec-guard" class="hidden">
    <div class="card">
      <h2 data-i18n="h_scope">Alcance Autorizado (Authorized Scope)</h2>
      <div style="overflow-x:auto"><table id="tbl-scope"><thead><tr><th>ID</th><th>Entorno</th><th>Patrones Permitidos</th><th>Nota de Autorización</th></tr></thead><tbody></tbody></table></div>
    </div>
    <div class="card">
      <h2 data-i18n="h_rules">Reglas de Intercepción PreToolUse (ARTEX Guard)</h2>
      <div style="overflow-x:auto"><table id="tbl-rules"><thead><tr><th>Regla</th><th>Acción</th><th>Patrón</th><th>Motivo</th></tr></thead><tbody></tbody></table></div>
    </div>
    <div class="card">
      <h2 data-i18n="h_audit">Registro de Auditoría PreToolUse</h2>
      <div style="overflow-x:auto"><table id="tbl-audit"><thead><tr><th>Hora</th><th>Herramienta</th><th>Decisión</th><th>Comando / Detalle</th><th>Motivo</th></tr></thead><tbody></tbody></table></div>
    </div>
  </section>

  <section id="sec-defense" class="hidden">
    <div class="card">
      <h2>Cobertura MITRE ATT&CK v16 Enterprise (Detección Defensiva ARTEX)</h2>
      <p style="color:var(--muted);font-size:0.83rem;margin-bottom:12px">Basado en <code>detections/attack/artex_navigator_layer.json</code> (9 reglas Sigma + 3 Suricata SIDs + Host Triage).</p>
      <div class="attack-grid">
        <div class="attack-tile"><strong>T1595 · Reconnaissance (Score 100)</strong><div style="font-size:0.8rem;color:var(--muted);margin-top:4px">Sondeo HTTP <code>artex-enrich/1.0</code> + velocidad/fan-out (Sigma + Suricata SID 1000001/1000002).</div></div>
        <div class="attack-tile"><strong>T1592 · Gather Victim Host Info (Score 100)</strong><div style="font-size:0.8rem;color:var(--muted);margin-top:4px">Auto-enriquecimiento DNS/HTTP leyendo <code>&lt;title&gt;</code> y cabeceras.</div></div>
        <div class="attack-tile"><strong>T1105 · Ingress Tool Transfer (Score 100)</strong><div style="font-size:0.8rem;color:var(--muted);margin-top:4px">Egreso <code>artex-selfupdate</code> hacia repositorios de releases.</div></div>
        <div class="attack-tile"><strong>T1059 · Command & Scripting (Score 100)</strong><div style="font-size:0.8rem;color:var(--muted);margin-top:4px">Marcador forense <code>【ARTEX 平台管控·非目标防御】</code> y ráfagas de bloqueo Guard.</div></div>
        <div class="attack-tile med"><strong>T1485 · Data Destruction (Score 65)</strong><div style="font-size:0.8rem;color:var(--muted);margin-top:4px">Caza de comandos destructivos (<code>rm -rf</code>, <code>DROP DATABASE</code>, <code>FLUSHALL</code>).</div></div>
        <div class="attack-tile med"><strong>T1561.002 · Disk Wipe (Score 50)</strong><div style="font-size:0.8rem;color:var(--muted);margin-top:4px">Detección de <code>mkfs</code>, <code>dd of=/dev/</code>, <code>shred</code>.</div></div>
        <div class="attack-tile med"><strong>T1489 · Service Stop (Score 50)</strong><div style="font-size:0.8rem;color:var(--muted);margin-top:4px">Detección de <code>iptables -F</code>, <code>nft flush ruleset</code>, <code>killall -9</code>.</div></div>
        <div class="attack-tile med"><strong>T1557 · AiTM Recording Proxy CA (Score 50)</strong><div style="font-size:0.8rem;color:var(--muted);margin-top:4px">Artefacto <code>_ca/mitmproxy-ca-cert.pem</code> + inyección <code>NODE_EXTRA_CA_CERTS</code> / <code>127.0.0.1:8788</code>.</div></div>
      </div>
    </div>
  </section>
</main>
<script>
let DATA = { stats:{}, tasks:[], assets:[], nodes:[], edges:[], anchors:[], findings:[], traces:[], guard_audit:[], intercept_rules:[], companies:[] };
let LANG = 'es';
const I18N = {
  es: { tab_overview:'Resumen', tab_graph:'Grafo Dual', tab_findings:'Hallazgos', tab_guard:'Guardia & Alcance', tab_defense:'Defensa ATT&CK', kpi_tasks:'Tareas', kpi_assets:'Nodos Asset Graph', kpi_exp:'Nodos Exploración', kpi_findings:'Hallazgos (Crít/Alt)', kpi_guard:'Eventos Guard (Bloq)' },
  en: { tab_overview:'Overview', tab_graph:'Dual Graph', tab_findings:'Findings', tab_guard:'Guard & Scope', tab_defense:'ATT&CK Defense', kpi_tasks:'Tasks', kpi_assets:'Asset Graph Nodes', kpi_exp:'Exploration Nodes', kpi_findings:'Findings (Crit/High)', kpi_guard:'Guard Events (Blocked)' }
};
function esc(s){ return String(s==null?'':s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }
function toggleLang(){
  LANG = LANG === 'es' ? 'en' : 'es';
  document.querySelectorAll('[data-i18n]').forEach(el => {
    const k = el.getAttribute('data-i18n');
    if (I18N[LANG][k]) el.textContent = I18N[LANG][k];
  });
}
function showTab(name, btn){
  ['overview','graph','findings','guard','defense'].forEach(t => {
    document.getElementById('sec-'+t).classList.toggle('hidden', t !== name);
  });
  document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
}
function renderFindings(){
  const f = document.getElementById('sevFilter').value;
  const tb = document.querySelector('#tbl-findings tbody');
  const rows = DATA.findings.filter(x => f==='all' || (f==='low' ? (x.severity==='low'||x.severity==='info') : x.severity===f));
  tb.innerHTML = rows.length ? rows.map(r => `<tr>
    <td>#F${r.id}</td>
    <td><span class="sev sev-${esc(r.severity)}">${esc(r.severity)}</span></td>
    <td><code>${esc(r.status)}</code></td>
    <td><strong>${esc(r.title)}</strong><div style="color:var(--muted);font-size:0.79rem;margin-top:3px">${esc(r.description)}</div>${r.remediation?`<div style="color:var(--emerald);font-size:0.78rem;margin-top:3px">Fix: ${esc(r.remediation)}</div>`:''}</td>
    <td><code>${esc(r.asset_value)}</code></td>
    <td><code>${esc(r.cwe||'-')}</code> (${Number(r.cvss||0).toFixed(1)})</td>
  </tr>`).join('') : '<tr><td colspan="6" style="color:var(--muted)">Sin hallazgos en este filtro.</td></tr>';
}
function renderDualGraph(){
  const box = document.getElementById('svg-box');
  const nodes = DATA.nodes.slice(0, 14);
  const assets = DATA.assets.slice(0, 14);
  const h = Math.max(260, Math.max(nodes.length, assets.length) * 54 + 60);
  const nPos = {}, aPos = {};
  let svg = `<svg width="920" height="${h}" viewBox="0 0 920 ${h}" xmlns="http://www.w3.org/2000/svg">`;
  svg += `<text x="30" y="26" fill="#a78bfa" font-size="13" font-weight="bold">EXPLORATION GRAPH (goal → intent → fact → finding)</text>`;
  svg += `<text x="530" y="26" fill="#38bdf8" font-size="13" font-weight="bold">ASSET GRAPH (domain → service → endpoint)</text>`;
  nodes.forEach((n, i) => { nPos[n.id] = {x: 195, y: 58 + i*50}; });
  assets.forEach((a, i) => { aPos[a.id] = {x: 700, y: 58 + i*50}; });
  DATA.edges.forEach(e => {
    const p1 = nPos[e.from_node_id], p2 = nPos[e.to_node_id];
    if (p1 && p2) svg += `<path d="M ${p1.x} ${p1.y+14} C 80 ${(p1.y+p2.y)/2}, 80 ${(p1.y+p2.y)/2}, ${p2.x} ${p2.y-14}" stroke="#a78bfa" stroke-width="1.6" fill="none"/>`;
  });
  DATA.anchors.forEach(an => {
    const p1 = nPos[an.node_id], p2 = aPos[an.asset_id];
    if (p1 && p2) svg += `<line x1="${p1.x+155}" y1="${p1.y}" x2="${p2.x-155}" y2="${p2.y}" stroke="#f59e0b" stroke-width="1.5" stroke-dasharray="5 4"/>`;
  });
  const nColors = { goal:'#10b981', intent:'#38bdf8', fact:'#a78bfa', finding:'#f43f5e', hint:'#f59e0b' };
  nodes.forEach(n => {
    const p = nPos[n.id], col = nColors[n.node_type] || '#94a3b8';
    const lbl = `[${n.node_type}] ${n.title}`.slice(0, 36);
    svg += `<g><rect x="${p.x-155}" y="${p.y-17}" width="310" height="34" rx="7" fill="#131c2e" stroke="${col}" stroke-width="1.6"/><text x="${p.x-143}" y="${p.y+4}" fill="#e5eefb" font-size="12">${esc(lbl)}</text></g>`;
  });
  assets.forEach(a => {
    const p = aPos[a.id];
    const lbl = `[${a.asset_type}] ${a.value}`.slice(0, 38);
    svg += `<g><rect x="${p.x-155}" y="${p.y-17}" width="330" height="34" rx="7" fill="#102033" stroke="#38bdf8" stroke-width="1.5"/><text x="${p.x-143}" y="${p.y+4}" fill="#e0f2fe" font-size="12">${esc(lbl)}</text></g>`;
  });
  if (!nodes.length && !assets.length) {
    svg += `<text x="460" y="140" text-anchor="middle" fill="#8ea0be" font-size="13">Ejecuta una tarea con artex-audit o artex-recon para poblar el Grafo Dual.</text>`;
  }
  svg += `</svg>`;
  box.innerHTML = svg;
}
async function loadSnapshot(){
  try {
    const res = await fetch('/api/snapshot');
    DATA = await res.json();
    const st = DATA.stats || {};
    document.getElementById('k-tasks').textContent = st.tasks || 0;
    document.getElementById('k-assets').textContent = st.assets || 0;
    document.getElementById('k-exp').textContent = st.exploration_nodes || 0;
    document.getElementById('k-findings').textContent = `${st.findings||0} (${st.critical_high||0})`;
    document.getElementById('k-guard').textContent = `${st.guard_events||0} (${st.guard_blocked||0})`;

    document.querySelector('#tbl-tasks tbody').innerHTML = DATA.tasks.length ? DATA.tasks.map(t => `<tr><td>#${t.id}</td><td><strong>${esc(t.title)}</strong></td><td><code>${esc(t.target)}</code></td><td><code>${esc(t.status)}</code></td><td>${esc(t.updated)}</td></tr>`).join('') : '<tr><td colspan="5" style="color:var(--muted)">Sin tareas registradas aún.</td></tr>';
    document.querySelector('#tbl-traces tbody').innerHTML = DATA.traces.length ? DATA.traces.map(tr => `<tr><td>#${tr.intent_id}</td><td><code>${esc(tr.worker_name)}</code></td><td>${tr.step_no}</td><td>${esc(tr.summary)}</td><td>${esc(tr.created)}</td></tr>`).join('') : '<tr><td colspan="5" style="color:var(--muted)">Sin trazas de workers aún.</td></tr>';
    document.querySelector('#tbl-assets tbody').innerHTML = DATA.assets.length ? DATA.assets.map(a => `<tr><td>A${a.id}</td><td><code>${esc(a.asset_type)}</code></td><td><code>${esc(a.value)}</code></td><td>${a.http_status||'-'}</td><td>${esc(a.title)} <span style="color:var(--muted)">${esc(a.tech_stack)}</span></td></tr>`).join('') : '<tr><td colspan="5" style="color:var(--muted)">Sin activos en el grafo.</td></tr>';
    document.querySelector('#tbl-scope tbody').innerHTML = DATA.companies.map(c => `<tr><td>#${c.id}</td><td><strong>${esc(c.name)}</strong></td><td><code>${esc(c.scope_patterns)}</code></td><td>${esc(c.authorized_note)}</td></tr>`).join('');
    document.querySelector('#tbl-rules tbody').innerHTML = DATA.intercept_rules.map(r => `<tr><td><code>${esc(r.name)}</code></td><td><span class="sev sev-${r.action==='deny'?'critical':'medium'}">${esc(r.action)}</span></td><td><code>${esc(r.pattern)}</code></td><td>${esc(r.reason)}</td></tr>`).join('');
    document.querySelector('#tbl-audit tbody').innerHTML = DATA.guard_audit.length ? DATA.guard_audit.map(g => `<tr><td>${esc(g.time)}</td><td><code>${esc(g.tool_name)}</code></td><td><span class="sev sev-${g.action==='deny'?'critical':(g.action==='ask'?'high':'low')}">${esc(g.action)}</span></td><td><code>${esc((g.command||'').slice(0,90))}</code></td><td>${esc(g.reason)}</td></tr>`).join('') : '<tr><td colspan="5" style="color:var(--muted)">Sin eventos interceptados aún.</td></tr>';
    renderFindings();
    renderDualGraph();
  } catch (e) { console.error(e); }
}
loadSnapshot();
setInterval(loadSnapshot, 6000);
</script>
</body>
</html>
"##;
