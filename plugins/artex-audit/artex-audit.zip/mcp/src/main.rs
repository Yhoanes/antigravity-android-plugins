// main.rs — ARTEX Audit Core & Dual-Graph Engine (artex-audit v1.0.0)
// Native Android ARM64 Rust MCP Server + SQLite WAL + PreToolUse Guard + 127.0.0.1:8787 Dashboard
mod dashboard;
mod json;
mod sqlite;

use dashboard::{build_findings_csv, build_markdown_report, serve_blocking};
use json::{
    make_tool, n_i64, parse_json, prop_arr_int, prop_bool, prop_int, prop_num, prop_str,
    prop_str_enum, s, JsonVal,
};
use sqlite::{sqlite_version, Db, SqlParam};
use std::env;
use std::fs;
use std::io::{self, BufRead, BufReader, Read, Write};
use std::net::TcpStream;
use std::path::{Path, PathBuf};
use std::process::{Command, Stdio};
use std::time::{Duration, SystemTime, UNIX_EPOCH};

const SERVER_NAME: &str = "artex-audit";
const SERVER_VERSION: &str = "1.0.0";
const DEFAULT_DASH_ADDR: &str = "127.0.0.1:8787";

struct EnvPaths {
    home: PathBuf,
    prefix: PathBuf,
    plugin_dir: PathBuf,
    artex_dir: PathBuf,
    db_path: PathBuf,
    pid_path: PathBuf,
}

impl EnvPaths {
    fn resolve() -> Self {
        let home = env::var("HOME")
            .map(PathBuf::from)
            .unwrap_or_else(|_| PathBuf::from("/data/user/0/com.agy/files"));
        let prefix = env::var("PREFIX")
            .map(PathBuf::from)
            .unwrap_or_else(|_| home.join("usr"));
        let plugin_dir = home.join(".gemini/config/plugins/artex-audit");
        let artex_dir = env::var("ARTEX_DATA_DIR")
            .map(PathBuf::from)
            .unwrap_or_else(|_| home.join(".gemini/artex"));
        let _ = fs::create_dir_all(&artex_dir);
        let db_path = artex_dir.join("artex.db");
        let pid_path = artex_dir.join("dashboard.pid");
        Self {
            home,
            prefix,
            plugin_dir,
            artex_dir,
            db_path,
            pid_path,
        }
    }
}

fn dashboard_alive(addr: &str) -> bool {
    if let Ok(addr_sock) = addr.parse() {
        TcpStream::connect_timeout(&addr_sock, Duration::from_millis(200)).is_ok()
    } else {
        TcpStream::connect(addr).is_ok()
    }
}

fn fnv_hex(data: &str) -> String {
    let mut h1: u64 = 0xcbf29ce484222325;
    let mut h2: u64 = 0x84222325cbf29ce4;
    for (i, b) in data.bytes().enumerate() {
        h1 ^= b as u64;
        h1 = h1.wrapping_mul(0x100000001b3);
        h2 ^= (b as u64).wrapping_add(i as u64);
        h2 = h2.wrapping_mul(0x100000001b3).rotate_left(5);
    }
    format!("{:016x}{:016x}", h1, h2)
}

// ---------------------------------------------------------------------------
// PreToolUse Hook Engine (ARTEX Guard & Scope Gate)
// ---------------------------------------------------------------------------

fn matches_pipe_patterns(haystack_lower: &str, pipe_pat: &str) -> Option<String> {
    for raw_tok in pipe_pat.split('|') {
        let tok = raw_tok
            .trim()
            .replace("\\.", ".")
            .replace("\\(", "(")
            .replace(".*", " ");
        if tok.is_empty() {
            continue;
        }
        let tl = tok.to_lowercase();
        if tl.contains(' ') {
            // Substring or multi-token ordered match
            let parts: Vec<&str> = tl.split_whitespace().collect();
            if parts.len() == 1 {
                if haystack_lower.contains(parts[0]) {
                    return Some(raw_tok.to_string());
                }
            } else {
                let mut cur = haystack_lower;
                let mut all_found = true;
                for pt in parts {
                    if let Some(idx) = cur.find(pt) {
                        cur = &cur[idx + pt.len()..];
                    } else {
                        all_found = false;
                        break;
                    }
                }
                if all_found {
                    return Some(raw_tok.to_string());
                }
            }
        } else if haystack_lower.contains(&tl) {
            return Some(raw_tok.to_string());
        }
    }
    None
}

fn evaluate_guard_command(paths: &EnvPaths, tool_name: &str, cmd: &str, conv_id: &str) -> (String, String) {
    let cmd_trimmed = cmd.trim();
    if cmd_trimmed.is_empty() {
        return ("allow".into(), String::new());
    }
    let lower = cmd_trimmed.to_lowercase();

    // Hard safety checks mirroring ARTEX guard/guard.go + Android runtime/bin protection
    let hard_denies: &[(&str, &str)] = &[
        ("--no-preserve-root", "【ARTEX Guard】 Destructive root deletion (--no-preserve-root) is strictly forbidden."),
        ("mkfs.", "【ARTEX Guard】 Disk formatting (mkfs) is blocked by ARTEX safety rules (T1561.002)."),
        ("dd of=/dev/", "【ARTEX Guard】 Raw block-device overwrite (dd of=/dev/) is blocked (T1561.002)."),
        ("wipe /dev/", "【ARTEX Guard】 Block-device wipe is blocked by ARTEX Guard."),
        ("shred /dev/", "【ARTEX Guard】 Block-device shred is blocked by ARTEX Guard."),
        ("iptables -f", "【ARTEX Guard】 Host firewall flush (iptables -F) is blocked (T1489)."),
        ("nft flush ruleset", "【ARTEX Guard】 Host firewall flush (nft flush ruleset) is blocked (T1489)."),
        ("kill -9 -1", "【ARTEX Guard】 Mass process termination (kill -9 -1) is blocked (T1489)."),
    ];
    for (pat, msg) in hard_denies {
        if lower.contains(pat) {
            if let Ok(db) = Db::open(&paths.db_path) {
                let _ = db.exec_params(
                    "INSERT INTO guard_audit (tool_name, action, reason, command, conversation_id) VALUES (?1, 'deny', ?2, ?3, ?4);",
                    &[
                        SqlParam::Text(tool_name),
                        SqlParam::Text(msg),
                        SqlParam::Text(cmd_trimmed),
                        SqlParam::Text(conv_id),
                    ],
                );
            }
            return ("deny".into(), (*msg).to_string());
        }
    }

    // Protect /data/user/0/com.agy/files/runtime/bin against rm/mv/overwrite
    if lower.contains("runtime/bin")
        && (lower.contains("rm ") || lower.contains("mv ") || lower.contains("> /data/user/0/com.agy/files/runtime/bin"))
    {
        let msg = "【ARTEX Guard】 Modifying or deleting $HOME/runtime/bin is strictly prohibited on Antigravity Android.";
        if let Ok(db) = Db::open(&paths.db_path) {
            let _ = db.exec_params(
                "INSERT INTO guard_audit (tool_name, action, reason, command, conversation_id) VALUES (?1, 'deny', ?2, ?3, ?4);",
                &[
                    SqlParam::Text(tool_name),
                    SqlParam::Text(msg),
                    SqlParam::Text(cmd_trimmed),
                    SqlParam::Text(conv_id),
                ],
            );
        }
        return ("deny".into(), msg.into());
    }

    // Check DB-configured intercept rules & scope gate for offensive scanners
    if let Ok(db) = Db::open(&paths.db_path) {
        if let Ok(rules) = db.query_rows(
            "SELECT name, pattern, action, reason FROM intercept_rules WHERE enabled = 1 AND builtin = 0;",
            &[],
        ) {
            for r in rules {
                let pat = r.get_str("pattern").unwrap_or("");
                let act = r.get_str("action").unwrap_or("ask");
                let rsn = r.get_str("reason").unwrap_or("Matched custom ARTEX intercept rule");
                if matches_pipe_patterns(&lower, pat).is_some() {
                    let _ = db.exec_params(
                        "INSERT INTO guard_audit (tool_name, action, reason, command, conversation_id) VALUES (?1, ?2, ?3, ?4, ?5);",
                        &[
                            SqlParam::Text(tool_name),
                            SqlParam::Text(act),
                            SqlParam::Text(rsn),
                            SqlParam::Text(cmd_trimmed),
                            SqlParam::Text(conv_id),
                        ],
                    );
                    return (act.to_string(), format!("【ARTEX Guard】 {}", rsn));
                }
            }
        }

        // Scope gate for active offensive scanners against external targets
        let scanner_prefixes = ["nmap ", "sqlmap ", "nuclei ", "ffuf ", "gobuster ", "nikto ", "hydra ", "masscan "];
        let uses_scanner = scanner_prefixes.iter().any(|sc| {
            lower.starts_with(sc)
                || lower.contains(&format!("; {}", sc))
                || lower.contains(&format!("&& {}", sc))
                || lower.contains(&format!("| {}", sc))
        });

        if uses_scanner {
            let mut scope_tokens: Vec<String> = vec![
                "localhost".into(),
                "127.0.0.1".into(),
                "::1".into(),
                "0.0.0.0".into(),
            ];
            if let Ok(comps) = db.query_rows("SELECT scope_patterns FROM companies;", &[]) {
                for c in comps {
                    if let Some(sp) = c.get_str("scope_patterns") {
                        for tok in sp.split(',') {
                            let clean = tok.trim().trim_end_matches('*').to_lowercase();
                            if !clean.is_empty() {
                                scope_tokens.push(clean);
                            }
                        }
                    }
                }
            }
            let in_scope = scope_tokens.iter().any(|tok| lower.contains(tok));
            if !in_scope {
                let msg = "【ARTEX Scope Gate】 Active security scanner target is not in your authorized scope list (artex_scope_configure). Confirm written authorization before proceeding.";
                let _ = db.exec_params(
                    "INSERT INTO guard_audit (tool_name, action, reason, command, conversation_id) VALUES (?1, 'ask', ?2, ?3, ?4);",
                    &[
                        SqlParam::Text(tool_name),
                        SqlParam::Text(msg),
                        SqlParam::Text(cmd_trimmed),
                        SqlParam::Text(conv_id),
                    ],
                );
                return ("ask".into(), msg.into());
            } else {
                let _ = db.exec_params(
                    "INSERT INTO guard_audit (tool_name, action, reason, command, conversation_id) VALUES (?1, 'allow', 'Authorized scope match', ?2, ?3);",
                    &[
                        SqlParam::Text(tool_name),
                        SqlParam::Text(cmd_trimmed),
                        SqlParam::Text(conv_id),
                    ],
                );
            }
        }
    }

    ("allow".into(), String::new())
}

fn run_hook_pre_tool(paths: &EnvPaths) -> i32 {
    let mut raw = String::new();
    let _ = io::stdin().read_to_string(&mut raw);
    let mut out = JsonVal::obj();
    if let Ok(payload) = parse_json(&raw) {
        let conv_id = payload.get_str("conversationId").unwrap_or("");
        if let Some(tc) = payload.get("toolCall") {
            let tname = tc.get_str("name").unwrap_or("run_command");
            let cmd = tc
                .get("args")
                .and_then(|a| a.get_str("CommandLine").or_else(|| a.get_str("command")))
                .unwrap_or("");
            let (decision, reason) = evaluate_guard_command(paths, tname, cmd, conv_id);
            out.insert("decision", s(&decision));
            if !reason.is_empty() {
                out.insert("reason", s(&reason));
            }
            println!("{}", out.to_json_string());
            return 0;
        }
    }
    out.insert("decision", s("allow"));
    println!("{}", out.to_json_string());
    0
}

// ---------------------------------------------------------------------------
// MCP Tool Implementations
// ---------------------------------------------------------------------------

fn tool_status(paths: &EnvPaths) -> Result<JsonVal, String> {
    let db = Db::open(&paths.db_path)?;
    let mut res = JsonVal::obj();
    res.insert("ok", JsonVal::Bool(true));
    res.insert("plugin", s(SERVER_NAME));
    res.insert("version", s(SERVER_VERSION));
    res.insert("sqlite_version", s(&sqlite_version()));
    res.insert("db_path", s(&paths.db_path.display().to_string()));
    res.insert("dashboard_url", s("http://127.0.0.1:8787"));
    res.insert("dashboard_running", JsonVal::Bool(dashboard_alive(DEFAULT_DASH_ADDR)));

    let mut counts = JsonVal::obj();
    counts.insert("companies", n_i64(db.query_i64("SELECT COUNT(*) FROM companies;", &[])));
    counts.insert("tasks", n_i64(db.query_i64("SELECT COUNT(*) FROM tasks;", &[])));
    counts.insert("assets", n_i64(db.query_i64("SELECT COUNT(*) FROM assets;", &[])));
    counts.insert(
        "exploration_nodes",
        n_i64(db.query_i64("SELECT COUNT(*) FROM exploration_nodes;", &[])),
    );
    counts.insert(
        "exploration_anchors",
        n_i64(db.query_i64("SELECT COUNT(*) FROM exploration_anchors;", &[])),
    );
    counts.insert("findings", n_i64(db.query_i64("SELECT COUNT(*) FROM findings;", &[])));
    counts.insert(
        "guard_audit_events",
        n_i64(db.query_i64("SELECT COUNT(*) FROM guard_audit;", &[])),
    );
    res.insert("counts", counts);
    Ok(res)
}

fn tool_scope_configure(paths: &EnvPaths, args: &JsonVal) -> Result<JsonVal, String> {
    let db = Db::open(&paths.db_path)?;
    let action = args.get_str("action").unwrap_or("list");
    let mut res = JsonVal::obj();
    res.insert("ok", JsonVal::Bool(true));

    match action {
        "upsert_company" => {
            let name = args.get_str("name").ok_or("Missing 'name'")?;
            let patterns = args
                .get_str("scope_patterns")
                .unwrap_or("localhost,127.0.0.1");
            let note = args
                .get_str("authorized_note")
                .unwrap_or("Explicitly authorized security assessment scope");
            db.exec_params(
                "INSERT INTO companies (name, scope_patterns, authorized_note) VALUES (?1, ?2, ?3)
                 ON CONFLICT(name) DO UPDATE SET scope_patterns=excluded.scope_patterns, authorized_note=excluded.authorized_note;",
                &[
                    SqlParam::Text(name),
                    SqlParam::Text(patterns),
                    SqlParam::Text(note),
                ],
            )?;
            res.insert("message", s("Authorized company scope saved"));
        }
        "add_rule" => {
            let name = args.get_str("name").ok_or("Missing rule 'name'")?;
            let pattern = args.get_str("pattern").ok_or("Missing 'pattern'")?;
            let rule_action = args.get_str("rule_action").unwrap_or("deny");
            let reason = args
                .get_str("reason")
                .unwrap_or("Custom ARTEX PreToolUse intercept rule");
            db.exec_params(
                "INSERT INTO intercept_rules (name, pattern, action, reason, enabled, builtin) VALUES (?1, ?2, ?3, ?4, 1, 0)
                 ON CONFLICT(name) DO UPDATE SET pattern=excluded.pattern, action=excluded.action, reason=excluded.reason, enabled=1;",
                &[
                    SqlParam::Text(name),
                    SqlParam::Text(pattern),
                    SqlParam::Text(rule_action),
                    SqlParam::Text(reason),
                ],
            )?;
            res.insert("message", s("Custom intercept rule saved"));
        }
        "check_command" => {
            let cmd = args.get_str("command").unwrap_or("");
            let (dec, rsn) = evaluate_guard_command(paths, "manual_check", cmd, "");
            res.insert("decision", s(&dec));
            res.insert("reason", s(&rsn));
        }
        _ => {}
    }

    res.insert(
        "companies",
        JsonVal::Arr(db.query_rows(
            "SELECT id, name, scope_patterns, authorized_note FROM companies ORDER BY id ASC;",
            &[],
        )?),
    );
    res.insert(
        "intercept_rules",
        JsonVal::Arr(db.query_rows(
            "SELECT id, name, pattern, action, reason, enabled, builtin FROM intercept_rules ORDER BY id ASC;",
            &[],
        )?),
    );
    Ok(res)
}

fn tool_task_manage(paths: &EnvPaths, args: &JsonVal) -> Result<JsonVal, String> {
    let db = Db::open(&paths.db_path)?;
    let action = args.get_str("action").unwrap_or("list");
    let mut res = JsonVal::obj();
    res.insert("ok", JsonVal::Bool(true));

    match action {
        "create" => {
            let title = args.get_str("title").ok_or("Missing 'title'")?;
            let target = args.get_str("target").unwrap_or("http://127.0.0.1");
            let lang = args.get_str("lang").unwrap_or("es");
            let company_id = args.get_i64("company_id").unwrap_or(1);
            let todolist = args
                .get("todolist")
                .map(|v| v.to_json_string())
                .unwrap_or_else(|| "[]".into());
            let (tid, _) = db.exec_params(
                "INSERT INTO tasks (company_id, title, target, status, lang, todolist_json) VALUES (?1, ?2, ?3, 'active', ?4, ?5);",
                &[
                    SqlParam::Int(company_id),
                    SqlParam::Text(title),
                    SqlParam::Text(target),
                    SqlParam::Text(lang),
                    SqlParam::Text(&todolist),
                ],
            )?;
            if let Some(goal_text) = args.get_str("initial_goal") {
                if !goal_text.is_empty() {
                    let _ = db.exec_params(
                        "INSERT INTO exploration_nodes (task_id, node_type, title, content, status, owner_worker) VALUES (?1, 'goal', ?2, ?2, 'active', 'planner');",
                        &[SqlParam::Int(tid), SqlParam::Text(goal_text)],
                    );
                }
            }
            res.insert("task_id", n_i64(tid));
        }
        "update_todolist" => {
            let tid = args.get_i64("task_id").ok_or("Missing 'task_id'")?;
            let todolist = args
                .get("todolist")
                .map(|v| v.to_json_string())
                .or_else(|| args.get_str("todolist_json").map(|x| x.to_string()))
                .unwrap_or_else(|| "[]".into());
            let status = args.get_str("status").unwrap_or("active");
            db.exec_params(
                "UPDATE tasks SET todolist_json = ?1, status = ?2, updated_at = strftime('%s','now') WHERE id = ?3;",
                &[
                    SqlParam::Text(&todolist),
                    SqlParam::Text(status),
                    SqlParam::Int(tid),
                ],
            )?;
            res.insert("updated_task_id", n_i64(tid));
        }
        _ => {}
    }

    res.insert(
        "tasks",
        JsonVal::Arr(db.query_rows(
            "SELECT id, company_id, title, target, status, lang, todolist_json, datetime(updated_at,'unixepoch') AS updated_at FROM tasks ORDER BY id DESC LIMIT 30;",
            &[],
        )?),
    );
    Ok(res)
}

fn tool_asset_upsert(paths: &EnvPaths, args: &JsonVal) -> Result<JsonVal, String> {
    let db = Db::open(&paths.db_path)?;
    let company_id = args.get_i64("company_id").unwrap_or(1);
    let asset_type = args.get_str("asset_type").unwrap_or("endpoint");
    let value = args.get_str("value").ok_or("Missing 'value'")?;
    let host = args.get_str("host").unwrap_or("");
    let port = args.get_i64("port").unwrap_or(0);
    let protocol = args.get_str("protocol").unwrap_or("http");
    let http_status = args.get_i64("http_status").unwrap_or(0);
    let title = args.get_str("title").unwrap_or("");
    let tech_stack = args.get_str("tech_stack").unwrap_or("");
    let parent_id = args.get_i64("parent_id");
    let metadata = args
        .get("metadata")
        .map(|m| m.to_json_string())
        .unwrap_or_else(|| "{}".into());

    let dedup_key = format!("{}:{}:{}", company_id, asset_type, value.trim().to_lowercase());
    let p_param = match parent_id {
        Some(pid) if pid > 0 => SqlParam::Int(pid),
        _ => SqlParam::Null,
    };

    db.exec_params(
        "INSERT INTO assets (company_id, parent_id, asset_type, value, dedup_key, host, port, protocol, http_status, title, tech_stack, metadata_json)
         VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8, ?9, ?10, ?11, ?12)
         ON CONFLICT(dedup_key) DO UPDATE SET
           host = CASE WHEN excluded.host != '' THEN excluded.host ELSE assets.host END,
           port = CASE WHEN excluded.port > 0 THEN excluded.port ELSE assets.port END,
           http_status = CASE WHEN excluded.http_status > 0 THEN excluded.http_status ELSE assets.http_status END,
           title = CASE WHEN excluded.title != '' THEN excluded.title ELSE assets.title END,
           tech_stack = CASE WHEN excluded.tech_stack != '' THEN excluded.tech_stack ELSE assets.tech_stack END,
           metadata_json = CASE WHEN excluded.metadata_json != '{}' THEN excluded.metadata_json ELSE assets.metadata_json END;",
        &[
            SqlParam::Int(company_id),
            p_param,
            SqlParam::Text(asset_type),
            SqlParam::Text(value.trim()),
            SqlParam::Text(&dedup_key),
            SqlParam::Text(host),
            SqlParam::Int(port),
            SqlParam::Text(protocol),
            SqlParam::Int(http_status),
            SqlParam::Text(title),
            SqlParam::Text(tech_stack),
            SqlParam::Text(&metadata),
        ],
    )?;

    let asset_id = db.query_i64(
        "SELECT id FROM assets WHERE dedup_key = ?1;",
        &[SqlParam::Text(&dedup_key)],
    );
    let mut res = JsonVal::obj();
    res.insert("ok", JsonVal::Bool(true));
    res.insert("asset_id", n_i64(asset_id));
    res.insert("dedup_key", s(&dedup_key));
    Ok(res)
}

fn tool_asset_dsl_search(paths: &EnvPaths, args: &JsonVal) -> Result<JsonVal, String> {
    let db = Db::open(&paths.db_path)?;
    let query = args.get_str("query").unwrap_or("").trim();
    let limit = args.get_i64("limit").unwrap_or(100).clamp(1, 500);

    let all_rows = db.query_rows(
        "SELECT id, company_id, parent_id, asset_type, value, host, port, protocol, http_status, title, tech_stack, metadata_json FROM assets ORDER BY id ASC LIMIT 1000;",
        &[],
    )?;

    let tokens: Vec<&str> = if query.is_empty() {
        Vec::new()
    } else {
        query.split_whitespace().collect()
    };

    let mut matched = Vec::new();
    for row in all_rows {
        let mut ok = true;
        for tok in &tokens {
            if let Some((k, v)) = tok.split_once('=') {
                let vl = v.trim_matches('"').to_lowercase();
                let actual = match k {
                    "type" | "asset_type" => row.get_str("asset_type").unwrap_or("").to_lowercase(),
                    "host" => row.get_str("host").unwrap_or("").to_lowercase(),
                    "status" | "http_status" => row.get_i64("http_status").unwrap_or(0).to_string(),
                    "port" => row.get_i64("port").unwrap_or(0).to_string(),
                    "protocol" => row.get_str("protocol").unwrap_or("").to_lowercase(),
                    _ => row.to_json_string().to_lowercase(),
                };
                if actual != vl {
                    ok = false;
                    break;
                }
            } else if let Some((k, v)) = tok.split_once('~') {
                let vl = v.trim_matches('"').to_lowercase();
                let actual = match k {
                    "value" | "path" | "url" => row.get_str("value").unwrap_or("").to_lowercase(),
                    "host" => row.get_str("host").unwrap_or("").to_lowercase(),
                    "title" => row.get_str("title").unwrap_or("").to_lowercase(),
                    "tech" | "stack" => row.get_str("tech_stack").unwrap_or("").to_lowercase(),
                    _ => row.to_json_string().to_lowercase(),
                };
                if !actual.contains(&vl) {
                    ok = false;
                    break;
                }
            } else {
                let vl = tok.to_lowercase();
                if !row.to_json_string().to_lowercase().contains(&vl) {
                    ok = false;
                    break;
                }
            }
        }
        if ok {
            matched.push(row);
            if matched.len() >= limit as usize {
                break;
            }
        }
    }

    let mut res = JsonVal::obj();
    res.insert("ok", JsonVal::Bool(true));
    res.insert("count", n_i64(matched.len() as i64));
    res.insert("assets", JsonVal::Arr(matched));
    Ok(res)
}

fn tool_graph_record(paths: &EnvPaths, args: &JsonVal) -> Result<JsonVal, String> {
    let db = Db::open(&paths.db_path)?;
    let task_id = args.get_i64("task_id").ok_or("Missing 'task_id'")?;
    let node_type = args.get_str("node_type").unwrap_or("fact");
    let title = args.get_str("title").ok_or("Missing 'title'")?;
    let content = args.get_str("content").unwrap_or("");
    let status = args.get_str("status").unwrap_or("done");
    let severity = args.get_str("severity").unwrap_or("info");
    let owner_worker = args.get_str("owner_worker").unwrap_or("worker");

    let (node_id, _) = db.exec_params(
        "INSERT INTO exploration_nodes (task_id, node_type, title, content, status, severity, owner_worker)
         VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7);",
        &[
            SqlParam::Int(task_id),
            SqlParam::Text(node_type),
            SqlParam::Text(title),
            SqlParam::Text(content),
            SqlParam::Text(status),
            SqlParam::Text(severity),
            SqlParam::Text(owner_worker),
        ],
    )?;

    if let Some(from_id) = args.get_i64("from_node_id") {
        if from_id > 0 {
            let edge_type = args.get_str("edge_type").unwrap_or(match node_type {
                "intent" => "spawns",
                "fact" => "yields",
                "finding" => "proves",
                _ => "derived_from",
            });
            let _ = db.exec_params(
                "INSERT OR IGNORE INTO exploration_edges (task_id, from_node_id, to_node_id, edge_type) VALUES (?1, ?2, ?3, ?4);",
                &[
                    SqlParam::Int(task_id),
                    SqlParam::Int(from_id),
                    SqlParam::Int(node_id),
                    SqlParam::Text(edge_type),
                ],
            );
        }
    }

    let mut anchored = 0i64;
    if let Some(arr) = args.get("asset_ids").and_then(|v| v.as_arr()) {
        for item in arr {
            if let Some(aid) = item.as_i64() {
                if aid > 0 {
                    let _ = db.exec_params(
                        "INSERT OR IGNORE INTO exploration_anchors (node_id, asset_id) VALUES (?1, ?2);",
                        &[SqlParam::Int(node_id), SqlParam::Int(aid)],
                    );
                    anchored += 1;
                }
            }
        }
    }

    if args.get_bool("prove_goal").unwrap_or(false) {
        if let Some(gid) = args.get_i64("goal_node_id").or_else(|| args.get_i64("from_node_id")) {
            let _ = db.exec_params(
                "UPDATE exploration_nodes SET status = 'proven', updated_at = strftime('%s','now') WHERE id = ?1 AND node_type = 'goal';",
                &[SqlParam::Int(gid)],
            );
        }
    }

    let mut res = JsonVal::obj();
    res.insert("ok", JsonVal::Bool(true));
    res.insert("node_id", n_i64(node_id));
    res.insert("anchored_assets", n_i64(anchored));
    Ok(res)
}

fn tool_graph_overview(paths: &EnvPaths, args: &JsonVal) -> Result<JsonVal, String> {
    let db = Db::open(&paths.db_path)?;
    let task_id = match args.get_i64("task_id") {
        Some(t) if t > 0 => t,
        _ => db.query_i64("SELECT id FROM tasks ORDER BY id DESC LIMIT 1;", &[]),
    };
    let mut res = JsonVal::obj();
    res.insert("ok", JsonVal::Bool(true));
    res.insert("task_id", n_i64(task_id));

    if task_id > 0 {
        res.insert(
            "task",
            JsonVal::Arr(db.query_rows(
                "SELECT id, title, target, status, lang, todolist_json FROM tasks WHERE id = ?1;",
                &[SqlParam::Int(task_id)],
            )?),
        );
        res.insert(
            "nodes",
            JsonVal::Arr(db.query_rows(
                "SELECT id, node_type, title, content, status, severity, owner_worker FROM exploration_nodes WHERE task_id = ?1 ORDER BY id ASC;",
                &[SqlParam::Int(task_id)],
            )?),
        );
        res.insert(
            "edges",
            JsonVal::Arr(db.query_rows(
                "SELECT from_node_id, to_node_id, edge_type FROM exploration_edges WHERE task_id = ?1 ORDER BY id ASC;",
                &[SqlParam::Int(task_id)],
            )?),
        );
        res.insert(
            "anchors",
            JsonVal::Arr(db.query_rows(
                "SELECT ea.node_id, ea.asset_id, a.asset_type, a.value FROM exploration_anchors ea JOIN exploration_nodes en ON en.id = ea.node_id JOIN assets a ON a.id = ea.asset_id WHERE en.task_id = ?1;",
                &[SqlParam::Int(task_id)],
            )?),
        );
        res.insert(
            "findings",
            JsonVal::Arr(db.query_rows(
                "SELECT id, title, severity, status, cwe, cvss, asset_id FROM findings WHERE task_id = ?1 ORDER BY id DESC;",
                &[SqlParam::Int(task_id)],
            )?),
        );
    }
    res.insert(
        "unanchored_assets_count",
        n_i64(db.query_i64(
            "SELECT COUNT(*) FROM assets a WHERE NOT EXISTS (SELECT 1 FROM exploration_anchors ea WHERE ea.asset_id = a.id);",
            &[],
        )),
    );
    Ok(res)
}

fn tool_worker_trace(paths: &EnvPaths, args: &JsonVal) -> Result<JsonVal, String> {
    let db = Db::open(&paths.db_path)?;
    let action = args.get_str("action").unwrap_or("search");
    let task_id = args.get_i64("task_id").unwrap_or(1);
    let mut res = JsonVal::obj();
    res.insert("ok", JsonVal::Bool(true));

    match action {
        "record" => {
            let intent_id = args.get_i64("intent_id").unwrap_or(0);
            let worker_name = args.get_str("worker_name").unwrap_or("worker-1");
            let step_no = args.get_i64("step_no").unwrap_or(1);
            let summary = args.get_str("summary").ok_or("Missing 'summary'")?;
            let raw_output = args.get_str("raw_output").unwrap_or("");
            let (id, _) = db.exec_params(
                "INSERT INTO worker_traces (task_id, intent_id, worker_name, step_no, summary, raw_output) VALUES (?1, ?2, ?3, ?4, ?5, ?6);",
                &[
                    SqlParam::Int(task_id),
                    SqlParam::Int(intent_id),
                    SqlParam::Text(worker_name),
                    SqlParam::Int(step_no),
                    SqlParam::Text(summary),
                    SqlParam::Text(raw_output),
                ],
            )?;
            res.insert("trace_id", n_i64(id));
        }
        "get" => {
            let intent_id = args.get_i64("intent_id").unwrap_or(0);
            res.insert(
                "traces",
                JsonVal::Arr(db.query_rows(
                    "SELECT id, intent_id, worker_name, step_no, summary, raw_output, datetime(created_at,'unixepoch') AS created_at FROM worker_traces WHERE task_id = ?1 AND (?2 = 0 OR intent_id = ?2) ORDER BY step_no ASC;",
                    &[SqlParam::Int(task_id), SqlParam::Int(intent_id)],
                )?),
            );
        }
        _ => {
            let q = args.get_str("query").unwrap_or("");
            let exclude_intent = args.get_i64("exclude_intent_id").unwrap_or(-1);
            let like_q = format!("%{}%", q);
            res.insert(
                "hits",
                JsonVal::Arr(db.query_rows(
                    "SELECT id, intent_id, worker_name, step_no, summary, substr(raw_output,1,400) AS snippet FROM worker_traces WHERE task_id = ?1 AND intent_id != ?2 AND (summary LIKE ?3 OR raw_output LIKE ?3) ORDER BY id DESC LIMIT 30;",
                    &[
                        SqlParam::Int(task_id),
                        SqlParam::Int(exclude_intent),
                        SqlParam::Text(&like_q),
                    ],
                )?),
            );
        }
    }
    Ok(res)
}

fn tool_finding_manage(paths: &EnvPaths, args: &JsonVal) -> Result<JsonVal, String> {
    let db = Db::open(&paths.db_path)?;
    let action = args.get_str("action").unwrap_or("list");
    let mut res = JsonVal::obj();
    res.insert("ok", JsonVal::Bool(true));

    match action {
        "add" => {
            let task_id = args.get_i64("task_id").ok_or("Missing 'task_id'")?;
            let title = args.get_str("title").ok_or("Missing 'title'")?;
            let severity = args.get_str("severity").unwrap_or("medium");
            let status = args.get_str("status").unwrap_or("verified");
            let cwe = args.get_str("cwe").unwrap_or("");
            let cvss = args.get_f64("cvss").unwrap_or(0.0);
            let desc = args.get_str("description").unwrap_or("");
            let repro = args.get_str("reproduction").unwrap_or("");
            let rem = args.get_str("remediation").unwrap_or("");
            let asset_id = args.get_i64("asset_id");

            let (nid, _) = db.exec_params(
                "INSERT INTO exploration_nodes (task_id, node_type, title, content, status, severity, owner_worker)
                 VALUES (?1, 'finding', ?2, ?3, ?4, ?5, 'worker');",
                &[
                    SqlParam::Int(task_id),
                    SqlParam::Text(title),
                    SqlParam::Text(desc),
                    SqlParam::Text(status),
                    SqlParam::Text(severity),
                ],
            )?;
            if let Some(aid) = asset_id {
                if aid > 0 {
                    let _ = db.exec_params(
                        "INSERT OR IGNORE INTO exploration_anchors (node_id, asset_id) VALUES (?1, ?2);",
                        &[SqlParam::Int(nid), SqlParam::Int(aid)],
                    );
                }
            }
            let a_param = match asset_id {
                Some(aid) if aid > 0 => SqlParam::Int(aid),
                _ => SqlParam::Null,
            };
            let cvss_sql = format!("{:.1}", cvss);
            let (fid, _) = db.exec_params(
                "INSERT INTO findings (task_id, asset_id, node_id, title, severity, status, cwe, cvss, description, reproduction, remediation)
                 VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7, CAST(?8 AS REAL), ?9, ?10, ?11);",
                &[
                    SqlParam::Int(task_id),
                    a_param,
                    SqlParam::Int(nid),
                    SqlParam::Text(title),
                    SqlParam::Text(severity),
                    SqlParam::Text(status),
                    SqlParam::Text(cwe),
                    SqlParam::Text(&cvss_sql),
                    SqlParam::Text(desc),
                    SqlParam::Text(repro),
                    SqlParam::Text(rem),
                ],
            )?;
            res.insert("finding_id", n_i64(fid));
            res.insert("node_id", n_i64(nid));
        }
        "update_status" => {
            let fid = args.get_i64("finding_id").ok_or("Missing 'finding_id'")?;
            let status = args.get_str("status").unwrap_or("retested_fixed");
            db.exec_params(
                "UPDATE findings SET status = ?1, updated_at = strftime('%s','now') WHERE id = ?2;",
                &[SqlParam::Text(status), SqlParam::Int(fid)],
            )?;
            res.insert("updated_finding_id", n_i64(fid));
        }
        _ => {}
    }

    let task_filter = args.get_i64("task_id").unwrap_or(0);
    let rows = if task_filter > 0 {
        db.query_rows(
            "SELECT f.id, f.task_id, f.title, f.severity, f.status, f.cwe, f.cvss, COALESCE(a.value,'-') AS asset FROM findings f LEFT JOIN assets a ON a.id = f.asset_id WHERE f.task_id = ?1 ORDER BY f.id DESC;",
            &[SqlParam::Int(task_filter)],
        )?
    } else {
        db.query_rows(
            "SELECT f.id, f.task_id, f.title, f.severity, f.status, f.cwe, f.cvss, COALESCE(a.value,'-') AS asset FROM findings f LEFT JOIN assets a ON a.id = f.asset_id ORDER BY f.id DESC LIMIT 100;",
            &[],
        )?
    };
    res.insert("findings", JsonVal::Arr(rows));
    Ok(res)
}

fn tool_evidence_archive(paths: &EnvPaths, args: &JsonVal) -> Result<JsonVal, String> {
    let db = Db::open(&paths.db_path)?;
    let task_id = args.get_i64("task_id").unwrap_or(1);
    let finding_id = args.get_i64("finding_id");
    let method = args.get_str("method").unwrap_or("GET");
    let url = args.get_str("url").ok_or("Missing 'url'")?;
    let req_headers = args.get_str("req_headers").unwrap_or("");
    let req_body = args.get_str("req_body").unwrap_or("");
    let status_code = args.get_i64("status_code").unwrap_or(200);
    let resp_headers = args.get_str("resp_headers").unwrap_or("");
    let resp_body = args.get_str("resp_body_excerpt").unwrap_or("");
    let digest = fnv_hex(&format!("{}\n{}\n{}\n{}", method, url, status_code, resp_body));

    let f_param = match finding_id {
        Some(fid) if fid > 0 => SqlParam::Int(fid),
        _ => SqlParam::Null,
    };
    let (eid, _) = db.exec_params(
        "INSERT INTO evidence_traffic (task_id, finding_id, method, url, req_headers, req_body, status_code, resp_headers, resp_body_excerpt, sha256)
         VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8, ?9, ?10);",
        &[
            SqlParam::Int(task_id),
            f_param,
            SqlParam::Text(method),
            SqlParam::Text(url),
            SqlParam::Text(req_headers),
            SqlParam::Text(req_body),
            SqlParam::Int(status_code),
            SqlParam::Text(resp_headers),
            SqlParam::Text(resp_body),
            SqlParam::Text(&digest),
        ],
    )?;
    if let Some(fid) = finding_id {
        if fid > 0 {
            let _ = db.exec_params(
                "UPDATE findings SET evidence_id = ?1 WHERE id = ?2;",
                &[SqlParam::Int(eid), SqlParam::Int(fid)],
            );
        }
    }
    let mut res = JsonVal::obj();
    res.insert("ok", JsonVal::Bool(true));
    res.insert("evidence_id", n_i64(eid));
    res.insert("fingerprint", s(&digest));
    Ok(res)
}

fn tool_report_export(paths: &EnvPaths, args: &JsonVal) -> Result<JsonVal, String> {
    let db = Db::open(&paths.db_path)?;
    let format = args.get_str("format").unwrap_or("markdown");
    let lang = args.get_str("lang").unwrap_or("es");
    let task_id = args.get_i64("task_id").filter(|t| *t > 0);
    let ts = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_secs())
        .unwrap_or(0);

    let default_out = paths.artex_dir.join(format!(
        "artex-report-{}.{}",
        ts,
        if format == "csv" { "csv" } else { "md" }
    ));
    let out_path = args
        .get_str("output_path")
        .map(PathBuf::from)
        .unwrap_or(default_out);
    if let Some(p) = out_path.parent() {
        let _ = fs::create_dir_all(p);
    }

    let content = if format == "csv" {
        build_findings_csv(&db, task_id)?
    } else {
        build_markdown_report(&db, task_id, lang)?
    };
    fs::write(&out_path, content.as_bytes()).map_err(|e| format!("Write error: {}", e))?;

    let mut res = JsonVal::obj();
    res.insert("ok", JsonVal::Bool(true));
    res.insert("format", s(format));
    res.insert("output_path", s(&out_path.display().to_string()));
    res.insert("bytes", n_i64(content.len() as i64));
    res.insert(
        "preview",
        s(&content.chars().take(1200).collect::<String>()),
    );
    Ok(res)
}

fn tool_dashboard_server(paths: &EnvPaths, args: &JsonVal) -> Result<JsonVal, String> {
    let action = args.get_str("action").unwrap_or("status");
    let addr = args.get_str("bind_addr").unwrap_or(DEFAULT_DASH_ADDR);
    let open_browser = args.get_bool("open_browser").unwrap_or(false);
    let url = format!("http://{}", addr);

    // Ensure DB initialized before starting/checking
    let _ = Db::open(&paths.db_path)?;

    let mut res = JsonVal::obj();
    res.insert("ok", JsonVal::Bool(true));
    res.insert("url", s(&url));

    match action {
        "stop" => {
            if let Ok(pid_txt) = fs::read_to_string(&paths.pid_path) {
                let pid = pid_txt.trim();
                if !pid.is_empty() {
                    let _ = Command::new("/system/bin/kill").arg(pid).status();
                }
                let _ = fs::remove_file(&paths.pid_path);
            }
            res.insert("running", JsonVal::Bool(dashboard_alive(addr)));
            res.insert("message", s("Stop signal sent to ARTEX dashboard"));
        }
        "start" => {
            if !dashboard_alive(addr) {
                let exe = env::current_exe()
                    .unwrap_or_else(|_| paths.plugin_dir.join("mcp/bin/artex-audit-mcp"));
                let child = Command::new(exe)
                    .arg("serve-dashboard")
                    .arg(addr)
                    .env("HOME", &paths.home)
                    .env("PREFIX", &paths.prefix)
                    .env("ARTEX_DATA_DIR", &paths.artex_dir)
                    .stdin(Stdio::null())
                    .stdout(Stdio::null())
                    .stderr(Stdio::null())
                    .spawn()
                    .map_err(|e| format!("Failed to spawn dashboard daemon: {}", e))?;
                let _ = fs::write(&paths.pid_path, format!("{}\n", child.id()));
                for _ in 0..15 {
                    if dashboard_alive(addr) {
                        break;
                    }
                    std::thread::sleep(Duration::from_millis(80));
                }
            }
            let alive = dashboard_alive(addr);
            if alive && open_browser {
                let xdg = paths.prefix.join("bin/xdg-open");
                if xdg.exists() {
                    let _ = Command::new(xdg)
                        .arg(&url)
                        .stdin(Stdio::null())
                        .stdout(Stdio::null())
                        .stderr(Stdio::null())
                        .spawn();
                }
            }
            res.insert("running", JsonVal::Bool(alive));
            res.insert(
                "message",
                s(if alive {
                    "ARTEX Global Mini-Dashboard active on loopback"
                } else {
                    "Dashboard spawned, awaiting socket readiness"
                }),
            );
        }
        _ => {
            res.insert("running", JsonVal::Bool(dashboard_alive(addr)));
        }
    }
    Ok(res)
}

fn build_tools_list() -> JsonVal {
    let tools = vec![
        make_tool(
            "artex_audit_status",
            "Check ARTEX Audit Core status, SQLite WAL Dual-Graph metrics, and whether the local 127.0.0.1:8787 Mini-Dashboard is running.",
            vec![],
            &[],
        ),
        make_tool(
            "artex_scope_configure",
            "Configure authorized assessment targets/domains/CIDRs and PreToolUse ARTEX Guard intercept rules.",
            vec![
                ("action", prop_str_enum("Operation", &["list", "upsert_company", "add_rule", "check_command"])),
                ("name", prop_str("Company/environment name or custom rule name")),
                ("scope_patterns", prop_str("Comma-separated authorized hostnames/IPs (e.g. 'localhost,127.0.0.1,staging.miapp.local')")),
                ("authorized_note", prop_str("Written scope/authorization reference")),
                ("pattern", prop_str("Pipe-separated pattern for add_rule")),
                ("rule_action", prop_str_enum("Guard action for add_rule", &["deny", "ask", "allow"])),
                ("reason", prop_str("Explanation when rule triggers")),
                ("command", prop_str("Shell command to dry-run test when action=check_command")),
            ],
            &[],
        ),
        make_tool(
            "artex_task_manage",
            "Create, list, or update ARTEX security audit tasks and the Planner's shared dependency todolist.",
            vec![
                ("action", prop_str_enum("Task operation", &["list", "create", "update_todolist"])),
                ("task_id", prop_int("Task ID (for update_todolist)")),
                ("company_id", prop_int("Owning company ID (default 1)")),
                ("title", prop_str("Audit task title")),
                ("target", prop_str("Authorized target root URL or workspace path")),
                ("lang", prop_str_enum("Output report language", &["es", "en", "ko", "zh", "ja"])),
                ("initial_goal", prop_str("Optional root goal node to seed in the Exploration Graph")),
                ("todolist", prop_arr_int("Optional array or pass todolist_json string for serial dependency steps")),
                ("todolist_json", prop_str("JSON array string of planner todolist steps")),
                ("status", prop_str_enum("Task lifecycle status", &["active", "paused", "completed"])),
            ],
            &[],
        ),
        make_tool(
            "artex_asset_upsert",
            "Insert or deduplicate an asset node in ARTEX's globally shared Asset Graph (root_domain -> subdomain -> ip -> service -> app -> endpoint).",
            vec![
                ("company_id", prop_int("Company ID (default 1)")),
                ("parent_id", prop_int("Optional parent asset ID")),
                ("asset_type", prop_str_enum("Node type in Asset Graph", &["root_domain", "subdomain", "ip", "service", "app", "endpoint"])),
                ("value", prop_str("Canonical asset value (domain, host:port, or /api/v1/path)")),
                ("host", prop_str("Hostname or IP")),
                ("port", prop_int("TCP/UDP port")),
                ("protocol", prop_str("Protocol (http, https, ws, tcp)")),
                ("http_status", prop_int("Observed HTTP status code")),
                ("title", prop_str("HTML <title> or route label")),
                ("tech_stack", prop_str("Detected framework/server stack")),
            ],
            &["value"],
        ),
        make_tool(
            "artex_asset_dsl_search",
            "Search the Asset Graph using ARTEX DSL expressions (e.g. 'type=endpoint status=200 value~/api/ tech~next').",
            vec![
                ("query", prop_str("Space-separated DSL filters: key=val, key~substr, or free text")),
                ("limit", prop_int("Max results (default 100)")),
            ],
            &[],
        ),
        make_tool(
            "artex_graph_record",
            "Record a node (goal, intent, fact, hint) in the per-task Exploration Graph, link lineage edges (spawns, yields, derived_from, proves), and anchor to asset_ids.",
            vec![
                ("task_id", prop_int("Task ID")),
                ("node_type", prop_str_enum("Exploration node kind", &["goal", "intent", "fact", "hint"])),
                ("title", prop_str("Short node headline")),
                ("content", prop_str("Detailed observation, hypothesis, or verified fact")),
                ("status", prop_str_enum("Node status", &["pending", "in_progress", "done", "proven", "blocked"])),
                ("severity", prop_str_enum("Optional impact hint", &["info", "low", "medium", "high", "critical"])),
                ("owner_worker", prop_str("Agent/subagent role name (planner, worker-1, recon)")),
                ("from_node_id", prop_int("Parent exploration node ID to connect from")),
                ("edge_type", prop_str_enum("Lineage edge type", &["spawns", "yields", "derived_from", "proves"])),
                ("asset_ids", prop_arr_int("Asset Graph IDs to pin via exploration_anchors")),
                ("prove_goal", prop_bool("Mark parent goal node as proven")),
                ("goal_node_id", prop_int("Explicit goal node ID when prove_goal=true")),
            ],
            &["task_id", "title"],
        ),
        make_tool(
            "artex_graph_overview",
            "Fetch the complete Dual-Graph state for a task (goals, intents, facts, edges, asset anchors, findings, and unanchored surface count).",
            vec![("task_id", prop_int("Task ID (defaults to latest task)"))],
            &[],
        ),
        make_tool(
            "artex_worker_trace",
            "Process-level observation sharing across workers (record, search_all_worker_traces, or get_worker_trace).",
            vec![
                ("action", prop_str_enum("Trace operation", &["record", "search", "get"])),
                ("task_id", prop_int("Task ID (default 1)")),
                ("intent_id", prop_int("Intent node ID")),
                ("exclude_intent_id", prop_int("Exclude caller's own intent ID during search")),
                ("worker_name", prop_str("Worker identifier")),
                ("step_no", prop_int("Step sequence number")),
                ("summary", prop_str("Key observation summary (for record)")),
                ("raw_output", prop_str("Command/HTTP excerpt (for record)")),
                ("query", prop_str("Keyword to search across other workers' traces")),
            ],
            &[],
        ),
        make_tool(
            "artex_finding_manage",
            "Record, list, or update verified security findings (CWE, CVSS, reproduction evidence, remediation) anchored to the Dual Graph.",
            vec![
                ("action", prop_str_enum("Finding operation", &["list", "add", "update_status"])),
                ("task_id", prop_int("Task ID")),
                ("finding_id", prop_int("Finding ID (for update_status)")),
                ("asset_id", prop_int("Target asset ID in Asset Graph")),
                ("title", prop_str("Finding title (in task's selected output language)")),
                ("severity", prop_str_enum("Severity level", &["critical", "high", "medium", "low", "info"])),
                ("status", prop_str_enum("Verification status", &["open", "verified", "retested_fixed", "false_positive"])),
                ("cwe", prop_str("CWE identifier, e.g. CWE-639 or CWE-89")),
                ("cvss", prop_num("CVSS v3.1 base score (0.0 - 10.0)")),
                ("description", prop_str("Clear technical impact description")),
                ("reproduction", prop_str("Non-destructive verification steps / evidence")),
                ("remediation", prop_str("Concrete code/config remediation")),
            ],
            &[],
        ),
        make_tool(
            "artex_evidence_archive",
            "Archive HTTP request/response traffic or verification evidence with an integrity fingerprint and link it to a finding.",
            vec![
                ("task_id", prop_int("Task ID")),
                ("finding_id", prop_int("Optional finding ID to link")),
                ("method", prop_str("HTTP method (GET, POST, etc.)")),
                ("url", prop_str("Target URL")),
                ("req_headers", prop_str("Request headers")),
                ("req_body", prop_str("Request body excerpt")),
                ("status_code", prop_int("HTTP response status code")),
                ("resp_headers", prop_str("Response headers")),
                ("resp_body_excerpt", prop_str("Sanitized response body excerpt")),
            ],
            &["url"],
        ),
        make_tool(
            "artex_report_export",
            "Export localized security assessment reports in Markdown (.md) or CSV (.csv) from the SQLite Dual Graph.",
            vec![
                ("format", prop_str_enum("Export format", &["markdown", "csv"])),
                ("lang", prop_str_enum("Report language", &["es", "en"])),
                ("task_id", prop_int("Optional task ID filter (omit for all tasks)")),
                ("output_path", prop_str("Optional destination file path")),
            ],
            &[],
        ),
        make_tool(
            "artex_dashboard_server",
            "Start, stop, or check the ARTEX Global Mini-Dashboard web UI on 127.0.0.1:8787 (Dual-Graph visualizer, Findings CSV/MD export, Guard logs, ATT&CK view).",
            vec![
                ("action", prop_str_enum("Dashboard lifecycle action", &["status", "start", "stop"])),
                ("bind_addr", prop_str("Loopback bind address (default 127.0.0.1:8787)")),
                ("open_browser", prop_bool("Open in Android browser via xdg-open when started")),
            ],
            &[],
        ),
    ];

    let mut out = JsonVal::obj();
    out.insert("tools", JsonVal::Arr(tools));
    out
}

fn dispatch_tool(paths: &EnvPaths, name: &str, args: &JsonVal) -> Result<JsonVal, String> {
    match name {
        "artex_audit_status" => tool_status(paths),
        "artex_scope_configure" => tool_scope_configure(paths, args),
        "artex_task_manage" => tool_task_manage(paths, args),
        "artex_asset_upsert" => tool_asset_upsert(paths, args),
        "artex_asset_dsl_search" => tool_asset_dsl_search(paths, args),
        "artex_graph_record" => tool_graph_record(paths, args),
        "artex_graph_overview" => tool_graph_overview(paths, args),
        "artex_worker_trace" => tool_worker_trace(paths, args),
        "artex_finding_manage" => tool_finding_manage(paths, args),
        "artex_evidence_archive" => tool_evidence_archive(paths, args),
        "artex_report_export" => tool_report_export(paths, args),
        "artex_dashboard_server" => tool_dashboard_server(paths, args),
        _ => Err(format!("Unknown tool: {}", name)),
    }
}

// ---------------------------------------------------------------------------
// MCP JSON-RPC 2.0 Framing (Line + Content-Length auto-detect)
// ---------------------------------------------------------------------------

#[derive(Clone, Copy)]
enum Framing {
    Line,
    ContentLength,
}

fn read_rpc_message<R: BufRead>(reader: &mut R) -> io::Result<Option<(String, Framing)>> {
    loop {
        let mut line = String::new();
        let n = reader.read_line(&mut line)?;
        if n == 0 {
            return Ok(None);
        }
        let trimmed = line.trim();
        if trimmed.is_empty() {
            continue;
        }
        if trimmed.starts_with('{') {
            return Ok(Some((trimmed.to_string(), Framing::Line)));
        }
        let lower = trimmed.to_ascii_lowercase();
        if let Some(rest) = lower.strip_prefix("content-length:") {
            let len: usize = rest
                .trim()
                .parse()
                .map_err(|_| io::Error::new(io::ErrorKind::InvalidData, "Bad Content-Length"))?;
            loop {
                let mut hdr = String::new();
                let hn = reader.read_line(&mut hdr)?;
                if hn == 0 || hdr.trim().is_empty() {
                    break;
                }
            }
            let mut buf = vec![0u8; len];
            reader.read_exact(&mut buf)?;
            let body = String::from_utf8_lossy(&buf).to_string();
            return Ok(Some((body, Framing::ContentLength)));
        }
    }
}

fn write_rpc_message<W: Write>(writer: &mut W, payload: &JsonVal, framing: Framing) -> io::Result<()> {
    let serialized = payload.to_json_string();
    match framing {
        Framing::Line => {
            writer.write_all(serialized.as_bytes())?;
            writer.write_all(b"\n")?;
        }
        Framing::ContentLength => {
            let header = format!("Content-Length: {}\r\n\r\n", serialized.len());
            writer.write_all(header.as_bytes())?;
            writer.write_all(serialized.as_bytes())?;
        }
    }
    writer.flush()
}

fn handle_rpc_request(paths: &EnvPaths, req: &JsonVal) -> Option<JsonVal> {
    let method = req.get_str("method").unwrap_or("");
    if method.starts_with("notifications/") {
        return None;
    }
    let id = req.get("id")?.clone();
    let mut resp = JsonVal::obj();
    resp.insert("jsonrpc", s("2.0"));
    resp.insert("id", id);

    match method {
        "initialize" => {
            let mut server_info = JsonVal::obj();
            server_info.insert("name", s(SERVER_NAME));
            server_info.insert("version", s(SERVER_VERSION));
            let mut caps = JsonVal::obj();
            caps.insert("tools", JsonVal::obj());
            let proto = req
                .get("params")
                .and_then(|p| p.get_str("protocolVersion"))
                .unwrap_or("2024-11-05");
            let mut result = JsonVal::obj();
            result.insert("protocolVersion", s(proto));
            result.insert("capabilities", caps);
            result.insert("serverInfo", server_info);
            resp.insert("result", result);
        }
        "ping" => {
            resp.insert("result", JsonVal::obj());
        }
        "tools/list" => {
            resp.insert("result", build_tools_list());
        }
        "tools/call" => {
            let params = req.get("params").cloned().unwrap_or_else(JsonVal::obj);
            let tname = params.get_str("name").unwrap_or("");
            let targs = params.get("arguments").cloned().unwrap_or_else(JsonVal::obj);
            match dispatch_tool(paths, tname, &targs) {
                Ok(val) => {
                    let mut citem = JsonVal::obj();
                    citem.insert("type", s("text"));
                    citem.insert("text", s(&val.to_json_string()));
                    let mut result = JsonVal::obj();
                    result.insert("content", JsonVal::Arr(vec![citem]));
                    resp.insert("result", result);
                }
                Err(e) => {
                    let mut err_obj = JsonVal::obj();
                    err_obj.insert("ok", JsonVal::Bool(false));
                    err_obj.insert("error", s(&e));
                    let mut citem = JsonVal::obj();
                    citem.insert("type", s("text"));
                    citem.insert("text", s(&err_obj.to_json_string()));
                    let mut result = JsonVal::obj();
                    result.insert("content", JsonVal::Arr(vec![citem]));
                    result.insert("isError", JsonVal::Bool(true));
                    resp.insert("result", result);
                }
            }
        }
        _ => {
            let mut err = JsonVal::obj();
            err.insert("code", JsonVal::Num(-32601.0));
            err.insert("message", s(&format!("Method not found: {}", method)));
            resp.insert("error", err);
        }
    }
    Some(resp)
}

fn main() {
    let paths = EnvPaths::resolve();
    let argv: Vec<String> = env::args().collect();
    if argv.len() > 1 {
        match argv[1].as_str() {
            "hook-pre-tool" => {
                std::process::exit(run_hook_pre_tool(&paths));
            }
            "serve-dashboard" => {
                let addr = argv.get(2).map(|x| x.as_str()).unwrap_or(DEFAULT_DASH_ADDR);
                if let Err(e) = serve_blocking(addr, &paths.db_path) {
                    eprintln!("{}", e);
                    std::process::exit(1);
                }
                return;
            }
            "dashboard" => {
                let sub = argv.get(2).map(|x| x.as_str()).unwrap_or("start");
                let mut a = JsonVal::obj();
                a.insert("action", s(sub));
                a.insert("open_browser", JsonVal::Bool(sub == "open"));
                if sub == "open" {
                    a.insert("action", s("start"));
                }
                match tool_dashboard_server(&paths, &a) {
                    Ok(v) => println!("{}", v.to_json_string()),
                    Err(e) => {
                        eprintln!("{}", e);
                        std::process::exit(1);
                    }
                }
                return;
            }
            "status" => {
                match tool_status(&paths) {
                    Ok(v) => println!("{}", v.to_json_string()),
                    Err(e) => {
                        eprintln!("{}", e);
                        std::process::exit(1);
                    }
                }
                return;
            }
            "report" => {
                let fmt = argv.get(2).map(|x| x.as_str()).unwrap_or("markdown");
                let mut a = JsonVal::obj();
                a.insert("format", s(fmt));
                match tool_report_export(&paths, &a) {
                    Ok(v) => println!("{}", v.to_json_string()),
                    Err(e) => {
                        eprintln!("{}", e);
                        std::process::exit(1);
                    }
                }
                return;
            }
            _ => {
                println!(
                    "Usage: artex-audit [status | dashboard start|stop|open | report markdown|csv | hook-pre-tool]"
                );
                return;
            }
        }
    }

    let stdin = io::stdin();
    let stdout = io::stdout();
    let mut reader = BufReader::new(stdin.lock());
    let mut writer = stdout.lock();

    while let Ok(Some((raw, framing))) = read_rpc_message(&mut reader) {
        if let Ok(req) = parse_json(&raw) {
            if let Some(resp) = handle_rpc_request(&paths, &req) {
                if write_rpc_message(&mut writer, &resp, framing).is_err() {
                    break;
                }
            }
        }
    }
}
