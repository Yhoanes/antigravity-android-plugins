# ARTEX Audit Core & Dual-Graph Rules (Android ARM64)

When the `artex-audit` plugin is enabled:

1. **Authorized Scope Only (Strict Legal & Safety Boundary):**
   - Only run security assessments, surface discovery, or verification against local sandboxes (`localhost`, `127.0.0.1`), local workspace codebases, or external targets explicitly authorized in writing and registered via `artex_scope_configure`.
   - Never run destructive commands, DoS, or unauthorized data exfiltration. The bundled `PreToolUse` hook (`artex-guard`) actively audits `run_command` and gates external scanners against `companies.scope_patterns`.

2. **Dual-Graph Audit Workflow (`$HOME/.gemini/artex/artex.db`):**
   - **Step 1 (Task & Scope):** Call `artex_scope_configure` (if adding a new authorized target) and `artex_task_manage` (`action: "create"`) with an `initial_goal` and `lang` (`es` by default).
   - **Step 2 (Asset Graph):** Persist discovered domains, services, apps, and endpoints via `artex_asset_upsert` (`root_domain -> subdomain -> ip -> service -> app -> endpoint`) and query them with `artex_asset_dsl_search`.
   - **Step 3 (Exploration Graph & Worker Traces):** Track reasoning lineage (`goal -> intent -> fact -> finding`) via `artex_graph_record` anchored to `asset_ids`, and share intermediate observations across subagents via `artex_worker_trace`.
   - **Step 4 (Findings, Evidence & Dashboard):** Record verified issues with CWE/CVSS and remediation via `artex_finding_manage` + `artex_evidence_archive`, export reports via `artex_report_export`, and launch the live console at `http://127.0.0.1:8787` via `artex_dashboard_server` (`action: "start"`).
