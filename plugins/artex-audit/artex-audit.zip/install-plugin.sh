#!/system/bin/sh
# install-plugin.sh — Installs and configures ARTEX Audit Core & Dual-Graph (v1.0.0, Native Rust ARM64 + SQLite WAL)
set -eu

SRC_DIR="$(CDPATH= cd -- "$(/system/bin/dirname -- "$0")" && pwd)"
case "$SRC_DIR" in
    */.gemini/*) HOME="${SRC_DIR%%/.gemini/*}" ;;
    *) HOME="${HOME:-/data/user/0/com.agy/files}" ;;
esac
PREFIX="${PREFIX:-$HOME/usr}"
CONFIG_DIR="$HOME/.gemini/config"
TARGET_DIR="$CONFIG_DIR/plugins/artex-audit"

/system/bin/mkdir -p "$CONFIG_DIR/plugins" "$HOME/.gemini/artex" "$PREFIX/tmp" "$PREFIX/bin"

if [ "$SRC_DIR" != "$TARGET_DIR" ]; then
    /system/bin/rm -rf "$TARGET_DIR"
    /system/bin/mkdir -p "$TARGET_DIR"
    /system/bin/cp -Rf "$SRC_DIR"/. "$TARGET_DIR"/
fi

/system/bin/chmod 0755 \
    "$TARGET_DIR/install-plugin.sh" \
    "$TARGET_DIR/mcp/bin/start-mcp.sh" \
    "$TARGET_DIR/mcp/bin/artex-guard-hook.sh" \
    "$TARGET_DIR/mcp/bin/artex-audit-mcp"

/system/bin/rm -f "$PREFIX/bin/artex-audit"
cat > "$PREFIX/bin/artex-audit" <<EOF
#!/system/bin/sh
export HOME="$HOME"
export PREFIX="$PREFIX"
[ -d "$PREFIX/lib" ] && export LD_LIBRARY_PATH="$PREFIX/lib\${LD_LIBRARY_PATH:+:\$LD_LIBRARY_PATH}"
exec "$TARGET_DIR/mcp/bin/artex-audit-mcp" "\$@"
EOF
/system/bin/chmod 0755 "$PREFIX/bin/artex-audit"

echo "================================================================="
echo " Plugin ARTEX Audit Core & Dual-Graph v1.0.0 (Rust ARM64) ready"
echo " Path: $TARGET_DIR"
echo "================================================================="
