# ARTEX Audit Core & Dual-Graph (`v1.0.0`) — Motor de Auditoría Autorizada en Rust ARM64 + SQLite WAL

Plugin nativo **ARM64 (`aarch64` + `LSE`)** para **Antigravity for Android** que porta la arquitectura central de [`jiwoochris/artex-global`](https://github.com/jiwoochris/artex-global) (`AGPL-3.0`) a un binario ultrarrápido en **Rust puro (`559 KB`, `<10 MB` RAM)** sobre **SQLite 3.54+ WAL (`~/.gemini/artex/artex.db`)** — **cero Docker y cero PostgreSQL**.

> [!IMPORTANT]
> **Uso Autorizado Exclusivamente (`artex-guard` Activo):**
> Diseñado estrictamente para auditar aplicaciones propias, servidores locales (`localhost` / `127.0.0.1`), laboratorios aislados (OWASP Juice Shop, DVWA) o entornos con autorización explícita por escrito registrada en `artex_scope_configure`. Incluye el hook `PreToolUse` (`artex-guard`) activo por defecto para bloquear comandos destructivos y controlar el alcance.

---

## Arquitectura en Antigravity Android

1. **Grafo Dual Anclado (`Asset Graph` ⇄ `Exploration Graph`):**
   - **Asset Graph (Global):** Deduplica jerárquicamente `root_domain → subdomain → ip → service → app → endpoint` y soporta búsqueda DSL (`type=endpoint status=200 value~/api/`).
   - **Exploration Graph (Por Tarea):** Registra la cadena `goal → intent → fact → finding` conectada a activos reales mediante `exploration_anchors`.
2. **Intercambio de Trazas entre Subagentes + Todolist del Planner:**
   - Permite que múltiples subagentes (`/teamwork` / `swarm`) compartan observaciones de proceso (`artex_worker_trace`) y avancen en orden de dependencias sin repetir pruebas.
3. **Mini-Dashboard Web Local (`http://127.0.0.1:8787`):**
   - Servidor HTTP nativo embebido en el propio binario Rust con interfaz oscura bilingüe (**ES / EN**), diagrama SVG interactivo del Grafo Dual, filtro de severidades, auditoría `PreToolUse` y descarga en 1 clic de reportes **CSV** y **Markdown**.

---

## Las 12 Herramientas MCP Nativas en Rust

| Herramienta | Categoría | Función Nativa ARM64 |
| :--- | :--- | :--- |
| `artex_audit_status` | Diagnóstico | Estado del motor Rust, versión SQLite WAL, conteos del Grafo Dual y estado del Dashboard `:8787`. |
| `artex_scope_configure` | Alcance & Guard | Configura dominios/IPs autorizados y reglas personalizadas de intercepción `PreToolUse`. |
| `artex_task_manage` | Orquestación | Crea/lista tareas de auditoría y gestiona el *todolist* compartido por dependencias del Planner. |
| `artex_asset_upsert` | Asset Graph | Inserta y deduplica nodos en el grafo global de activos con enlace padre-hijo. |
| `artex_asset_dsl_search` | Asset Graph | Consulta rápida tipo DSL (`type=endpoint`, `host~api`, `tech~next`, `status=200`). |
| `artex_graph_record` | Exploration Graph | Registra `goal`, `intent`, `fact`, `hint`, aristas de linaje y anclas a `asset_ids` (`prove_goal`). |
| `artex_graph_overview` | Grafo Dual | Snapshot completo de objetivos, intents, hechos, hallazgos y superficie pendiente de auditar. |
| `artex_worker_trace` | Multi-Agente | Comparte y busca trazas de ejecución entre workers (`record`, `search`, `get`). |
| `artex_finding_manage` | Vulnerabilidades | Registra, actualiza o re-verifica (`retested_fixed`) hallazgos con **CVSS v3.1**, **CWE** y mitigación. |
| `artex_evidence_archive` | Evidencia | Archiva peticiones/respuestas HTTP sanitizadas con huella de integridad vinculadas a cada hallazgo. |
| `artex_report_export` | Entregables | Exporta informes ejecutivos y técnicos en **Markdown (`.md`)** o **CSV (`.csv`)** en español o inglés. |
| `artex_dashboard_server` | Consola Web | Inicia, detiene o abre (`xdg-open`) el Mini-Dashboard local en `http://127.0.0.1:8787`. |

---

## CLI en Terminal (`$PREFIX/bin/artex-audit`)

```bash
artex-audit status
artex-audit dashboard open      # Levanta http://127.0.0.1:8787 y lo abre en el navegador Android
artex-audit report markdown     # Exporta el informe completo en Markdown
artex-audit report csv          # Exporta la tabla de hallazgos en CSV
```
