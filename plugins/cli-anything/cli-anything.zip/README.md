# CLI-Anything Studio & Hub (`v1.0.0`) — Motor Agent-Native CLI & CLI-Hub en Rust ARM64

Plugin nativo **ARM64 (`aarch64` + `LSE`)** para **Antigravity for Android** que porta la arquitectura completa de [`HKUDS/CLI-Anything`](https://github.com/HKUDS/CLI-Anything) (`MIT`) y **`cli-anything-hub v0.4.1`** a un servidor MCP ultrarrápido en **Rust puro (`614 KB`, `<10 MB` RAM, `0` crates externas)**.

Convierte cualquier repositorio, librería o aplicación en una **interfaz de línea de comandos determinista para agentes de IA** (con estado persistente, bloqueo `fcntl`, `undo/redo`, `--dry-run`, modo `ReplSkin` interactivo y salida `--json`) y te conecta al catálogo en vivo de **+103 CLIs agent-native y 5 Matrices de Capacidades**.

---

## Ventajas Exclusivas en Antigravity Android ARM64

1. **Instalación Streaming en `<3s` (Sin Clonar `100+ MB`):**
   - En lugar de clonar todo el monorepo de `HKUDS/CLI-Anything` con `pip install git+https://...`, `cli_anything_hub_install` extrae en streaming únicamente el subdirectorio `<app>/agent-harness` y su `SKILL.md`, ejecuta **`agy-fix-paths`** para corregir los *shebangs* Bionic en `$PREFIX/bin` y sincroniza el `SKILL.md` automáticamente en `~/.gemini/config/skills/`.
2. **Semáforo Inteligente de Compatibilidad Android (`android_tier`):**
   - Clasifica automáticamente las +103 herramientas de CLI-Hub en `native_ready` (100% nativas en Android ARM64), `remote_api` (clientes REST/API para `n8n`, `dify`, `ollama`, `comfyui`, `jumpserver`) y `desktop_gui` (manipulación de proyectos en Python con aviso claro cuando el renderizado final requiere app de escritorio), detectando sinergias con tus plugins nativos en Rust (`agy-video-studio`, `game-studio`, `unity-android`, `github`).
3. **Generador PEP 420 + Validador Oficial `52/52` en `<15 ms`:**
   - Escanea cualquier código fuente local o repo de GitHub (`cli_anything_analyze_target`), genera el paquete completo `cli_anything.<software>` (`cli_anything_scaffold`) compatible con almacenamiento Android `/sdcard` (`noexec`-safe) y audita las **52 reglas oficiales de `HARNESS.md`** en Rust puro (`cli_anything_validate`).

---

## Las 10 Herramientas MCP Nativas en Rust

| Herramienta | Categoría | Función Nativa ARM64 |
| :--- | :--- | :--- |
| `cli_anything_status` | Diagnóstico | Estado del motor Rust, Python 3, `click`/`pytest`, `cli-hub`, cachés locales, CLIs instalados y Skills sincronizados. |
| `cli_anything_setup` | Bootstrap 1-Click | Instala `click`, `requests`, `pytest`, `prompt_toolkit` y el `cli-anything-hub v0.4.1` embebido + `agy-fix-paths` y precarga el registro. |
| `cli_anything_hub_search` | Catálogo `103+` | Búsqueda instantánea en Rust sobre los 79 harnesses HKUDS + 24 CLIs públicos con filtro `android_tier`. |
| `cli_anything_hub_install` | Gestor de Paquetes | Instala, actualiza o elimina CLIs en `<3s` vía tarball streaming + `agy-fix-paths` + auto-sync de `SKILL.md`. |
| `cli_anything_matrix` | Workflow Matrices | Explora las 5 Matrices (`video-creation`, `image-design`, `knowledge-research`, etc.), busca capacidades (`can`), corre `preflight` y sincroniza su `SKILL.md`. |
| `cli_anything_analyze_target` | `HARNESS` Fase 0–1 | Clona o escanea un repositorio detectando lenguajes, frameworks CLI/API/GUI, formatos de estado y patrones `undo`. |
| `cli_anything_scaffold` | `HARNESS` Fase 2–3 | Genera un paquete PEP 420 `cli_anything.<software>` completo (`Click` + `ReplSkin` + `Session` `fcntl` + tests), instala `-e` y ejecuta `agy-fix-paths`. |
| `cli_anything_validate` | `HARNESS` Fase 4–6 | Audita las **52 comprobaciones oficiales** en 8 categorías en `<15ms`, ejecuta `pytest -v` opcional y actualiza `TEST.md`. |
| `cli_anything_skill_sync` | `HARNESS` Fase 6.5–7 | Extrae metadatos AST con `skill_generator.py`, genera `SKILL.md` y gestiona skills sincronizados en Antigravity. |
| `cli_anything_exec` | Ejecutor JSON | Ejecuta cualquier `cli-anything-<app>` instalado inyectando `--json` y variables Bionic de forma determinista. |

---

## CLI en Terminal (`$PREFIX/bin/cli-anything` & `$PREFIX/bin/cli-hub`)

```bash
cli-anything status
cli-anything setup
cli-anything search diagram
cli-anything install mermaid
cli-anything scaffold my-workflow
cli-anything validate /storage/emulated/0/Documents/CLI-Anything/my-workflow/agent-harness --pytest
```
