#!/system/bin/sh
# install-plugin.sh — Installs and configures CLI-Anything Studio & Hub Android (v1.0.0, Native Rust ARM64)
set -eu

SRC_DIR="$(CDPATH= cd -- "$(/system/bin/dirname -- "$0")" && pwd)"
case "$SRC_DIR" in
    */.gemini/*) HOME="${SRC_DIR%%/.gemini/*}" ;;
    *) HOME="${HOME:-/data/user/0/com.agy/files}" ;;
esac
PREFIX="${PREFIX:-$HOME/usr}"
CONFIG_DIR="$HOME/.gemini/config"
TARGET_DIR="$CONFIG_DIR/plugins/cli-anything"

/system/bin/mkdir -p "$CONFIG_DIR/plugins" "$CONFIG_DIR/skills" "$HOME/.cli-hub" "$PREFIX/tmp" "$PREFIX/bin"

if [ "$SRC_DIR" != "$TARGET_DIR" ]; then
    /system/bin/rm -rf "$TARGET_DIR"
    /system/bin/mkdir -p "$TARGET_DIR"
    /system/bin/cp -Rf "$SRC_DIR"/. "$TARGET_DIR"/
fi

/system/bin/chmod 0755 \
    "$TARGET_DIR/install-plugin.sh" \
    "$TARGET_DIR/mcp/bin/start-mcp.sh" \
    "$TARGET_DIR/mcp/bin/cli-anything-mcp"

/system/bin/rm -f "$PREFIX/bin/cli-anything"
cat > "$PREFIX/bin/cli-anything" <<EOF
#!/system/bin/sh
export HOME="$HOME"
export PREFIX="$PREFIX"
[ -d "$PREFIX/lib" ] && export LD_LIBRARY_PATH="$PREFIX/lib\${LD_LIBRARY_PATH:+:\$LD_LIBRARY_PATH}"
exec "$TARGET_DIR/mcp/bin/cli-anything-mcp" "\$@"
EOF
/system/bin/chmod 0755 "$PREFIX/bin/cli-anything"

echo "================================================================="
echo " Plugin CLI-Anything Studio & Hub v1.0.0 (Rust ARM64) installed"
echo " Path: $TARGET_DIR"
echo " CLI:  $PREFIX/bin/cli-anything"
echo "================================================================="
