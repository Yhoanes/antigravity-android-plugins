# CLI-Anything Studio & Hub Rules (Android ARM64 — Native Rust)

When the `cli-anything` plugin is enabled on Antigravity for Android:

1. **Prefer Native `cli-anything` Rust MCP Tools for Agent-Native CLI Workflows:**
   - **Discover & Install Pre-Built CLIs (`103+` in CLI-Hub):** Call `cli_anything_hub_search` first (filter with `android_tier: "native_ready"` or `"remote_api"` on Android) and install via `cli_anything_hub_install` (`action: "install"`), which streams only the target subdirectory from GitHub in `<3s` (avoiding `100+ MB` monorepo clones), runs `agy-fix-paths`, and syncs `SKILL.md` into `~/.gemini/config/skills/` automatically.
   - **Multi-Tool Capability Matrices:** Use `cli_anything_matrix` (`list`, `can`, `preflight`, `render_skill`) before bulk-installing workflow tools so only required capabilities are installed.
   - **Build Custom Agent-Native CLIs from Any Repo (`HARNESS.md` 7-Phase SOP):** Read the `cli-anything` skill first, run `cli_anything_analyze_target` -> `cli_anything_scaffold` -> customize domain modules -> `cli_anything_validate` (`52/52` checks + `run_pytest: true`) -> `cli_anything_skill_sync`.

2. **Android ARM64 & Native Studio Plugin Synergy:**
   - Check `android_tier` in `cli_anything_hub_search`: `desktop_gui` harnesses (like desktop `gimp`, `obs-studio`, or `iterm2`) can manipulate project XML/JSON state in Python on Android, but require their desktop GUI binary for final local rendering.
   - For **Blender 5.0 3D / Video**, **Remotion 4.0**, **Godot 4**, **Unity 6**, **GitHub**, and **Binary Reverse Engineering**, prefer pairing with your installed native Rust plugins (`agy-video-studio`, `agy-remotion`, `game-studio`, `unity-android`, `github`, `craft-anything`).

3. **Android Sandbox & Bionic Safety:**
   - Always run `agy-fix-paths` (handled automatically by `cli_anything_setup`, `cli_anything_hub_install`, and `cli_anything_scaffold`) after `pip` or `npm` console-script installs so `$PREFIX/bin/cli-anything-*` shebangs work cleanly on Android.
   - Never modify, overwrite, or delete anything inside `/data/user/0/com.agy/files/runtime/bin/`; CLI wrappers live exclusively in `$PREFIX/bin/{cli-anything,cli-hub}`.
