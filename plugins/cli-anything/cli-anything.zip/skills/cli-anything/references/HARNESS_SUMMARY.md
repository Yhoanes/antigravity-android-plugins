# HARNESS.md — Critical PEP 420 & Stateful CLI Checklist

1. **PEP 420 Namespace Rule (Mandatory):**
   - `agent-harness/cli_anything/` MUST NOT contain `__init__.py`.
   - `agent-harness/cli_anything/<software>/` MUST contain `__init__.py`.
   - `setup.py` MUST call `find_namespace_packages(include=["cli_anything.*"])`.

2. **One-Shot Auto-Save + `--dry-run`:**
   - Every one-shot mutating Click subcommand MUST call `session.snapshot(...)`, mutate state, and call `session.save_session(dry_run=ctx.obj["dry_run"])` before exiting so state is never lost between agent tool invocations.

3. **Exclusive Session Locking (`_locked_save_json`):**
   - Open existing session JSON with `"r+"` (never `"w"`, which truncates before acquiring `fcntl.flock(LOCK_EX)`), acquire lock, `seek(0)`, `truncate()`, and write JSON safely.

4. **Deterministic Agent Output (`--json`):**
   - Support `--json` on the root Click group so every subcommand and `handle_error` emits valid RFC 8259 JSON without ANSI escape codes polluting stdout.

5. **Android Bionic Console Scripts:**
   - Always run `agy-fix-paths` (or use `cli_anything_scaffold` / `cli_anything_skill_sync`) after `pip install -e .` so `$PREFIX/bin/cli-anything-<software>` uses `/data/user/0/com.agy/files/usr/bin/python3`.
