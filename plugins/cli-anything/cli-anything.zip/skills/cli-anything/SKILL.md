---
name: cli-anything
description: Build, refine, test, and validate stateful agent-native Python Click CLIs (--json, ReplSkin REPL, fcntl session locking, undo/redo, auto-save + --dry-run, PEP 420 cli_anything.* namespace, and SKILL.md) from any local codebase or GitHub repository using HKUDS/CLI-Anything's 7-phase HARNESS.md methodology on Android ARM64.
---

# CLI-Anything Harness Builder (`HARNESS.md` 7-Phase SOP — Android ARM64)

Use this skill whenever the user wants to **turn a codebase, library, script collection, REST service, or application into a deterministic, stateful CLI (`cli-anything-<software>`)** designed for AI agents, or wants to **validate, test, or refine** an existing CLI-Anything harness.

For full upstream architectural reference, read:
- Bundled full SOP: `/data/user/0/com.agy/files/.gemini/config/plugins/cli-anything/mcp/toolkit/HARNESS.md`
- Condensed Android checklist: `references/HARNESS_SUMMARY.md` in this skill folder.

---

## End-to-End 7-Phase Workflow on Antigravity Android

### Phase 0 & 1: Target Acquisition & Codebase Analysis
1. Call **`cli_anything_status`** (and **`cli_anything_setup`** once if `click` or `pytest` is missing).
2. Call **`cli_anything_analyze_target`** with `target` set to either a local folder or a GitHub URL (`https://github.com/owner/repo`).
3. Inspect the target's core engine, data/project files (`.json`, `.xml`, `.yaml`, `.sqlite`), existing CLI commands, API routes, and undo/mutation operations.

### Phase 2 & 3: Architecture Design & PEP 420 Scaffolding
1. Call **`cli_anything_scaffold`** with:
   - `software_name`: kebab-case identifier (e.g. `"invoice-pilot"`)
   - `domain_group`: primary domain noun (e.g. `"invoice"`, `"diagram"`, `"pipeline"`)
   - `backend_bin`: optional underlying executable wrapped by `utils/<pkg>_backend.py`
   - `output_dir`: defaults to `/storage/emulated/0/Documents/CLI-Anything/` (`noexec`-safe because console scripts install into `$PREFIX/bin`).
2. Customize the generated modules under `<software>/agent-harness/cli_anything/<pkg>/`:
   - **`core/project.py`**: Real data-model creation, parsing, validation, and atomic `.tmp` saves.
   - **`core/session.py`**: Keep `_locked_save_json` (`fcntl.flock`) + `snapshot()` / `undo()` / `redo()` intact.
   - **`core/export.py`**: Real output generation + programmatic output verification (size > 0, magic bytes / header validation).
   - **`utils/<pkg>_backend.py`**: Wrap the real software library, REST API, or binary executable cleanly.
   - **`<pkg>_cli.py`**: Expand Click command groups so every mutation snapshots session state, auto-saves unless `--dry-run` is set, and emits parseable JSON when `--json` is passed.

### Phase 4, 5 & 6: Test Planning (`TEST.md`), Unit + E2E Implementation & Validation
1. Update `tests/TEST.md` (Part 1 plan), `tests/test_core.py` (unit tests with synthetic data), and `tests/test_full_e2e.py` (real file exports + `TestCLISubprocess` using `_resolve_cli("cli-anything-<slug>")` with `CLI_ANYTHING_FORCE_INSTALLED` support and **no hardcoded `cwd=`**).
2. Call **`cli_anything_validate`** with `harness_path` and `run_pytest: true`:
   - Verifies all **52 official `HARNESS.md` checks** across 8 categories (`Directory Structure`, `Required Files`, `CLI Standards`, `Core Modules`, `Test Standards`, `Documentation`, `PyPI PEP 420 Packaging`, `Code Quality`).
   - Runs `pytest -v` and automatically writes Part 2 results into `tests/TEST.md`.
   - Fix any reported check failure until `overall == "PASS"` (`52/52`).

### Phase 6.5 & 7: `SKILL.md` Generation, Editable Install & `agy-fix-paths`
1. Call **`cli_anything_skill_sync`** (`action: "generate_and_sync"`, `install_editable: true`):
   - Extracts all Click groups and subcommands via AST (`skill_generator.py`), writes `SKILL.md`, installs `cli-anything-<slug>` into `$PREFIX/bin`, runs `agy-fix-paths`, and registers `~/.gemini/config/skills/cli-anything-<slug>/SKILL.md` for Antigravity.
2. Verify execution via **`cli_anything_exec`** (`cli_name: "<slug>"`, `args: ["project", "profiles"]`).
