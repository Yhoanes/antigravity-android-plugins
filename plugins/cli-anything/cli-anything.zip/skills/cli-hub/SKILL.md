---
name: cli-hub
description: Browse, filter by Android ARM64 compatibility, install, and run 103+ pre-built agent-native CLIs and 5 Curated Capability Matrices from HKUDS CLI-Hub (clianything.cc) using native Rust MCP tools and ported cli-hub v0.4.1.
---

# CLI-Hub & Capability Matrices Guide (Android ARM64)

Use this skill whenever the user wants to **discover, evaluate, install, or run pre-built agent-native CLIs** from `HKUDS/CLI-Anything` (`clianything.cc`) or plan a multi-tool workflow with **CLI-Hub Capability Matrices**.

---

## 1. Searching & Evaluating Android ARM64 Compatibility

Call **`cli_anything_hub_search`** before installing:
- `query`: keyword such as `"mermaid"`, `"diagram"`, `"database"`, `"workflow"`, `"cloud"`, `"research"`.
- `android_tier`:
  - **`"native_ready"`** *(Recommended on Android)*: Runs 100% natively on Antigravity Android ARM64 (Python/Node/Cloud APIs/Headless tools like `mermaid`, `chromadb`, `exa`, `supabase`, `stripe`, `vercel`, `cloudflare`, `pandoc`, `yt-dlp`, etc.).
  - **`"remote_api"`**: Runs 100% natively on Android as a stateful REST/API client against a local or remote server (`n8n`, `dify-workflow`, `comfyui`, `ollama`, `jumpserver`, `adguardhome`, `firefly-iii`).
  - **`"desktop_gui"`**: Project/XML/JSON state manipulation runs in Python on Android, while final local rendering expects a desktop X11/macOS/Windows GUI app (`gimp`, `obs-studio`, `kdenlive`, `iterm2`).

---

## 2. Fast Subdirectory Installation & Skill Auto-Sync

Call **`cli_anything_hub_install`**:
- `action: "install"`, `name: "<cli-name>"`, `sync_skill: true`
- **Why use the MCP tool instead of raw `pip install git+...` on Android?**
  1. Streams **only** `<name>/agent-harness` + `skills/cli-anything-<name>/SKILL.md` from GitHub's tarball in `<3s` instead of cloning the entire `100+ MB` monorepo.
  2. Injects Android Bionic `GIT_EXEC_PATH`, `SSL_CERT_FILE`, and `TMPDIR`.
  3. Runs **`agy-fix-paths`** so `$PREFIX/bin/cli-anything-<name>` executes cleanly without `/bin/sh` errors.
  4. Copies `SKILL.md` directly into `~/.gemini/config/skills/cli-anything-<name>/SKILL.md` so you can read its exact command groups immediately.

---

## 3. Curated Capability Matrices (`video-creation`, `image-design`, `knowledge-research`, etc.)

When a task spans multiple tools, use **`cli_anything_matrix`**:
1. `action: "list"` — inspect available matrices.
2. `action: "can"`, `query: "<intent>"` — find matching capabilities across all matrices.
3. `action: "preflight"`, `name: "<matrix>"` — check which providers are already active on this Android device (requires `cli_anything_setup` for full provider probing).
4. `action: "render_skill"`, `name: "<matrix>"` — sync the matrix's provider-routing `SKILL.md` into `~/.gemini/config/skills/cli-matrix-<matrix>/SKILL.md`.

---

## 4. Terminal Commands (`$PREFIX/bin/cli-anything` & `$PREFIX/bin/cli-hub`)

```bash
# Fast Rust CLI (0 Python startup overhead):
cli-anything status
cli-anything search diagram
cli-anything install mermaid

# Full Python CLI-Hub v0.4.1 (after cli_anything_setup):
cli-hub list
cli-hub can "transcribe audio"
cli-hub matrix preflight knowledge-research --json
```
