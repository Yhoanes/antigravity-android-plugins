// main.rs — CLI-Anything Studio & Hub Android (cli-anything v1.0.0)
// Native Android ARM64 Rust MCP Server + PEP 420 Harness Generator + 52-Check Validator + CLI-Hub Bridge
mod json;
mod templates;

use json::{
    make_tool, n_i64, parse_json, prop_arr_str, prop_bool, prop_int, prop_str, prop_str_enum, s,
    JsonVal,
};
use std::collections::BTreeMap;
use std::env;
use std::fs;
use std::io::{self, BufRead, BufReader, Write};
use std::path::{Path, PathBuf};
use std::process::Command;
use std::time::{SystemTime, UNIX_EPOCH};
use templates::HarnessSpec;

const SERVER_NAME: &str = "cli-anything";
const SERVER_VERSION: &str = "1.0.0";

const REGISTRY_URL: &str = "https://hkuds.github.io/CLI-Anything/registry.json";
const PUBLIC_REGISTRY_URL: &str = "https://hkuds.github.io/CLI-Anything/public_registry.json";
const MATRIX_REGISTRY_URL: &str = "https://hkuds.github.io/CLI-Anything/matrix_registry.json";
const CACHE_TTL_SECS: u64 = 3600;

struct EnvPaths {
    home: PathBuf,
    prefix: PathBuf,
    plugin_dir: PathBuf,
    toolkit_dir: PathBuf,
    hub_cache_dir: PathBuf,
    skills_dir: PathBuf,
    tmp_dir: PathBuf,
}

impl EnvPaths {
    fn resolve() -> Self {
        let mut home = env::var("HOME")
            .ok()
            .filter(|v| !v.is_empty())
            .map(PathBuf::from)
            .unwrap_or_else(|| PathBuf::from("/data/user/0/com.agy/files"));

        let exe_plugin_dir = env::current_exe().ok().and_then(|exe| {
            // .../plugins/<dir>/mcp/bin/cli-anything-mcp
            let bin_dir = exe.parent()?;
            let mcp_dir = bin_dir.parent()?;
            let p_dir = mcp_dir.parent()?;
            if p_dir.join("plugin.json").exists() || mcp_dir.join("toolkit").exists() {
                Some(p_dir.to_path_buf())
            } else {
                None
            }
        });

        if let Some(ref pdir) = exe_plugin_dir {
            let pstr = pdir.to_string_lossy();
            if let Some(idx) = pstr.find("/.gemini/") {
                home = PathBuf::from(&pstr[..idx]);
            }
        }

        let prefix = env::var("PREFIX")
            .ok()
            .filter(|v| !v.is_empty())
            .map(PathBuf::from)
            .unwrap_or_else(|| home.join("usr"));

        let plugin_dir =
            exe_plugin_dir.unwrap_or_else(|| home.join(".gemini/config/plugins/cli-anything"));
        let toolkit_dir = plugin_dir.join("mcp/toolkit");
        let hub_cache_dir = home.join(".cli-hub");
        let skills_dir = home.join(".gemini/config/skills");
        let tmp_dir = prefix.join("tmp");

        let _ = fs::create_dir_all(&hub_cache_dir);
        let _ = fs::create_dir_all(&skills_dir);
        let _ = fs::create_dir_all(&tmp_dir);

        Self {
            home,
            prefix,
            plugin_dir,
            toolkit_dir,
            hub_cache_dir,
            skills_dir,
            tmp_dir,
        }
    }

    fn build_path_env(&self) -> String {
        let p_bin = self.prefix.join("bin");
        let r_bin = self.home.join("runtime/bin");
        let cur = env::var("PATH").unwrap_or_else(|_| "/system/bin".into());
        format!("{}:{}:{}", p_bin.display(), r_bin.display(), cur)
    }

    fn apply_bionic_env(&self, cmd: &mut Command) {
        cmd.env("HOME", &self.home);
        cmd.env("PREFIX", &self.prefix);
        cmd.env("TMPDIR", &self.tmp_dir);
        cmd.env("PATH", self.build_path_env());
        cmd.env("GIT_CONFIG_NOSYSTEM", "1");
        cmd.env("GODEBUG", "netdns=cgo");
        let git_exec = self.prefix.join("libexec/git-core");
        if git_exec.is_dir() {
            cmd.env("GIT_EXEC_PATH", git_exec);
        }
        let cert = self.prefix.join("etc/tls/cert.pem");
        if cert.is_file() {
            cmd.env("SSL_CERT_FILE", &cert);
            cmd.env("CURL_CA_BUNDLE", &cert);
            cmd.env("REQUESTS_CA_BUNDLE", &cert);
        }
        let lib_dir = self.prefix.join("lib");
        if lib_dir.is_dir() {
            let existing = env::var("LD_LIBRARY_PATH").unwrap_or_default();
            let merged = if existing.is_empty() {
                lib_dir.to_string_lossy().to_string()
            } else {
                format!("{}:{}", lib_dir.display(), existing)
            };
            cmd.env("LD_LIBRARY_PATH", merged);
        }
    }

    fn which(&self, bin_name: &str) -> Option<PathBuf> {
        for dir in self.build_path_env().split(':') {
            if dir.is_empty() {
                continue;
            }
            let cand = Path::new(dir).join(bin_name);
            if cand.is_file() {
                return Some(cand);
            }
        }
        None
    }

    fn ensure_cli_wrapper(&self) {
        let bin_dir = self.prefix.join("bin");
        let _ = fs::create_dir_all(&bin_dir);
        let wrapper = bin_dir.join("cli-anything");
        let mcp_bin = self.plugin_dir.join("mcp/bin/cli-anything-mcp");
        if !wrapper.exists() && mcp_bin.is_file() {
            let script = format!(
                "#!/system/bin/sh\nexport HOME=\"{}\"\nexport PREFIX=\"{}\"\nexec \"{}\" \"$@\"\n",
                self.home.display(),
                self.prefix.display(),
                mcp_bin.display()
            );
            if fs::write(&wrapper, script).is_ok() {
                #[cfg(unix)]
                {
                    use std::os::unix::fs::PermissionsExt;
                    let _ = fs::set_permissions(&wrapper, fs::Permissions::from_mode(0o755));
                }
            }
        }
    }

    fn run_fix_paths(&self) -> bool {
        if let Some(fixer) = self.which("agy-fix-paths") {
            let mut cmd = Command::new(fixer);
            self.apply_bionic_env(&mut cmd);
            return cmd.output().map(|o| o.status.success()).unwrap_or(false);
        }
        false
    }
}

fn now_secs() -> u64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_secs())
        .unwrap_or(0)
}

fn sanitize_slug(raw: &str) -> (String, String, String) {
    let mut slug = String::new();
    let mut prev_sep = false;
    for ch in raw.trim().chars() {
        if ch.is_ascii_alphanumeric() {
            slug.push(ch.to_ascii_lowercase());
            prev_sep = false;
        } else if (ch == '-' || ch == '_' || ch == ' ') && !slug.is_empty() && !prev_sep {
            slug.push('-');
            prev_sep = true;
        }
    }
    while slug.ends_with('-') {
        slug.pop();
    }
    if slug.is_empty() {
        slug = "custom-tool".into();
    }
    if slug.chars().next().map(|c| c.is_ascii_digit()).unwrap_or(false) {
        slug = format!("app-{}", slug);
    }
    let pkg_mod = slug.replace('-', "_");
    let display = slug
        .split('-')
        .map(|w| {
            let mut cs = w.chars();
            match cs.next() {
                Some(f) => format!("{}{}", f.to_ascii_uppercase(), cs.as_str()),
                None => String::new(),
            }
        })
        .collect::<Vec<_>>()
        .join(" ");
    (slug, pkg_mod, display)
}

fn run_cmd_capture(paths: &EnvPaths, prog: &Path, args: &[&str], cwd: Option<&Path>) -> (i32, String, String) {
    let mut cmd = Command::new(prog);
    paths.apply_bionic_env(&mut cmd);
    cmd.args(args);
    if let Some(d) = cwd {
        cmd.current_dir(d);
    }
    match cmd.output() {
        Ok(out) => (
            out.status.code().unwrap_or(-1),
            String::from_utf8_lossy(&out.stdout).to_string(),
            String::from_utf8_lossy(&out.stderr).to_string(),
        ),
        Err(e) => (-1, String::new(), e.to_string()),
    }
}

// ---------------------------------------------------------------------------
// Registry Fetching & Android ARM64 Compatibility Classifier
// ---------------------------------------------------------------------------

fn fetch_cached_url(paths: &EnvPaths, url: &str, cache_name: &str, force: bool) -> Result<JsonVal, String> {
    let cache_file = paths.hub_cache_dir.join(cache_name);
    if !force && cache_file.is_file() {
        if let Ok(raw) = fs::read_to_string(&cache_file) {
            if let Ok(parsed) = parse_json(&raw) {
                let ts = parsed.get_f64("_cached_at").unwrap_or(0.0) as u64;
                if now_secs().saturating_sub(ts) < CACHE_TTL_SECS {
                    if let Some(data) = parsed.get("data") {
                        return Ok(data.clone());
                    }
                }
            }
        }
    }

    let curl_bin = paths
        .which("curl")
        .unwrap_or_else(|| PathBuf::from("/data/user/0/com.agy/files/usr/bin/curl"));
    let (code, stdout, stderr) = run_cmd_capture(paths, &curl_bin, &["-fsSL", "--max-time", "20", url], None);
    if code == 0 && !stdout.trim().is_empty() {
        if let Ok(data) = parse_json(&stdout) {
            let mut wrapper = JsonVal::obj();
            wrapper.insert("_cached_at", JsonVal::Num(now_secs() as f64));
            wrapper.insert("data", data.clone());
            let _ = fs::write(&cache_file, wrapper.to_json_string());
            return Ok(data);
        }
    }

    // Fallback to stale cache if offline
    if cache_file.is_file() {
        if let Ok(raw) = fs::read_to_string(&cache_file) {
            if let Ok(parsed) = parse_json(&raw) {
                if let Some(data) = parsed.get("data") {
                    return Ok(data.clone());
                }
            }
        }
    }

    Err(format!("Failed to fetch {}: {}", url, stderr.trim()))
}

fn classify_android_compat(paths: &EnvPaths, cli: &JsonVal) -> (&'static str, String) {
    let name = cli.get_str("name").unwrap_or("").to_lowercase();
    let req = cli.get_str("requires").unwrap_or("").to_lowercase();
    let cat = cli.get_str("category").unwrap_or("").to_lowercase();

    // Special native Antigravity plugin synergies
    if name == "blender" {
        let has_b = paths.which("blender-headless").is_some();
        return (
            "native_ready",
            if has_b {
                "Works natively with bare-metal Blender 5.0 Headless + agy-video-studio plugin!".into()
            } else {
                "Headless-capable on Android ARM64 (pair with agy-video-studio / agy-blender-setup).".into()
            },
        );
    }
    if name == "godot" {
        return (
            "native_ready",
            "Works on Android ARM64; pair with your installed game-studio Rust MCP plugin (120-144 FPS APK builder).".into(),
        );
    }
    if name == "unity" {
        return (
            "native_ready",
            "YAML/project ops work on Android; pair with your installed unity-android Rust MCP + official unity-cli v1.0.0.".into(),
        );
    }
    if name == "gh" || name == "github" {
        return (
            "native_ready",
            "Works natively on Android ARM64 (plus 91 native Rust tools in your github plugin).".into(),
        );
    }

    let desktop_only = [
        "gimp",
        "inkscape",
        "krita",
        "kdenlive",
        "shotcut",
        "obs-studio",
        "audacity",
        "freecad",
        "qgis",
        "cloudcompare",
        "musescore",
        "live2d",
        "iterm2",
        "nsight-graphics",
        "nslogger",
        "eez-studio",
        "libreoffice",
        "calibre",
        "xmind",
        "zwift",
        "vlc",
        "wireshark",
    ];
    if desktop_only.iter().any(|d| *d == name)
        || req.contains("macos")
        || req.contains("windows")
        || req.contains("xcode")
    {
        return (
            "desktop_gui",
            "Intermediate project/state JSON/XML commands work in Python on Android, but final local rendering requires the desktop GUI app.".into(),
        );
    }

    let remote_servers = [
        "jumpserver",
        "adguardhome",
        "comfyui",
        "ollama",
        "n8n",
        "dify-workflow",
        "firefly-iii",
        "home-assistant",
        "nextcloud",
        "sonarqube",
        "grafana",
        "prometheus",
    ];
    if remote_servers.iter().any(|r| *r == name)
        || req.contains("instance")
        || req.contains("server")
        || req.contains("running")
    {
        return (
            "remote_api",
            "100% compatible on Android ARM64 — connects over HTTP/REST to a local or remote service instance.".into(),
        );
    }

    let _ = cat;
    (
        "native_ready",
        "100% native-ready on Antigravity Android ARM64 (Python / Node.js / Cloud API / Headless CLI).".into(),
    )
}

fn load_installed_map(paths: &EnvPaths) -> BTreeMap<String, JsonVal> {
    let mut out = BTreeMap::new();
    let inst_file = paths.hub_cache_dir.join("installed.json");
    if inst_file.is_file() {
        if let Ok(raw) = fs::read_to_string(&inst_file) {
            if let Ok(JsonVal::Obj(map)) = parse_json(&raw) {
                out = map;
            }
        }
    }
    // Also auto-detect any cli-anything-* binaries in $PREFIX/bin
    if let Ok(entries) = fs::read_dir(paths.prefix.join("bin")) {
        for e in entries.flatten() {
            let fname = e.file_name().to_string_lossy().to_string();
            if let Some(rest) = fname.strip_prefix("cli-anything-") {
                if !out.contains_key(rest) {
                    let mut info = JsonVal::obj();
                    info.insert("entry_point", s(&fname));
                    info.insert("detected_in_bin", JsonVal::Bool(true));
                    out.insert(rest.to_string(), info);
                }
            }
        }
    }
    out
}

fn save_installed_map(paths: &EnvPaths, map: &BTreeMap<String, JsonVal>) {
    let inst_file = paths.hub_cache_dir.join("installed.json");
    let val = JsonVal::Obj(map.clone());
    let _ = fs::write(inst_file, val.to_json_string());
}

fn fetch_merged_clis(paths: &EnvPaths, force: bool) -> Result<Vec<JsonVal>, String> {
    let reg = fetch_cached_url(paths, REGISTRY_URL, "registry_cache.json", force)?;
    let mut all = Vec::new();
    if let Some(arr) = reg.get("clis").and_then(|v| v.as_arr()) {
        for item in arr {
            let mut c = item.clone();
            c.insert("_source", s("harness"));
            all.push(c);
        }
    }
    if let Ok(pub_reg) = fetch_cached_url(paths, PUBLIC_REGISTRY_URL, "public_registry_cache.json", force) {
        if let Some(arr) = pub_reg.get("clis").and_then(|v| v.as_arr()) {
            for item in arr {
                let mut c = item.clone();
                c.insert("_source", s("public"));
                all.push(c);
            }
        }
    }
    Ok(all)
}

// ---------------------------------------------------------------------------
// Tool 1: cli_anything_status
// ---------------------------------------------------------------------------

fn check_py_mod(paths: &EnvPaths, py: &Path, mod_name: &str) -> bool {
    let snippet = format!("import {}", mod_name);
    let (code, _, _) = run_cmd_capture(paths, py, &["-c", &snippet], None);
    code == 0
}

fn tool_status(paths: &EnvPaths) -> Result<JsonVal, String> {
    paths.ensure_cli_wrapper();
    let py = paths.which("python3");
    let py_ver = py
        .as_ref()
        .map(|p| {
            let (_, out, err) = run_cmd_capture(paths, p, &["--version"], None);
            let txt = if out.trim().is_empty() { err } else { out };
            txt.trim().to_string()
        })
        .unwrap_or_else(|| "missing".into());

    let mut py_mods = JsonVal::obj();
    for m in ["pip", "click", "requests", "pytest", "prompt_toolkit", "setuptools", "cli_hub"] {
        let ok = py.as_ref().map(|p| check_py_mod(paths, p, m)).unwrap_or(false);
        py_mods.insert(m, JsonVal::Bool(ok));
    }

    let toolkit_ready = paths.toolkit_dir.join("HARNESS.md").is_file()
        && paths.toolkit_dir.join("repl_skin.py").is_file()
        && paths.toolkit_dir.join("skill_generator.py").is_file()
        && paths.toolkit_dir.join("cli-hub/setup.py").is_file();

    let installed = load_installed_map(paths);
    let inst_names: Vec<JsonVal> = installed.keys().map(|k| s(k)).collect();

    let mut synced_skills = Vec::new();
    if let Ok(rd) = fs::read_dir(&paths.skills_dir) {
        for e in rd.flatten() {
            let name = e.file_name().to_string_lossy().to_string();
            if (name.starts_with("cli-anything-") || name.starts_with("cli-matrix-"))
                && e.path().join("SKILL.md").is_file()
            {
                synced_skills.push(s(&name));
            }
        }
    }

    let mut out = JsonVal::obj();
    out.insert("ok", JsonVal::Bool(true));
    out.insert("server", s(SERVER_NAME));
    out.insert("version", s(SERVER_VERSION));
    out.insert("plugin_dir", s(&paths.plugin_dir.to_string_lossy()));
    out.insert("toolkit_ready", JsonVal::Bool(toolkit_ready));
    out.insert("python_version", s(&py_ver));
    out.insert("python_modules", py_mods);
    out.insert("cli_hub_bin_ready", JsonVal::Bool(paths.which("cli-hub").is_some()));
    out.insert("cli_anything_bin_ready", JsonVal::Bool(paths.which("cli-anything").is_some()));
    out.insert("node_ready", JsonVal::Bool(paths.which("node").is_some()));
    out.insert("npm_ready", JsonVal::Bool(paths.which("npm").is_some()));
    out.insert("git_ready", JsonVal::Bool(paths.which("git").is_some()));
    out.insert("agy_fix_paths_ready", JsonVal::Bool(paths.which("agy-fix-paths").is_some()));
    out.insert(
        "registry_cached",
        JsonVal::Bool(paths.hub_cache_dir.join("registry_cache.json").is_file()),
    );
    out.insert("installed_harnesses_count", n_i64(inst_names.len() as i64));
    out.insert("installed_harnesses", JsonVal::Arr(inst_names));
    out.insert("synced_skills", JsonVal::Arr(synced_skills));
    Ok(out)
}

// ---------------------------------------------------------------------------
// Tool 2: cli_anything_setup
// ---------------------------------------------------------------------------

fn tool_setup(paths: &EnvPaths, args: &JsonVal) -> Result<JsonVal, String> {
    paths.ensure_cli_wrapper();
    let with_test_deps = args.get_bool("with_test_deps").unwrap_or(true);
    let warm_registry = args.get_bool("warm_registry").unwrap_or(true);

    let py = paths
        .which("python3")
        .ok_or_else(|| "python3 not found. Run: pkg update && pkg install python".to_string())?;

    let mut pkgs = vec!["setuptools", "wheel", "click", "requests"];
    if with_test_deps {
        pkgs.push("pytest");
        pkgs.push("prompt_toolkit");
    }

    let mut pip_args = vec!["-m", "pip", "install", "--upgrade"];
    pip_args.extend(pkgs.iter().copied());
    let (code1, out1, err1) = run_cmd_capture(paths, &py, &pip_args, None);
    if code1 != 0 {
        return Err(format!("Failed installing base Python deps:\n{}\n{}", out1, err1));
    }

    // Install bundled upstream cli-anything-hub (with _matrix_data & Android Bionic patches)
    let hub_src = paths.toolkit_dir.join("cli-hub");
    if !hub_src.join("setup.py").is_file() {
        return Err(format!("Bundled cli-hub not found at {}", hub_src.display()));
    }
    let hub_str = hub_src.to_string_lossy().to_string();
    let (code2, out2, err2) = run_cmd_capture(
        paths,
        &py,
        &["-m", "pip", "install", "--no-build-isolation", "--no-deps", "--force-reinstall", &hub_str],
        None,
    );
    if code2 != 0 {
        return Err(format!("Failed installing bundled cli-anything-hub:\n{}\n{}", out2, err2));
    }

    let fixed_paths = paths.run_fix_paths();

    let mut cached_counts = JsonVal::obj();
    if warm_registry {
        if let Ok(all) = fetch_merged_clis(paths, true) {
            cached_counts.insert("total_clis", n_i64(all.len() as i64));
        }
        if let Ok(mat) = fetch_cached_url(paths, MATRIX_REGISTRY_URL, "matrix_registry_cache.json", true) {
            let mc = mat
                .get("matrices")
                .and_then(|v| v.as_arr())
                .map(|a| a.len())
                .unwrap_or(0);
            cached_counts.insert("matrices", n_i64(mc as i64));
        }
    }

    let mut res = JsonVal::obj();
    res.insert("ok", JsonVal::Bool(true));
    res.insert("cli_hub_bin", s(&paths.which("cli-hub").map(|p| p.to_string_lossy().to_string()).unwrap_or_default()));
    res.insert("agy_fix_paths_applied", JsonVal::Bool(fixed_paths));
    res.insert("warmed_registries", cached_counts);
    res.insert("status", tool_status(paths)?);
    Ok(res)
}

// ---------------------------------------------------------------------------
// Tool 3: cli_anything_hub_search
// ---------------------------------------------------------------------------

fn tool_hub_search(paths: &EnvPaths, args: &JsonVal) -> Result<JsonVal, String> {
    let query = args.get_str("query").unwrap_or("").trim().to_lowercase();
    let category = args.get_str("category").unwrap_or("").trim().to_lowercase();
    let source = args.get_str("source").unwrap_or("all").trim().to_lowercase();
    let android_tier = args.get_str("android_tier").unwrap_or("all").trim().to_lowercase();
    let force_refresh = args.get_bool("force_refresh").unwrap_or(false);
    let limit = args.get_i64("limit").unwrap_or(30).clamp(1, 150) as usize;

    let all_clis = fetch_merged_clis(paths, force_refresh)?;
    let installed = load_installed_map(paths);

    let mut categories = Vec::new();
    let mut matches = Vec::new();
    let mut tier_counts: BTreeMap<String, i64> = BTreeMap::new();

    for c in &all_clis {
        let cat = c.get_str("category").unwrap_or("uncategorized").to_string();
        if !categories.contains(&cat) {
            categories.push(cat.clone());
        }
        let c_src = c.get_str("_source").unwrap_or("harness");
        if source != "all" && !source.is_empty() && c_src != source {
            continue;
        }
        if !category.is_empty() && cat.to_lowercase() != category {
            continue;
        }

        let name = c.get_str("name").unwrap_or("");
        let disp = c.get_str("display_name").unwrap_or(name);
        let desc = c.get_str("description").unwrap_or("");

        if !query.is_empty() {
            let hay = format!("{} {} {} {}", name, disp, desc, cat).to_lowercase();
            let all_toks = query.split_whitespace().all(|tok| hay.contains(tok));
            if !all_toks {
                continue;
            }
        }

        let (tier, note) = classify_android_compat(paths, c);
        *tier_counts.entry(tier.to_string()).or_insert(0) += 1;

        if android_tier != "all" && !android_tier.is_empty() && tier != android_tier {
            continue;
        }

        let mut item = JsonVal::obj();
        item.insert("name", s(name));
        item.insert("display_name", s(disp));
        item.insert("version", s(c.get_str("version").unwrap_or("latest")));
        item.insert("category", s(&cat));
        item.insert("source", s(c_src));
        item.insert("entry_point", s(c.get_str("entry_point").unwrap_or("")));
        item.insert("requires", s(c.get_str("requires").unwrap_or("")));
        item.insert("description", s(desc));
        item.insert("installed", JsonVal::Bool(installed.contains_key(name)));
        item.insert("android_tier", s(tier));
        item.insert("android_note", s(&note));
        matches.push(item);
    }

    categories.sort();
    let total_matches = matches.len();
    matches.truncate(limit);

    let mut tc_obj = JsonVal::obj();
    for (k, v) in tier_counts {
        tc_obj.insert(&k, n_i64(v));
    }

    let mut out = JsonVal::obj();
    out.insert("ok", JsonVal::Bool(true));
    out.insert("total_registry_clis", n_i64(all_clis.len() as i64));
    out.insert("total_matches", n_i64(total_matches as i64));
    out.insert("returned", n_i64(matches.len() as i64));
    out.insert("android_tier_breakdown", tc_obj);
    out.insert("categories", JsonVal::Arr(categories.into_iter().map(|c| s(&c)).collect()));
    out.insert("results", JsonVal::Arr(matches));
    Ok(out)
}

// ---------------------------------------------------------------------------
// Tool 4: cli_anything_hub_install
// ---------------------------------------------------------------------------

fn ensure_python_click(paths: &EnvPaths, py: &Path) -> Result<(), String> {
    if !check_py_mod(paths, py, "click") || !check_py_mod(paths, py, "setuptools") {
        let (code, out, err) = run_cmd_capture(
            paths,
            py,
            &["-m", "pip", "install", "setuptools", "wheel", "click", "requests"],
            None,
        );
        if code != 0 {
            return Err(format!("Failed bootstrapping click/setuptools:\n{}\n{}", out, err));
        }
    }
    Ok(())
}

fn sync_skill_from_harness(paths: &EnvPaths, harness_dir: &Path, cli_name: &str) -> Option<String> {
    let skill_dir = paths.skills_dir.join(format!("cli-anything-{}", cli_name));
    let dest_skill = skill_dir.join("SKILL.md");

    // Check packaged skills/SKILL.md inside cli_anything/*
    if let Ok(rd) = fs::read_dir(harness_dir.join("cli_anything")) {
        for e in rd.flatten() {
            let cand = e.path().join("skills/SKILL.md");
            if cand.is_file() {
                let _ = fs::create_dir_all(&skill_dir);
                if fs::copy(&cand, &dest_skill).is_ok() {
                    return Some(dest_skill.to_string_lossy().to_string());
                }
            }
        }
    }

    // Generate via bundled skill_generator.py
    if let Some(py) = paths.which("python3") {
        let sg = paths.toolkit_dir.join("skill_generator.py");
        if sg.is_file() {
            let _ = fs::create_dir_all(&skill_dir);
            let (code, _, _) = run_cmd_capture(
                paths,
                &py,
                &[
                    &sg.to_string_lossy(),
                    &harness_dir.to_string_lossy(),
                    "-o",
                    &dest_skill.to_string_lossy(),
                ],
                None,
            );
            if code == 0 && dest_skill.is_file() {
                return Some(dest_skill.to_string_lossy().to_string());
            }
        }
    }
    None
}

fn tool_hub_install(paths: &EnvPaths, args: &JsonVal) -> Result<JsonVal, String> {
    let action = args.get_str("action").unwrap_or("installed").trim();
    let name = args.get_str("name").unwrap_or("").trim();
    let sync_skill = args.get_bool("sync_skill").unwrap_or(true);

    let mut installed = load_installed_map(paths);

    if action == "installed" {
        let mut arr = Vec::new();
        for (k, v) in &installed {
            let mut item = v.clone();
            item.insert("name", s(k));
            arr.push(item);
        }
        let mut out = JsonVal::obj();
        out.insert("ok", JsonVal::Bool(true));
        out.insert("count", n_i64(arr.len() as i64));
        out.insert("installed", JsonVal::Arr(arr));
        return Ok(out);
    }

    if name.is_empty() {
        return Err("Parameter 'name' is required for info/install/uninstall/update.".into());
    }

    let all_clis = fetch_merged_clis(paths, false)?;
    let cli_opt = all_clis
        .iter()
        .find(|c| c.get_str("name").unwrap_or("").eq_ignore_ascii_case(name));

    if action == "info" {
        let c = cli_opt.ok_or_else(|| format!("CLI '{}' not found in CLI-Hub registry.", name))?;
        let (tier, note) = classify_android_compat(paths, c);
        let mut out = c.clone();
        out.insert("ok", JsonVal::Bool(true));
        out.insert("installed", JsonVal::Bool(installed.contains_key(&name.to_lowercase())));
        out.insert("android_tier", s(tier));
        out.insert("android_note", s(&note));
        return Ok(out);
    }

    if action == "uninstall" {
        let pkg_name = format!("cli-anything-{}", name.to_lowercase());
        if let Some(py) = paths.which("python3") {
            let _ = run_cmd_capture(paths, &py, &["-m", "pip", "uninstall", "-y", &pkg_name], None);
        }
        if let Some(c) = cli_opt {
            if let Some(npm_pkg) = c.get_str("npm_package") {
                if let Some(npm) = paths.which("npm") {
                    let _ = run_cmd_capture(paths, &npm, &["uninstall", "-g", npm_pkg], None);
                }
            }
        }
        installed.remove(&name.to_lowercase());
        save_installed_map(paths, &installed);
        let skill_dir = paths.skills_dir.join(&pkg_name);
        let removed_skill = if skill_dir.is_dir() {
            let _ = fs::remove_dir_all(&skill_dir);
            true
        } else {
            false
        };
        let mut out = JsonVal::obj();
        out.insert("ok", JsonVal::Bool(true));
        out.insert("uninstalled", s(name));
        out.insert("removed_synced_skill", JsonVal::Bool(removed_skill));
        return Ok(out);
    }

    // install or update
    let c = cli_opt.ok_or_else(|| format!("CLI '{}' not found in CLI-Hub registry.", name))?;
    let canon_name = c.get_str("name").unwrap_or(name).to_string();
    let src_type = c.get_str("_source").unwrap_or("harness");
    let install_cmd = c.get_str("install_cmd").unwrap_or("");
    let entry_point = c.get_str("entry_point").unwrap_or("");
    let (tier, note) = classify_android_compat(paths, c);

    let mut synced_skill_path: Option<String> = None;

    if src_type == "harness" || install_cmd.starts_with("pip install") {
        let py = paths
            .which("python3")
            .ok_or_else(|| "python3 not found on PATH".to_string())?;
        ensure_python_click(paths, &py)?;

        let marker = "git+https://github.com/HKUDS/CLI-Anything.git#subdirectory=";
        if let Some(idx) = install_cmd.find(marker) {
            let subdir = install_cmd[idx + marker.len()..].split_whitespace().next().unwrap_or("");
            let skill_rel = c
                .get_str("skill_md")
                .unwrap_or("")
                .trim()
                .to_string();
            let extract_base = paths.tmp_dir.join("cli-hub-extract").join(&canon_name);
            let _ = fs::remove_dir_all(&extract_base);
            let _ = fs::create_dir_all(&extract_base);

            let sh = Path::new("/system/bin/sh");
            let tar_targets = if !skill_rel.is_empty() && skill_rel.starts_with("skills/") {
                format!(
                    "\"CLI-Anything-main/{}\" \"CLI-Anything-main/{}\"",
                    subdir, skill_rel
                )
            } else {
                format!("\"CLI-Anything-main/{}\"", subdir)
            };
            let pipeline = format!(
                "curl -fsSL \"https://codeload.github.com/HKUDS/CLI-Anything/tar.gz/refs/heads/main\" | tar -xz -C \"{}\" --strip-components=1 {} 2>/dev/null || curl -fsSL \"https://codeload.github.com/HKUDS/CLI-Anything/tar.gz/refs/heads/main\" | tar -xz -C \"{}\" --strip-components=1 \"CLI-Anything-main/{}\"",
                extract_base.display(),
                tar_targets,
                extract_base.display(),
                subdir
            );
            let (ec, _, eerr) = run_cmd_capture(paths, sh, &["-c", &pipeline], None);
            let target_harness = extract_base.join(subdir);
            if ec != 0 || !target_harness.is_dir() {
                return Err(format!("Failed streaming '{}' from GitHub tarball: {}", subdir, eerr));
            }

            let mut pip_flags = vec!["-m", "pip", "install"];
            if action == "update" {
                pip_flags.push("--upgrade");
                pip_flags.push("--force-reinstall");
            }
            let th_str = target_harness.to_string_lossy().to_string();
            pip_flags.push(&th_str);
            let (pc, pout, perr) = run_cmd_capture(paths, &py, &pip_flags, None);
            if pc != 0 {
                return Err(format!("pip install failed for {}:\n{}\n{}", canon_name, pout, perr));
            }

            if sync_skill {
                let extracted_skill = extract_base.join(&skill_rel);
                if !skill_rel.is_empty() && extracted_skill.is_file() {
                    let dest_dir = paths.skills_dir.join(format!("cli-anything-{}", canon_name));
                    let _ = fs::create_dir_all(&dest_dir);
                    let dest_md = dest_dir.join("SKILL.md");
                    if fs::copy(&extracted_skill, &dest_md).is_ok() {
                        synced_skill_path = Some(dest_md.to_string_lossy().to_string());
                    }
                }
                if synced_skill_path.is_none() {
                    synced_skill_path = sync_skill_from_harness(paths, &target_harness, &canon_name);
                }
            }
            let _ = fs::remove_dir_all(&extract_base);
        } else {
            let pkg_tokens: Vec<&str> = install_cmd
                .strip_prefix("pip install ")
                .unwrap_or(install_cmd)
                .split_whitespace()
                .collect();
            let mut pip_args = vec!["-m", "pip", "install"];
            if action == "update" {
                pip_args.push("--upgrade");
            }
            pip_args.extend(pkg_tokens);
            let (pc, pout, perr) = run_cmd_capture(paths, &py, &pip_args, None);
            if pc != 0 {
                return Err(format!("pip install failed:\n{}\n{}", pout, perr));
            }
        }
    } else if let Some(npm_pkg) = c.get_str("npm_package") {
        let npm = paths
            .which("npm")
            .ok_or_else(|| "npm not found. Install Node.js via: pkg install nodejs".to_string())?;
        let (nc, nout, nerr) = run_cmd_capture(paths, &npm, &["install", "-g", npm_pkg], None);
        if nc != 0 {
            return Err(format!("npm install -g {} failed:\n{}\n{}", npm_pkg, nout, nerr));
        }
    } else {
        return Err(format!(
            "Unsupported install strategy for '{}'. Install command: {}",
            canon_name, install_cmd
        ));
    }

    let fixed = paths.run_fix_paths();
    let resolved_bin = paths
        .which(entry_point)
        .map(|p| p.to_string_lossy().to_string());

    let mut rec = JsonVal::obj();
    rec.insert("version", s(c.get_str("version").unwrap_or("latest")));
    rec.insert("entry_point", s(entry_point));
    rec.insert("source", s(src_type));
    rec.insert("installed_at", n_i64(now_secs() as i64));
    installed.insert(canon_name.clone(), rec);
    save_installed_map(paths, &installed);

    let mut out = JsonVal::obj();
    out.insert("ok", JsonVal::Bool(true));
    out.insert("action", s(action));
    out.insert("name", s(&canon_name));
    out.insert("entry_point", s(entry_point));
    out.insert("resolved_binary", resolved_bin.map(|v| s(&v)).unwrap_or(JsonVal::Null));
    out.insert("agy_fix_paths_applied", JsonVal::Bool(fixed));
    out.insert("synced_skill_md", synced_skill_path.map(|v| s(&v)).unwrap_or(JsonVal::Null));
    out.insert("android_tier", s(tier));
    out.insert("android_note", s(&note));
    Ok(out)
}

// ---------------------------------------------------------------------------
// Tool 5: cli_anything_matrix
// ---------------------------------------------------------------------------

fn tool_matrix(paths: &EnvPaths, args: &JsonVal) -> Result<JsonVal, String> {
    let action = args.get_str("action").unwrap_or("list").trim();
    let name = args.get_str("name").unwrap_or("").trim();
    let query = args.get_str("query").unwrap_or("").trim().to_lowercase();
    let force_refresh = args.get_bool("force_refresh").unwrap_or(false);

    let mat_reg = fetch_cached_url(paths, MATRIX_REGISTRY_URL, "matrix_registry_cache.json", force_refresh)?;
    let matrices = mat_reg
        .get("matrices")
        .and_then(|v| v.as_arr())
        .cloned()
        .unwrap_or_default();

    if action == "list" {
        let mut summaries = Vec::new();
        for m in &matrices {
            let mut item = JsonVal::obj();
            item.insert("name", s(m.get_str("name").unwrap_or("")));
            item.insert("display_name", s(m.get_str("display_name").unwrap_or("")));
            item.insert("category", s(m.get_str("category").unwrap_or("")));
            item.insert("description", s(m.get_str("description").unwrap_or("")));
            let caps_n = m.get("capabilities").and_then(|v| v.as_arr()).map(|a| a.len()).unwrap_or(0);
            let recs_n = m.get("recipes").and_then(|v| v.as_arr()).map(|a| a.len()).unwrap_or(0);
            item.insert("capabilities_count", n_i64(caps_n as i64));
            item.insert("recipes_count", n_i64(recs_n as i64));
            summaries.push(item);
        }
        let mut out = JsonVal::obj();
        out.insert("ok", JsonVal::Bool(true));
        out.insert("count", n_i64(summaries.len() as i64));
        out.insert("matrices", JsonVal::Arr(summaries));
        return Ok(out);
    }

    if action == "can" {
        if query.is_empty() {
            return Err("Provide 'query' (e.g. 'transcribe audio' or 'diagram') for action='can'.".into());
        }
        let mut hits = Vec::new();
        for m in &matrices {
            let mname = m.get_str("name").unwrap_or("");
            if let Some(caps) = m.get("capabilities").and_then(|v| v.as_arr()) {
                for cap in caps {
                    let cid = cap.get_str("id").unwrap_or("");
                    let cname = cap.get_str("name").unwrap_or("");
                    let cdesc = cap.get_str("description").unwrap_or("");
                    let hay = format!("{} {} {}", cid, cname, cdesc).to_lowercase();
                    if query.split_whitespace().all(|t| hay.contains(t)) {
                        let mut h = JsonVal::obj();
                        h.insert("matrix", s(mname));
                        h.insert("capability_id", s(cid));
                        h.insert("name", s(cname));
                        h.insert("description", s(cdesc));
                        hits.push(h);
                    }
                }
            }
        }
        let mut out = JsonVal::obj();
        out.insert("ok", JsonVal::Bool(true));
        out.insert("matches", JsonVal::Arr(hits));
        return Ok(out);
    }

    let m = matrices
        .iter()
        .find(|x| x.get_str("name").unwrap_or("").eq_ignore_ascii_case(name))
        .ok_or_else(|| format!("Matrix '{}' not found. Call action='list' first.", name))?;

    if action == "render_skill" {
        let canon = m.get_str("name").unwrap_or(name);
        let src_skill = paths
            .toolkit_dir
            .join("cli-hub/cli_hub/_matrix_data")
            .join(canon)
            .join("SKILL.md");
        if !src_skill.is_file() {
            return Err(format!("Bundled matrix SKILL.md not found for '{}'", canon));
        }
        let dest_dir = paths.skills_dir.join(format!("cli-matrix-{}", canon));
        let _ = fs::create_dir_all(&dest_dir);
        let dest_md = dest_dir.join("SKILL.md");
        fs::copy(&src_skill, &dest_md).map_err(|e| e.to_string())?;
        let mut out = JsonVal::obj();
        out.insert("ok", JsonVal::Bool(true));
        out.insert("matrix", s(canon));
        out.insert("synced_skill_path", s(&dest_md.to_string_lossy()));
        return Ok(out);
    }

    // info or preflight
    if action == "preflight" {
        if let Some(cli_hub_bin) = paths.which("cli-hub") {
            let (code, stdout, _) = run_cmd_capture(
                paths,
                &cli_hub_bin,
                &["matrix", "preflight", name, "--json"],
                None,
            );
            if (code == 0 || code == 3) && !stdout.trim().is_empty() {
                if let Ok(parsed) = parse_json(&stdout) {
                    let mut out = JsonVal::obj();
                    out.insert("ok", JsonVal::Bool(true));
                    out.insert("exit_code", n_i64(code as i64));
                    out.insert("preflight", parsed);
                    return Ok(out);
                }
            }
        }
    }

    // Native Rust summary/preflight fallback
    let mut cap_list = Vec::new();
    if let Some(caps) = m.get("capabilities").and_then(|v| v.as_arr()) {
        for cap in caps {
            let mut cobj = JsonVal::obj();
            cobj.insert("id", s(cap.get_str("id").unwrap_or("")));
            cobj.insert("name", s(cap.get_str("name").unwrap_or("")));
            cobj.insert("description", s(cap.get_str("description").unwrap_or("")));
            cap_list.push(cobj);
        }
    }
    let mut out = JsonVal::obj();
    out.insert("ok", JsonVal::Bool(true));
    out.insert("name", s(m.get_str("name").unwrap_or("")));
    out.insert("display_name", s(m.get_str("display_name").unwrap_or("")));
    out.insert("description", s(m.get_str("description").unwrap_or("")));
    out.insert("capabilities", JsonVal::Arr(cap_list));
    Ok(out)
}

// ---------------------------------------------------------------------------
// Tool 6: cli_anything_analyze_target (Phase 0 & Phase 1 of HARNESS.md)
// ---------------------------------------------------------------------------

fn scan_repo_tree(
    dir: &Path,
    depth: usize,
    lang_counts: &mut BTreeMap<String, i64>,
    signals: &mut Vec<String>,
    total_files: &mut usize,
) {
    if depth > 6 || *total_files > 4000 {
        return;
    }
    let skip_dirs = [
        ".git",
        "node_modules",
        "target",
        "__pycache__",
        ".venv",
        "venv",
        "dist",
        "build",
        ".next",
        ".gradle",
    ];
    let entries = match fs::read_dir(dir) {
        Ok(e) => e,
        Err(_) => return,
    };
    for ent in entries.flatten() {
        let p = ent.path();
        let fname = ent.file_name().to_string_lossy().to_string();
        if p.is_dir() {
            if !skip_dirs.contains(&fname.as_str()) {
                scan_repo_tree(&p, depth + 1, lang_counts, signals, total_files);
            }
            continue;
        }
        *total_files += 1;
        let ext = p
            .extension()
            .and_then(|x| x.to_str())
            .unwrap_or("")
            .to_ascii_lowercase();
        let lang = match ext.as_str() {
            "py" => "python",
            "rs" => "rust",
            "ts" | "tsx" => "typescript",
            "js" | "mjs" | "cjs" => "javascript",
            "go" => "go",
            "c" | "cpp" | "cc" | "h" | "hpp" => "c_cpp",
            "cs" => "csharp",
            "kt" | "java" => "jvm",
            "gd" => "gdscript",
            "sh" => "shell",
            _ => "",
        };
        if !lang.is_empty() {
            *lang_counts.entry(lang.to_string()).or_insert(0) += 1;
        }

        for marker in [
            "pyproject.toml",
            "setup.py",
            "Cargo.toml",
            "package.json",
            "go.mod",
            "CMakeLists.txt",
            "openapi.json",
            "docker-compose.yml",
        ] {
            if fname == marker && !signals.contains(&fname) {
                signals.push(fname.clone());
            }
        }

        // Sample small source files for framework fingerprints
        if matches!(ext.as_str(), "py" | "rs" | "ts" | "js" | "toml" | "json") && signals.len() < 25 {
            if let Ok(meta) = p.metadata() {
                if meta.len() < 120_000 {
                    if let Ok(txt) = fs::read_to_string(&p) {
                        for (needle, tag) in [
                            ("import click", "cli:click"),
                            ("import typer", "cli:typer"),
                            ("import argparse", "cli:argparse"),
                            ("FastAPI(", "api:fastapi"),
                            ("Flask(__name__", "api:flask"),
                            ("PyQt", "gui:pyqt"),
                            ("tkinter", "gui:tkinter"),
                            ("electron", "gui:electron"),
                            ("clap::", "cli:clap"),
                            ("sqlite3", "state:sqlite"),
                            ("undo", "pattern:undo_redo"),
                        ] {
                            let tag_s = tag.to_string();
                            if txt.contains(needle) && !signals.contains(&tag_s) {
                                signals.push(tag_s);
                            }
                        }
                    }
                }
            }
        }
    }
}

fn tool_analyze_target(paths: &EnvPaths, args: &JsonVal) -> Result<JsonVal, String> {
    let target = args
        .get_str("target")
        .unwrap_or("")
        .trim();
    if target.is_empty() {
        return Err("Provide 'target' (local source directory or GitHub repository URL).".into());
    }

    let local_dir = if target.starts_with("http://")
        || target.starts_with("https://")
        || target.starts_with("github.com/")
    {
        let url = if target.starts_with("github.com/") {
            format!("https://{}", target)
        } else {
            target.to_string()
        };
        let repo_tail = url
            .trim_end_matches('/')
            .trim_end_matches(".git")
            .rsplit('/')
            .next()
            .unwrap_or("repo");
        let (slug, _, _) = sanitize_slug(repo_tail);
        let dest = paths.tmp_dir.join("cli-anything-targets").join(&slug);
        if !dest.join(".git").is_dir() {
            let _ = fs::remove_dir_all(&dest);
            if let Some(parent) = dest.parent() {
                let _ = fs::create_dir_all(parent);
            }
            let git = paths
                .which("git")
                .ok_or_else(|| "git not found on PATH".to_string())?;
            let (gc, _, gerr) = run_cmd_capture(
                paths,
                &git,
                &["clone", "--depth", "1", &url, &dest.to_string_lossy()],
                None,
            );
            if gc != 0 {
                return Err(format!("Failed cloning {}: {}", url, gerr));
            }
        }
        dest
    } else {
        let p = PathBuf::from(target);
        if !p.is_dir() {
            return Err(format!("Target directory does not exist: {}", p.display()));
        }
        p
    };

    let raw_name = local_dir
        .file_name()
        .map(|s| s.to_string_lossy().to_string())
        .unwrap_or_else(|| "app".into());
    let (cli_slug, pkg_mod, display_name) = sanitize_slug(&raw_name);

    let mut lang_counts = BTreeMap::new();
    let mut signals = Vec::new();
    let mut total_files = 0usize;
    scan_repo_tree(&local_dir, 0, &mut lang_counts, &mut signals, &mut total_files);

    let mut langs_obj = JsonVal::obj();
    let mut primary_lang = "unknown".to_string();
    let mut max_cnt = 0i64;
    for (k, v) in &lang_counts {
        langs_obj.insert(k, n_i64(*v));
        if *v > max_cnt {
            max_cnt = *v;
            primary_lang = k.clone();
        }
    }

    let mut out = JsonVal::obj();
    out.insert("ok", JsonVal::Bool(true));
    out.insert("local_path", s(&local_dir.to_string_lossy()));
    out.insert("recommended_cli_slug", s(&cli_slug));
    out.insert("recommended_pkg_mod", s(&pkg_mod));
    out.insert("display_name", s(&display_name));
    out.insert("total_files_scanned", n_i64(total_files as i64));
    out.insert("primary_language", s(&primary_lang));
    out.insert("languages", langs_obj);
    out.insert(
        "detected_signals",
        JsonVal::Arr(signals.into_iter().map(|x| s(&x)).collect()),
    );
    out.insert("harness_sop_path", s(&paths.toolkit_dir.join("HARNESS.md").to_string_lossy()));
    out.insert(
        "next_step",
        s("Call cli_anything_scaffold to create the PEP 420 agent-harness skeleton, customize domain modules for the target's core operations, then run cli_anything_validate & cli_anything_skill_sync."),
    );
    Ok(out)
}

// ---------------------------------------------------------------------------
// Tool 7: cli_anything_scaffold (Phase 2 & Phase 3 PEP 420 Generator)
// ---------------------------------------------------------------------------

fn default_harnesses_root(paths: &EnvPaths) -> PathBuf {
    let docs = PathBuf::from("/storage/emulated/0/Documents");
    if docs.is_dir() {
        let target = docs.join("CLI-Anything");
        if fs::create_dir_all(&target).is_ok() {
            return target;
        }
    }
    let fallback = paths.home.join(".gemini/antigravity-app/scratch/cli-anything");
    let _ = fs::create_dir_all(&fallback);
    fallback
}

fn tool_scaffold(paths: &EnvPaths, args: &JsonVal) -> Result<JsonVal, String> {
    let raw_name = args.get_str("software_name").unwrap_or("").trim();
    if raw_name.is_empty() {
        return Err("Provide 'software_name' (e.g. 'mermaid-flow' or 'my_api').".into());
    }
    let (cli_slug, pkg_mod, auto_display) = sanitize_slug(raw_name);
    let display_name = args
        .get_str("display_name")
        .filter(|v| !v.trim().is_empty())
        .map(|v| v.trim().to_string())
        .unwrap_or(auto_display);
    let description = args
        .get_str("description")
        .filter(|v| !v.trim().is_empty())
        .map(|v| v.trim().to_string())
        .unwrap_or_else(|| {
            format!(
                "Agent-native stateful CLI harness for {} with --json output, session undo/redo, and REPL.",
                display_name
            )
        });
    let (_, domain_clean, _) = sanitize_slug(args.get_str("domain_group").unwrap_or("item"));
    let domain_group = domain_clean.replace('-', "_");
    let backend_bin = args.get_str("backend_bin").unwrap_or("").trim().to_string();
    let install_editable = args.get_bool("install_editable").unwrap_or(true);
    let sync_skill = args.get_bool("sync_skill").unwrap_or(true);
    let overwrite = args.get_bool("overwrite").unwrap_or(false);

    let root_base = args
        .get_str("output_dir")
        .filter(|v| !v.trim().is_empty())
        .map(PathBuf::from)
        .unwrap_or_else(|| default_harnesses_root(paths));

    let app_root = root_base.join(&cli_slug);
    let harness_dir = app_root.join("agent-harness");
    let ns_dir = harness_dir.join("cli_anything");
    let pkg_dir = ns_dir.join(&pkg_mod);

    if pkg_dir.exists() && !overwrite {
        return Err(format!(
            "Harness already exists at {} (pass overwrite=true to regenerate).",
            harness_dir.display()
        ));
    }

    fs::create_dir_all(pkg_dir.join("core")).map_err(|e| e.to_string())?;
    fs::create_dir_all(pkg_dir.join("utils")).map_err(|e| e.to_string())?;
    fs::create_dir_all(pkg_dir.join("tests")).map_err(|e| e.to_string())?;
    fs::create_dir_all(pkg_dir.join("skills")).map_err(|e| e.to_string())?;

    // Strictly guarantee PEP 420 rule: NO __init__.py in cli_anything/
    let forbidden_init = ns_dir.join("__init__.py");
    if forbidden_init.exists() {
        let _ = fs::remove_file(&forbidden_init);
    }

    let spec = HarnessSpec {
        cli_slug: cli_slug.clone(),
        pkg_mod: pkg_mod.clone(),
        display_name: display_name.clone(),
        description: description.clone(),
        backend_bin,
        domain_group,
    };

    let sop_upper = format!("{}.md", pkg_mod.to_ascii_uppercase());
    let files_to_write: Vec<(PathBuf, String)> = vec![
        (harness_dir.join(&sop_upper), templates::render_sop_md(&spec)),
        (harness_dir.join("setup.py"), templates::render_setup_py(&spec)),
        (pkg_dir.join("__init__.py"), templates::render_init_py(&spec)),
        (pkg_dir.join("__main__.py"), templates::render_main_py(&spec)),
        (pkg_dir.join("README.md"), templates::render_readme_md(&spec)),
        (
            pkg_dir.join(format!("{}_cli.py", pkg_mod)),
            templates::render_cli_py(&spec),
        ),
        (pkg_dir.join("core/__init__.py"), templates::render_core_init()),
        (
            pkg_dir.join("core/project.py"),
            templates::render_project_py(&spec),
        ),
        (
            pkg_dir.join("core/session.py"),
            templates::render_session_py(&spec),
        ),
        (
            pkg_dir.join("core/export.py"),
            templates::render_export_py(&spec),
        ),
        (pkg_dir.join("utils/__init__.py"), templates::render_utils_init()),
        (
            pkg_dir.join(format!("utils/{}_backend.py", pkg_mod)),
            templates::render_backend_py(&spec),
        ),
        (pkg_dir.join("tests/TEST.md"), templates::render_test_md(&spec)),
        (
            pkg_dir.join("tests/test_core.py"),
            templates::render_test_core_py(&spec),
        ),
        (
            pkg_dir.join("tests/test_full_e2e.py"),
            templates::render_test_e2e_py(&spec),
        ),
    ];

    for (fpath, content) in &files_to_write {
        fs::write(fpath, content).map_err(|e| format!("Write failed {}: {}", fpath.display(), e))?;
    }

    // Copy official ReplSkin
    let repl_src = paths.toolkit_dir.join("repl_skin.py");
    if repl_src.is_file() {
        fs::copy(&repl_src, pkg_dir.join("utils/repl_skin.py")).map_err(|e| e.to_string())?;
    }

    let mut installed_bin: Option<String> = None;
    if install_editable {
        if let Some(py) = paths.which("python3") {
            ensure_python_click(paths, &py)?;
            let hd_str = harness_dir.to_string_lossy().to_string();
            let (pc, _, _) = run_cmd_capture(
                paths,
                &py,
                &["-m", "pip", "install", "--no-build-isolation", "-e", &hd_str],
                None,
            );
            if pc == 0 {
                paths.run_fix_paths();
                let ep = format!("cli-anything-{}", cli_slug);
                installed_bin = paths.which(&ep).map(|p| p.to_string_lossy().to_string());
                let mut inst_map = load_installed_map(paths);
                let mut rec = JsonVal::obj();
                rec.insert("version", s("0.1.0"));
                rec.insert("entry_point", s(&ep));
                rec.insert("source", s("local-scaffold"));
                rec.insert("harness_path", s(&hd_str));
                inst_map.insert(cli_slug.clone(), rec);
                save_installed_map(paths, &inst_map);
            }
        }
    }

    let synced_skill = if sync_skill {
        sync_skill_from_harness(paths, &harness_dir, &cli_slug)
    } else {
        None
    };

    let mut out = JsonVal::obj();
    out.insert("ok", JsonVal::Bool(true));
    out.insert("cli_slug", s(&cli_slug));
    out.insert("pkg_mod", s(&pkg_mod));
    out.insert("entry_point", s(&format!("cli-anything-{}", cli_slug)));
    out.insert("harness_path", s(&harness_dir.to_string_lossy()));
    out.insert("installed_binary", installed_bin.map(|v| s(&v)).unwrap_or(JsonVal::Null));
    out.insert("synced_skill_md", synced_skill.map(|v| s(&v)).unwrap_or(JsonVal::Null));
    Ok(out)
}

// ---------------------------------------------------------------------------
// Tool 8: cli_anything_validate (52-Check Official HARNESS.md Validator)
// ---------------------------------------------------------------------------

struct CatTracker {
    name: &'static str,
    passed: usize,
    total: usize,
    failures: Vec<String>,
}

impl CatTracker {
    fn new(name: &'static str) -> Self {
        Self {
            name,
            passed: 0,
            total: 0,
            failures: Vec::new(),
        }
    }

    fn check(&mut self, cond: bool, fail_msg: &str) {
        self.total += 1;
        if cond {
            self.passed += 1;
        } else {
            self.failures.push(fail_msg.to_string());
        }
    }

    fn to_json(&self) -> JsonVal {
        let mut o = JsonVal::obj();
        o.insert("category", s(self.name));
        o.insert("passed", n_i64(self.passed as i64));
        o.insert("total", n_i64(self.total as i64));
        o.insert(
            "failures",
            JsonVal::Arr(self.failures.iter().map(|f| s(f)).collect()),
        );
        o
    }
}

fn collect_py_files(dir: &Path, out: &mut Vec<PathBuf>) {
    if let Ok(rd) = fs::read_dir(dir) {
        for e in rd.flatten() {
            let p = e.path();
            let fname = e.file_name().to_string_lossy().to_string();
            if p.is_dir() {
                if fname != "__pycache__" && fname != ".pytest_cache" && !fname.ends_with(".egg-info") {
                    collect_py_files(&p, out);
                }
            } else if p.extension().and_then(|x| x.to_str()) == Some("py") {
                out.push(p);
            }
        }
    }
}

fn resolve_harness_dir(raw: &str) -> Result<PathBuf, String> {
    let p = PathBuf::from(raw.trim());
    if p.join("cli_anything").is_dir() {
        return Ok(p);
    }
    if p.join("agent-harness/cli_anything").is_dir() {
        return Ok(p.join("agent-harness"));
    }
    Err(format!(
        "Could not locate agent-harness/cli_anything inside '{}'",
        p.display()
    ))
}

fn tool_validate(paths: &EnvPaths, args: &JsonVal) -> Result<JsonVal, String> {
    let raw_path = args.get_str("harness_path").unwrap_or("").trim();
    if raw_path.is_empty() {
        return Err("Provide 'harness_path' pointing to agent-harness/ or its parent folder.".into());
    }
    let run_pytest = args.get_bool("run_pytest").unwrap_or(false);
    let harness_dir = resolve_harness_dir(raw_path)?;
    let ns_dir = harness_dir.join("cli_anything");

    // Detect <software> package dir inside cli_anything/
    let mut pkg_mod = String::new();
    let mut pkg_dir = PathBuf::new();
    if let Ok(rd) = fs::read_dir(&ns_dir) {
        for e in rd.flatten() {
            if e.path().is_dir() && e.file_name().to_string_lossy() != "__pycache__" {
                pkg_mod = e.file_name().to_string_lossy().to_string();
                pkg_dir = e.path();
                break;
            }
        }
    }
    if pkg_mod.is_empty() {
        return Err(format!("No subpackage directory found inside {}", ns_dir.display()));
    }
    let cli_slug = pkg_mod.replace('_', "-");
    let setup_txt = fs::read_to_string(harness_dir.join("setup.py")).unwrap_or_default();

    // 1. Directory Structure (5 checks)
    let mut c1 = CatTracker::new("1. Directory Structure");
    c1.check(pkg_dir.is_dir(), "cli_anything/<software>/ directory missing");
    c1.check(
        !ns_dir.join("__init__.py").exists(),
        "cli_anything/__init__.py MUST NOT exist (PEP 420 namespace package)",
    );
    c1.check(
        pkg_dir.join("__init__.py").is_file(),
        "cli_anything/<software>/__init__.py missing",
    );
    c1.check(
        pkg_dir.join("core").is_dir() && pkg_dir.join("utils").is_dir() && pkg_dir.join("tests").is_dir(),
        "core/, utils/, and tests/ subdirectories must all exist",
    );
    c1.check(
        harness_dir.join("setup.py").is_file() && setup_txt.contains("find_namespace_packages"),
        "setup.py missing or does not use find_namespace_packages",
    );

    // 2. Required Files (9 checks)
    let mut c2 = CatTracker::new("2. Required Files");
    let cli_py_path = pkg_dir.join(format!("{}_cli.py", pkg_mod));
    let proj_py_path = pkg_dir.join("core/project.py");
    let sess_py_path = pkg_dir.join("core/session.py");
    let exp_py_path = pkg_dir.join("core/export.py");
    let test_md_path = pkg_dir.join("tests/TEST.md");
    let test_core_path = pkg_dir.join("tests/test_core.py");
    let test_e2e_path = pkg_dir.join("tests/test_full_e2e.py");
    let readme_path = pkg_dir.join("README.md");

    let mut sop_md_found = None;
    if let Ok(rd) = fs::read_dir(&harness_dir) {
        for e in rd.flatten() {
            let fnm = e.file_name().to_string_lossy().to_string();
            if fnm.ends_with(".md") && fnm != "HARNESS.md" && fnm != "README.md" {
                sop_md_found = Some(e.path());
                break;
            }
        }
    }

    c2.check(readme_path.is_file(), "README.md missing in subpackage");
    c2.check(cli_py_path.is_file(), "<software>_cli.py missing");
    c2.check(proj_py_path.is_file(), "core/project.py missing");
    c2.check(sess_py_path.is_file(), "core/session.py missing");
    c2.check(exp_py_path.is_file(), "core/export.py missing");
    c2.check(test_md_path.is_file(), "tests/TEST.md missing");
    c2.check(test_core_path.is_file(), "tests/test_core.py missing");
    c2.check(test_e2e_path.is_file(), "tests/test_full_e2e.py missing");
    c2.check(sop_md_found.is_some(), "<SOFTWARE>.md SOP file missing in agent-harness/");

    // 3. CLI Implementation Standards (7 checks)
    let cli_txt = fs::read_to_string(&cli_py_path).unwrap_or_default();
    let mut c3 = CatTracker::new("3. CLI Implementation Standards");
    c3.check(cli_txt.contains("import click"), "CLI does not import click");
    c3.check(cli_txt.contains(".group("), "CLI does not define Click command groups");
    c3.check(cli_txt.contains("--json"), "CLI missing --json flag");
    c3.check(cli_txt.contains("--project"), "CLI missing --project flag");
    c3.check(cli_txt.contains("handle_error"), "CLI missing handle_error decorator");
    c3.check(cli_txt.contains("def repl"), "CLI missing interactive repl command");
    c3.check(
        cli_txt.contains("Session") && cli_txt.contains("--dry-run"),
        "CLI missing stateful Session + --dry-run mutation handling",
    );

    // 4. Core Module Standards (5 checks)
    let proj_txt = fs::read_to_string(&proj_py_path).unwrap_or_default();
    let sess_txt = fs::read_to_string(&sess_py_path).unwrap_or_default();
    let exp_txt = fs::read_to_string(&exp_py_path).unwrap_or_default();
    let mut c4 = CatTracker::new("4. Core Module Standards");
    c4.check(
        proj_txt.contains("def create")
            && proj_txt.contains("def open")
            && proj_txt.contains("def save")
            && proj_txt.contains("def info")
            && proj_txt.contains("def list_profiles"),
        "project.py missing one of create/open/save/info/list_profiles",
    );
    c4.check(
        sess_txt.contains("class Session")
            && sess_txt.contains("def undo")
            && sess_txt.contains("def redo")
            && sess_txt.contains("def snapshot"),
        "session.py missing Session class or undo/redo/snapshot",
    );
    c4.check(
        exp_txt.contains("def render") && exp_txt.contains("EXPORT_PRESETS"),
        "export.py missing render() or EXPORT_PRESETS",
    );
    c4.check(
        proj_txt.contains("\"\"\"") && sess_txt.contains("\"\"\"") && exp_txt.contains("\"\"\""),
        "Core modules missing docstrings",
    );
    c4.check(
        proj_txt.contains("->") && sess_txt.contains("->") && exp_txt.contains("->"),
        "Core functions missing Python type hints",
    );

    // 5. Test Standards (10 checks)
    let tmd_txt = fs::read_to_string(&test_md_path).unwrap_or_default();
    let tcore_txt = fs::read_to_string(&test_core_path).unwrap_or_default();
    let te2e_txt = fs::read_to_string(&test_e2e_path).unwrap_or_default();
    let mut c5 = CatTracker::new("5. Test Standards");
    c5.check(
        tmd_txt.contains("Part 1") && tmd_txt.contains("Part 2"),
        "TEST.md missing Part 1 (Plan) or Part 2 (Results)",
    );
    c5.check(tcore_txt.contains("def test_"), "test_core.py has no unit test functions");
    c5.check(te2e_txt.contains("export"), "test_full_e2e.py does not test export pipeline");
    c5.check(te2e_txt.contains("workflow"), "test_full_e2e.py missing workflow scenario test");
    c5.check(
        te2e_txt.contains("class TestCLISubprocess"),
        "test_full_e2e.py missing TestCLISubprocess class",
    );
    c5.check(
        te2e_txt.contains("_resolve_cli("),
        "TestCLISubprocess missing _resolve_cli() helper",
    );
    c5.check(
        te2e_txt.contains("CLI_ANYTHING_FORCE_INSTALLED"),
        "_resolve_cli missing CLI_ANYTHING_FORCE_INSTALLED support",
    );
    c5.check(
        te2e_txt.contains("[_resolve_cli]"),
        "_resolve_cli does not print resolved backend trace",
    );
    c5.check(
        !te2e_txt.contains("cwd="),
        "Subprocess _run must not hardcode cwd= (CLI must work from any directory)",
    );
    c5.check(
        te2e_txt.contains("size") || te2e_txt.contains("st_size"),
        "E2E tests must verify output file non-zero byte size",
    );

    // 6. Documentation Standards (4 checks)
    let rmd_txt = fs::read_to_string(&readme_path).unwrap_or_default();
    let sop_txt = sop_md_found
        .as_ref()
        .and_then(|p| fs::read_to_string(p).ok())
        .unwrap_or_default();
    let mut c6 = CatTracker::new("6. Documentation Standards");
    c6.check(
        rmd_txt.contains("## Installation") && rmd_txt.contains("## Usage"),
        "README.md missing Installation or Usage sections",
    );
    c6.check(
        sop_txt.contains("Architecture") && sop_txt.contains("Command"),
        "<SOFTWARE>.md missing Architecture or Command Map section",
    );
    c6.check(
        !harness_dir.join("HARNESS.md").exists(),
        "Duplicate HARNESS.md found inside agent-harness/ (reference plugin toolkit instead)",
    );
    c6.check(
        rmd_txt.contains("```"),
        "README.md missing fenced command examples",
    );

    // 7. PyPI Packaging Standards (7 checks)
    let mut c7 = CatTracker::new("7. PyPI Packaging Standards");
    c7.check(
        setup_txt.contains("find_namespace_packages") && setup_txt.contains("cli_anything.*"),
        "setup.py must call find_namespace_packages(include=['cli_anything.*'])",
    );
    c7.check(
        setup_txt.contains(&format!("cli-anything-{}", cli_slug)),
        "setup.py package name does not follow cli-anything-<software>",
    );
    c7.check(
        setup_txt.contains("console_scripts") && setup_txt.contains(":main"),
        "setup.py missing console_scripts :main entry point",
    );
    c7.check(
        !ns_dir.join("__init__.py").exists(),
        "PEP 420 violation: cli_anything/__init__.py exists",
    );
    c7.check(
        cli_txt.contains(&format!("cli_anything.{}", pkg_mod)),
        "CLI imports do not use cli_anything.<software> namespace prefix",
    );
    c7.check(
        setup_txt.contains("install_requires"),
        "setup.py missing install_requires",
    );
    c7.check(
        setup_txt.contains("python_requires") && setup_txt.contains("3.10"),
        "setup.py missing python_requires >=3.10",
    );

    // 8. Code Quality (5 checks)
    let mut py_files = Vec::new();
    collect_py_files(&pkg_dir, &mut py_files);
    let mut syntax_ok = true;
    if let Some(py) = paths.which("python3") {
        let mut args_vec: Vec<String> = vec!["-m".into(), "py_compile".into()];
        for pf in &py_files {
            args_vec.push(pf.to_string_lossy().to_string());
        }
        let arg_refs: Vec<&str> = args_vec.iter().map(|s| s.as_str()).collect();
        let (sc, _, _) = run_cmd_capture(paths, &py, &arg_refs, None);
        syntax_ok = sc == 0;
    }
    let mut has_bare_except = false;
    let mut has_hardcoded_desktop = false;
    for pf in &py_files {
        if let Ok(t) = fs::read_to_string(pf) {
            for line in t.lines() {
                let tr = line.trim();
                if tr == "except:" || tr.starts_with("except: ") {
                    has_bare_except = true;
                }
                if tr.contains("/root/cli-anything") || tr.contains("/home/ubuntu/") {
                    has_hardcoded_desktop = true;
                }
            }
        }
    }
    let mut c8 = CatTracker::new("8. Code Quality");
    c8.check(syntax_ok, "Python syntax error detected by py_compile");
    c8.check(!py_files.is_empty(), "No Python files found in package");
    c8.check(
        pkg_mod.chars().all(|c| c.is_ascii_lowercase() || c.is_ascii_digit() || c == '_'),
        "Package module name is not PEP 8 snake_case",
    );
    c8.check(!has_hardcoded_desktop, "Hardcoded /root/ or /home/ubuntu/ path detected");
    c8.check(!has_bare_except, "Bare 'except:' clause found (use 'except Exception:')");

    let cats = [c1, c2, c3, c4, c5, c6, c7, c8];
    let total_passed: usize = cats.iter().map(|c| c.passed).sum();
    let total_checks: usize = cats.iter().map(|c| c.total).sum();

    let mut pytest_result = JsonVal::Null;
    if run_pytest {
        if let Some(py) = paths.which("python3") {
            let mut cmd = Command::new(&py);
            paths.apply_bionic_env(&mut cmd);
            cmd.env("PYTHONPATH", &harness_dir);
            cmd.args(["-m", "pytest", "-v", "--tb=short", &pkg_dir.join("tests").to_string_lossy()]);
            if let Ok(po) = cmd.output() {
                let code = po.status.code().unwrap_or(-1);
                let stdout = String::from_utf8_lossy(&po.stdout).to_string();
                let stderr = String::from_utf8_lossy(&po.stderr).to_string();
                if code == 0 && test_md_path.is_file() {
                    let existing = fs::read_to_string(&test_md_path).unwrap_or_default();
                    let base = existing.split("## Part 2:").next().unwrap_or(&existing).trim_end();
                    let updated = format!(
                        "{}\n\n## Part 2: Execution Results\n\n```text\n{}\n```\n",
                        base,
                        stdout.trim()
                    );
                    let _ = fs::write(&test_md_path, updated);
                }
                let mut pr = JsonVal::obj();
                pr.insert("passed", JsonVal::Bool(code == 0));
                pr.insert("exit_code", n_i64(code as i64));
                pr.insert("stdout", s(stdout.trim()));
                if !stderr.trim().is_empty() {
                    pr.insert("stderr", s(stderr.trim()));
                }
                pytest_result = pr;
            }
        }
    }

    let mut out = JsonVal::obj();
    out.insert("ok", JsonVal::Bool(total_passed == total_checks));
    out.insert("software", s(&cli_slug));
    out.insert("harness_path", s(&harness_dir.to_string_lossy()));
    out.insert("passed_checks", n_i64(total_passed as i64));
    out.insert("total_checks", n_i64(total_checks as i64));
    out.insert(
        "overall",
        s(if total_passed == total_checks {
            "PASS"
        } else {
            "NEEDS_FIXES"
        }),
    );
    out.insert(
        "categories",
        JsonVal::Arr(cats.iter().map(|c| c.to_json()).collect()),
    );
    out.insert("pytest", pytest_result);
    Ok(out)
}

// ---------------------------------------------------------------------------
// Tool 9: cli_anything_skill_sync (Phase 6.5 & Phase 7)
// ---------------------------------------------------------------------------

fn tool_skill_sync(paths: &EnvPaths, args: &JsonVal) -> Result<JsonVal, String> {
    let action = args.get_str("action").unwrap_or("generate_and_sync").trim();

    if action == "list" {
        let mut arr = Vec::new();
        if let Ok(rd) = fs::read_dir(&paths.skills_dir) {
            for e in rd.flatten() {
                let nm = e.file_name().to_string_lossy().to_string();
                let smd = e.path().join("SKILL.md");
                if (nm.starts_with("cli-anything-") || nm.starts_with("cli-matrix-")) && smd.is_file() {
                    let mut item = JsonVal::obj();
                    item.insert("name", s(&nm));
                    item.insert("path", s(&smd.to_string_lossy()));
                    arr.push(item);
                }
            }
        }
        let mut out = JsonVal::obj();
        out.insert("ok", JsonVal::Bool(true));
        out.insert("count", n_i64(arr.len() as i64));
        out.insert("skills", JsonVal::Arr(arr));
        return Ok(out);
    }

    if action == "remove" {
        let skill_name = args.get_str("skill_name").unwrap_or("").trim();
        if skill_name.is_empty() {
            return Err("Provide 'skill_name' (e.g. 'cli-anything-demo') for action='remove'.".into());
        }
        let target = paths.skills_dir.join(skill_name);
        let existed = target.is_dir();
        if existed {
            let _ = fs::remove_dir_all(&target);
        }
        let mut out = JsonVal::obj();
        out.insert("ok", JsonVal::Bool(true));
        out.insert("removed", JsonVal::Bool(existed));
        out.insert("skill_name", s(skill_name));
        return Ok(out);
    }

    let raw_path = args.get_str("harness_path").unwrap_or("").trim();
    if raw_path.is_empty() {
        return Err("Provide 'harness_path' for action='generate_and_sync'.".into());
    }
    let install_editable = args.get_bool("install_editable").unwrap_or(true);
    let harness_dir = resolve_harness_dir(raw_path)?;

    let mut pkg_mod = String::new();
    if let Ok(rd) = fs::read_dir(harness_dir.join("cli_anything")) {
        for e in rd.flatten() {
            if e.path().is_dir() && e.file_name().to_string_lossy() != "__pycache__" {
                pkg_mod = e.file_name().to_string_lossy().to_string();
                break;
            }
        }
    }
    if pkg_mod.is_empty() {
        return Err("No cli_anything/<software> package found.".into());
    }
    let cli_slug = pkg_mod.replace('_', "-");

    let py = paths
        .which("python3")
        .ok_or_else(|| "python3 not found on PATH".to_string())?;
    let sg = paths.toolkit_dir.join("skill_generator.py");
    let dest_dir = paths.skills_dir.join(format!("cli-anything-{}", cli_slug));
    let _ = fs::create_dir_all(&dest_dir);
    let dest_md = dest_dir.join("SKILL.md");

    let (gc, gout, gerr) = run_cmd_capture(
        paths,
        &py,
        &[
            &sg.to_string_lossy(),
            &harness_dir.to_string_lossy(),
            "-o",
            &dest_md.to_string_lossy(),
        ],
        None,
    );
    if gc != 0 {
        return Err(format!("skill_generator.py failed:\n{}\n{}", gout, gerr));
    }

    let mut resolved_bin = None;
    if install_editable {
        ensure_python_click(paths, &py)?;
        let hd_str = harness_dir.to_string_lossy().to_string();
        let (ic, iout, ierr) = run_cmd_capture(
            paths,
            &py,
            &["-m", "pip", "install", "--no-build-isolation", "-e", &hd_str],
            None,
        );
        if ic != 0 {
            return Err(format!("Editable install failed:\n{}\n{}", iout, ierr));
        }
        paths.run_fix_paths();
        resolved_bin = paths
            .which(&format!("cli-anything-{}", cli_slug))
            .map(|p| p.to_string_lossy().to_string());
    }

    let mut out = JsonVal::obj();
    out.insert("ok", JsonVal::Bool(true));
    out.insert("skill_name", s(&format!("cli-anything-{}", cli_slug)));
    out.insert("synced_skill_path", s(&dest_md.to_string_lossy()));
    out.insert("installed_binary", resolved_bin.map(|v| s(&v)).unwrap_or(JsonVal::Null));
    Ok(out)
}

// ---------------------------------------------------------------------------
// Tool 10: cli_anything_exec
// ---------------------------------------------------------------------------

fn tool_exec(paths: &EnvPaths, args: &JsonVal) -> Result<JsonVal, String> {
    let cli_name = args.get_str("cli_name").unwrap_or("").trim();
    if cli_name.is_empty() {
        return Err("Provide 'cli_name' (e.g. 'mermaid' or 'cli-anything-mermaid').".into());
    }
    let json_mode = args.get_bool("json_mode").unwrap_or(true);
    let bin_name = if cli_name.starts_with("cli-anything-") || cli_name == "cli-hub" {
        cli_name.to_string()
    } else {
        format!("cli-anything-{}", cli_name)
    };

    let bin_path = paths.which(&bin_name).or_else(|| paths.which(cli_name)).ok_or_else(|| {
        format!(
            "Executable '{}' not found in $PREFIX/bin or PATH. Install it first via cli_anything_hub_install or cli_anything_scaffold.",
            bin_name
        )
    })?;

    let mut cmd_args: Vec<String> = Vec::new();
    if json_mode && bin_name.starts_with("cli-anything-") {
        cmd_args.push("--json".into());
    }
    if let Some(arr) = args.get("args").and_then(|v| v.as_arr()) {
        for item in arr {
            if let Some(st) = item.as_str() {
                if !(json_mode && st == "--json" && cmd_args.contains(&"--json".to_string())) {
                    cmd_args.push(st.to_string());
                }
            }
        }
    }

    let arg_refs: Vec<&str> = cmd_args.iter().map(|s| s.as_str()).collect();
    let cwd_opt = args.get_str("cwd").filter(|v| !v.is_empty()).map(Path::new);
    let (code, stdout, stderr) = run_cmd_capture(paths, &bin_path, &arg_refs, cwd_opt);

    let mut out = JsonVal::obj();
    out.insert("ok", JsonVal::Bool(code == 0));
    out.insert("exit_code", n_i64(code as i64));
    out.insert("binary", s(&bin_path.to_string_lossy()));
    if let Ok(parsed_json) = parse_json(stdout.trim()) {
        out.insert("data", parsed_json);
    } else {
        out.insert("stdout", s(stdout.trim()));
    }
    if !stderr.trim().is_empty() {
        out.insert("stderr", s(stderr.trim()));
    }
    Ok(out)
}

// ---------------------------------------------------------------------------
// MCP Tool Schemas & Dispatcher
// ---------------------------------------------------------------------------

fn build_tools_list() -> JsonVal {
    let tools = vec![
        make_tool(
            "cli_anything_status",
            "Inspect CLI-Anything Studio & Hub Android ARM64 status: Python 3, Click, cli-hub, HARNESS.md toolkit, cached registries, installed cli-anything-* binaries, and synced Antigravity skills.",
            vec![],
            &[],
        ),
        make_tool(
            "cli_anything_setup",
            "One-click Android ARM64 bootstrap: installs/upgrades click, requests, setuptools, pytest, prompt_toolkit, and bundled official cli-anything-hub (v0.4.1 with Capability Matrices), runs agy-fix-paths, and warms ~/.cli-hub registry caches.",
            vec![
                ("with_test_deps", prop_bool("Install pytest and prompt_toolkit alongside click/requests (default: true).")),
                ("warm_registry", prop_bool("Pre-fetch and cache the 103+ CLIs and 5 workflow matrices (default: true).")),
            ],
            &[],
        ),
        make_tool(
            "cli_anything_hub_search",
            "Search and filter the 103+ agent-native CLIs from CLI-Hub (79 HKUDS harnesses + 24 public CLIs) at native Rust speed with automatic Android ARM64 compatibility classification (native_ready, remote_api, desktop_gui).",
            vec![
                ("query", prop_str("Search keyword matching name, description, or category (leave empty to browse).")),
                ("category", prop_str("Optional category filter (e.g. devops, developer-tools, ai, productivity, diagramming, video).")),
                ("source", prop_str_enum("Registry source filter.", &["all", "harness", "public"])),
                ("android_tier", prop_str_enum("Filter by Android ARM64 execution compatibility.", &["all", "native_ready", "remote_api", "desktop_gui"])),
                ("limit", prop_int("Maximum results to return (default: 30, max: 150).")),
                ("force_refresh", prop_bool("Bypass 1-hour local cache and fetch fresh registries.")),
            ],
            &[],
        ),
        make_tool(
            "cli_anything_hub_install",
            "Install, update, uninstall, inspect, or list CLIs from CLI-Hub on Android ARM64. Uses fast streaming GitHub subdirectory tarball extraction (<3s, skipping 100MB full clone), runs agy-fix-paths, and auto-syncs SKILL.md into Antigravity.",
            vec![
                ("action", prop_str_enum("Operation to perform.", &["install", "uninstall", "update", "info", "installed"])),
                ("name", prop_str("CLI name in CLI-Hub (e.g. 'mermaid', 'chromadb', 'n8n', 'exa', 'dify-workflow').")),
                ("sync_skill", prop_bool("Automatically install the CLI's SKILL.md into ~/.gemini/config/skills/ (default: true).")),
            ],
            &["action"],
        ),
        make_tool(
            "cli_anything_matrix",
            "Explore and run CLI-Anything Curated Capability Matrices (video-creation, image-design, knowledge-research, etc.): list matrices, search capabilities ('can'), run Android preflight, or sync a matrix SKILL.md into Antigravity.",
            vec![
                ("action", prop_str_enum("Matrix operation.", &["list", "info", "can", "preflight", "render_skill"])),
                ("name", prop_str("Matrix name (e.g. 'video-creation', 'image-design', 'knowledge-research').")),
                ("query", prop_str("Capability query for action='can' (e.g. 'transcribe audio', 'diagram').")),
                ("force_refresh", prop_bool("Force refresh matrix_registry.json cache.")),
            ],
            &["action"],
        ),
        make_tool(
            "cli_anything_analyze_target",
            "Phase 0 & Phase 1 of HARNESS.md: acquire a local directory or shallow-clone a GitHub repo and scan its languages, CLI/API/GUI frameworks, state formats, and undo patterns to plan an agent-native CLI harness.",
            vec![
                ("target", prop_str("Local codebase path or GitHub repository URL (e.g. 'https://github.com/owner/repo').")),
            ],
            &["target"],
        ),
        make_tool(
            "cli_anything_scaffold",
            "Phase 2 & Phase 3 of HARNESS.md: scaffold a complete PEP 420 compliant cli_anything.<software> harness (Click groups, ReplSkin REPL, fcntl-locked Session undo/redo, auto-save + --dry-run, --json output, unit + E2E tests), install editable with agy-fix-paths, and sync SKILL.md.",
            vec![
                ("software_name", prop_str("Target software identifier (e.g. 'task-tracker', 'invoice-engine').")),
                ("display_name", prop_str("Optional human-readable title.")),
                ("description", prop_str("One-line summary of what the software/CLI does.")),
                ("domain_group", prop_str("Primary domain command group name (default: 'item', e.g. 'diagram', 'workflow', 'record').")),
                ("backend_bin", prop_str("Optional underlying native executable wrapped by utils/<pkg>_backend.py.")),
                ("output_dir", prop_str("Optional parent directory (defaults to /storage/emulated/0/Documents/CLI-Anything/).")),
                ("install_editable", prop_bool("Run pip install -e . + agy-fix-paths automatically (default: true).")),
                ("sync_skill", prop_bool("Generate and sync SKILL.md into ~/.gemini/config/skills/ (default: true).")),
                ("overwrite", prop_bool("Overwrite existing scaffold directory if present (default: false).")),
            ],
            &["software_name"],
        ),
        make_tool(
            "cli_anything_validate",
            "Validate any CLI-Anything agent-harness against all 52 official HARNESS.md checks across 8 categories in <15ms (PEP 420 namespace, Click --json/--dry-run, core modules, TestCLISubprocess, AST syntax), optionally running pytest and updating TEST.md.",
            vec![
                ("harness_path", prop_str("Path to agent-harness/ directory (or its parent software folder).")),
                ("run_pytest", prop_bool("Also execute pytest -v on unit and E2E suites and write Part 2 results to TEST.md.")),
            ],
            &["harness_path"],
        ),
        make_tool(
            "cli_anything_skill_sync",
            "Phase 6.5 & Phase 7: extract Click AST metadata via skill_generator.py to generate SKILL.md, optionally pip install -e + agy-fix-paths, and sync/list/remove CLI-Anything skills in Antigravity (~/.gemini/config/skills/).",
            vec![
                ("action", prop_str_enum("Skill sync action.", &["generate_and_sync", "list", "remove"])),
                ("harness_path", prop_str("Path to agent-harness/ directory (required for generate_and_sync).")),
                ("skill_name", prop_str("Skill directory name for action='remove' (e.g. 'cli-anything-demo').")),
                ("install_editable", prop_bool("Also run pip install -e + agy-fix-paths (default: true).")),
            ],
            &["action"],
        ),
        make_tool(
            "cli_anything_exec",
            "Execute an installed cli-anything-<name> harness (or cli-hub) with Bionic-safe environment variables and automatic --json output parsing.",
            vec![
                ("cli_name", prop_str("CLI name or binary (e.g. 'mermaid', 'cli-anything-mermaid', or 'cli-hub').")),
                ("args", prop_arr_str("Command-line arguments passed to the CLI (e.g. ['project', 'new', '-n', 'demo', '-o', '/tmp/p.json']).")),
                ("json_mode", prop_bool("Automatically prepend --json for cli-anything-* harnesses (default: true).")),
                ("cwd", prop_str("Optional working directory.")),
            ],
            &["cli_name"],
        ),
    ];

    let mut out = JsonVal::obj();
    out.insert("tools", JsonVal::Arr(tools));
    out
}

fn dispatch_tool(paths: &EnvPaths, name: &str, args: &JsonVal) -> Result<JsonVal, String> {
    match name {
        "cli_anything_status" => tool_status(paths),
        "cli_anything_setup" => tool_setup(paths, args),
        "cli_anything_hub_search" => tool_hub_search(paths, args),
        "cli_anything_hub_install" => tool_hub_install(paths, args),
        "cli_anything_matrix" => tool_matrix(paths, args),
        "cli_anything_analyze_target" => tool_analyze_target(paths, args),
        "cli_anything_scaffold" => tool_scaffold(paths, args),
        "cli_anything_validate" => tool_validate(paths, args),
        "cli_anything_skill_sync" => tool_skill_sync(paths, args),
        "cli_anything_exec" => tool_exec(paths, args),
        _ => Err(format!("Unknown tool: {}", name)),
    }
}

// ---------------------------------------------------------------------------
// MCP JSON-RPC 2.0 Framing (Line + Content-Length auto-detect)
// ---------------------------------------------------------------------------

#[derive(Clone, Copy)]
enum Framing {
    Line,
    ContentLength,
}

fn read_rpc_message<R: BufRead>(reader: &mut R) -> io::Result<Option<(String, Framing)>> {
    loop {
        let mut line = String::new();
        let n = reader.read_line(&mut line)?;
        if n == 0 {
            return Ok(None);
        }
        let trimmed = line.trim();
        if trimmed.is_empty() {
            continue;
        }
        if trimmed.starts_with('{') {
            return Ok(Some((trimmed.to_string(), Framing::Line)));
        }
        let lower = trimmed.to_ascii_lowercase();
        if let Some(rest) = lower.strip_prefix("content-length:") {
            let len: usize = rest
                .trim()
                .parse()
                .map_err(|_| io::Error::new(io::ErrorKind::InvalidData, "Bad Content-Length"))?;
            loop {
                let mut hdr = String::new();
                let hn = reader.read_line(&mut hdr)?;
                if hn == 0 || hdr.trim().is_empty() {
                    break;
                }
            }
            let mut buf = vec![0u8; len];
            reader.read_exact(&mut buf)?;
            let body = String::from_utf8_lossy(&buf).to_string();
            return Ok(Some((body, Framing::ContentLength)));
        }
    }
}

fn write_rpc_message<W: Write>(writer: &mut W, payload: &JsonVal, framing: Framing) -> io::Result<()> {
    let serialized = payload.to_json_string();
    match framing {
        Framing::Line => {
            writer.write_all(serialized.as_bytes())?;
            writer.write_all(b"\n")?;
        }
        Framing::ContentLength => {
            let header = format!("Content-Length: {}\r\n\r\n", serialized.len());
            writer.write_all(header.as_bytes())?;
            writer.write_all(serialized.as_bytes())?;
        }
    }
    writer.flush()
}

fn handle_rpc_request(paths: &EnvPaths, req: &JsonVal) -> Option<JsonVal> {
    let method = req.get_str("method").unwrap_or("");
    if method.starts_with("notifications/") {
        return None;
    }
    let id = req.get("id")?.clone();
    let mut resp = JsonVal::obj();
    resp.insert("jsonrpc", s("2.0"));
    resp.insert("id", id);

    match method {
        "initialize" => {
            paths.ensure_cli_wrapper();
            let mut server_info = JsonVal::obj();
            server_info.insert("name", s(SERVER_NAME));
            server_info.insert("version", s(SERVER_VERSION));
            let mut caps = JsonVal::obj();
            caps.insert("tools", JsonVal::obj());
            let proto = req
                .get("params")
                .and_then(|p| p.get_str("protocolVersion"))
                .unwrap_or("2024-11-05");
            let mut result = JsonVal::obj();
            result.insert("protocolVersion", s(proto));
            result.insert("capabilities", caps);
            result.insert("serverInfo", server_info);
            resp.insert("result", result);
        }
        "ping" => {
            resp.insert("result", JsonVal::obj());
        }
        "tools/list" => {
            resp.insert("result", build_tools_list());
        }
        "tools/call" => {
            let params = req.get("params").cloned().unwrap_or_else(JsonVal::obj);
            let tname = params.get_str("name").unwrap_or("");
            let targs = params.get("arguments").cloned().unwrap_or_else(JsonVal::obj);
            match dispatch_tool(paths, tname, &targs) {
                Ok(val) => {
                    let mut citem = JsonVal::obj();
                    citem.insert("type", s("text"));
                    citem.insert("text", s(&val.to_json_string()));
                    let mut result = JsonVal::obj();
                    result.insert("content", JsonVal::Arr(vec![citem]));
                    resp.insert("result", result);
                }
                Err(e) => {
                    let mut err_obj = JsonVal::obj();
                    err_obj.insert("ok", JsonVal::Bool(false));
                    err_obj.insert("error", s(&e));
                    let mut citem = JsonVal::obj();
                    citem.insert("type", s("text"));
                    citem.insert("text", s(&err_obj.to_json_string()));
                    let mut result = JsonVal::obj();
                    result.insert("content", JsonVal::Arr(vec![citem]));
                    result.insert("isError", JsonVal::Bool(true));
                    resp.insert("result", result);
                }
            }
        }
        _ => {
            let mut err = JsonVal::obj();
            err.insert("code", JsonVal::Num(-32601.0));
            err.insert("message", s(&format!("Method not found: {}", method)));
            resp.insert("error", err);
        }
    }
    Some(resp)
}

fn print_cli_result(res: Result<JsonVal, String>) {
    match res {
        Ok(v) => {
            let _ = writeln!(io::stdout(), "{}", v.to_json_string());
        }
        Err(e) => {
            let mut err = JsonVal::obj();
            err.insert("ok", JsonVal::Bool(false));
            err.insert("error", s(&e));
            let _ = writeln!(io::stderr(), "{}", err.to_json_string());
            std::process::exit(1);
        }
    }
}

fn main() {
    let paths = EnvPaths::resolve();
    let argv: Vec<String> = env::args().collect();
    if argv.len() > 1 {
        match argv[1].as_str() {
            "status" => {
                print_cli_result(tool_status(&paths));
                return;
            }
            "setup" => {
                print_cli_result(tool_setup(&paths, &JsonVal::obj()));
                return;
            }
            "search" => {
                let mut a = JsonVal::obj();
                if let Some(q) = argv.get(2) {
                    a.insert("query", s(q));
                }
                print_cli_result(tool_hub_search(&paths, &a));
                return;
            }
            "install" | "uninstall" | "update" | "info" | "installed" => {
                let mut a = JsonVal::obj();
                a.insert("action", s(&argv[1]));
                if let Some(nm) = argv.get(2) {
                    a.insert("name", s(nm));
                }
                print_cli_result(tool_hub_install(&paths, &a));
                return;
            }
            "validate" => {
                let mut a = JsonVal::obj();
                if let Some(hp) = argv.get(2) {
                    a.insert("harness_path", s(hp));
                }
                if argv.iter().any(|x| x == "--pytest") {
                    a.insert("run_pytest", JsonVal::Bool(true));
                }
                print_cli_result(tool_validate(&paths, &a));
                return;
            }
            "scaffold" => {
                let mut a = JsonVal::obj();
                if let Some(nm) = argv.get(2) {
                    a.insert("software_name", s(nm));
                }
                print_cli_result(tool_scaffold(&paths, &a));
                return;
            }
            "analyze" => {
                let mut a = JsonVal::obj();
                if let Some(t) = argv.get(2) {
                    a.insert("target", s(t));
                }
                print_cli_result(tool_analyze_target(&paths, &a));
                return;
            }
            "matrix" => {
                let mut a = JsonVal::obj();
                let sub = argv.get(2).map(|x| x.as_str()).unwrap_or("list");
                a.insert("action", s(sub));
                if let Some(arg3) = argv.get(3) {
                    if sub == "can" {
                        a.insert("query", s(arg3));
                    } else {
                        a.insert("name", s(arg3));
                    }
                }
                print_cli_result(tool_matrix(&paths, &a));
                return;
            }
            _ => {
                println!("Usage: cli-anything [status | setup | search <query> | install|uninstall|update|info <name> | installed | analyze <path|url> | scaffold <name> | validate <harness_path> [--pytest] | matrix list|can|preflight <arg>]");
                return;
            }
        }
    }

    let stdin = io::stdin();
    let stdout = io::stdout();
    let mut reader = BufReader::new(stdin.lock());
    let mut writer = stdout.lock();

    while let Ok(Some((raw, framing))) = read_rpc_message(&mut reader) {
        if let Ok(req) = parse_json(&raw) {
            if let Some(resp) = handle_rpc_request(&paths, &req) {
                if write_rpc_message(&mut writer, &resp, framing).is_err() {
                    break;
                }
            }
        }
    }
}
