// templates.rs — Production PEP 420 Harness Scaffolder (HARNESS.md 52/52 Compliant)
// Generates stateful Click + ReplSkin + fcntl-locked Session + --json + --dry-run harnesses

pub struct HarnessSpec {
    pub cli_slug: String,      // kebab-case e.g. "task-flow"
    pub pkg_mod: String,       // snake_case e.g. "task_flow"
    pub display_name: String,  // Title Case e.g. "Task Flow"
    pub description: String,
    pub backend_bin: String,   // optional underlying binary e.g. "ffmpeg" or ""
    pub domain_group: String,  // custom domain command group e.g. "item" or "task"
}

pub fn render_setup_py(spec: &HarnessSpec) -> String {
    format!(
        r#"from setuptools import setup, find_namespace_packages

setup(
    name="cli-anything-{slug}",
    version="0.1.0",
    description={desc:?},
    packages=find_namespace_packages(include=["cli_anything.*"]),
    include_package_data=True,
    package_data={{
        "cli_anything.{pkg}": ["skills/*.md", "README.md"],
    }},
    python_requires=">=3.10",
    install_requires=[
        "click>=8.0",
    ],
    extras_require={{
        "dev": ["pytest>=7.0"],
        "repl": ["prompt_toolkit>=3.0"],
    }},
    entry_points={{
        "console_scripts": [
            "cli-anything-{slug}=cli_anything.{pkg}.{pkg}_cli:main",
        ],
    }},
)
"#,
        slug = spec.cli_slug,
        pkg = spec.pkg_mod,
        desc = format!(
            "Agent-native stateful CLI harness for {} (built with CLI-Anything on Antigravity Android ARM64)",
            spec.display_name
        ),
    )
}

pub fn render_init_py(spec: &HarnessSpec) -> String {
    format!(
        r#""""Agent-native CLI harness package for {display}."""

__version__ = "0.1.0"
__software__ = "{slug}"
"#,
        display = spec.display_name,
        slug = spec.cli_slug
    )
}

pub fn render_main_py(spec: &HarnessSpec) -> String {
    format!(
        r#""""Module entry point for python -m cli_anything.{pkg}.{pkg}_cli."""

from cli_anything.{pkg}.{pkg}_cli import main

if __name__ == "__main__":
    main()
"#,
        pkg = spec.pkg_mod
    )
}

pub fn render_core_init() -> String {
    r#""""Core state, project, session, and export modules."""
"#
    .to_string()
}

pub fn render_utils_init() -> String {
    r#""""Backend execution and terminal REPL skin utilities."""
"#
    .to_string()
}

pub fn render_project_py(spec: &HarnessSpec) -> String {
    format!(
        r#""""Project management and state persistence for {display}."""

from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Any

PROFILES: dict[str, dict[str, Any]] = {{
    "default": {{
        "name": "default",
        "format_version": "1.0",
        "software": "{slug}",
        "settings": {{"strict_validation": True, "encoding": "utf-8"}},
    }},
    "minimal": {{
        "name": "minimal",
        "format_version": "1.0",
        "software": "{slug}",
        "settings": {{"strict_validation": False, "encoding": "utf-8"}},
    }},
    "production": {{
        "name": "production",
        "format_version": "1.0",
        "software": "{slug}",
        "settings": {{"strict_validation": True, "audit_trail": True, "encoding": "utf-8"}},
    }},
}}


def list_profiles() -> list[dict[str, Any]]:
    """Return available configuration profiles for new projects."""
    return [dict(v) for v in PROFILES.values()]


def create(
    name: str,
    profile: str = "default",
    output_path: str | None = None,
    metadata: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Create a new {display} project dictionary and optionally persist it."""
    if profile not in PROFILES:
        raise ValueError(f"Unknown profile '{{profile}}'. Available: {{', '.join(PROFILES)}}")
    now = int(time.time())
    project: dict[str, Any] = {{
        "schema": "cli-anything.{slug}.project/v1",
        "name": name,
        "software": "{slug}",
        "profile": profile,
        "settings": dict(PROFILES[profile]["settings"]),
        "created_at": now,
        "updated_at": now,
        "items": [],
        "metadata": dict(metadata or {{}}),
    }}
    if output_path:
        save(project, output_path)
    return project


def open(project_path: str) -> dict[str, Any]:
    """Open and validate an existing {display} project file from disk."""
    path = Path(project_path).expanduser().resolve()
    if not path.is_file():
        raise FileNotFoundError(f"Project file not found: {{path}}")
    data = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(data, dict) or "name" not in data or "items" not in data:
        raise ValueError(f"Invalid {slug} project structure in {{path}}")
    return data


def save(project: dict[str, Any], project_path: str) -> dict[str, Any]:
    """Persist a project dictionary atomically to disk."""
    path = Path(project_path).expanduser().resolve()
    path.parent.mkdir(parents=True, exist_ok=True)
    project["updated_at"] = int(time.time())
    tmp_path = path.with_suffix(path.suffix + ".tmp")
    tmp_path.write_text(json.dumps(project, indent=2, ensure_ascii=False), encoding="utf-8")
    tmp_path.replace(path)
    return {{"saved": True, "path": str(path), "size": path.stat().st_size}}


def info(project: dict[str, Any]) -> dict[str, Any]:
    """Return a concise summary of project metadata and item counts."""
    items = project.get("items", [])
    return {{
        "name": project.get("name", "untitled"),
        "software": project.get("software", "{slug}"),
        "profile": project.get("profile", "default"),
        "item_count": len(items),
        "created_at": project.get("created_at"),
        "updated_at": project.get("updated_at"),
        "settings": project.get("settings", {{}}),
    }}


def add_entry(
    project: dict[str, Any],
    title: str,
    kind: str = "task",
    payload: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Append a structured domain entry to the project state."""
    if not title.strip():
        raise ValueError("Entry title cannot be empty")
    items = project.setdefault("items", [])
    entry = {{
        "id": f"item-{{len(items) + 1:04d}}",
        "title": title.strip(),
        "kind": kind.strip() or "task",
        "payload": dict(payload or {{}}),
        "created_at": int(time.time()),
    }}
    items.append(entry)
    project["updated_at"] = int(time.time())
    return entry


def remove_entry(project: dict[str, Any], entry_id: str) -> dict[str, Any]:
    """Remove a domain entry by ID and return the removed record."""
    items = project.get("items", [])
    for idx, item in enumerate(items):
        if item.get("id") == entry_id:
            removed = items.pop(idx)
            project["updated_at"] = int(time.time())
            return removed
    raise KeyError(f"Entry '{{entry_id}}' not found in project")
"#,
        display = spec.display_name,
        slug = spec.cli_slug,
    )
}

pub fn render_session_py(spec: &HarnessSpec) -> String {
    format!(
        r#""""Session state, undo/redo stack, and exclusive file locking for {display}."""

from __future__ import annotations

import copy
import json
import time
from pathlib import Path
from typing import Any

try:
    import fcntl
except ImportError:  # pragma: no cover
    fcntl = None  # type: ignore[assignment]


def _locked_save_json(path: Path, data: dict[str, Any]) -> None:
    """Save session JSON using exclusive file locking without pre-lock truncation."""
    path.parent.mkdir(parents=True, exist_ok=True)
    serialized = json.dumps(data, indent=2, ensure_ascii=False)
    mode = "r+" if path.exists() else "w+"
    with path.open(mode, encoding="utf-8") as fh:
        if fcntl is not None:
            fcntl.flock(fh.fileno(), fcntl.LOCK_EX)
        try:
            fh.seek(0)
            fh.truncate()
            fh.write(serialized)
            fh.flush()
        finally:
            if fcntl is not None:
                fcntl.flock(fh.fileno(), fcntl.LOCK_UN)


class Session:
    """Stateful session manager with snapshot history, undo/redo, and auto-save."""

    def __init__(
        self,
        project: dict[str, Any] | None = None,
        project_path: str | None = None,
        session_path: str | None = None,
        max_history: int = 50,
    ) -> None:
        self.project: dict[str, Any] = copy.deepcopy(project) if project else {{}}
        self.project_path: str | None = project_path
        self.session_path: str = session_path or str(
            Path.home() / ".cli-anything" / "sessions" / "{slug}_session.json"
        )
        self.max_history: int = max_history
        self.undo_stack: list[dict[str, Any]] = []
        self.redo_stack: list[dict[str, Any]] = []
        self.modified: bool = False

    def snapshot(self, label: str = "mutation") -> dict[str, Any]:
        """Push current project state onto the undo stack before mutating."""
        snap = {{
            "label": label,
            "timestamp": int(time.time()),
            "state": copy.deepcopy(self.project),
        }}
        self.undo_stack.append(snap)
        if len(self.undo_stack) > self.max_history:
            self.undo_stack.pop(0)
        self.redo_stack.clear()
        self.modified = True
        return {{"label": label, "undo_depth": len(self.undo_stack)}}

    def undo(self) -> dict[str, Any]:
        """Revert project state to the most recent snapshot."""
        if not self.undo_stack:
            raise RuntimeError("Nothing to undo")
        last = self.undo_stack.pop()
        self.redo_stack.append(
            {{
                "label": last["label"],
                "timestamp": int(time.time()),
                "state": copy.deepcopy(self.project),
            }}
        )
        self.project = copy.deepcopy(last["state"])
        self.modified = True
        return {{"undone": last["label"], "undo_depth": len(self.undo_stack), "redo_depth": len(self.redo_stack)}}

    def redo(self) -> dict[str, Any]:
        """Re-apply the most recently undone snapshot."""
        if not self.redo_stack:
            raise RuntimeError("Nothing to redo")
        nxt = self.redo_stack.pop()
        self.undo_stack.append(
            {{
                "label": nxt["label"],
                "timestamp": int(time.time()),
                "state": copy.deepcopy(self.project),
            }}
        )
        self.project = copy.deepcopy(nxt["state"])
        self.modified = True
        return {{"redone": nxt["label"], "undo_depth": len(self.undo_stack), "redo_depth": len(self.redo_stack)}}

    def status(self) -> dict[str, Any]:
        """Return session metadata and undo/redo depths."""
        return {{
            "project_name": self.project.get("name"),
            "project_path": self.project_path,
            "session_path": self.session_path,
            "modified": self.modified,
            "undo_depth": len(self.undo_stack),
            "redo_depth": len(self.redo_stack),
        }}

    def save_session(self, dry_run: bool = False) -> dict[str, Any]:
        """Persist session state and (if configured) project file unless dry_run is True."""
        if dry_run:
            return {{"saved": False, "dry_run": True, "session_path": self.session_path}}
        payload = {{
            "project_path": self.project_path,
            "modified": self.modified,
            "project": self.project,
            "undo_stack": self.undo_stack[-20:],
            "redo_stack": self.redo_stack[-20:],
        }}
        _locked_save_json(Path(self.session_path).expanduser().resolve(), payload)
        if self.project_path and self.project:
            from cli_anything.{pkg}.core import project as proj_mod
            proj_mod.save(self.project, self.project_path)
            self.modified = False
        return {{"saved": True, "dry_run": False, "session_path": self.session_path, "project_path": self.project_path}}

    @classmethod
    def load_session(cls, session_path: str) -> "Session":
        """Restore a persisted Session instance from disk."""
        path = Path(session_path).expanduser().resolve()
        if not path.is_file():
            return cls(session_path=str(path))
        raw = json.loads(path.read_text(encoding="utf-8"))
        sess = cls(
            project=raw.get("project") or {{}},
            project_path=raw.get("project_path"),
            session_path=str(path),
        )
        sess.modified = bool(raw.get("modified", False))
        sess.undo_stack = list(raw.get("undo_stack") or [])
        sess.redo_stack = list(raw.get("redo_stack") or [])
        return sess
"#,
        display = spec.display_name,
        slug = spec.cli_slug,
        pkg = spec.pkg_mod,
    )
}

pub fn render_export_py(spec: &HarnessSpec) -> String {
    format!(
        r###""""Export and rendering pipeline for {display}."""

from __future__ import annotations

import csv
import io
import json
from pathlib import Path
from typing import Any

EXPORT_PRESETS: dict[str, dict[str, Any]] = {{
    "json": {{"extension": ".json", "mime": "application/json", "description": "Canonical JSON artifact"}},
    "markdown": {{"extension": ".md", "mime": "text/markdown", "description": "Structured Markdown report"}},
    "csv": {{"extension": ".csv", "mime": "text/csv", "description": "Tabular CSV export of project items"}},
    "html": {{"extension": ".html", "mime": "text/html", "description": "Standalone HTML summary"}},
}}


def render(
    project: dict[str, Any],
    output_path: str,
    preset: str = "json",
    overwrite: bool = False,
) -> dict[str, Any]:
    """Render a {display} project into a verified output artifact on disk."""
    if preset not in EXPORT_PRESETS:
        raise ValueError(f"Unsupported export preset '{{preset}}'. Choices: {{', '.join(EXPORT_PRESETS)}}")
    out = Path(output_path).expanduser().resolve()
    if out.exists() and not overwrite:
        raise FileExistsError(f"Output file already exists (pass --overwrite): {{out}}")
    out.parent.mkdir(parents=True, exist_ok=True)

    name = project.get("name", "untitled")
    items = project.get("items", [])

    if preset == "json":
        content = json.dumps(project, indent=2, ensure_ascii=False)
    elif preset == "markdown":
        lines = [
            f"# {{name}}",
            "",
            f"- **Software:** `{slug}`",
            f"- **Profile:** `{{project.get('profile', 'default')}}`",
            f"- **Items:** {{len(items)}}",
            "",
            "## Entries",
            "",
        ]
        for it in items:
            lines.append(f"- **{{it.get('id')}}** (`{{it.get('kind')}}`): {{it.get('title')}}")
        content = "\n".join(lines) + "\n"
    elif preset == "csv":
        buf = io.StringIO()
        writer = csv.writer(buf)
        writer.writerow(["id", "kind", "title", "created_at"])
        for it in items:
            writer.writerow([it.get("id", ""), it.get("kind", ""), it.get("title", ""), it.get("created_at", "")])
        content = buf.getvalue()
    else:
        rows = "".join(
            f"<tr><td>{{it.get('id')}}</td><td>{{it.get('kind')}}</td><td>{{it.get('title')}}</td></tr>"
            for it in items
        )
        content = (
            f"<!DOCTYPE html><html><head><meta charset='utf-8'><title>{{name}}</title></head>"
            f"<body><h1>{{name}}</h1><table><thead><tr><th>ID</th><th>Kind</th><th>Title</th></tr></thead>"
            f"<tbody>{{rows}}</tbody></table></body></html>\n"
        )

    out.write_text(content, encoding="utf-8")
    size = out.stat().st_size
    if size <= 0:
        raise RuntimeError(f"Export produced an empty file: {{out}}")
    return {{
        "exported": True,
        "path": str(out),
        "preset": preset,
        "size": size,
        "item_count": len(items),
    }}
"###,
        display = spec.display_name,
        slug = spec.cli_slug,
    )
}

pub fn render_backend_py(spec: &HarnessSpec) -> String {
    let default_bin = if spec.backend_bin.is_empty() {
        spec.cli_slug.as_str()
    } else {
        spec.backend_bin.as_str()
    };
    format!(
        r#""""Backend discovery and subprocess execution helper for {display}."""

from __future__ import annotations

import os
import shutil
import subprocess
from typing import Any

DEFAULT_BACKEND_BIN = "{bin}"


def _android_path() -> str:
    prefix = os.environ.get("PREFIX", "/data/user/0/com.agy/files/usr")
    cur = os.environ.get("PATH", "")
    return f"{{prefix}}/bin:{{cur}}" if os.path.isdir(f"{{prefix}}/bin") else cur


def find_backend(binary_name: str | None = None) -> str | None:
    """Locate the native backend executable on PATH (including Android $PREFIX/bin)."""
    target = binary_name or DEFAULT_BACKEND_BIN
    return shutil.which(target, path=_android_path())


def probe_backend(binary_name: str | None = None) -> dict[str, Any]:
    """Probe backend availability and version string without failing when optional."""
    target = binary_name or DEFAULT_BACKEND_BIN
    resolved = find_backend(target)
    if not resolved:
        return {{
            "available": False,
            "binary": target,
            "path": None,
            "install_hint": f"pkg install {{target}}  # or install upstream {display} backend",
        }}
    proc = subprocess.run(
        [resolved, "--version"],
        capture_output=True,
        text=True,
        timeout=10,
        check=False,
    )
    first_line = (proc.stdout or proc.stderr or "").strip().splitlines()
    return {{
        "available": True,
        "binary": target,
        "path": resolved,
        "version_output": first_line[0] if first_line else "detected",
    }}
"#,
        display = spec.display_name,
        bin = default_bin,
    )
}

pub fn render_cli_py(spec: &HarnessSpec) -> String {
    format!(
        r#""""Click CLI and stateful REPL entry point for {display}."""

from __future__ import annotations

import functools
import json
import shlex
import sys
from pathlib import Path
from typing import Any, Callable

import click

from cli_anything.{pkg} import __version__
from cli_anything.{pkg}.core import export as export_mod
from cli_anything.{pkg}.core import project as project_mod
from cli_anything.{pkg}.core.session import Session
from cli_anything.{pkg}.utils import {pkg}_backend as backend_mod
from cli_anything.{pkg}.utils.repl_skin import ReplSkin


def _emit(ctx: click.Context, payload: dict[str, Any], human_msg: str | None = None) -> None:
    """Emit either deterministic JSON or human-readable output."""
    if ctx.obj and ctx.obj.get("json"):
        click.echo(json.dumps(payload, indent=2, ensure_ascii=False))
    else:
        if human_msg:
            click.echo(human_msg)
        else:
            click.echo(json.dumps(payload, indent=2, ensure_ascii=False))


def handle_error(func: Callable[..., Any]) -> Callable[..., Any]:
    """Consistent error handling decorator supporting --json agent mode."""

    @functools.wraps(func)
    def wrapper(*args: Any, **kwargs: Any) -> Any:
        ctx = click.get_current_context(silent=True)
        as_json = bool(ctx and ctx.obj and ctx.obj.get("json"))
        try:
            return func(*args, **kwargs)
        except Exception as exc:
            if as_json:
                click.echo(json.dumps({{"ok": False, "error": str(exc), "type": type(exc).__name__}}), err=True)
            else:
                click.secho(f"Error: {{exc}}", fg="red", err=True)
            sys.exit(1)

    return wrapper


def _load_active_session(ctx: click.Context) -> Session:
    """Load session and active project from CLI context options."""
    opts = ctx.obj or {{}}
    sess = Session.load_session(opts["session"]) if opts.get("session") else Session()
    proj_path = opts.get("project")
    if proj_path:
        p = Path(proj_path).expanduser().resolve()
        sess.project_path = str(p)
        if p.is_file():
            sess.project = project_mod.open(str(p))
    return sess


@click.group(invoke_without_command=True)
@click.version_option(__version__, prog_name="cli-anything-{slug}")
@click.option("--json", "as_json", is_flag=True, help="Emit deterministic JSON for AI agents.")
@click.option("--project", "-p", "project_path", default=None, help="Path to {slug} project file.")
@click.option("--session", "-s", "session_path", default=None, help="Path to session state JSON.")
@click.option("--dry-run", is_flag=True, help="Preview mutations without writing to disk.")
@click.pass_context
def cli(
    ctx: click.Context,
    as_json: bool,
    project_path: str | None,
    session_path: str | None,
    dry_run: bool,
) -> None:
    """Agent-native stateful CLI harness for {display}."""
    ctx.ensure_object(dict)
    ctx.obj["json"] = as_json
    ctx.obj["project"] = project_path
    ctx.obj["session"] = session_path
    ctx.obj["dry_run"] = dry_run
    if ctx.invoked_subcommand is None:
        ctx.invoke(repl)


@cli.group()
def project() -> None:
    """Create, inspect, validate, and manage {display} project files."""


@project.command("new")
@click.option("--name", "-n", default="untitled", help="Project title.")
@click.option("--profile", default="default", help="Project profile name.")
@click.option("--output", "-o", required=True, help="Output project file path.")
@click.pass_context
@handle_error
def project_new(ctx: click.Context, name: str, profile: str, output: str) -> None:
    """Create a new project file on disk."""
    dry = bool(ctx.obj.get("dry_run"))
    proj = project_mod.create(name=name, profile=profile, output_path=None if dry else output)
    res = {{"ok": True, "dry_run": dry, "path": str(Path(output).expanduser().resolve()), "project": project_mod.info(proj)}}
    _emit(ctx, res, f"Created project '{{name}}' at {{res['path']}}")


@project.command("info")
@click.option("--project", "-p", "local_project", default=None, help="Project file path.")
@click.pass_context
@handle_error
def project_info(ctx: click.Context, local_project: str | None) -> None:
    """Inspect metadata and counts of a project file."""
    target = local_project or ctx.obj.get("project")
    if not target:
        raise ValueError("Specify --project / -p <path>")
    proj = project_mod.open(target)
    summary = project_mod.info(proj)
    _emit(ctx, {{"ok": True, "info": summary}}, f"Project {{summary['name']}} ({{summary['item_count']}} items)")


@project.command("profiles")
@click.pass_context
@handle_error
def project_profiles(ctx: click.Context) -> None:
    """List available project profiles."""
    profs = project_mod.list_profiles()
    _emit(ctx, {{"ok": True, "profiles": profs}})


@cli.group("{domain}")
def domain_group() -> None:
    """Manage {domain} entries inside the active {display} project."""


@domain_group.command("add")
@click.option("--title", "-t", required=True, help="Title of the {domain} entry.")
@click.option("--kind", "-k", default="{domain}", help="Category/kind tag.")
@click.pass_context
@handle_error
def domain_add(ctx: click.Context, title: str, kind: str) -> None:
    """Add an entry to the active project with session auto-save."""
    sess = _load_active_session(ctx)
    if not sess.project:
        sess.project = project_mod.create(name="default")
    sess.snapshot(f"add:{{title}}")
    entry = project_mod.add_entry(sess.project, title=title, kind=kind)
    save_res = sess.save_session(dry_run=bool(ctx.obj.get("dry_run")))
    _emit(ctx, {{"ok": True, "entry": entry, "persistence": save_res}}, f"Added {{entry['id']}}: {{entry['title']}}")


@domain_group.command("list")
@click.pass_context
@handle_error
def domain_list(ctx: click.Context) -> None:
    """List all entries in the active project."""
    sess = _load_active_session(ctx)
    items = sess.project.get("items", []) if sess.project else []
    _emit(ctx, {{"ok": True, "count": len(items), "items": items}})


@domain_group.command("remove")
@click.argument("entry_id")
@click.pass_context
@handle_error
def domain_remove(ctx: click.Context, entry_id: str) -> None:
    """Remove an entry by ID with undo snapshot and auto-save."""
    sess = _load_active_session(ctx)
    if not sess.project:
        raise ValueError("No active project loaded")
    sess.snapshot(f"remove:{{entry_id}}")
    removed = project_mod.remove_entry(sess.project, entry_id)
    save_res = sess.save_session(dry_run=bool(ctx.obj.get("dry_run")))
    _emit(ctx, {{"ok": True, "removed": removed, "persistence": save_res}}, f"Removed {{entry_id}}")


@cli.group()
def session() -> None:
    """Inspect session state and perform undo/redo history operations."""


@session.command("status")
@click.pass_context
@handle_error
def session_status(ctx: click.Context) -> None:
    """Display active session status and undo/redo stack depths."""
    sess = _load_active_session(ctx)
    _emit(ctx, {{"ok": True, "status": sess.status()}})


@session.command("undo")
@click.pass_context
@handle_error
def session_undo(ctx: click.Context) -> None:
    """Undo the last project mutation."""
    sess = _load_active_session(ctx)
    res = sess.undo()
    sess.save_session(dry_run=bool(ctx.obj.get("dry_run")))
    _emit(ctx, {{"ok": True, **res}}, f"Undid {{res['undone']}}")


@session.command("redo")
@click.pass_context
@handle_error
def session_redo(ctx: click.Context) -> None:
    """Redo the last undone project mutation."""
    sess = _load_active_session(ctx)
    res = sess.redo()
    sess.save_session(dry_run=bool(ctx.obj.get("dry_run")))
    _emit(ctx, {{"ok": True, **res}}, f"Redid {{res['redone']}}")


@cli.group()
def export() -> None:
    """Render and export {display} projects to verified output formats."""


@export.command("presets")
@click.pass_context
@handle_error
def export_presets(ctx: click.Context) -> None:
    """List supported export presets."""
    _emit(ctx, {{"ok": True, "presets": export_mod.EXPORT_PRESETS}})


@export.command("render")
@click.argument("output_path")
@click.option("--preset", default="json", type=click.Choice(list(export_mod.EXPORT_PRESETS.keys())))
@click.option("--overwrite", is_flag=True, help="Overwrite existing output file.")
@click.pass_context
@handle_error
def export_render(ctx: click.Context, output_path: str, preset: str, overwrite: bool) -> None:
    """Export the active project into a verified file artifact."""
    sess = _load_active_session(ctx)
    if not sess.project:
        raise ValueError("Specify --project / -p <path> before exporting")
    result = export_mod.render(sess.project, output_path=output_path, preset=preset, overwrite=overwrite)
    _emit(ctx, {{"ok": True, **result}}, f"Exported {{result['path']}} ({{result['size']}} bytes)")


@cli.command("doctor")
@click.pass_context
@handle_error
def doctor(ctx: click.Context) -> None:
    """Probe native backend availability on this system."""
    probe = backend_mod.probe_backend()
    _emit(ctx, {{"ok": True, "backend": probe}})


@cli.command("repl")
@click.pass_context
def repl(ctx: click.Context) -> None:
    """Launch interactive stateful REPL using unified ReplSkin."""
    skin = ReplSkin("{pkg}", version=__version__)
    skin.print_banner()
    pt_session = skin.create_prompt_session()
    sess = _load_active_session(ctx)
    commands_help = {{
        "project new -n <name> -o <path>": "Create a new project file",
        "project info -p <path>": "Show project summary",
        "{domain} add -t <title>": "Add entry to current project",
        "{domain} list": "List entries in current project",
        "session undo | redo | status": "Navigate undo/redo history",
        "export render <out> --preset markdown": "Export project artifact",
        "doctor": "Check native backend status",
        "help / quit": "Show help or exit REPL",
    }}
    while True:
        proj_label = sess.project.get("name") if sess.project else None
        try:
            line = skin.get_input(pt_session, project_name=proj_label, modified=sess.modified).strip()
        except (EOFError, KeyboardInterrupt):
            break
        if not line:
            continue
        if line in ("quit", "exit", "q"):
            break
        if line == "help":
            skin.help(commands_help)
            continue
        try:
            argv = shlex.split(line)
            cli.main(args=argv, prog_name="cli-anything-{slug}", standalone_mode=False)
            sess = _load_active_session(ctx)
        except SystemExit:
            pass
        except Exception as exc:
            skin.error(str(exc))
    skin.print_goodbye()


def main() -> None:
    """Console script entry point."""
    cli(obj={{}})


if __name__ == "__main__":
    main()
"#,
        display = spec.display_name,
        pkg = spec.pkg_mod,
        slug = spec.cli_slug,
        domain = spec.domain_group,
    )
}

pub fn render_sop_md(spec: &HarnessSpec) -> String {
    format!(
        r#"# {display} — Agent-Native CLI Architecture & SOP

## Architecture Analysis

- **Software Identifier:** `{slug}` (`cli_anything.{pkg}`)
- **Summary:** {desc}
- **Interaction Mode:** Dual Click Subcommand CLI (`--json` deterministic output) + Stateful `ReplSkin` REPL
- **Persistence & Concurrency:** Atomic `.tmp` project writes + `fcntl.flock` exclusive session locking (`_locked_save_json`) + automatic mutation save with `--dry-run` override.

## Command Map

| Group | Subcommands | Purpose |
| :--- | :--- | :--- |
| `project` | `new`, `info`, `profiles` | Project initialization, validation, and profile inspection |
| `{domain}` | `add`, `list`, `remove` | Core domain operations with automatic snapshot & session save |
| `session` | `status`, `undo`, `redo` | Multi-step state history navigation |
| `export` | `presets`, `render` | Verified artifact generation (`json`, `markdown`, `csv`, `html`) |
| `doctor` | *(root command)* | Backend binary discovery on `$PREFIX/bin` / `$PATH` |

## Rendering & Backend Gap Assessment

- Project creation, state mutations, undo/redo snapshots, and structured exports (`JSON`, `Markdown`, `CSV`, `HTML`) execute 100% natively in Python 3.10+ on Android ARM64 and Linux.
- Optional external binary backend (`{bin}`) is probed dynamically via `cli_anything.{pkg}.utils.{pkg}_backend`.
"#,
        display = spec.display_name,
        slug = spec.cli_slug,
        pkg = spec.pkg_mod,
        desc = spec.description,
        domain = spec.domain_group,
        bin = if spec.backend_bin.is_empty() {
            spec.cli_slug.as_str()
        } else {
            spec.backend_bin.as_str()
        },
    )
}

pub fn render_readme_md(spec: &HarnessSpec) -> String {
    format!(
        r#"# cli-anything-{slug}

{desc}

## Installation

```bash
pip install -e .
# On Antigravity Android ARM64, fix console_scripts shebangs:
agy-fix-paths
```

## Usage

```bash
# Inspect CLI help
cli-anything-{slug} --help

# Launch interactive REPL
cli-anything-{slug}

# Create a project with JSON output for AI agents
cli-anything-{slug} --json project new --name demo -o ./demo.json

# Mutate state (auto-saves session & project)
cli-anything-{slug} --json -p ./demo.json {domain} add --title "First item"

# Export verified Markdown report
cli-anything-{slug} --json -p ./demo.json export render ./demo.md --preset markdown --overwrite
```

## Command Reference

- `project new | info | profiles`
- `{domain} add | list | remove`
- `session status | undo | redo`
- `export presets | render`
- `doctor`
- `repl`

## Examples

```bash
# Preview a mutation without touching disk (--dry-run)
cli-anything-{slug} --json --dry-run -p ./demo.json {domain} add --title "Preview only"
```
"#,
        slug = spec.cli_slug,
        desc = spec.description,
        domain = spec.domain_group,
    )
}

pub fn render_test_md(spec: &HarnessSpec) -> String {
    format!(
        r#"# Test Plan & Results — `cli-anything-{slug}`

## Part 1: Test Inventory Plan

- `test_core.py`: 8 unit tests covering `project.py`, `session.py` (snapshots, undo/redo, `fcntl` locking, `--dry-run`), and `export.py`
- `test_full_e2e.py`: 5 end-to-end & subprocess tests verifying real file artifacts, multi-step workflows, and `_resolve_cli("cli-anything-{slug}")`

### Realistic Workflow Scenarios
1. **End-to-End Lifecycle (`test_workflow_lifecycle`):** Create project -> add 2 `{domain}` entries -> undo 1 -> redo 1 -> export Markdown & CSV -> verify file headers and non-zero byte counts.
2. **Agent JSON Subprocess (`TestCLISubprocess`):** Execute `cli-anything-{slug} --json` commands without hardcoded `cwd`, validating exit codes and deterministic JSON output.

---

## Part 2: Execution Results

Run `cli_anything_validate` with `run_pytest: true` (or `pytest -v`) to append live test execution logs below.
"#,
        slug = spec.cli_slug,
        domain = spec.domain_group,
    )
}

pub fn render_test_core_py(spec: &HarnessSpec) -> String {
    format!(
        r###""""Unit tests for cli_anything.{pkg}.core (synthetic data, zero external deps)."""

from pathlib import Path
import pytest

from cli_anything.{pkg}.core import export as export_mod
from cli_anything.{pkg}.core import project as project_mod
from cli_anything.{pkg}.core.session import Session


def test_list_profiles() -> None:
    profiles = project_mod.list_profiles()
    names = {{p["name"] for p in profiles}}
    assert "default" in names
    assert "production" in names


def test_create_and_info() -> None:
    proj = project_mod.create(name="unit-demo", profile="production")
    summary = project_mod.info(proj)
    assert summary["name"] == "unit-demo"
    assert summary["profile"] == "production"
    assert summary["item_count"] == 0


def test_invalid_profile_raises() -> None:
    with pytest.raises(ValueError):
        project_mod.create(name="bad", profile="nonexistent")


def test_add_and_remove_entry() -> None:
    proj = project_mod.create(name="entries")
    e1 = project_mod.add_entry(proj, title="Alpha", kind="{domain}")
    assert e1["id"] == "item-0001"
    assert len(proj["items"]) == 1
    removed = project_mod.remove_entry(proj, "item-0001")
    assert removed["title"] == "Alpha"
    assert len(proj["items"]) == 0


def test_project_save_and_open(tmp_path: Path) -> None:
    pfile = tmp_path / "proj.json"
    proj = project_mod.create(name="disk-test", output_path=str(pfile))
    assert pfile.is_file()
    loaded = project_mod.open(str(pfile))
    assert loaded["name"] == proj["name"]


def test_session_undo_redo_and_locking(tmp_path: Path) -> None:
    pfile = tmp_path / "sess_proj.json"
    sfile = tmp_path / "session.json"
    proj = project_mod.create(name="hist", output_path=str(pfile))
    sess = Session(project=proj, project_path=str(pfile), session_path=str(sfile))

    sess.snapshot("add-one")
    project_mod.add_entry(sess.project, title="Step 1")
    assert len(sess.project["items"]) == 1

    sess.undo()
    assert len(sess.project["items"]) == 0

    sess.redo()
    assert len(sess.project["items"]) == 1

    saved = sess.save_session(dry_run=False)
    assert saved["saved"] is True
    assert sfile.is_file()

    restored = Session.load_session(str(sfile))
    assert len(restored.project["items"]) == 1


def test_session_dry_run_skips_write(tmp_path: Path) -> None:
    sfile = tmp_path / "dry_session.json"
    sess = Session(project=project_mod.create(name="dry"), session_path=str(sfile))
    res = sess.save_session(dry_run=True)
    assert res["dry_run"] is True
    assert not sfile.exists()


def test_export_presets_validation(tmp_path: Path) -> None:
    proj = project_mod.create(name="exp")
    project_mod.add_entry(proj, title="Row 1")
    md_out = tmp_path / "out.md"
    res = export_mod.render(proj, str(md_out), preset="markdown", overwrite=True)
    assert res["exported"] is True
    assert md_out.read_text(encoding="utf-8").startswith("# exp")
"###,
        pkg = spec.pkg_mod,
        domain = spec.domain_group,
    )
}

pub fn render_test_e2e_py(spec: &HarnessSpec) -> String {
    format!(
        r#""""End-to-end workflow and subprocess CLI tests for cli-anything-{slug}."""

import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

from cli_anything.{pkg}.core import export as export_mod
from cli_anything.{pkg}.core import project as project_mod
from cli_anything.{pkg}.core.session import Session


def _resolve_cli(name: str) -> list[str]:
    """Resolve installed CLI command; falls back to python -m for dev.

    Set env CLI_ANYTHING_FORCE_INSTALLED=1 to require the installed command.
    """
    force = os.environ.get("CLI_ANYTHING_FORCE_INSTALLED", "").strip() == "1"
    path = shutil.which(name)
    if path:
        print(f"[_resolve_cli] Using installed command: {{path}}")
        return [path]
    if force:
        raise RuntimeError(f"{{name}} not found in PATH. Install with: pip install -e .")
    module = "cli_anything.{pkg}.{pkg}_cli"
    print(f"[_resolve_cli] Falling back to: {{sys.executable}} -m {{module}}")
    return [sys.executable, "-m", module]


def test_workflow_lifecycle(tmp_path: Path) -> None:
    pfile = tmp_path / "workflow.json"
    sfile = tmp_path / "workflow_session.json"
    proj = project_mod.create(name="Production Workflow", profile="production", output_path=str(pfile))
    sess = Session(project=proj, project_path=str(pfile), session_path=str(sfile))

    sess.snapshot("step-1")
    project_mod.add_entry(sess.project, title="Configure pipeline", kind="{domain}")
    sess.snapshot("step-2")
    project_mod.add_entry(sess.project, title="Publish artifact", kind="{domain}")
    sess.undo()
    assert len(sess.project["items"]) == 1
    sess.redo()
    assert len(sess.project["items"]) == 2
    sess.save_session()

    csv_path = tmp_path / "report.csv"
    html_path = tmp_path / "report.html"
    r_csv = export_mod.render(sess.project, str(csv_path), preset="csv", overwrite=True)
    r_html = export_mod.render(sess.project, str(html_path), preset="html", overwrite=True)

    assert r_csv["size"] > 20
    assert "Configure pipeline" in csv_path.read_text(encoding="utf-8")
    assert r_html["size"] > 40
    assert html_path.read_text(encoding="utf-8").startswith("<!DOCTYPE html>")


class TestCLISubprocess:
    CLI_BASE = _resolve_cli("cli-anything-{slug}")

    def _run(self, args: list[str], check: bool = True) -> subprocess.CompletedProcess[str]:
        env = dict(os.environ)
        harness_root = str(Path(__file__).resolve().parents[3])
        env["PYTHONPATH"] = harness_root + os.pathsep + env.get("PYTHONPATH", "")
        return subprocess.run(
            self.CLI_BASE + args,
            capture_output=True,
            text=True,
            check=check,
            env=env,
        )

    def test_help(self) -> None:
        result = self._run(["--help"])
        assert result.returncode == 0
        assert "project" in result.stdout

    def test_project_new_and_mutation_json(self, tmp_path: Path) -> None:
        proj_file = tmp_path / "sub_proj.json"
        sess_file = tmp_path / "sub_sess.json"
        out_md = tmp_path / "sub_out.md"

        r1 = self._run(["--json", "project", "new", "-n", "SubDemo", "-o", str(proj_file)])
        data1 = json.loads(r1.stdout)
        assert data1["ok"] is True
        assert proj_file.is_file()

        r2 = self._run(
            ["--json", "-p", str(proj_file), "-s", str(sess_file), "{domain}", "add", "-t", "Agent Task"]
        )
        data2 = json.loads(r2.stdout)
        assert data2["ok"] is True
        assert data2["entry"]["title"] == "Agent Task"

        r3 = self._run(
            ["--json", "-p", str(proj_file), "export", "render", str(out_md), "--preset", "markdown", "--overwrite"]
        )
        data3 = json.loads(r3.stdout)
        assert data3["ok"] is True
        assert out_md.is_file() and out_md.stat().st_size > 0
"#,
        slug = spec.cli_slug,
        pkg = spec.pkg_mod,
        domain = spec.domain_group,
    )
}
