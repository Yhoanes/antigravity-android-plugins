---
name: craft-rebuild
description: Study, port, and rebuild applications, games, consoles/firmware, Electron bundles, websites, or native tools into a clean modern codebase (including Android ARM64, Web, React/Vite, Rust, Godot 4, or Kotlin/Compose) using Craft Anything v0.5.0's Study -> Brief -> Build -> Check workflow in Deep or Clean-Room mode.
---

# Craft Rebuild v0.5.0: Structured Software & Game Porting

Use this skill when the user wants to **study an existing app, game, console/firmware binary, bundle, or website and rebuild or port it** into a clean, maintainable project (e.g., porting a PC/console game or Electron tool to native Android ARM64, Godot 4, Web, or Rust).

## 1. Choose the Mode: Deep vs. Clean-Room

- **Deep Mode (default):** Inspects package structure, symbols, strings, JS bundles (`js_app_map`, `js_release_audit`), game archives (`game_godot_pck_extract`, `game_il2cpp_meta_show`, `game_pak_list`, `game_unity_bundle_list`), console/firmware containers (`retro_to_elf_convert`, `firmware_esp_uf2_show`), `.NET NativeAOT` (`nativeaot_metadata_show`), and pseudo-C / Ghidra decompilation (`native_functions_decompile`, `ghidra_headless_run`).
- **Clean-Room Mode (when requested):** Call `settings_set` (`deep_mode: false`). Never open, read, list, or decompile internal files of the target; build strictly from user specifications, external behavior, or public specs.

## 2. Four-Phase Rebuild Workflow

### Phase 1 — Study (Read-Only Evidence Gathering)
1. Identify the target (`path` on device or `url`).
2. Run format-matched triage first:
   - **Standard Binary / APK / Folder:** `core_target_open` and `core_target_triage`.
   - **Electron / JS Release (`resources/app.asar` or bundle):** `js_app_map` + `js_release_audit`.
   - **Games:**
     - **Godot 3/4:** `game_godot_pck_extract` to inspect/extract `res://` scenes, `.gd` scripts, and shaders directly for `game-studio`.
     - **Unity:** `game_il2cpp_meta_show` on `global-metadata.dat` + `game_unity_bundle_list` / `game_unity_asset_export`.
     - **Unreal:** `game_pak_list`, `game_iostore_list`, `game_pak_extract`, `game_unreal_texture_export`.
     - **GameCube / Wii `.dol`, DOS `.com`, or Raw ROMs:** `retro_to_elf_convert` -> `core_target_open` -> `native_functions_decompile` (or `ghidra_headless_run`).
   - **Web App / API Simulation:** Capture `.har` traffic and call `rl_har_env_build` + `rl_har_env_serve` to spin up a deterministic local Rust mock API while rebuilding the frontend or training agents.
3. Record open questions in `core_unknown_add` and settled facts in `core_finding_record`.

### Phase 2 — Architecture Brief & Checklist
1. Honor the user's chosen target stack first (Kotlin/Compose, Godot 4 Vulkan Mobile, NDK/SDL3, Rust, React/Vite).
2. Create a concise 3–7 step implementation checklist covering data models, core logic/parsers, touch-first UI/controls (on Android), and verification.

### Phase 3 — Clean Implementation
1. Write all new source code inside a dedicated output directory, keeping any reference target strictly read-only.
2. Reimplement layout, styling, and algorithms cleanly in idiomatic target-language code rather than pasting raw decompiler output.

### Phase 4 — Verification & Diff Summary
1. Compile/typecheck/test the new build completely (`rebuild_check` or native build/test suite).
2. Review `core_unknowns_show` and summarize how the new build maps to the original architecture.
