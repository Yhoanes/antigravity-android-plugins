---
name: ghidra-arm64
description: Install on demand, configure, and run native Android ARM64 Ghidra 12.1.4 (decompile, sleigh, analyzeHeadless, ghidra_headless_run, retro_to_elf_convert, and Craft Anything Deep Ghidra integration) inside Antigravity Android while respecting mobile RAM and storage constraints.
---

# Native Android ARM64 Ghidra 12.1.4 & Retro/Firmware ELF Bridge Guide (v0.5.0)

This plugin bundles precompiled **Android ARM64 Bionic (`aarch64-linux-android`)** native binaries for Ghidra 12.1.4 + our native Rust `craft-plus-mcp` bridge:
- `decompile` (`3.6 MB`, PIE, stripped)
- `sleigh` (`1.5 MB`, PIE, stripped)
- `craft-plus-mcp` (`<1 MB` pure Rust ARM64 LSE binary providing `retro_to_elf_convert` and `ghidra_headless_run`)
- `craft-ghidra-setup` (automated installer for OpenJDK 21 + Ghidra 12.1.4 Public distribution)

## 1. Fast Tier (0 Java) vs. Deep Ghidra Tier

1. **Tier 1 — Instant Pure-Rust Decompilation (`<50 MB` RAM, 0 Java):**
   - For standard ELF/PE/Mach-O, call `core_target_open` -> `native_functions_decompile`.
   - For **Nintendo GameCube/Wii `.dol`**, **16-bit DOS `.com`**, **ESP32 `0xE9` firmware**, **UF2 images**, or **raw console/MCU ROMs**, call `retro_to_elf_convert` first! It synthesizes a standard ELF with exact virtual addresses and symbols in `$PREFIX/tmp/craft-elf/` in `<5 ms` so Craft Anything's Rust pseudo-C engine can decompile it immediately without starting JVM.
2. **Tier 2 — Full Ghidra 12.1.4 ARM64 (`ghidra_headless_run` & Deep Mode):**
   - Use `ghidra_headless_run` (or Deep Ghidra tools) when you need SLEIGH processor specs (`PowerPC:BE:32:default`, `MIPS:LE:32:default`, `x86:LE:16:Real Mode`), C++ vtable/struct recovery, or batch decompilation. `ghidra_headless_run` automatically converts `.dol`, `.uf2`, and ESP32 images to ELF first and enforces mobile RAM caps (`max_ram: "1536M"`) and dot-free project paths.

## 2. Checking & Installing Ghidra 12.1.4 On Demand

1. Check readiness via `craft-plus doctor` or:
   ```sh
   ls -la "$HOME/usr/opt/ghidra/ghidra_12.1.4_PUBLIC/support/analyzeHeadless"
   ```
2. If not installed yet, inform the user (`~450 MB` download, deleted right after extraction) and run:
   ```sh
   craft-ghidra-setup
   ```

## 3. Mobile Safety Guardrails

- **Dot-Free Paths:** Always keep Ghidra projects and temp files under `$PREFIX/tmp/ghidra-projects` (never inside `~/.gemini` or `~/.config`).
- **Protect `$HOME/runtime/bin`:** Never modify `/data/user/0/com.agy/files/runtime/bin/`; all wrappers (`analyzeHeadless`, `craft-plus`, `craft-anything-cli`, `craft-ghidra-setup`) reside in `$PREFIX/bin`.
