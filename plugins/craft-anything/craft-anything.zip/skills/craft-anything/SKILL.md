---
name: craft-anything
description: Investigate how shipped software, firmware, consoles, GPUs, games, and web APIs work (ELF/PE/Mach-O, APK/DEX, Electron .asar, .NET & NativeAOT, WASM, CUDA/PTX, ESP32/UF2/DTB, Godot .pck, Unity IL2CPP, GameCube/Wii .dol, Erlang BEAM, and RL HAR mocks) using Craft Anything + Plus's 335 native Rust MCP tools.
---

# Craft Anything v0.5.0 Plus: Evidence-First Software, Firmware & RL Investigation

Use this skill when an answer depends on **built, packaged, or captured software**: an ELF/PE/Mach-O binary or `.so`/`.dll`, an Android APK/DEX, an Electron `.asar` or JS release, a `.NET` or **NativeAOT** binary, a WebAssembly module, embedded firmware (`ESP32`, `UF2`, `.dtb`/`FIT`), GPU `fatbin`/`PTX`, game archives (Unreal `.pak`/`IoStore`, Unity `AssetBundles` + `IL2CPP` `global-metadata.dat`, Godot `.pck`, GameCube/Wii `.dol`), or a `.har` web capture for RL environment synthesis.

## 1. Unified 335-Tool Native Rust MCP Architecture

- `start-mcp.sh` launches `craft-plus-mcp` wrapping `craft-anything-cli --deep mcp --all-tools`, exposing **335 native ARM64 Rust tools** in one MCP server (`<50 MB` RAM, zero Python/Node/Docker).
- Never run `craft-anything-cli setup --yes` on Android; for health checks run `craft-plus doctor` or `craft-anything-cli capabilities`.
- For **Clean-Room** rebuilds, call `settings_set` (`deep_mode: false`) before opening any target.

## 2. Entry Points by Target Format

- **ELF / PE / Mach-O / `.so` / `.dll`:** `core_target_open` -> `core_target_triage` -> `native_functions_decompile`, `native_call_graph_show`, `native_value_flow_show`.
- **Consoles / Retro / Raw Firmware (`.dol`, DOS `.com`, `ESP32`, `UF2`, Raw ROMs):**
  1. Call `retro_to_elf_convert` first to synthesize a standards-compliant ELF with exact virtual memory sections and symbols in `$PREFIX/tmp/craft-elf/`.
  2. Open that `.elf` directly with `core_target_open` + `native_functions_decompile` (0 Java!) or pass to `ghidra_headless_run` for deep SLEIGH/C++ recovery.
- **IoT Firmware & Bootloaders:** `firmware_esp_uf2_show` (ESP32 `0xE9` + SHA-256 + `esp_app_desc_t`, partition tables, UF2 30+ MCUs) and `firmware_dtb_fit_show` (`.dtb` & U-Boot `FIT`).
- **GPU & AI Compute:** `gpu_cuda_ptx_show` (NVIDIA `.nv_fatbin` LZ4 decompression, `sm_*` targets, PTX assembly & `.entry` kernel params) and `formats_ai_weights_show` (`GGUF` / `safetensors`).
- **Games (Unity / Godot / Unreal):**
  - **Godot 3.x / 4.x:** `game_godot_pck_extract` (standalone `.pck` or embedded executable tail -> extracts `res://` scenes/scripts directly for `game-studio`).
  - **Unity:** `game_il2cpp_meta_show` (`global-metadata.dat` v24–v39 classes/methods/literals) + `game_unity_bundle_list` / `game_unity_asset_export`.
  - **Unreal:** `game_pak_list`, `game_iostore_list`, `game_pak_extract`, `game_unreal_texture_export`.
- **Managed, NativeAOT & BEAM:** `managed_assembly_show`, `nativeaot_metadata_show` (`.NET 7–10 NativeAOT`, `RTR\0` ReadyToRun, single-file bundles), `formats_beam_show` (Erlang/Elixir `.beam`).
- **Electron / JS Bundles & Security Audit:** `js_app_map` + `js_release_audit` (exposed source maps, masked secret leaks, internal endpoints, Electron fuse risks).
- **RL Environments & Deterministic Mock Servers from `.har`:**
  1. `rl_har_env_build` (`har_path`, `output_dir`) -> generates `env_manifest.json`, `openapi.json`, `agent_tools.json`, and `reward_checks.json`.
  2. `rl_har_env_serve` (`action: "start" | "status" | "evaluate" | "reset" | "stop"`) -> serves live stateful CRUD HTTP endpoints on `127.0.0.1:<port>` in `<2 MB` RAM and computes `0.0..1.0` RL episode rewards.

## 3. Durable Working Memory Workflow

1. Call `core_investigation_show` / `core_session_show` to resume or start cleanly.
2. Define `core_brief_write` and `core_plan_update`.
3. Track `core_hypothesis_record`, `core_unknown_add`, and settled `core_finding_record` citing `ev_...` evidence IDs, finishing multi-step sessions with `core_handoff_write`.
