//! `craft-plus-mcp` v0.5.0 — Native Android ARM64 Rust MCP Multiplexer & Binary Supercharger
//! Wraps `craft-anything-cli --deep mcp --all-tools` over stdio, seamlessly merging all 323
//! upstream Craft Anything tools with 12 pure-Rust specialized firmware, GPU, game, console->ELF,
//! .NET NativeAOT, Ghidra headless, and stateful RL HAR environment tools in a single MCP server.

mod elf_synth;
mod firmware;
mod gpu_game_formats;
mod retro_aot;
mod rl_har;
mod sha256;
mod tools;

use serde_json::{json, Value};
use std::collections::HashSet;
use std::env;
use std::fs;
use std::io::{self, BufRead, BufReader, BufWriter, Write};
use std::os::unix::fs::PermissionsExt;
use std::path::{Path, PathBuf};
use std::process::{Child, Command, Stdio};
use std::sync::{Arc, Mutex};
use tools::{dispatch_plus_tool, is_plus_tool, plus_tool_schemas, PLUS_TOOL_NAMES};

/// Upstream Craft Anything tool names that exceed Antigravity's 64-character prefixed MCP limit
/// (`"mcp_craft-anything_craft-anything_".len() == 34`, leaving max 30 chars for tool names).
/// `craft-plus-mcp` transparently rewrites these 3 names in `tools/list` and translates them back
/// on `tools/call`, eliminating greyed-out / disabled strikethrough tools in the UI.
const UPSTREAM_TOOL_ALIASES: &[(&str, &str)] = &[
    ("native_function_references_list", "native_fn_references_list"),
    ("native_function_instructions_list", "native_fn_instructions_list"),
    ("native_rizin_session_command_run", "native_rizin_session_cmd_run"),
];

fn shorten_upstream_tool_name(name: &str) -> Option<&'static str> {
    for &(long_name, short_name) in UPSTREAM_TOOL_ALIASES {
        if name == long_name {
            return Some(short_name);
        }
    }
    None
}

fn restore_upstream_tool_name(name: &str) -> Option<&'static str> {
    for &(long_name, short_name) in UPSTREAM_TOOL_ALIASES {
        if name == short_name {
            return Some(long_name);
        }
    }
    None
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum WireFraming {
    Newline,
    ContentLength,
}

fn main() {
    let args: Vec<String> = env::args().collect();
    let sub = args.get(1).map(|s| s.as_str()).unwrap_or("mcp");

    match sub {
        "mcp" | "--mcp" => {
            ensure_prefix_wrappers();
            let upstream = args.get(2).cloned().unwrap_or_else(resolve_upstream_binary);
            if let Err(e) = run_mcp_multiplexer(&upstream) {
                eprintln!("[craft-plus-mcp] fatal: {}", e);
                std::process::exit(1);
            }
        }
        "doctor" | "--doctor" => {
            let upstream = resolve_upstream_binary();
            let prefix = env::var("PREFIX").unwrap_or_else(|_| "/data/user/0/com.agy/files/usr".into());
            let ghidra = Path::new(&prefix).join("opt/ghidra/ghidra_12.1.4_PUBLIC/support/analyzeHeadless");
            let report = json!({
                "name": "craft-plus-mcp",
                "version": env!("CARGO_PKG_VERSION"),
                "arch": env::consts::ARCH,
                "os": env::consts::OS,
                "upstream_craft_anything_cli": upstream,
                "upstream_present": Path::new(&upstream).exists(),
                "ghidra_12_1_4_headless_ready": ghidra.exists(),
                "plus_tools_count": PLUS_TOOL_NAMES.len(),
                "plus_tools": PLUS_TOOL_NAMES,
                "healthy": Path::new(&upstream).exists(),
            });
            println!("{}", serde_json::to_string_pretty(&report).unwrap_or_default());
        }
        "tools" => {
            println!(
                "{}",
                serde_json::to_string_pretty(&plus_tool_schemas()).unwrap_or_default()
            );
        }
        "call" => {
            let Some(tname) = args.get(2) else {
                eprintln!("Usage: craft-plus call <tool_name> ['{{\"path\":\"...\"}}']");
                std::process::exit(2);
            };
            let raw_json = args.get(3).map(|s| s.as_str()).unwrap_or("{}");
            let parsed_args: Value = match serde_json::from_str(raw_json) {
                Ok(v) => v,
                Err(e) => {
                    eprintln!("Invalid JSON arguments: {}", e);
                    std::process::exit(2);
                }
            };
            match dispatch_plus_tool(tname, &parsed_args) {
                Ok(val) => {
                    println!("{}", serde_json::to_string_pretty(&val).unwrap_or_default());
                }
                Err(err) => {
                    eprintln!(
                        "{}",
                        serde_json::to_string_pretty(&json!({ "error": err })).unwrap_or_default()
                    );
                    std::process::exit(1);
                }
            }
        }
        "-h" | "--help" | "help" => {
            println!(
                "craft-plus-mcp v{}\nUsage:\n  craft-plus-mcp mcp [upstream_craft_anything_cli_path]\n  craft-plus-mcp doctor\n  craft-plus-mcp tools\n  craft-plus-mcp call <tool_name> '<json_args>'",
                env!("CARGO_PKG_VERSION")
            );
        }
        _ => {
            // Default fallback if invoked with unknown flags: run MCP multiplexer
            ensure_prefix_wrappers();
            let upstream = resolve_upstream_binary();
            if let Err(e) = run_mcp_multiplexer(&upstream) {
                eprintln!("[craft-plus-mcp] fatal: {}", e);
                std::process::exit(1);
            }
        }
    }
}

fn resolve_upstream_binary() -> String {
    if let Ok(p) = env::var("CRAFT_ANYTHING_UPSTREAM_BIN") {
        if Path::new(&p).exists() {
            return p;
        }
    }
    if let Ok(exe) = env::current_exe() {
        if let Some(dir) = exe.parent() {
            let sibling = dir.join("craft-anything-cli");
            if sibling.exists() {
                return sibling.to_string_lossy().to_string();
            }
        }
    }
    let home = env::var("HOME").unwrap_or_else(|_| "/data/user/0/com.agy/files".into());
    format!(
        "{}/.gemini/config/plugins/craft-anything/mcp/bin/craft-anything-cli",
        home
    )
}

/// Atomically self-heals CLI wrappers inside `$PREFIX/bin` ONLY (never touching `$HOME/runtime/bin`).
fn ensure_prefix_wrappers() {
    let Ok(exe) = env::current_exe() else { return };
    let Some(bin_dir) = exe.parent() else { return };
    let home = env::var("HOME").unwrap_or_else(|_| "/data/user/0/com.agy/files".into());
    let prefix = env::var("PREFIX").unwrap_or_else(|_| format!("{}/usr", home));
    let prefix_bin = PathBuf::from(&prefix).join("bin");
    if !prefix_bin.is_dir() {
        return;
    }

    let targets: &[(&str, PathBuf)] = &[
        ("craft-plus", exe.clone()),
        ("craft-anything-cli", bin_dir.join("craft-anything-cli")),
        ("craft-ghidra-setup", bin_dir.join("craft-ghidra-setup")),
    ];

    for (name, target) in targets {
        if !target.exists() {
            continue;
        }
        let dst = prefix_bin.join(name);
        let script = format!(
            "#!/system/bin/sh\nexport HOME=\"{}\"\nexport PREFIX=\"{}\"\nexport XDG_CONFIG_HOME=\"{}/.config\"\nexec \"{}\" \"$@\"\n",
            home,
            prefix,
            home,
            target.display()
        );
        let existing = fs::read_to_string(&dst).unwrap_or_default();
        if existing != script {
            let tmp = prefix_bin.join(format!(".{}.agy.{}.tmp", name, std::process::id()));
            if fs::write(&tmp, script.as_bytes()).is_ok() {
                let _ = fs::set_permissions(&tmp, fs::Permissions::from_mode(0o755));
                let _ = fs::rename(&tmp, &dst);
            }
        }
    }
}

fn read_rpc_frame<R: BufRead>(reader: &mut R) -> io::Result<Option<(String, WireFraming)>> {
    loop {
        let mut line = String::new();
        let n = reader.read_line(&mut line)?;
        if n == 0 {
            return Ok(None);
        }
        let trimmed = line.trim();
        if trimmed.is_empty() {
            continue;
        }
        if trimmed
            .get(..15)
            .map(|p| p.eq_ignore_ascii_case("content-length:"))
            .unwrap_or(false)
        {
            let len_str = trimmed[15..].trim();
            let content_len: usize = len_str.parse().map_err(|e| {
                io::Error::new(
                    io::ErrorKind::InvalidData,
                    format!("Bad Content-Length: {}", e),
                )
            })?;
            // Consume remaining headers until empty line
            loop {
                let mut h = String::new();
                let hn = reader.read_line(&mut h)?;
                if hn == 0 || h == "\r\n" || h == "\n" {
                    break;
                }
            }
            let mut buf = vec![0u8; content_len];
            reader.read_exact(&mut buf)?;
            let s = String::from_utf8(buf)
                .map_err(|e| io::Error::new(io::ErrorKind::InvalidData, e))?;
            return Ok(Some((s, WireFraming::ContentLength)));
        }
        return Ok(Some((trimmed.to_string(), WireFraming::Newline)));
    }
}

fn write_rpc_frame<W: Write>(writer: &mut W, payload: &str, framing: WireFraming) -> io::Result<()> {
    match framing {
        WireFraming::Newline => {
            writer.write_all(payload.as_bytes())?;
            writer.write_all(b"\n")?;
        }
        WireFraming::ContentLength => {
            write!(writer, "Content-Length: {}\r\n\r\n", payload.len())?;
            writer.write_all(payload.as_bytes())?;
        }
    }
    writer.flush()
}

struct SharedMuxState {
    client_framing: WireFraming,
    pending_tools_list: HashSet<String>,
    pending_init: HashSet<String>,
}

fn id_key(id: &Value) -> String {
    serde_json::to_string(id).unwrap_or_default()
}

fn spawn_upstream(upstream_bin: &str) -> Result<Child, String> {
    Command::new(upstream_bin)
        .args(["--deep", "mcp", "--all-tools"])
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .stderr(Stdio::inherit())
        .spawn()
        .map_err(|e| format!("Failed spawning upstream '{}': {}", upstream_bin, e))
}

fn run_mcp_multiplexer(upstream_bin: &str) -> Result<(), String> {
    let mut child = spawn_upstream(upstream_bin)?;
    let child_stdin = child.stdin.take().ok_or("Missing child stdin")?;
    let child_stdout = child.stdout.take().ok_or("Missing child stdout")?;

    let stdout_lock = Arc::new(Mutex::new(BufWriter::new(io::stdout())));
    let state = Arc::new(Mutex::new(SharedMuxState {
        client_framing: WireFraming::Newline,
        pending_tools_list: HashSet::new(),
        pending_init: HashSet::new(),
    }));

    // Pump Thread: Upstream (`craft-anything-cli`) -> Client (`stdout`)
    let out_for_up = Arc::clone(&stdout_lock);
    let state_for_up = Arc::clone(&state);
    let upstream_pump = std::thread::spawn(move || {
        let mut reader = BufReader::new(child_stdout);
        while let Ok(Some((raw_line, _up_framing))) = read_rpc_frame(&mut reader) {
            let mut out_payload = raw_line.clone();
            let framing = {
                let mut st = state_for_up.lock().unwrap();
                let f = st.client_framing;
                if let Ok(mut msg) = serde_json::from_str::<Value>(&raw_line) {
                    if let Some(id_val) = msg.get("id").cloned() {
                        let k = id_key(&id_val);
                        if st.pending_tools_list.remove(&k) {
                            let has_next_cursor = msg
                                .pointer("/result/nextCursor")
                                .map(|v| !v.is_null())
                                .unwrap_or(false);
                            if let Some(tools_arr) = msg
                                .pointer_mut("/result/tools")
                                .and_then(Value::as_array_mut)
                            {
                                for tool_item in tools_arr.iter_mut() {
                                    let alias_opt = tool_item
                                        .get("name")
                                        .and_then(Value::as_str)
                                        .and_then(shorten_upstream_tool_name);
                                    if let Some(short_name) = alias_opt {
                                        if let Some(obj) = tool_item.as_object_mut() {
                                            obj.insert(
                                                "name".into(),
                                                Value::String(short_name.to_string()),
                                            );
                                        }
                                    }
                                }
                                if !has_next_cursor {
                                    tools_arr.extend(plus_tool_schemas());
                                }
                                if let Ok(s) = serde_json::to_string(&msg) {
                                    out_payload = s;
                                }
                            }
                        } else if st.pending_init.remove(&k) {
                            if let Some(res_obj) =
                                msg.get_mut("result").and_then(Value::as_object_mut)
                            {
                                let prev = res_obj
                                    .get("instructions")
                                    .and_then(Value::as_str)
                                    .unwrap_or("");
                                let merged = format!(
                                    "{}\n\n[Craft Anything + Ghidra v0.5.0 ARM64 Plus]: Also includes 12 pure-Rust specialized tools: firmware_esp_uf2_show, firmware_dtb_fit_show, gpu_cuda_ptx_show, game_godot_pck_extract, game_il2cpp_meta_show, formats_beam_show, js_release_audit, retro_to_elf_convert (.dol/.com/ESP32/UF2/ROM -> ELF without Java), ghidra_headless_run, nativeaot_metadata_show, rl_har_env_build, and rl_har_env_serve.",
                                    prev
                                );
                                res_obj.insert("instructions".into(), Value::String(merged));
                                if let Ok(s) = serde_json::to_string(&msg) {
                                    out_payload = s;
                                }
                            }
                        }
                    }
                }
                f
            };

            if let Ok(mut out) = out_for_up.lock() {
                if write_rpc_frame(&mut *out, &out_payload, framing).is_err() {
                    break;
                }
            }
        }
    });

    // Main Thread: Client (`stdin`) -> Local `craft-plus` handler OR Upstream (`child_stdin`)
    let mut client_reader = BufReader::new(io::stdin());
    let mut up_writer = BufWriter::new(child_stdin);

    while let Ok(Some((raw_req, req_framing))) = read_rpc_frame(&mut client_reader) {
        if let Ok(mut st) = state.lock() {
            st.client_framing = req_framing;
        }

        let Ok(msg) = serde_json::from_str::<Value>(&raw_req) else {
            let _ = write_rpc_frame(&mut up_writer, &raw_req, WireFraming::Newline);
            continue;
        };

        let method = msg.get("method").and_then(Value::as_str).unwrap_or("");
        match method {
            "tools/call" => {
                let tool_name = msg
                    .pointer("/params/name")
                    .and_then(Value::as_str)
                    .unwrap_or("");
                if is_plus_tool(tool_name) {
                    let req_id = msg.get("id").cloned().unwrap_or(Value::Null);
                    let tool_args = msg
                        .pointer("/params/arguments")
                        .cloned()
                        .unwrap_or_else(|| json!({}));

                    // Execute plus tool on a worker thread so upstream traffic is never blocked
                    let tname_owned = tool_name.to_string();
                    let out_clone = Arc::clone(&stdout_lock);
                    std::thread::spawn(move || {
                        let resp_msg = match dispatch_plus_tool(&tname_owned, &tool_args) {
                            Ok(val) => {
                                let pretty = serde_json::to_string_pretty(&val)
                                    .unwrap_or_else(|_| "{}".into());
                                json!({
                                    "jsonrpc": "2.0",
                                    "id": req_id,
                                    "result": {
                                        "content": [{ "type": "text", "text": pretty }],
                                        "structuredContent": val,
                                        "isError": false
                                    }
                                })
                            }
                            Err(err_txt) => {
                                let err_obj = json!({ "error": err_txt, "tool": tname_owned });
                                json!({
                                    "jsonrpc": "2.0",
                                    "id": req_id,
                                    "result": {
                                        "content": [{ "type": "text", "text": serde_json::to_string_pretty(&err_obj).unwrap_or(err_txt) }],
                                        "isError": true
                                    }
                                })
                            }
                        };
                        if let Ok(line) = serde_json::to_string(&resp_msg) {
                            if let Ok(mut out) = out_clone.lock() {
                                let _ = write_rpc_frame(&mut *out, &line, req_framing);
                            }
                        }
                    });
                    continue;
                } else if let Some(upstream_long_name) = restore_upstream_tool_name(tool_name) {
                    let mut rewritten = msg.clone();
                    if let Some(params_obj) =
                        rewritten.get_mut("params").and_then(Value::as_object_mut)
                    {
                        params_obj.insert(
                            "name".into(),
                            Value::String(upstream_long_name.to_string()),
                        );
                    }
                    let payload = serde_json::to_string(&rewritten).unwrap_or(raw_req);
                    if write_rpc_frame(&mut up_writer, &payload, WireFraming::Newline).is_err() {
                        break;
                    }
                    continue;
                }
            }
            "tools/list" => {
                if let Some(id_val) = msg.get("id") {
                    if let Ok(mut st) = state.lock() {
                        st.pending_tools_list.insert(id_key(id_val));
                    }
                }
            }
            "initialize" => {
                if let Some(id_val) = msg.get("id") {
                    if let Ok(mut st) = state.lock() {
                        st.pending_init.insert(id_key(id_val));
                    }
                }
            }
            _ => {}
        }

        if write_rpc_frame(&mut up_writer, &raw_req, WireFraming::Newline).is_err() {
            break;
        }
    }

    drop(up_writer);
    rl_har::stop_all_servers();
    let _ = child.kill();
    let _ = child.wait();
    let _ = upstream_pump.join();
    Ok(())
}

// ============================================================================
// Comprehensive Unit Tests
// ============================================================================

#[cfg(test)]
mod tests {
    use super::*;
    use crate::sha256::sha256_hex;
    use std::io::Read;

    #[test]
    fn test_tool_names_respect_64_char_antigravity_mcp_limit() {
        let prefix = "mcp_craft-anything_craft-anything_";
        for &name in PLUS_TOOL_NAMES {
            let full = format!("{}{}", prefix, name);
            assert!(
                full.len() <= 64,
                "Tool '{}' prefixed length {} exceeds 64",
                full,
                full.len()
            );
        }
        for &(long_name, short_name) in UPSTREAM_TOOL_ALIASES {
            assert!(
                format!("{}{}", prefix, long_name).len() > 64,
                "Expected '{}' to exceed 64 before aliasing",
                long_name
            );
            let full_short = format!("{}{}", prefix, short_name);
            assert!(
                full_short.len() <= 64,
                "Alias '{}' prefixed length {} exceeds 64",
                full_short,
                full_short.len()
            );
            assert_eq!(shorten_upstream_tool_name(long_name), Some(short_name));
            assert_eq!(restore_upstream_tool_name(short_name), Some(long_name));
        }
        assert_eq!(plus_tool_schemas().len(), PLUS_TOOL_NAMES.len());
    }

    #[test]
    fn test_sha256_fips_vectors() {
        assert_eq!(
            sha256_hex(b""),
            "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
        );
        assert_eq!(
            sha256_hex(b"abc"),
            "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad"
        );
    }

    #[test]
    fn test_dol_to_elf_and_uf2_and_rl_har_roundtrip() {
        let tmp = env::temp_dir().join(format!("craft_plus_test_{}", std::process::id()));
        let _ = fs::create_dir_all(&tmp);

        // 1. Synthesize a valid Nintendo GameCube/Wii .dol binary and convert to PowerPC ELF
        let mut dol = vec![0u8; 0x140];
        // text0 offset = 0x100, load_addr = 0x80003100, size = 0x20
        dol[0..4].copy_from_slice(&0x100u32.to_be_bytes());
        dol[0x48..0x4C].copy_from_slice(&0x8000_3100u32.to_be_bytes());
        dol[0x90..0x94].copy_from_slice(&0x20u32.to_be_bytes());
        // bss = 0x80004000, size = 0x100, entry = 0x80003100
        dol[0xD8..0xDC].copy_from_slice(&0x8000_4000u32.to_be_bytes());
        dol[0xDC..0xE0].copy_from_slice(&0x100u32.to_be_bytes());
        dol[0xE0..0xE4].copy_from_slice(&0x8000_3100u32.to_be_bytes());
        // PowerPC `blr` (0x4e800020)
        dol[0x100..0x104].copy_from_slice(&0x4e80_0020u32.to_be_bytes());

        let dol_path = tmp.join("boot.dol");
        let elf_out = tmp.join("boot.elf");
        fs::write(&dol_path, &dol).unwrap();

        let res = dispatch_plus_tool(
            "retro_to_elf_convert",
            &json!({ "path": dol_path.to_str().unwrap(), "output_path": elf_out.to_str().unwrap() }),
        )
        .unwrap();
        assert_eq!(res["detected_format"], "dol");
        assert_eq!(res["e_machine"], 20); // EM_PPC
        let elf_bytes = fs::read(&elf_out).unwrap();
        assert_eq!(&elf_bytes[0..4], b"\x7fELF");
        assert_eq!(elf_bytes[5], 2); // Big-endian

        // 2. Synthesize an RP2040 UF2 block and inspect it
        let mut uf2 = vec![0u8; 512];
        uf2[0..4].copy_from_slice(&0x0A32_4655u32.to_le_bytes());
        uf2[4..8].copy_from_slice(&0x9E5D_5157u32.to_le_bytes());
        uf2[8..12].copy_from_slice(&0x0000_2000u32.to_le_bytes()); // familyID present
        uf2[12..16].copy_from_slice(&0x1000_0000u32.to_le_bytes());
        uf2[16..20].copy_from_slice(&16u32.to_le_bytes());
        uf2[20..24].copy_from_slice(&0u32.to_le_bytes());
        uf2[24..28].copy_from_slice(&1u32.to_le_bytes());
        uf2[28..32].copy_from_slice(&0xE48B_FF56u32.to_le_bytes()); // RP2040
        uf2[508..512].copy_from_slice(&0x0AB1_6F30u32.to_le_bytes());
        let uf2_path = tmp.join("pico.uf2");
        fs::write(&uf2_path, &uf2).unwrap();
        let uf2_res = dispatch_plus_tool(
            "firmware_esp_uf2_show",
            &json!({ "path": uf2_path.to_str().unwrap() }),
        )
        .unwrap();
        assert_eq!(uf2_res["format"], "uf2");
        assert_eq!(uf2_res["valid_blocks"], 1);

        // 3. Test RL HAR Environment Build + Live Rust HTTP Mock + Reward Evaluation
        let har_json = json!({
            "log": {
                "entries": [
                    {
                        "request": { "method": "GET", "url": "http://127.0.0.1:3000/api/folders" },
                        "response": {
                            "status": 200,
                            "content": { "mimeType": "application/json", "text": "[{\"id\":\"1\",\"name\":\"Inbox\"}]" }
                        }
                    },
                    {
                        "request": {
                            "method": "POST",
                            "url": "http://127.0.0.1:3000/api/folders",
                            "postData": { "text": "{\"name\":\"Projects\"}" }
                        },
                        "response": {
                            "status": 201,
                            "content": { "mimeType": "application/json", "text": "{\"id\":\"2\",\"name\":\"Projects\"}" }
                        }
                    }
                ]
            }
        });
        let har_path = tmp.join("session.har");
        let env_dir = tmp.join("my_rl_env");
        fs::write(&har_path, serde_json::to_string(&har_json).unwrap()).unwrap();

        let build_res = dispatch_plus_tool(
            "rl_har_env_build",
            &json!({
                "har_path": har_path.to_str().unwrap(),
                "output_dir": env_dir.to_str().unwrap(),
                "name": "folders-env"
            }),
        )
        .unwrap();
        assert_eq!(build_res["route_count"], 2);

        let srv_res = dispatch_plus_tool(
            "rl_har_env_serve",
            &json!({ "action": "start", "env_dir": env_dir.to_str().unwrap() }),
        )
        .unwrap();
        let port = srv_res["port"].as_u64().unwrap() as u16;

        // Before calling POST, reward should be 0.0
        let ev0 = dispatch_plus_tool(
            "rl_har_env_serve",
            &json!({ "action": "evaluate", "port": port }),
        )
        .unwrap();
        assert_eq!(ev0["reward"], 0.0);

        // Send a real HTTP POST to the Rust mock server!
        let mut sock = std::net::TcpStream::connect(("127.0.0.1", port)).unwrap();
        let body = b"{\"name\":\"Archive\"}";
        write!(
            sock,
            "POST /api/folders HTTP/1.1\r\nHost: 127.0.0.1\r\nContent-Length: {}\r\n\r\n",
            body.len()
        )
        .unwrap();
        sock.write_all(body).unwrap();
        let mut resp_str = String::new();
        sock.read_to_string(&mut resp_str).unwrap();
        assert!(resp_str.contains("201 Created"));
        assert!(resp_str.contains("Archive"));

        // Now reward must be 1.0!
        let ev1 = dispatch_plus_tool(
            "rl_har_env_serve",
            &json!({ "action": "evaluate", "port": port }),
        )
        .unwrap();
        assert_eq!(ev1["reward"], 1.0);

        dispatch_plus_tool(
            "rl_har_env_serve",
            &json!({ "action": "stop", "port": port }),
        )
        .unwrap();

        let _ = fs::remove_dir_all(&tmp);
    }
}
