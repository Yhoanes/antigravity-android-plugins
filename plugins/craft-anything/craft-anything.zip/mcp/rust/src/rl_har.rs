//! Block 3 (100% Pure Rust, Zero Docker, Zero Python):
//! - `rl_har_env_build`: Converts recorded `.har` (HTTP Archive) web sessions into portable RL environments
//!   (`env_manifest.json`, `openapi.json`, `agent_tools.json`, `reward_checks.json`).
//! - `rl_har_env_serve`: Deterministic in-process Rust HTTP stateful mock & RL evaluator server on `127.0.0.1:<port>`
//!   with `/__rl/reset`, `/__rl/trace`, and `/__rl/evaluate` endpoints (`<2 MB` RAM).

use serde::{Deserialize, Serialize};
use serde_json::{json, Map, Value};
use std::collections::{BTreeMap, HashMap};
use std::fs;
use std::io::{BufRead, BufReader, Read, Write};
use std::net::{TcpListener, TcpStream};
use std::path::Path;
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::{Arc, Mutex, OnceLock};
use std::time::Duration;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RecordedFixture {
    pub method: String,
    pub raw_path: String,
    pub route_pattern: String,
    pub status: u16,
    pub content_type: String,
    pub request_sample: Option<Value>,
    pub response_body: Value,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RewardCheck {
    pub id: String,
    pub description: String,
    /// `"collection_contains"`, `"collection_not_contains"`, `"method_called"`
    pub kind: String,
    pub target: String,
    pub expected_field: Option<String>,
    pub expected_value: Option<Value>,
    pub weight: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct EnvManifest {
    pub name: String,
    pub source_har: String,
    pub base_origins: Vec<String>,
    pub routes: Vec<RouteSummary>,
    pub seed_collections: BTreeMap<String, Vec<Value>>,
    pub fixtures: Vec<RecordedFixture>,
    pub reward_checks: Vec<RewardCheck>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RouteSummary {
    pub method: String,
    pub pattern: String,
    pub collection: Option<String>,
    pub sample_status: u16,
    pub tool_name: String,
}

// ============================================================================
// 1. HAR -> RL Environment Builder (`rl_har_env_build`)
// ============================================================================

pub fn tool_rl_har_env_build(args: &Value) -> Result<Value, String> {
    let har_path = args
        .get("har_path")
        .and_then(Value::as_str)
        .ok_or("Missing required string parameter 'har_path'")?;
    let out_dir_str = args
        .get("output_dir")
        .and_then(Value::as_str)
        .ok_or("Missing required string parameter 'output_dir'")?;
    let env_name = args
        .get("name")
        .and_then(Value::as_str)
        .unwrap_or("craft-rl-env");
    let include_static = args
        .get("include_static")
        .and_then(Value::as_bool)
        .unwrap_or(false);

    let raw = fs::read_to_string(har_path)
        .map_err(|e| format!("Failed reading HAR '{}': {}", har_path, e))?;
    let har: Value =
        serde_json::from_str(&raw).map_err(|e| format!("Invalid HAR JSON '{}': {}", har_path, e))?;

    let entries = har
        .pointer("/log/entries")
        .and_then(Value::as_array)
        .ok_or("HAR file missing `log.entries` array")?;

    let mut origins = Vec::new();
    let mut fixtures = Vec::new();
    let mut route_map: BTreeMap<(String, String), RouteSummary> = BTreeMap::new();
    let mut seed_collections: BTreeMap<String, Vec<Value>> = BTreeMap::new();

    for ent in entries {
        let method = ent
            .pointer("/request/method")
            .and_then(Value::as_str)
            .unwrap_or("GET")
            .to_ascii_uppercase();
        if method == "OPTIONS" {
            continue;
        }
        let Some(url) = ent.pointer("/request/url").and_then(Value::as_str) else {
            continue;
        };
        let (origin, raw_path) = split_url(url);
        if !origin.is_empty() && !origins.contains(&origin) {
            origins.push(origin);
        }

        if !include_static && is_static_asset_path(&raw_path) {
            continue;
        }

        let status = ent
            .pointer("/response/status")
            .and_then(Value::as_u64)
            .unwrap_or(200) as u16;
        if status == 0 {
            continue;
        }
        let mime = ent
            .pointer("/response/content/mimeType")
            .and_then(Value::as_str)
            .unwrap_or("application/json")
            .to_string();

        let req_text = ent.pointer("/request/postData/text").and_then(Value::as_str);
        let req_sample = req_text.map(|t| {
            serde_json::from_str::<Value>(t).unwrap_or_else(|_| Value::String(t.chars().take(2048).collect()))
        });

        let resp_text = ent
            .pointer("/response/content/text")
            .and_then(Value::as_str)
            .unwrap_or("{}");
        let resp_val = serde_json::from_str::<Value>(resp_text)
            .unwrap_or_else(|_| json!({ "_raw_text": resp_text.chars().take(8192).collect::<String>() }));

        let path_no_q = raw_path.split('?').next().unwrap_or(&raw_path);
        let (pattern, collection) = normalize_route_pattern(path_no_q);

        // Seed collection state from recorded GET list responses
        if method == "GET" && (200..300).contains(&status) {
            if let Some(ref col) = collection {
                if !pattern.ends_with("/{id}") {
                    if let Some(arr) = resp_val.as_array() {
                        seed_collections
                            .entry(col.clone())
                            .or_insert_with(|| arr.clone());
                    } else if let Some(arr) = resp_val
                        .as_object()
                        .and_then(|o| o.get("items").or_else(|| o.get("data")).or_else(|| o.get(col)))
                        .and_then(Value::as_array)
                    {
                        seed_collections
                            .entry(col.clone())
                            .or_insert_with(|| arr.clone());
                    }
                }
            }
        }

        let key = (method.clone(), pattern.clone());
        route_map.entry(key).or_insert_with(|| RouteSummary {
            tool_name: make_tool_identifier(&method, &pattern),
            method: method.clone(),
            pattern: pattern.clone(),
            collection: collection.clone(),
            sample_status: status,
        });

        fixtures.push(RecordedFixture {
            method,
            raw_path,
            route_pattern: pattern,
            status,
            content_type: mime,
            request_sample: req_sample,
            response_body: resp_val,
        });
    }

    if fixtures.is_empty() {
        return Err("No API/HTTP entries remained in HAR after filtering static assets (pass include_static=true to include HTML/static files)".into());
    }

    let routes: Vec<RouteSummary> = route_map.into_values().collect();

    // Auto-generate sensible starter RL reward checks
    let mut reward_checks = Vec::new();
    for r in &routes {
        if matches!(r.method.as_str(), "POST" | "PUT" | "PATCH" | "DELETE") {
            reward_checks.push(RewardCheck {
                id: format!("called_{}", r.tool_name),
                description: format!("Verify agent invoked {} {}", r.method, r.pattern),
                kind: "method_called".into(),
                target: format!("{} {}", r.method, r.pattern),
                expected_field: None,
                expected_value: None,
                weight: 1.0,
            });
            break;
        }
    }
    if reward_checks.is_empty() {
        if let Some(first) = routes.first() {
            reward_checks.push(RewardCheck {
                id: format!("called_{}", first.tool_name),
                description: format!("Verify agent queried {} {}", first.method, first.pattern),
                kind: "method_called".into(),
                target: format!("{} {}", first.method, first.pattern),
                expected_field: None,
                expected_value: None,
                weight: 1.0,
            });
        }
    }

    let manifest = EnvManifest {
        name: env_name.to_string(),
        source_har: har_path.to_string(),
        base_origins: origins.clone(),
        routes: routes.clone(),
        seed_collections: seed_collections.clone(),
        fixtures,
        reward_checks: reward_checks.clone(),
    };

    let out_dir = Path::new(out_dir_str);
    fs::create_dir_all(out_dir)
        .map_err(|e| format!("Failed creating output_dir '{}': {}", out_dir_str, e))?;

    let manifest_path = out_dir.join("env_manifest.json");
    let openapi_path = out_dir.join("openapi.json");
    let tools_path = out_dir.join("agent_tools.json");
    let rewards_path = out_dir.join("reward_checks.json");

    fs::write(
        &manifest_path,
        serde_json::to_string_pretty(&manifest).unwrap_or_default(),
    )
    .map_err(|e| format!("Failed writing env_manifest.json: {}", e))?;

    let openapi = build_openapi_spec(env_name, &routes);
    fs::write(
        &openapi_path,
        serde_json::to_string_pretty(&openapi).unwrap_or_default(),
    )
    .map_err(|e| format!("Failed writing openapi.json: {}", e))?;

    let agent_tools = build_agent_tools(&routes);
    fs::write(
        &tools_path,
        serde_json::to_string_pretty(&agent_tools).unwrap_or_default(),
    )
    .map_err(|e| format!("Failed writing agent_tools.json: {}", e))?;

    fs::write(
        &rewards_path,
        serde_json::to_string_pretty(&reward_checks).unwrap_or_default(),
    )
    .map_err(|e| format!("Failed writing reward_checks.json: {}", e))?;

    Ok(json!({
        "env_name": env_name,
        "output_dir": out_dir_str,
        "origins": origins,
        "route_count": routes.len(),
        "seed_collections": seed_collections.keys().collect::<Vec<_>>(),
        "routes": routes,
        "files_written": [
            manifest_path.to_string_lossy(),
            openapi_path.to_string_lossy(),
            tools_path.to_string_lossy(),
            rewards_path.to_string_lossy(),
        ],
        "serve_hint": format!(
            "Call rl_har_env_serve with action='start' and env_dir='{}' to launch the stateful Rust HTTP mock & RL evaluator on 127.0.0.1 without Docker.",
            out_dir_str
        ),
    }))
}

fn split_url(url: &str) -> (String, String) {
    if let Some(idx) = url.find("://") {
        let rest = &url[idx + 3..];
        if let Some(slash) = rest.find('/') {
            let origin = url[..idx + 3 + slash].to_string();
            let path = rest[slash..].to_string();
            return (origin, path);
        }
        return (url.to_string(), "/".into());
    }
    (String::new(), url.to_string())
}

fn is_static_asset_path(p: &str) -> bool {
    let clean = p.split('?').next().unwrap_or(p).to_ascii_lowercase();
    for ext in [
        ".png", ".jpg", ".jpeg", ".gif", ".webp", ".svg", ".ico", ".woff", ".woff2", ".ttf",
        ".css", ".map", ".mp4", ".webm", ".mp3",
    ] {
        if clean.ends_with(ext) {
            return true;
        }
    }
    false
}

fn looks_like_id_segment(seg: &str) -> bool {
    if seg.is_empty() {
        return false;
    }
    if seg.chars().all(|c| c.is_ascii_digit()) {
        return true;
    }
    // UUID or long hex/slug ID
    if seg.len() >= 16 && seg.chars().all(|c| c.is_ascii_hexdigit() || c == '-') {
        return true;
    }
    false
}

fn normalize_route_pattern(path: &str) -> (String, Option<String>) {
    let segs: Vec<&str> = path.split('/').filter(|s| !s.is_empty()).collect();
    if segs.is_empty() {
        return ("/".into(), None);
    }
    let mut norm = Vec::with_capacity(segs.len());
    let mut collection = None;
    for (i, &s) in segs.iter().enumerate() {
        if looks_like_id_segment(s) {
            norm.push("{id}");
            if i > 0 && collection.is_none() {
                collection = Some(segs[i - 1].to_string());
            }
        } else {
            norm.push(s);
        }
    }
    if collection.is_none() {
        if let Some(&last) = norm.last() {
            if last != "{id}" && !matches!(last, "v1" | "v2" | "v3" | "api" | "graphql") {
                collection = Some(last.to_string());
            }
        }
    }
    (format!("/{}", norm.join("/")), collection)
}

fn make_tool_identifier(method: &str, pattern: &str) -> String {
    let cleaned: String = pattern
        .chars()
        .map(|c| {
            if c.is_ascii_alphanumeric() {
                c.to_ascii_lowercase()
            } else {
                '_'
            }
        })
        .collect();
    let compact = cleaned
        .split('_')
        .filter(|s| !s.is_empty())
        .collect::<Vec<_>>()
        .join("_");
    format!("{}_{}", method.to_ascii_lowercase(), if compact.is_empty() { "root" } else { &compact })
}

fn build_openapi_spec(name: &str, routes: &[RouteSummary]) -> Value {
    let mut paths = Map::new();
    for r in routes {
        let entry = paths
            .entry(r.pattern.clone())
            .or_insert_with(|| Value::Object(Map::new()));
        if let Some(obj) = entry.as_object_mut() {
            obj.insert(
                r.method.to_ascii_lowercase(),
                json!({
                    "operationId": r.tool_name,
                    "responses": {
                        r.sample_status.to_string(): { "description": "Recorded HAR response" }
                    }
                }),
            );
        }
    }
    json!({
        "openapi": "3.1.0",
        "info": { "title": name, "version": "1.0.0" },
        "paths": paths,
    })
}

fn build_agent_tools(routes: &[RouteSummary]) -> Value {
    let tools: Vec<Value> = routes
        .iter()
        .map(|r| {
            json!({
                "name": r.tool_name,
                "description": format!("Execute {} {}", r.method, r.pattern),
                "method": r.method,
                "path_template": r.pattern,
                "parameters": {
                    "type": "object",
                    "properties": {
                        "id": { "type": "string", "description": "Path {id} parameter when present" },
                        "query": { "type": "string", "description": "Optional query string" },
                        "body": { "type": "object", "description": "JSON request payload" }
                    }
                }
            })
        })
        .collect();
    json!({ "tools": tools })
}

// ============================================================================
// 2. Deterministic In-Process Rust Stateful HTTP Mock & RL Evaluator (`rl_har_env_serve`)
// ============================================================================

struct RunningEnvServer {
    env_dir: String,
    port: u16,
    stop_flag: Arc<AtomicBool>,
    state: Arc<Mutex<RuntimeState>>,
}

struct RuntimeState {
    collections: BTreeMap<String, Vec<Value>>,
    trace: Vec<TraceEvent>,
    next_id: u64,
}

#[derive(Debug, Clone, Serialize)]
struct TraceEvent {
    seq: usize,
    method: String,
    path: String,
    pattern: String,
    status: u16,
}

fn server_registry() -> &'static Mutex<HashMap<u16, RunningEnvServer>> {
    static REG: OnceLock<Mutex<HashMap<u16, RunningEnvServer>>> = OnceLock::new();
    REG.get_or_init(|| Mutex::new(HashMap::new()))
}

pub fn stop_all_servers() {
    if let Ok(mut map) = server_registry().lock() {
        for (_, srv) in map.drain() {
            srv.stop_flag.store(true, Ordering::SeqCst);
            let _ = TcpStream::connect(("127.0.0.1", srv.port));
        }
    }
}

pub fn tool_rl_har_env_serve(args: &Value) -> Result<Value, String> {
    let action = args
        .get("action")
        .and_then(Value::as_str)
        .unwrap_or("status")
        .to_ascii_lowercase();

    match action.as_str() {
        "start" => {
            let env_dir = args
                .get("env_dir")
                .and_then(Value::as_str)
                .ok_or("Missing 'env_dir' for action='start'")?;
            let req_port = args.get("port").and_then(Value::as_u64).unwrap_or(0) as u16;
            if req_port == 45157 || req_port == 45158 {
                return Err("Ports 45157 and 45158 are reserved for Antigravity core; pick e.g. 18080 or 0 (auto)".into());
            }

            let manifest_path = Path::new(env_dir).join("env_manifest.json");
            let m_txt = fs::read_to_string(&manifest_path).map_err(|e| {
                format!(
                    "Cannot read '{}': {} (build the environment first with rl_har_env_build)",
                    manifest_path.display(),
                    e
                )
            })?;
            let mut manifest: EnvManifest = serde_json::from_str(&m_txt)
                .map_err(|e| format!("Invalid env_manifest.json: {}", e))?;

            // Reload custom `reward_checks.json` if user/agent edited it!
            let rewards_path = Path::new(env_dir).join("reward_checks.json");
            if let Ok(r_txt) = fs::read_to_string(&rewards_path) {
                if let Ok(custom_checks) = serde_json::from_str::<Vec<RewardCheck>>(&r_txt) {
                    manifest.reward_checks = custom_checks;
                }
            }

            let listener = TcpListener::bind(("127.0.0.1", req_port))
                .map_err(|e| format!("Failed binding 127.0.0.1:{}: {}", req_port, e))?;
            let _ = listener.set_nonblocking(true);
            let actual_port = listener
                .local_addr()
                .map_err(|e| format!("local_addr error: {}", e))?
                .port();

            let stop_flag = Arc::new(AtomicBool::new(false));
            let rt_state = Arc::new(Mutex::new(RuntimeState {
                collections: manifest.seed_collections.clone(),
                trace: Vec::new(),
                next_id: 1000,
            }));

            let stop_clone = Arc::clone(&stop_flag);
            let state_clone = Arc::clone(&rt_state);
            let manifest_arc = Arc::new(manifest.clone());

            std::thread::spawn(move || {
                run_http_loop(listener, stop_clone, state_clone, manifest_arc);
            });

            if let Ok(mut reg) = server_registry().lock() {
                reg.insert(
                    actual_port,
                    RunningEnvServer {
                        env_dir: env_dir.to_string(),
                        port: actual_port,
                        stop_flag,
                        state: rt_state,
                    },
                );
            }

            Ok(json!({
                "status": "running",
                "base_url": format!("http://127.0.0.1:{}", actual_port),
                "port": actual_port,
                "env_name": manifest.name,
                "routes_mounted": manifest.routes.len(),
                "control_endpoints": {
                    "reset": format!("POST http://127.0.0.1:{}/__rl/reset", actual_port),
                    "trace": format!("GET http://127.0.0.1:{}/__rl/trace", actual_port),
                    "evaluate": format!("POST http://127.0.0.1:{}/__rl/evaluate", actual_port),
                }
            }))
        }
        "status" => {
            let reg = server_registry().lock().map_err(|_| "Lock poisoned")?;
            let list: Vec<Value> = reg
                .values()
                .map(|s| {
                    let trace_len = s.state.lock().map(|st| st.trace.len()).unwrap_or(0);
                    json!({
                        "port": s.port,
                        "base_url": format!("http://127.0.0.1:{}", s.port),
                        "env_dir": s.env_dir,
                        "requests_handled": trace_len,
                    })
                })
                .collect();
            Ok(json!({ "active_servers": list }))
        }
        "evaluate" => {
            let port = resolve_target_port(args)?;
            let (env_dir, snapshot_cols, snapshot_trace) = {
                let reg = server_registry().lock().map_err(|_| "Lock poisoned")?;
                let srv = reg
                    .get(&port)
                    .ok_or_else(|| format!("No running RL mock server on port {}", port))?;
                let st = srv.state.lock().map_err(|_| "State lock poisoned")?;
                (srv.env_dir.clone(), st.collections.clone(), st.trace.clone())
            };
            let checks = load_reward_checks(Path::new(&env_dir));
            Ok(evaluate_checks(&checks, &snapshot_cols, &snapshot_trace))
        }
        "reset" => {
            let port = resolve_target_port(args)?;
            let env_dir = {
                let reg = server_registry().lock().map_err(|_| "Lock poisoned")?;
                reg.get(&port)
                    .ok_or_else(|| format!("No running RL mock server on port {}", port))?
                    .env_dir
                    .clone()
            };
            let m_txt = fs::read_to_string(Path::new(&env_dir).join("env_manifest.json"))
                .map_err(|e| format!("Failed reloading manifest: {}", e))?;
            let manifest: EnvManifest =
                serde_json::from_str(&m_txt).map_err(|e| format!("Invalid manifest: {}", e))?;
            let reg = server_registry().lock().map_err(|_| "Lock poisoned")?;
            if let Some(srv) = reg.get(&port) {
                if let Ok(mut st) = srv.state.lock() {
                    st.collections = manifest.seed_collections;
                    st.trace.clear();
                    st.next_id = 1000;
                }
            }
            Ok(json!({ "status": "reset_complete", "port": port }))
        }
        "stop" => {
            let port = resolve_target_port(args)?;
            let removed = server_registry()
                .lock()
                .map_err(|_| "Lock poisoned")?
                .remove(&port);
            if let Some(srv) = removed {
                srv.stop_flag.store(true, Ordering::SeqCst);
                let _ = TcpStream::connect(("127.0.0.1", port));
                Ok(json!({ "status": "stopped", "port": port }))
            } else {
                Err(format!("No running RL mock server on port {}", port))
            }
        }
        other => Err(format!(
            "Unsupported action '{}'. Expected: start, status, evaluate, reset, stop",
            other
        )),
    }
}

fn resolve_target_port(args: &Value) -> Result<u16, String> {
    if let Some(p) = args.get("port").and_then(Value::as_u64) {
        return Ok(p as u16);
    }
    let reg = server_registry().lock().map_err(|_| "Lock poisoned")?;
    if reg.len() == 1 {
        return Ok(*reg.keys().next().unwrap());
    }
    Err("Specify 'port' (multiple or zero RL mock servers currently active)".into())
}

fn load_reward_checks(env_dir: &Path) -> Vec<RewardCheck> {
    if let Ok(txt) = fs::read_to_string(env_dir.join("reward_checks.json")) {
        if let Ok(v) = serde_json::from_str::<Vec<RewardCheck>>(&txt) {
            return v;
        }
    }
    Vec::new()
}

fn evaluate_checks(
    checks: &[RewardCheck],
    collections: &BTreeMap<String, Vec<Value>>,
    trace: &[TraceEvent],
) -> Value {
    if checks.is_empty() {
        return json!({
            "reward": 1.0,
            "passed": true,
            "note": "No reward checks configured",
            "trace_events": trace.len(),
        });
    }
    let mut earned = 0.0f64;
    let mut total_w = 0.0f64;
    let mut details = Vec::new();

    for c in checks {
        let w = c.weight.max(0.0);
        total_w += w;
        let ok = match c.kind.as_str() {
            "method_called" => trace
                .iter()
                .any(|ev| format!("{} {}", ev.method, ev.pattern).eq_ignore_ascii_case(&c.target)
                    || format!("{} {}", ev.method, ev.path).eq_ignore_ascii_case(&c.target)),
            "collection_contains" => {
                if let (Some(items), Some(field), Some(exp)) = (
                    collections.get(&c.target),
                    c.expected_field.as_deref(),
                    c.expected_value.as_ref(),
                ) {
                    items.iter().any(|item| item.get(field) == Some(exp))
                } else {
                    false
                }
            }
            "collection_not_contains" => {
                if let (Some(items), Some(field), Some(exp)) = (
                    collections.get(&c.target),
                    c.expected_field.as_deref(),
                    c.expected_value.as_ref(),
                ) {
                    !items.iter().any(|item| item.get(field) == Some(exp))
                } else {
                    true
                }
            }
            _ => false,
        };
        if ok {
            earned += w;
        }
        details.push(json!({
            "id": c.id,
            "description": c.description,
            "passed": ok,
            "weight": w,
        }));
    }

    let score = if total_w > 0.0 { earned / total_w } else { 1.0 };
    json!({
        "reward": (score * 10000.0).round() / 10000.0,
        "passed": (score - 1.0).abs() < 1e-9,
        "checks": details,
        "trace_events": trace.len(),
    })
}

fn run_http_loop(
    listener: TcpListener,
    stop_flag: Arc<AtomicBool>,
    state: Arc<Mutex<RuntimeState>>,
    manifest: Arc<EnvManifest>,
) {
    while !stop_flag.load(Ordering::Relaxed) {
        match listener.accept() {
            Ok((stream, _)) => {
                if stop_flag.load(Ordering::Relaxed) {
                    break;
                }
                let _ = handle_http_conn(stream, &state, &manifest);
            }
            Err(ref e) if e.kind() == std::io::ErrorKind::WouldBlock => {
                std::thread::sleep(Duration::from_millis(25));
            }
            Err(_) => break,
        }
    }
}

fn handle_http_conn(
    mut stream: TcpStream,
    state: &Arc<Mutex<RuntimeState>>,
    manifest: &EnvManifest,
) -> std::io::Result<()> {
    let _ = stream.set_nonblocking(false);
    let _ = stream.set_read_timeout(Some(Duration::from_secs(5)));
    let _ = stream.set_write_timeout(Some(Duration::from_secs(5)));

    let mut reader = BufReader::new(stream.try_clone()?);
    let mut req_line = String::new();
    if reader.read_line(&mut req_line)? == 0 {
        return Ok(());
    }
    let parts: Vec<&str> = req_line.trim().split_whitespace().collect();
    if parts.len() < 2 {
        return Ok(());
    }
    let method = parts[0].to_ascii_uppercase();
    let raw_target = parts[1].to_string();

    let mut content_len = 0usize;
    loop {
        let mut hline = String::new();
        if reader.read_line(&mut hline)? == 0 || hline == "\r\n" || hline == "\n" {
            break;
        }
        if let Some((k, v)) = hline.split_once(':') {
            if k.trim().eq_ignore_ascii_case("content-length") {
                content_len = v.trim().parse::<usize>().unwrap_or(0).min(2 * 1024 * 1024);
            }
        }
    }

    let mut body_bytes = vec![0u8; content_len];
    if content_len > 0 {
        reader.read_exact(&mut body_bytes)?;
    }
    let req_json = serde_json::from_slice::<Value>(&body_bytes).ok();

    let path_only = raw_target.split('?').next().unwrap_or(&raw_target);

    // Built-in RL control plane routes
    if path_only == "/__rl/reset" {
        if let Ok(mut st) = state.lock() {
            st.collections = manifest.seed_collections.clone();
            st.trace.clear();
            st.next_id = 1000;
        }
        return write_json_resp(&mut stream, 200, &json!({ "ok": true, "reset": true }));
    }
    if path_only == "/__rl/trace" {
        let trace_val = state
            .lock()
            .map(|st| serde_json::to_value(&st.trace).unwrap_or(json!([])))
            .unwrap_or(json!([]));
        return write_json_resp(&mut stream, 200, &json!({ "trace": trace_val }));
    }
    if path_only == "/__rl/evaluate" {
        let eval = if let Ok(st) = state.lock() {
            evaluate_checks(&manifest.reward_checks, &st.collections, &st.trace)
        } else {
            json!({ "reward": 0.0 })
        };
        return write_json_resp(&mut stream, 200, &eval);
    }

    let (pattern, col_opt) = normalize_route_pattern(path_only);
    let last_seg = path_only.rsplit('/').next().unwrap_or("");

    let mut resp_status = 404u16;
    let mut resp_val = json!({ "error": "Not found in recorded HAR environment", "path": raw_target });

    if let Ok(mut st) = state.lock() {
        // 1. Stateful CRUD on seeded or dynamic collections
        if let Some(ref col) = col_opt {
            if method == "POST" && !pattern.ends_with("/{id}") {
                let id_str = st.next_id.to_string();
                st.next_id += 1;
                let mut new_item = req_json.clone().unwrap_or_else(|| json!({}));
                if let Some(obj) = new_item.as_object_mut() {
                    obj.entry("id").or_insert_with(|| json!(id_str));
                }
                st.collections
                    .entry(col.clone())
                    .or_default()
                    .push(new_item.clone());
                resp_status = 201;
                resp_val = new_item;
            } else if method == "GET" && !pattern.ends_with("/{id}") && st.collections.contains_key(col) {
                resp_status = 200;
                resp_val = Value::Array(st.collections.get(col).cloned().unwrap_or_default());
            } else if pattern.ends_with("/{id}") && st.collections.contains_key(col) {
                let items = st.collections.entry(col.clone()).or_default();
                match method.as_str() {
                    "GET" => {
                        if let Some(found) = items.iter().find(|it| id_matches(it, last_seg)) {
                            resp_status = 200;
                            resp_val = found.clone();
                        }
                    }
                    "PUT" | "PATCH" => {
                        if let Some(found) = items.iter_mut().find(|it| id_matches(it, last_seg)) {
                            if let (Some(dst), Some(src)) = (found.as_object_mut(), req_json.and_then(|v| v.as_object().cloned())) {
                                for (k, v) in src {
                                    dst.insert(k, v);
                                }
                            }
                            resp_status = 200;
                            resp_val = found.clone();
                        }
                    }
                    "DELETE" => {
                        let before = items.len();
                        items.retain(|it| !id_matches(it, last_seg));
                        if items.len() < before {
                            resp_status = 200;
                            resp_val = json!({ "deleted": last_seg });
                        }
                    }
                    _ => {}
                }
            }
        }

        // 2. Fallback to exact raw_path + method HAR fixture, then pattern + method HAR fixture
        if resp_status == 404 {
            if let Some(fx) = manifest
                .fixtures
                .iter()
                .find(|f| f.method == method && f.raw_path == raw_target)
                .or_else(|| {
                    manifest
                        .fixtures
                        .iter()
                        .find(|f| f.method == method && f.route_pattern == pattern)
                })
            {
                resp_status = fx.status;
                resp_val = fx.response_body.clone();
            }
        }

        let seq = st.trace.len() + 1;
        st.trace.push(TraceEvent {
            seq,
            method,
            path: raw_target,
            pattern,
            status: resp_status,
        });
    }

    write_json_resp(&mut stream, resp_status, &resp_val)
}

fn id_matches(item: &Value, seg: &str) -> bool {
    let Some(v) = item.get("id") else { return false };
    match v {
        Value::String(s) => s == seg,
        Value::Number(n) => n.to_string() == seg,
        _ => false,
    }
}

fn write_json_resp(stream: &mut TcpStream, status: u16, body: &Value) -> std::io::Result<()> {
    let payload = serde_json::to_vec(body).unwrap_or_else(|_| b"{}".to_vec());
    let reason = match status {
        200 => "OK",
        201 => "Created",
        204 => "No Content",
        400 => "Bad Request",
        404 => "Not Found",
        _ => "Response",
    };
    write!(
        stream,
        "HTTP/1.1 {} {}\r\nContent-Type: application/json; charset=utf-8\r\nAccess-Control-Allow-Origin: *\r\nContent-Length: {}\r\nConnection: close\r\n\r\n",
        status,
        reason,
        payload.len()
    )?;
    stream.write_all(&payload)?;
    stream.flush()
}
