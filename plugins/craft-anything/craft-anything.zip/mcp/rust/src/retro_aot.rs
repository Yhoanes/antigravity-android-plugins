//! Block 2 (100% Pure Rust):
//! - `retro_to_elf_convert`: Nintendo GameCube/Wii `.dol`, DOS `.com`, ESP32 `0xE9`, UF2 & Raw Console/MCU ROMs -> Standard ELF32/ELF64
//! - `ghidra_headless_run`: Mobile-safe ARM64 Ghidra 12.1.4 headless runner with auto-ELF conversion & C decompilation JSON export
//! - `nativeaot_metadata_show`: .NET 7/8/9/10 NativeAOT, ReadyToRun (`RTR\0`) & Single-File bundle inspector

use crate::elf_synth::{build_elf, ArchSpec, SynthSection, SynthSymbol};
use crate::firmware::{extract_firmware_segments, sanitize_filename};
use crate::sha256::sha256_hex;
use serde_json::{json, Value};
use std::collections::BTreeMap;
use std::fs;
use std::path::{Path, PathBuf};
use std::process::{Command, Stdio};
use std::time::{Duration, Instant};

fn u16_le(b: &[u8], o: usize) -> Option<u16> {
    Some(u16::from_le_bytes(b.get(o..o + 2)?.try_into().ok()?))
}
fn u32_le(b: &[u8], o: usize) -> Option<u32> {
    Some(u32::from_le_bytes(b.get(o..o + 4)?.try_into().ok()?))
}
fn u64_le(b: &[u8], o: usize) -> Option<u64> {
    Some(u64::from_le_bytes(b.get(o..o + 8)?.try_into().ok()?))
}
fn u32_be(b: &[u8], o: usize) -> Option<u32> {
    Some(u32::from_be_bytes(b.get(o..o + 4)?.try_into().ok()?))
}

fn parse_addr_arg(v: Option<&Value>, default: u64) -> Result<u64, String> {
    let Some(val) = v else { return Ok(default) };
    if let Some(n) = val.as_u64() {
        return Ok(n);
    }
    if let Some(s) = val.as_str() {
        let t = s.trim();
        if let Some(hex) = t.strip_prefix("0x").or_else(|| t.strip_prefix("0X")) {
            return u64::from_str_radix(&hex.replace('_', ""), 16)
                .map_err(|e| format!("Invalid hex address '{}': {}", s, e));
        }
        return t
            .parse::<u64>()
            .map_err(|e| format!("Invalid integer address '{}': {}", s, e));
    }
    Err("Address parameter must be an integer or hex string like '0x08000000'".into())
}

fn dot_free_tmp_dir() -> PathBuf {
    if let Ok(p) = std::env::var("PREFIX") {
        let candidate = PathBuf::from(&p).join("tmp");
        if !candidate.to_string_lossy().contains("/.") {
            return candidate;
        }
    }
    PathBuf::from("/data/user/0/com.agy/files/usr/tmp")
}

// ============================================================================
// 1. Retro / Console / Firmware -> Standard ELF Synthesizer (`retro_to_elf_convert`)
// ============================================================================

pub fn tool_retro_to_elf_convert(args: &Value) -> Result<Value, String> {
    let path_str = args
        .get("path")
        .and_then(Value::as_str)
        .ok_or("Missing required string parameter 'path'")?;
    let format_req = args
        .get("format")
        .and_then(Value::as_str)
        .unwrap_or("auto")
        .trim()
        .to_ascii_lowercase();
    let arch_override = args.get("arch").and_then(Value::as_str);

    let data = fs::read(path_str).map_err(|e| format!("Failed reading '{}': {}", path_str, e))?;
    if data.is_empty() {
        return Err("Input file is empty".into());
    }

    let in_path = Path::new(path_str);
    let ext = in_path
        .extension()
        .and_then(|e| e.to_str())
        .unwrap_or("")
        .to_ascii_lowercase();
    let stem = sanitize_filename(
        in_path
            .file_stem()
            .and_then(|s| s.to_str())
            .unwrap_or("target"),
    );

    let detected_fmt = if format_req != "auto" {
        format_req
    } else if is_likely_dol(&data) || ext == "dol" {
        "dol".into()
    } else if data.len() >= 512
        && u32_le(&data, 0) == Some(0x0A32_4655)
        && u32_le(&data, 4) == Some(0x9E5D_5157)
    {
        "uf2".into()
    } else if data[0] == 0xE9 && data.len() >= 24 && (1..=24).contains(&data[1]) {
        "esp32".into()
    } else if ext == "com" && data.len() <= 65280 {
        "dos_com".into()
    } else {
        "raw".into()
    };

    let (arch, entry, sections, symbols, extra_meta) = match detected_fmt.as_str() {
        "dol" => convert_dol(&data, arch_override)?,
        "dos_com" | "com" | "dos" => {
            let base = parse_addr_arg(args.get("base_addr"), 0x0100)?;
            convert_dos_com(&data, base, arch_override)?
        }
        "esp32" | "uf2" => convert_firmware(&data, arch_override)?,
        "raw" => {
            let arch_name = arch_override.ok_or(
                "For format='raw', please specify 'arch' (e.g. 'arm', 'thumb', 'aarch64', 'mips', 'mipsel', 'ppc', 'riscv32', 'xtensa', 'x86', 'm68k', 'sh4')",
            )?;
            let arch = ArchSpec::from_name(arch_name)?;
            let base = parse_addr_arg(args.get("base_addr"), 0x0800_0000)?;
            let entry = parse_addr_arg(args.get("entry_addr"), base)?;
            let file_off = parse_addr_arg(args.get("file_offset"), 0)? as usize;
            let slice = data.get(file_off..).ok_or("file_offset exceeds input size")?;
            let secs = vec![SynthSection {
                name: ".rom_text".into(),
                vaddr: base,
                mem_size: slice.len() as u64,
                data: slice.to_vec(),
                executable: true,
                writable: true,
                nobits: false,
                align: 16,
            }];
            let syms = vec![SynthSymbol {
                name: "_rom_entry".into(),
                value: entry,
                size: 0,
                is_func: true,
                section_index: 1,
            }];
            (arch, entry, secs, syms, json!({ "raw_bytes": slice.len() }))
        }
        other => {
            return Err(format!(
                "Unsupported format '{}'. Expected: auto, dol, dos_com, esp32, uf2, raw",
                other
            ))
        }
    };

    let elf_bytes = build_elf(arch, entry, &sections, &symbols)?;

    let out_path = if let Some(p) = args.get("output_path").and_then(Value::as_str) {
        PathBuf::from(p)
    } else {
        let dir = dot_free_tmp_dir().join("craft-elf");
        let _ = fs::create_dir_all(&dir);
        dir.join(format!("{}.elf", stem))
    };
    if let Some(parent) = out_path.parent() {
        let _ = fs::create_dir_all(parent);
    }
    fs::write(&out_path, &elf_bytes)
        .map_err(|e| format!("Failed writing synthesized ELF '{}': {}", out_path.display(), e))?;

    let sec_summary: Vec<Value> = sections
        .iter()
        .map(|s| {
            json!({
                "name": s.name,
                "vaddr": format!("0x{:08x}", s.vaddr),
                "mem_size": s.mem_size,
                "file_bytes": s.data.len(),
                "executable": s.executable,
                "writable": s.writable,
                "nobits": s.nobits,
            })
        })
        .collect();

    Ok(json!({
        "source_path": path_str,
        "detected_format": detected_fmt,
        "output_elf_path": out_path.to_string_lossy(),
        "output_elf_bytes": elf_bytes.len(),
        "output_elf_sha256": sha256_hex(&elf_bytes),
        "architecture": arch.name,
        "e_machine": arch.e_machine,
        "entry_point": format!("0x{:08x}", entry),
        "sections": sec_summary,
        "symbols_injected": symbols.len(),
        "format_details": extra_meta,
        "next_step": format!(
            "Open '{}' directly with Craft Anything's core_target_open + native_functions_decompile (0 Java, <50MB RAM) or pass to ghidra_headless_run.",
            out_path.display()
        ),
    }))
}

fn is_likely_dol(data: &[u8]) -> bool {
    if data.len() < 0x100 {
        return false;
    }
    let entry = u32_be(data, 0xE0).unwrap_or(0);
    // GameCube / Wii executables reside in cached MEM1/MEM2 (`0x8000_0000..0x9400_0000`)
    if !(0x8000_0000..=0x93FF_FFFF).contains(&entry) {
        return false;
    }
    let mut valid_secs = 0usize;
    for i in 0..18 {
        let off = u32_be(data, i * 4).unwrap_or(0) as usize;
        let addr = u32_be(data, 0x48 + i * 4).unwrap_or(0);
        let sz = u32_be(data, 0x90 + i * 4).unwrap_or(0) as usize;
        if sz == 0 {
            continue;
        }
        if off < 0x100 || off.saturating_add(sz) > data.len() || addr < 0x8000_0000 {
            return false;
        }
        valid_secs += 1;
    }
    valid_secs >= 1
}

fn convert_dol(
    data: &[u8],
    arch_override: Option<&str>,
) -> Result<(ArchSpec, u64, Vec<SynthSection>, Vec<SynthSymbol>, Value), String> {
    if data.len() < 0x100 {
        return Err("DOL file truncated (<256 bytes header)".into());
    }
    let arch = ArchSpec::from_name(arch_override.unwrap_or("ppc"))?;
    let bss_addr = u32_be(data, 0xD8).unwrap_or(0) as u64;
    let bss_size = u32_be(data, 0xDC).unwrap_or(0) as u64;
    let entry = u32_be(data, 0xE0).unwrap_or(0) as u64;

    let mut sections = Vec::new();
    let mut symbols = Vec::new();
    let mut entry_sec_idx: u16 = 1;

    // 7 text sections (0..7) + 11 data sections (7..18)
    for i in 0..18 {
        let file_off = u32_be(data, i * 4).unwrap_or(0) as usize;
        let load_addr = u32_be(data, 0x48 + i * 4).unwrap_or(0) as u64;
        let size = u32_be(data, 0x90 + i * 4).unwrap_or(0) as usize;
        if size == 0 {
            continue;
        }
        let slice = data
            .get(file_off..file_off.saturating_add(size))
            .ok_or_else(|| format!("DOL section {} exceeds file bounds", i))?;
        let is_text = i < 7;
        let name = if is_text {
            format!(".text{}", i)
        } else {
            format!(".data{}", i - 7)
        };
        sections.push(SynthSection {
            name: name.clone(),
            vaddr: load_addr,
            mem_size: size as u64,
            data: slice.to_vec(),
            executable: is_text,
            writable: !is_text,
            nobits: false,
            align: 32,
        });
        let sec_idx = sections.len() as u16;
        if entry >= load_addr && entry < load_addr + (size as u64) {
            entry_sec_idx = sec_idx;
        }
        symbols.push(SynthSymbol {
            name: format!("dol_{}", name.trim_start_matches('.')),
            value: load_addr,
            size: size as u64,
            is_func: is_text,
            section_index: sec_idx,
        });
    }

    if bss_addr != 0 && bss_size != 0 {
        sections.push(SynthSection {
            name: ".bss".into(),
            vaddr: bss_addr,
            mem_size: bss_size,
            data: Vec::new(),
            executable: false,
            writable: true,
            nobits: true,
            align: 32,
        });
        symbols.push(SynthSymbol {
            name: "dol_bss_start".into(),
            value: bss_addr,
            size: bss_size,
            is_func: false,
            section_index: sections.len() as u16,
        });
    }

    symbols.insert(
        0,
        SynthSymbol {
            name: "_dol_start".into(),
            value: entry,
            size: 0,
            is_func: true,
            section_index: entry_sec_idx,
        },
    );

    let console = if entry >= 0x8000_3400 {
        "Nintendo GameCube / Wii (PowerPC Gekko / Broadway)"
    } else {
        "Nintendo GameCube DOL"
    };

    Ok((
        arch,
        entry,
        sections,
        symbols,
        json!({
            "console": console,
            "bss_addr": format!("0x{:08x}", bss_addr),
            "bss_size": bss_size,
        }),
    ))
}

fn convert_dos_com(
    data: &[u8],
    base: u64,
    arch_override: Option<&str>,
) -> Result<(ArchSpec, u64, Vec<SynthSection>, Vec<SynthSymbol>, Value), String> {
    let arch = ArchSpec::from_name(arch_override.unwrap_or("x86"))?;
    let mut interrupts: BTreeMap<String, usize> = BTreeMap::new();
    for i in 0..data.len().saturating_sub(1) {
        if data[i] == 0xCD {
            let irq = data[i + 1];
            if matches!(irq, 0x10 | 0x13 | 0x16 | 0x1A | 0x20 | 0x21 | 0x2F | 0x33) {
                let label = match irq {
                    0x10 => "INT_10h_Video_BIOS",
                    0x13 => "INT_13h_Disk_BIOS",
                    0x16 => "INT_16h_Keyboard_BIOS",
                    0x1A => "INT_1Ah_RTC_Timer",
                    0x20 => "INT_20h_DOS_Terminate",
                    0x21 => "INT_21h_DOS_API",
                    0x2F => "INT_2Fh_Multiplex",
                    0x33 => "INT_33h_Mouse",
                    _ => "INT_Other",
                };
                *interrupts.entry(label.into()).or_insert(0) += 1;
            }
        }
    }

    let sections = vec![SynthSection {
        name: ".dos_com".into(),
        vaddr: base,
        mem_size: data.len() as u64,
        data: data.to_vec(),
        executable: true,
        writable: true,
        nobits: false,
        align: 16,
    }];
    let symbols = vec![SynthSymbol {
        name: "_dos_com_start".into(),
        value: base,
        size: data.len() as u64,
        is_func: true,
        section_index: 1,
    }];
    Ok((
        arch,
        base,
        sections,
        symbols,
        json!({
            "dos_psp_base": format!("0x{:x}", base.saturating_sub(0x100)),
            "bios_dos_interrupt_candidates": interrupts,
            "ghidra_language_hint": "x86:LE:16:Real Mode",
        }),
    ))
}

fn convert_firmware(
    data: &[u8],
    arch_override: Option<&str>,
) -> Result<(ArchSpec, u64, Vec<SynthSection>, Vec<SynthSymbol>, Value), String> {
    let parsed = extract_firmware_segments(data)?;
    let chosen_arch = arch_override.unwrap_or(&parsed.arch_hint);
    let arch = ArchSpec::from_name(chosen_arch)?;
    let mut sections = Vec::with_capacity(parsed.segments.len());
    let mut symbols = Vec::new();
    let mut entry_sec_idx = 1u16;

    for (idx, seg) in parsed.segments.iter().enumerate() {
        sections.push(SynthSection {
            name: seg.name.clone(),
            vaddr: seg.vaddr,
            mem_size: seg.data.len() as u64,
            data: seg.data.clone(),
            executable: seg.executable,
            writable: seg.writable,
            nobits: false,
            align: 16,
        });
        let sidx = (idx + 1) as u16;
        if parsed.entry_point >= seg.vaddr
            && parsed.entry_point < seg.vaddr + (seg.data.len() as u64)
        {
            entry_sec_idx = sidx;
        }
        symbols.push(SynthSymbol {
            name: format!("seg_{}_{:08x}", idx, seg.vaddr),
            value: seg.vaddr,
            size: seg.data.len() as u64,
            is_func: seg.executable,
            section_index: sidx,
        });
    }
    symbols.insert(
        0,
        SynthSymbol {
            name: "_firmware_entry".into(),
            value: parsed.entry_point,
            size: 0,
            is_func: true,
            section_index: entry_sec_idx,
        },
    );

    Ok((
        arch,
        parsed.entry_point,
        sections,
        symbols,
        json!({
            "firmware_container": parsed.format,
            "auto_arch": parsed.arch_hint,
        }),
    ))
}

// ============================================================================
// 2. Mobile-Guarded Ghidra 12.1.4 ARM64 Headless Runner (`ghidra_headless_run`)
// ============================================================================

pub fn tool_ghidra_headless_run(args: &Value) -> Result<Value, String> {
    let path_str = args
        .get("path")
        .and_then(Value::as_str)
        .ok_or("Missing required string parameter 'path'")?;
    let processor = args.get("processor").and_then(Value::as_str);
    let max_functions = args
        .get("max_functions")
        .and_then(Value::as_u64)
        .unwrap_or(40)
        .min(300) as usize;
    let decompile_count = args
        .get("decompile_count")
        .and_then(Value::as_u64)
        .unwrap_or(3)
        .min(15) as usize;
    let function_filter = args
        .get("function_filter")
        .and_then(Value::as_str)
        .unwrap_or("");
    let max_mem = args
        .get("max_ram")
        .and_then(Value::as_str)
        .unwrap_or("1536M");
    let timeout_secs = args
        .get("timeout_sec")
        .and_then(Value::as_u64)
        .unwrap_or(180)
        .clamp(20, 600);

    let prefix = std::env::var("PREFIX").unwrap_or_else(|_| "/data/user/0/com.agy/files/usr".into());
    let home = std::env::var("HOME").unwrap_or_else(|_| "/data/user/0/com.agy/files".into());
    let ghidra_root = PathBuf::from(&prefix).join("opt/ghidra/ghidra_12.1.4_PUBLIC");
    let headless = ghidra_root.join("support/analyzeHeadless");

    if !headless.exists() {
        return Err(
            "Ghidra 12.1.4 ARM64 is not installed yet at $PREFIX/opt/ghidra/ghidra_12.1.4_PUBLIC. Run `craft-ghidra-setup` in terminal, or use `retro_to_elf_convert` + Craft Anything's built-in Rust `native_functions_decompile` immediately without Java."
                .into(),
        );
    }

    // Auto-convert `.dol`, `.uf2`, `ESP32 0xE9` into standard ELF first unless caller explicitly passed a custom processor on raw/com
    let data_head = fs::read(path_str).map_err(|e| format!("Cannot read '{}': {}", path_str, e))?;
    let ext = Path::new(path_str)
        .extension()
        .and_then(|e| e.to_str())
        .unwrap_or("")
        .to_ascii_lowercase();
    let mut effective_target = PathBuf::from(path_str);
    let mut auto_converted = false;

    if processor.is_none()
        && !data_head.starts_with(b"\x7fELF")
        && !data_head.starts_with(b"MZ")
        && (is_likely_dol(&data_head)
            || ext == "dol"
            || (data_head.len() >= 512 && u32_le(&data_head, 0) == Some(0x0A32_4655))
            || (data_head.first() == Some(&0xE9) && data_head.len() >= 24 && (1..=24).contains(&data_head[1])))
    {
        let conv = tool_retro_to_elf_convert(&json!({ "path": path_str }))?;
        if let Some(elf_p) = conv.get("output_elf_path").and_then(Value::as_str) {
            effective_target = PathBuf::from(elf_p);
            auto_converted = true;
        }
    }

    let tmp_base = dot_free_tmp_dir();
    let proj_root = tmp_base.join("ghidra-projects");
    let script_dir = tmp_base.join("ghidra-plus-scripts");
    let report_dir = tmp_base.join("ghidra-reports");
    for d in [&proj_root, &script_dir, &report_dir] {
        fs::create_dir_all(d).map_err(|e| format!("Failed creating {:?}: {}", d, e))?;
    }

    // Write clean self-contained Ghidra Java post-script
    let script_path = script_dir.join("CraftPlusExport.java");
    fs::write(&script_path, GHIDRA_EXPORT_JAVA)
        .map_err(|e| format!("Failed writing Ghidra export script: {}", e))?;

    let run_id = format!(
        "cp_{}_{}",
        std::process::id(),
        std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .map(|d| d.as_millis())
            .unwrap_or(0)
    );
    let report_file = report_dir.join(format!("{}.json", run_id));

    let bash_bin = PathBuf::from(&prefix).join("bin/bash");
    let mut cmd = if bash_bin.exists() {
        let mut c = Command::new(&bash_bin);
        c.arg(&headless);
        c
    } else {
        Command::new(&headless)
    };

    cmd.arg(&proj_root)
        .arg(&run_id)
        .arg("-import")
        .arg(&effective_target)
        .arg("-deleteProject")
        .arg("-scriptPath")
        .arg(&script_dir)
        .arg("-postScript")
        .arg("CraftPlusExport.java")
        .arg(&report_file)
        .arg(max_functions.to_string())
        .arg(decompile_count.to_string())
        .arg(function_filter);

    if let Some(proc_id) = processor {
        cmd.arg("-processor").arg(proc_id);
    }

    let java_home = PathBuf::from(&prefix).join("lib/jvm/java-21-openjdk");
    let path_env = format!(
        "{}/bin:{}/bin:{}/runtime/bin:/system/bin",
        prefix,
        java_home.display(),
        home
    );
    cmd.env("HOME", &home)
        .env("PREFIX", &prefix)
        .env("JAVA_HOME", &java_home)
        .env("PATH", path_env)
        .env("TMPDIR", &tmp_base)
        .env("MAXMEM", max_mem)
        .env("GHIDRA_HEADLESS_MAXMEM", max_mem)
        .env(
            "JDK_JAVA_OPTIONS",
            format!("-Duser.home={} -Djava.io.tmpdir={}", home, tmp_base.display()),
        )
        .stdin(Stdio::null())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped());

    let mut child = cmd
        .spawn()
        .map_err(|e| format!("Failed launching Ghidra analyzeHeadless: {}", e))?;

    let deadline = Instant::now() + Duration::from_secs(timeout_secs);
    let status = loop {
        match child.try_wait() {
            Ok(Some(st)) => break st,
            Ok(None) => {
                if Instant::now() >= deadline {
                    let _ = child.kill();
                    let _ = child.wait();
                    return Err(format!(
                        "Ghidra analyzeHeadless timed out after {}s (RAM cap {}). Try narrowing function_filter or increasing timeout_sec.",
                        timeout_secs, max_mem
                    ));
                }
                std::thread::sleep(Duration::from_millis(250));
            }
            Err(e) => return Err(format!("Error waiting on Ghidra process: {}", e)),
        }
    };

    let output = child
        .wait_with_output()
        .map_err(|e| format!("Failed reading Ghidra output: {}", e))?;

    if report_file.exists() {
        let rep_txt = fs::read_to_string(&report_file).unwrap_or_default();
        let _ = fs::remove_file(&report_file);
        if let Ok(mut parsed) = serde_json::from_str::<Value>(&rep_txt) {
            if let Some(obj) = parsed.as_object_mut() {
                obj.insert("auto_converted_to_elf".into(), json!(auto_converted));
                obj.insert(
                    "analyzed_binary".into(),
                    json!(effective_target.to_string_lossy()),
                );
            }
            return Ok(parsed);
        }
    }

    let stderr_tail: String = String::from_utf8_lossy(&output.stderr)
        .lines()
        .rev()
        .take(25)
        .collect::<Vec<_>>()
        .into_iter()
        .rev()
        .collect::<Vec<_>>()
        .join("\n");
    let stdout_tail: String = String::from_utf8_lossy(&output.stdout)
        .lines()
        .rev()
        .take(25)
        .collect::<Vec<_>>()
        .into_iter()
        .rev()
        .collect::<Vec<_>>()
        .join("\n");

    Err(format!(
        "Ghidra exited with status {} without producing JSON report.\nSTDOUT:\n{}\nSTDERR:\n{}",
        status, stdout_tail, stderr_tail
    ))
}

const GHIDRA_EXPORT_JAVA: &str = r#"import ghidra.app.decompiler.DecompInterface;
import ghidra.app.decompiler.DecompileResults;
import ghidra.app.script.GhidraScript;
import ghidra.program.model.listing.Function;
import ghidra.program.model.listing.FunctionIterator;
import java.io.FileWriter;

public class CraftPlusExport extends GhidraScript {
    private static String esc(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r")
                .replace("\t", "\\t");
    }

    @Override
    protected void run() throws Exception {
        String[] a = getScriptArgs();
        String outPath = a.length > 0 ? a[0] : "/tmp/ghidra_report.json";
        int maxFn = a.length > 1 ? Integer.parseInt(a[1]) : 40;
        int maxDec = a.length > 2 ? Integer.parseInt(a[2]) : 3;
        String filter = a.length > 3 ? a[3].toLowerCase() : "";

        DecompInterface ifc = new DecompInterface();
        ifc.openProgram(currentProgram);

        StringBuilder fnsJson = new StringBuilder("[");
        StringBuilder decJson = new StringBuilder("[");
        int total = 0;
        int listed = 0;
        int decompiled = 0;

        FunctionIterator it = currentProgram.getFunctionManager().getFunctions(true);
        while (it.hasNext() && !monitor.isCancelled()) {
            Function fn = it.next();
            total++;
            String name = fn.getName();
            if (!filter.isEmpty() && !name.toLowerCase().contains(filter)) {
                continue;
            }
            long sz = fn.getBody().getNumAddresses();
            if (listed < maxFn) {
                if (listed > 0) fnsJson.append(",");
                fnsJson.append("{\"name\":\"").append(esc(name)).append("\",")
                       .append("\"entry\":\"0x").append(fn.getEntryPoint().toString()).append("\",")
                       .append("\"size\":").append(sz).append("}");
                listed++;
            }
            if (decompiled < maxDec && !fn.isThunk() && !fn.isExternal() && sz >= 8) {
                DecompileResults res = ifc.decompileFunction(fn, 25, monitor);
                if (res != null && res.decompileCompleted() && res.getDecompiledFunction() != null) {
                    String c = res.getDecompiledFunction().getC();
                    if (c.length() > 6000) c = c.substring(0, 6000) + "\n/* ... truncated ... */";
                    if (decompiled > 0) decJson.append(",");
                    decJson.append("{\"name\":\"").append(esc(name)).append("\",")
                           .append("\"entry\":\"0x").append(fn.getEntryPoint().toString()).append("\",")
                           .append("\"c\":\"").append(esc(c)).append("\"}");
                    decompiled++;
                }
            }
        }
        ifc.dispose();
        fnsJson.append("]");
        decJson.append("]");

        StringBuilder root = new StringBuilder("{");
        root.append("\"program\":\"").append(esc(currentProgram.getName())).append("\",");
        root.append("\"language\":\"").append(esc(currentProgram.getLanguageID().toString())).append("\",");
        root.append("\"compiler\":\"").append(esc(currentProgram.getCompilerSpec().getCompilerSpecID().toString())).append("\",");
        root.append("\"image_base\":\"0x").append(currentProgram.getImageBase().toString()).append("\",");
        root.append("\"total_functions\":").append(total).append(",");
        root.append("\"functions\":").append(fnsJson).append(",");
        root.append("\"decompiled\":").append(decJson);
        root.append("}");

        try (FileWriter fw = new FileWriter(outPath)) {
            fw.write(root.toString());
        }
    }
}
"#;

// ============================================================================
// 3. .NET 7/8/9/10 NativeAOT & ReadyToRun Inspector (`nativeaot_metadata_show`)
// ============================================================================

pub fn tool_nativeaot_metadata_show(args: &Value) -> Result<Value, String> {
    let path_str = args
        .get("path")
        .and_then(Value::as_str)
        .ok_or("Missing required string parameter 'path'")?;
    let limit = args.get("limit").and_then(Value::as_u64).unwrap_or(100).min(1000) as usize;

    let b = fs::read(path_str).map_err(|e| format!("Failed reading '{}': {}", path_str, e))?;
    if b.len() < 64 {
        return Err("File too small to be a native binary".into());
    }

    let container = if b.starts_with(b"\x7fELF") {
        "ELF"
    } else if b.starts_with(b"MZ") {
        "PE"
    } else if matches!(
        u32_le(&b, 0),
        Some(0xFEED_FACE | 0xFEED_FACF | 0xCEFA_EDFE | 0xCFFAEDFE | 0xCAFE_BABE)
    ) {
        "Mach-O"
    } else {
        "Unknown"
    };

    let sections = match container {
        "ELF" => list_elf_section_names(&b),
        "PE" => list_pe_section_names(&b),
        _ => Vec::new(),
    };

    let aot_sections: Vec<String> = sections
        .iter()
        .filter(|s| {
            let l = s.to_ascii_lowercase();
            l.contains("managed")
                || l.contains("hydrated")
                || l.contains("__modules")
                || l.contains("frozen")
                || l.contains("rtr")
                || l.contains("dotnet")
        })
        .cloned()
        .collect();

    // Scan for ReadyToRun (`RTR\0` = 0x00525452) headers used by both NativeAOT & Crossgen2 R2R
    let mut rtr_headers = Vec::new();
    let mut pos = 0usize;
    while pos + 16 <= b.len() && rtr_headers.len() < 16 {
        if b[pos] == b'R' && b[pos + 1] == b'T' && b[pos + 2] == b'R' && b[pos + 3] == 0 {
            let major = u16_le(&b, pos + 4).unwrap_or(0);
            let minor = u16_le(&b, pos + 6).unwrap_or(0);
            let attrs = u32_le(&b, pos + 8).unwrap_or(0);
            let num_secs = u32_le(&b, pos + 12).unwrap_or(0);
            // Sanity check ReadyToRun major version (1..25) and section count (1..64)
            if (1..=30).contains(&major) && minor <= 30 && (1..=64).contains(&num_secs) {
                let mut sec_types = Vec::new();
                for s in 0..(num_secs as usize) {
                    let row = pos + 16 + s * 16;
                    if row + 16 > b.len() {
                        break;
                    }
                    let stype = u32_le(&b, row).unwrap_or(0);
                    sec_types.push(rtr_section_name(stype));
                }
                rtr_headers.push(json!({
                    "offset": format!("0x{:x}", pos),
                    "rtr_version": format!("{}.{}", major, minor),
                    "attributes": format!("0x{:08x}", attrs),
                    "section_count": num_secs,
                    "sections": sec_types,
                }));
                pos += 16 + (num_secs as usize) * 16;
                continue;
            }
        }
        pos += 4;
    }

    // Check .NET Single-File AppHost bundle signature (32-byte SHA-256 of ".net core bundle")
    const BUNDLE_SIG: [u8; 32] = [
        0x8b, 0x12, 0x02, 0xb9, 0x6a, 0x61, 0x20, 0x38, 0x72, 0x7b, 0x93, 0x02, 0x14, 0xd7, 0xa0,
        0x32, 0x13, 0xf5, 0xb9, 0xe6, 0xef, 0xae, 0x33, 0x18, 0xee, 0x3b, 0x2d, 0xce, 0x24, 0xb3,
        0x6a, 0xae,
    ];
    let mut single_file_manifest_offset = None;
    if let Some(sig_pos) = b.windows(32).position(|w| w == BUNDLE_SIG) {
        if sig_pos >= 8 {
            let hdr_off = u64_le(&b, sig_pos - 8).unwrap_or(0);
            if hdr_off > 0 && (hdr_off as usize) < b.len() {
                single_file_manifest_offset = Some(format!("0x{:x}", hdr_off));
            }
        }
    }

    // Scan ASCII strings for compiler banners (`.NET 8.0`, `CoreRT`, `NativeAOT`, `System.Private.CoreLib`) and C# mangled/type symbols
    let (banners, managed_symbols) = scan_dotnet_strings(&b, limit);

    let is_nativeaot = !aot_sections.is_empty()
        || !rtr_headers.is_empty()
        || banners.iter().any(|s| s.contains("System.Private.CoreLib") || s.contains(".NET"));

    Ok(json!({
        "format": "dotnet_nativeaot_or_r2r",
        "container": container,
        "path": path_str,
        "file_size": b.len(),
        "detected_dotnet_native": is_nativeaot,
        "single_file_bundle_header_offset": single_file_manifest_offset,
        "aot_specific_sections": aot_sections,
        "all_binary_sections": sections,
        "ready_to_run_headers": rtr_headers,
        "runtime_and_compiler_banners": banners,
        "recovered_managed_identifiers_sample": managed_symbols,
    }))
}

fn rtr_section_name(id: u32) -> String {
    match id {
        100 => "CompilerIdentifier".into(),
        101 => "ImportSections".into(),
        102 => "RuntimeFunctions".into(),
        103 => "MethodDefEntryPoints".into(),
        104 => "ExceptionInfo".into(),
        105 => "DebugInfo".into(),
        106 => "DelayLoadMethodCallThunks".into(),
        108 => "AvailableTypes".into(),
        109 => "InstanceMethodEntryPoints".into(),
        110 => "InliningInfo".into(),
        200..=299 => format!("NativeAOT_DehydratedOrTypeMap({})", id),
        300..=399 => format!("NativeAOT_ModuleSection({})", id),
        _ => format!("Section_{}", id),
    }
}

fn list_elf_section_names(b: &[u8]) -> Vec<String> {
    let is_64 = b.get(4) == Some(&2);
    let is_le = b.get(5) != Some(&2);
    if !is_le {
        return Vec::new();
    }
    let (shoff, shentsize, shnum, shstrndx) = if is_64 {
        (
            u64_le(b, 40).unwrap_or(0) as usize,
            u16_le(b, 58).unwrap_or(0) as usize,
            u16_le(b, 60).unwrap_or(0) as usize,
            u16_le(b, 62).unwrap_or(0) as usize,
        )
    } else {
        (
            u32_le(b, 32).unwrap_or(0) as usize,
            u16_le(b, 46).unwrap_or(0) as usize,
            u16_le(b, 48).unwrap_or(0) as usize,
            u16_le(b, 50).unwrap_or(0) as usize,
        )
    };
    if shoff == 0 || shentsize < 40 || shstrndx >= shnum {
        return Vec::new();
    }
    let str_hdr = shoff + shstrndx * shentsize;
    let (str_off, str_sz) = if is_64 {
        (
            u64_le(b, str_hdr + 24).unwrap_or(0) as usize,
            u64_le(b, str_hdr + 32).unwrap_or(0) as usize,
        )
    } else {
        (
            u32_le(b, str_hdr + 16).unwrap_or(0) as usize,
            u32_le(b, str_hdr + 20).unwrap_or(0) as usize,
        )
    };
    let Some(strtab) = b.get(str_off..str_off.saturating_add(str_sz)) else {
        return Vec::new();
    };
    let mut out = Vec::new();
    for i in 1..shnum.min(256) {
        let h = shoff + i * shentsize;
        let Some(noff_u32) = u32_le(b, h) else { break };
        let noff = noff_u32 as usize;
        if let Some(sub) = strtab.get(noff..) {
            let end = sub.iter().position(|&c| c == 0).unwrap_or(sub.len());
            let s = String::from_utf8_lossy(&sub[..end]).to_string();
            if !s.is_empty() {
                out.push(s);
            }
        }
    }
    out
}

fn list_pe_section_names(b: &[u8]) -> Vec<String> {
    let Some(pe_off_u32) = u32_le(b, 0x3C) else { return Vec::new() };
    let pe_off = pe_off_u32 as usize;
    if b.get(pe_off..pe_off + 4) != Some(b"PE\0\0") {
        return Vec::new();
    }
    let num_secs = u16_le(b, pe_off + 6).unwrap_or(0) as usize;
    let opt_sz = u16_le(b, pe_off + 20).unwrap_or(0) as usize;
    let sec_base = pe_off + 24 + opt_sz;
    let mut out = Vec::new();
    for i in 0..num_secs.min(128) {
        let off = sec_base + i * 40;
        let Some(raw_name) = b.get(off..off + 8) else { break };
        let end = raw_name.iter().position(|&c| c == 0).unwrap_or(8);
        let s = String::from_utf8_lossy(&raw_name[..end]).to_string();
        if !s.is_empty() {
            out.push(s);
        }
    }
    out
}

fn scan_dotnet_strings(b: &[u8], limit: usize) -> (Vec<String>, Vec<String>) {
    let mut banners = Vec::new();
    let mut symbols = Vec::new();
    let mut i = 0usize;
    while i < b.len() {
        if b[i].is_ascii_graphic() || b[i] == b' ' {
            let start = i;
            while i < b.len() && (b[i].is_ascii_graphic() || b[i] == b' ') && (i - start) < 220 {
                i += 1;
            }
            let len = i - start;
            if len >= 10 {
                if let Ok(s) = std::str::from_utf8(&b[start..i]) {
                    let t = s.trim();
                    if (t.contains(".NET ")
                        || t.contains("System.Private.")
                        || t.contains("NativeAOT")
                        || t.contains("ReadyToRun")
                        || t.contains("@scc"))
                        && banners.len() < 25
                        && !banners.iter().any(|x| x == t)
                    {
                        banners.push(t.to_string());
                    } else if symbols.len() < limit
                        && (t.starts_with("S_P_CoreLib_")
                            || t.contains("__Module")
                            || (t.contains("::") && !t.contains(' '))
                            || (t.ends_with(".dll") && !t.contains(' ')))
                        && !symbols.iter().any(|x| x == t)
                    {
                        symbols.push(t.to_string());
                    }
                }
            }
        } else {
            i += 1;
        }
    }
    (banners, symbols)
}
