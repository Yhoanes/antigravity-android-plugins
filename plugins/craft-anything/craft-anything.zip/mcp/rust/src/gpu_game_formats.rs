//! Specialized GPU, Game, Erlang BEAM & JavaScript Release Exposure Analyzers (100% Rust):
//! - `gpu_cuda_ptx_show`: CUDA fatbin (`0xBA55ED50`), ELF cubin (`EM_CUDA=190`), host `.nv_fatbin`, LZ4 fatbin decompression & PTX kernel parser
//! - `game_godot_pck_extract`: Godot 3.x / 4.x `.pck` (standalone or embedded executable tail) inspector & extractor
//! - `game_il2cpp_meta_show`: Unity `IL2CPP` `global-metadata.dat` (`0xFAB11BAF`, v24..v39) assembly/type/method/literal decoder
//! - `formats_beam_show`: Erlang / Elixir `.beam` (`FOR1` + `BEAM` IFF chunks) atom/export/import/lambda inspector
//! - `js_release_audit`: JS / Electron / Web bundle source-map, secret leak, internal endpoint & fuse auditor

use crate::firmware::safe_join_under;
use crate::sha256::hex_encode;
use serde_json::{json, Value};
use std::collections::BTreeSet;
use std::fs;
use std::path::Path;

fn u16_le(b: &[u8], o: usize) -> Option<u16> {
    Some(u16::from_le_bytes(b.get(o..o + 2)?.try_into().ok()?))
}
fn u32_le(b: &[u8], o: usize) -> Option<u32> {
    Some(u32::from_le_bytes(b.get(o..o + 4)?.try_into().ok()?))
}
fn i32_le(b: &[u8], o: usize) -> Option<i32> {
    Some(i32::from_le_bytes(b.get(o..o + 4)?.try_into().ok()?))
}
fn u64_le(b: &[u8], o: usize) -> Option<u64> {
    Some(u64::from_le_bytes(b.get(o..o + 8)?.try_into().ok()?))
}
fn u32_be(b: &[u8], o: usize) -> Option<u32> {
    Some(u32::from_be_bytes(b.get(o..o + 4)?.try_into().ok()?))
}

// ============================================================================
// 1. GPU CUDA / HIP / PTX Inspector (`gpu_cuda_ptx_show`)
// ============================================================================

pub fn tool_gpu_cuda_ptx_show(args: &Value) -> Result<Value, String> {
    let path_str = args
        .get("path")
        .and_then(Value::as_str)
        .ok_or("Missing required string parameter 'path'")?;
    let include_ptx = args.get("include_ptx").and_then(Value::as_bool).unwrap_or(true);
    let max_ptx_chars = args
        .get("max_ptx_chars")
        .and_then(Value::as_u64)
        .unwrap_or(8000)
        .min(64000) as usize;

    let data = fs::read(path_str).map_err(|e| format!("Failed reading '{}': {}", path_str, e))?;
    if data.is_empty() {
        return Err("Empty file".into());
    }

    // Case A: Plaintext `.ptx`
    if let Ok(txt) = std::str::from_utf8(&data[..data.len().min(4096)]) {
        if txt.contains(".version") && (txt.contains(".target") || txt.contains(".entry")) {
            let full_txt = String::from_utf8_lossy(&data);
            let parsed = parse_ptx_text(&full_txt, include_ptx, max_ptx_chars);
            return Ok(json!({
                "format": "ptx_source",
                "path": path_str,
                "file_size": data.len(),
                "ptx": parsed,
            }));
        }
    }

    // Case B: Standalone ELF `cubin` (EM_CUDA = 190 or EM_AMDGPU = 224)
    let mut elf_info = None;
    if data.starts_with(b"\x7fELF") && data.len() >= 64 {
        let e_machine = u16_le(&data, 18).unwrap_or(0);
        if e_machine == 190 || e_machine == 224 {
            let e_flags = u32_le(&data, 48).unwrap_or(0);
            let sm_arch = e_flags & 0xFF;
            elf_info = Some(json!({
                "gpu_vendor": if e_machine == 190 { "NVIDIA CUDA cubin" } else { "AMD ROCm HSACO" },
                "e_machine": e_machine,
                "sm_arch": if e_machine == 190 { format!("sm_{}", sm_arch) } else { format!("gfx_flags_0x{:x}", e_flags) },
            }));
        }
    }

    // Scan for all CUDA fatbin containers (`0xBA55ED50`, version `0x0001`, hdr_size `0x0010`)
    let mut fatbins = Vec::new();
    let mut extracted_ptx = Vec::new();
    let mut pos = 0usize;
    while pos + 16 <= data.len() {
        if data[pos] == 0x50 && data[pos + 1] == 0xED && data[pos + 2] == 0x55 && data[pos + 3] == 0xBA {
            let ver = u16_le(&data, pos + 4).unwrap_or(0);
            let hdr_sz = u16_le(&data, pos + 6).unwrap_or(0) as usize;
            let payload_sz = u64_le(&data, pos + 8).unwrap_or(0) as usize;
            if ver == 1 && hdr_sz >= 16 && pos + hdr_sz + payload_sz <= data.len() {
                let entries = parse_fatbin_entries(
                    &data[pos + hdr_sz..pos + hdr_sz + payload_sz],
                    include_ptx,
                    max_ptx_chars,
                    &mut extracted_ptx,
                );
                fatbins.push(json!({
                    "offset": format!("0x{:x}", pos),
                    "payload_bytes": payload_sz,
                    "entries": entries,
                }));
                pos += hdr_sz + payload_sz;
                continue;
            }
        }
        pos += 4;
    }

    // Fallback scan for uncompressed inline `.version X.Y ... .target sm_XX` inside host binaries
    if extracted_ptx.is_empty() {
        if let Some(idx) = find_subslice(&data, b".version ") {
            let end = (idx + 65536).min(data.len());
            let end_nul = data[idx..end]
                .iter()
                .position(|&c| c == 0)
                .map(|p| idx + p)
                .unwrap_or(end);
            let txt = String::from_utf8_lossy(&data[idx..end_nul]);
            if txt.contains(".target") {
                extracted_ptx.push(parse_ptx_text(&txt, include_ptx, max_ptx_chars));
            }
        }
    }

    if elf_info.is_none() && fatbins.is_empty() && extracted_ptx.is_empty() {
        return Err("No CUDA fatbin (0xBA55ED50), cubin (EM_CUDA=190), ROCm HSACO (EM_AMDGPU=224), or embedded PTX found in target.".into());
    }

    Ok(json!({
        "format": if elf_info.is_some() { "gpu_cubin_elf" } else { "cuda_fatbin_carrier" },
        "path": path_str,
        "file_size": data.len(),
        "cubin_header": elf_info,
        "fatbin_containers": fatbins,
        "ptx_modules": extracted_ptx,
    }))
}

fn parse_fatbin_entries(
    buf: &[u8],
    include_ptx: bool,
    max_ptx_chars: usize,
    ptx_out: &mut Vec<Value>,
) -> Vec<Value> {
    let mut entries = Vec::new();
    let mut off = 0usize;
    while off + 64 <= buf.len() {
        let kind = u16_le(buf, off).unwrap_or(0);
        let hdr_size = u32_le(buf, off + 4).unwrap_or(0) as usize;
        let padded_payload_size = u64_le(buf, off + 8).unwrap_or(0) as usize;
        let compressed_size = u32_le(buf, off + 16).unwrap_or(0) as usize;
        let sm_arch = u32_le(buf, off + 28).unwrap_or(0);
        let uncompressed_size = u64_le(buf, off + 56).unwrap_or(0) as usize;

        if (kind != 1 && kind != 2) || hdr_size < 64 || off + hdr_size + padded_payload_size > buf.len() {
            break;
        }
        let kind_str = if kind == 1 { "ptx" } else { "cubin_sass" };
        let payload_start = off + hdr_size;
        let raw_payload = &buf[payload_start..payload_start + padded_payload_size];
        let is_compressed = uncompressed_size > 0 && compressed_size > 0 && compressed_size <= padded_payload_size;

        if kind == 1 && ptx_out.len() < 16 {
            let ptx_bytes = if is_compressed {
                decompress_cuda_lz4(&raw_payload[..compressed_size], uncompressed_size.min(4 * 1024 * 1024))
            } else {
                let end = raw_payload.iter().position(|&c| c == 0).unwrap_or(raw_payload.len());
                raw_payload[..end].to_vec()
            };
            let txt = String::from_utf8_lossy(&ptx_bytes);
            if txt.contains(".version") || txt.contains(".entry") || txt.contains(".func") {
                ptx_out.push(parse_ptx_text(&txt, include_ptx, max_ptx_chars));
            }
        }

        entries.push(json!({
            "kind": kind_str,
            "sm_arch": format!("sm_{}", sm_arch),
            "compressed": is_compressed,
            "payload_bytes": if is_compressed { compressed_size } else { padded_payload_size },
            "uncompressed_bytes": if is_compressed { uncompressed_size } else { padded_payload_size },
        }));

        off = payload_start + padded_payload_size;
    }
    entries
}

/// Pure-Rust LZ4 raw block decompressor used by NVIDIA `nvcc` inside `.nv_fatbin`.
fn decompress_cuda_lz4(inp: &[u8], max_out: usize) -> Vec<u8> {
    let mut out = Vec::with_capacity(max_out.min(65536));
    let mut ip = 0usize;
    while ip < inp.len() && out.len() < max_out {
        let token = inp[ip];
        ip += 1;
        let mut lit_len = (token >> 4) as usize;
        if lit_len == 15 {
            while ip < inp.len() {
                let s = inp[ip] as usize;
                ip += 1;
                lit_len += s;
                if s != 255 {
                    break;
                }
            }
        }
        if ip + lit_len > inp.len() {
            out.extend_from_slice(&inp[ip..]);
            break;
        }
        out.extend_from_slice(&inp[ip..ip + lit_len]);
        ip += lit_len;
        if ip + 2 > inp.len() {
            break;
        }
        let offset = u16::from_le_bytes([inp[ip], inp[ip + 1]]) as usize;
        ip += 2;
        if offset == 0 || offset > out.len() {
            break;
        }
        let mut match_len = ((token & 0x0F) as usize) + 4;
        if (token & 0x0F) == 15 {
            while ip < inp.len() {
                let s = inp[ip] as usize;
                ip += 1;
                match_len += s;
                if s != 255 {
                    break;
                }
            }
        }
        let start = out.len() - offset;
        for i in 0..match_len {
            if out.len() >= max_out {
                break;
            }
            let b = out[start + i];
            out.push(b);
        }
    }
    out
}

fn parse_ptx_text(txt: &str, include_ptx: bool, max_chars: usize) -> Value {
    let mut version = String::new();
    let mut target = String::new();
    let mut address_size = String::new();
    let mut kernels = Vec::new();

    let lines: Vec<&str> = txt.lines().collect();
    let mut i = 0usize;
    while i < lines.len() {
        let trimmed = lines[i].trim();
        if let Some(rest) = trimmed.strip_prefix(".version") {
            version = rest.trim().to_string();
        } else if let Some(rest) = trimmed.strip_prefix(".target") {
            target = rest.trim().to_string();
        } else if let Some(rest) = trimmed.strip_prefix(".address_size") {
            address_size = rest.trim().to_string();
        } else if trimmed.contains(".entry ") || trimmed.starts_with(".entry ") {
            // Collect header up to `{` or `;`
            let mut sig = String::from(trimmed);
            let mut j = i + 1;
            while j < lines.len() && !sig.contains('{') && !sig.ends_with(';') && j <= i + 32 {
                sig.push(' ');
                sig.push_str(lines[j].trim());
                j += 1;
            }
            if let Some(entry_pos) = sig.find(".entry ") {
                let after = sig[entry_pos + 7..].trim();
                let kname: String = after
                    .chars()
                    .take_while(|c| c.is_ascii_alphanumeric() || *c == '_' || *c == '$')
                    .collect();
                let params: Vec<String> = sig
                    .split(".param")
                    .skip(1)
                    .map(|p| {
                        p.trim()
                            .trim_end_matches(|c: char| matches!(c, ',' | ')' | '{' | ';'))
                            .trim()
                            .to_string()
                    })
                    .filter(|p| !p.is_empty())
                    .collect();
                kernels.push(json!({
                    "name": kname,
                    "visible": trimmed.contains(".visible"),
                    "params": params,
                }));
            }
            i = j;
            continue;
        }
        i += 1;
    }

    let preview = if include_ptx {
        Some(txt.chars().take(max_chars).collect::<String>())
    } else {
        None
    };

    json!({
        "ptx_version": version,
        "target": target,
        "address_size": address_size,
        "kernel_count": kernels.len(),
        "kernels": kernels,
        "ptx_text_preview": preview,
        "truncated": txt.len() > max_chars,
    })
}

fn find_subslice(haystack: &[u8], needle: &[u8]) -> Option<usize> {
    if needle.is_empty() || haystack.len() < needle.len() {
        return None;
    }
    haystack.windows(needle.len()).position(|w| w == needle)
}

// ============================================================================
// 2. Godot `.pck` Inspector & Extractor (`game_godot_pck_extract`)
// ============================================================================

pub fn tool_game_godot_pck_extract(args: &Value) -> Result<Value, String> {
    let path_str = args
        .get("path")
        .and_then(Value::as_str)
        .ok_or("Missing required string parameter 'path'")?;
    let output_dir = args.get("output_dir").and_then(Value::as_str);
    let filter = args
        .get("filter")
        .and_then(Value::as_str)
        .unwrap_or("")
        .to_ascii_lowercase();
    let limit = args.get("limit").and_then(Value::as_u64).unwrap_or(200).min(5000) as usize;

    let data = fs::read(path_str).map_err(|e| format!("Failed reading '{}': {}", path_str, e))?;
    if data.len() < 40 {
        return Err("File too small to be a Godot .pck archive".into());
    }

    // Locate `GDPC` (0x43504447 LE): either at offset 0 or via embedded executable footer (`GDPC` in last 4 bytes -> 8-byte size before it)
    let pck_start = if &data[0..4] == b"GDPC" {
        0usize
    } else if &data[data.len() - 4..] == b"GDPC" && data.len() >= 12 {
        let embedded_size = u64_le(&data, data.len() - 12).unwrap_or(0) as usize;
        let cand = data.len().saturating_sub(12).saturating_sub(embedded_size);
        if data.get(cand..cand + 4) == Some(b"GDPC") {
            cand
        } else {
            find_subslice(&data, b"GDPC").ok_or("Missing GDPC header in executable")?
        }
    } else {
        return Err("Missing Godot PCK magic 'GDPC' (checked header and embedded executable footer)".into());
    };

    let b = &data[pck_start..];
    let pack_version = u32_le(b, 4).ok_or("Truncated PCK version")?;
    let eng_major = u32_le(b, 8).unwrap_or(0);
    let eng_minor = u32_le(b, 12).unwrap_or(0);
    let eng_patch = u32_le(b, 16).unwrap_or(0);

    let (pack_flags, file_base, mut cursor) = if pack_version >= 2 {
        let flags = u32_le(b, 20).unwrap_or(0);
        let fbase = u64_le(b, 24).unwrap_or(0) as usize;
        // 16 reserved u32s (64 bytes) follow at offset 32..96
        (flags, fbase, 96usize)
    } else {
        // PCK v0 / v1: 16 reserved u32s at offset 20..84
        (0u32, 0usize, 84usize)
    };

    let dir_encrypted = (pack_flags & 1) != 0;
    let rel_filebase = (pack_flags & 2) != 0;
    if dir_encrypted {
        return Ok(json!({
            "format": "godot_pck",
            "path": path_str,
            "pck_version": pack_version,
            "godot_version": format!("{}.{}.{}", eng_major, eng_minor, eng_patch),
            "directory_encrypted": true,
            "note": "PCK directory is AES-256 encrypted (PACK_DIR_ENCRYPTED). Recover the 32-byte key from the host binary first using Craft Anything's native_bytes_find / Ghidra."
        }));
    }

    let file_count = u32_le(b, cursor).ok_or("Truncated PCK file count")? as usize;
    cursor += 4;

    let mut entries_json = Vec::new();
    let mut extracted_count = 0usize;
    let mut encrypted_files = 0usize;
    let mut total_bytes_unpacked = 0u64;

    for _ in 0..file_count.min(200_000) {
        let Some(path_len_u32) = u32_le(b, cursor) else { break };
        let path_len = path_len_u32 as usize;
        cursor += 4;
        let Some(raw_path) = b.get(cursor..cursor.saturating_add(path_len)) else { break };
        cursor += path_len;
        let Some(rel_off) = u64_le(b, cursor) else { break };
        let Some(fsize) = u64_le(b, cursor + 8) else { break };
        let Some(md5_bytes) = b.get(cursor + 16..cursor + 32) else { break };
        cursor += 32;
        let entry_flags = if pack_version >= 2 {
            let f = u32_le(b, cursor).unwrap_or(0);
            cursor += 4;
            f
        } else {
            0
        };

        let end_nul = raw_path.iter().position(|&c| c == 0).unwrap_or(raw_path.len());
        let res_path = String::from_utf8_lossy(&raw_path[..end_nul]).to_string();
        let is_enc = (entry_flags & 1) != 0;
        if is_enc {
            encrypted_files += 1;
        }
        total_bytes_unpacked = total_bytes_unpacked.saturating_add(fsize);

        if !filter.is_empty() && !res_path.to_ascii_lowercase().contains(&filter) {
            continue;
        }

        let abs_off = if pack_version >= 2 && (rel_filebase || pck_start > 0 || file_base > 0) {
            pck_start.saturating_add(file_base).saturating_add(rel_off as usize)
        } else {
            pck_start.saturating_add(rel_off as usize)
        };

        if let Some(out_root) = output_dir {
            if !is_enc {
                if let Some(slice) = data.get(abs_off..abs_off.saturating_add(fsize as usize)) {
                    if let Some(dst) = safe_join_under(Path::new(out_root), &res_path) {
                        if let Some(parent) = dst.parent() {
                            let _ = fs::create_dir_all(parent);
                        }
                        if fs::write(&dst, slice).is_ok() {
                            extracted_count += 1;
                        }
                    }
                }
            }
        }

        if entries_json.len() < limit {
            entries_json.push(json!({
                "path": res_path,
                "size": fsize,
                "offset": format!("0x{:x}", abs_off),
                "md5": hex_encode(md5_bytes),
                "encrypted": is_enc,
            }));
        }
    }

    Ok(json!({
        "format": "godot_pck",
        "path": path_str,
        "embedded_offset": format!("0x{:x}", pck_start),
        "pck_version": pack_version,
        "godot_version": format!("{}.{}.{}", eng_major, eng_minor, eng_patch),
        "pack_flags": pack_flags,
        "total_files": file_count,
        "total_unpacked_bytes": total_bytes_unpacked,
        "encrypted_file_count": encrypted_files,
        "extracted_count": extracted_count,
        "output_dir": output_dir,
        "entries": entries_json,
    }))
}

// ============================================================================
// 3. Unity IL2CPP `global-metadata.dat` Decoder (`game_il2cpp_meta_show`)
// ============================================================================

pub fn tool_game_il2cpp_meta_show(args: &Value) -> Result<Value, String> {
    let path_str = args
        .get("path")
        .and_then(Value::as_str)
        .ok_or("Missing required string parameter 'path'")?;
    let filter = args
        .get("filter")
        .and_then(Value::as_str)
        .unwrap_or("")
        .to_ascii_lowercase();
    let limit = args.get("limit").and_then(Value::as_u64).unwrap_or(100).min(1000) as usize;

    let b = fs::read(path_str).map_err(|e| format!("Failed reading '{}': {}", path_str, e))?;
    if b.len() < 176 {
        return Err("File too small for Unity global-metadata.dat".into());
    }
    let sanity = u32_le(&b, 0).unwrap_or(0);
    let version = i32_le(&b, 4).unwrap_or(0);
    if sanity != 0xFAB1_1BAF {
        return Err(format!(
            "Invalid IL2CPP sanity magic 0x{:08x} (expected 0xFAB11BAF). Note: obfuscated Unity games sometimes XOR or strip this header in libil2cpp.so.",
            sanity
        ));
    }

    // Standard Il2CppGlobalMetadataHeader initial fields (consistent across v24..v39):
    // [8]: stringLiteralOffset, [12]: stringLiteralSize,
    // [16]: stringLiteralDataOffset, [20]: stringLiteralDataSize,
    // [24]: stringOffset, [28]: stringSize,
    // [32]: eventsOffset, [36]: eventsSize,
    // [40]: propertiesOffset, [44]: propertiesSize,
    // [48]: methodsOffset, [52]: methodsSize, ...
    // [160]: typeDefinitionsOffset, [164]: typeDefinitionsSize,
    // [168]: imagesOffset (or [172] on v24.0 with rgctxEntries; auto-probed below!)
    let str_lit_off = u32_le(&b, 8).unwrap_or(0) as usize;
    let str_lit_sz = u32_le(&b, 12).unwrap_or(0) as usize;
    let str_lit_data_off = u32_le(&b, 16).unwrap_or(0) as usize;
    let str_lit_data_sz = u32_le(&b, 20).unwrap_or(0) as usize;
    let str_off = u32_le(&b, 24).unwrap_or(0) as usize;
    let str_sz = u32_le(&b, 28).unwrap_or(0) as usize;
    let methods_off = u32_le(&b, 48).unwrap_or(0) as usize;
    let methods_sz = u32_le(&b, 52).unwrap_or(0) as usize;

    let str_heap = b
        .get(str_off..str_off.saturating_add(str_sz).min(b.len()))
        .unwrap_or(&[]);
    let lit_data = b
        .get(str_lit_data_off..str_lit_data_off.saturating_add(str_lit_data_sz).min(b.len()))
        .unwrap_or(&[]);

    // Decode String Literals (each Il2CppStringLiteral is 8 bytes: u32 length, i32 dataIndex)
    let total_literals = str_lit_sz / 8;
    let mut literals = Vec::new();
    if let Some(lit_tab) = b.get(str_lit_off..str_lit_off.saturating_add(str_lit_sz)) {
        for i in 0..total_literals {
            let len = u32_le(lit_tab, i * 8).unwrap_or(0) as usize;
            let idx = u32_le(lit_tab, i * 8 + 4).unwrap_or(0) as usize;
            if let Some(raw) = lit_data.get(idx..idx.saturating_add(len)) {
                let s = String::from_utf8_lossy(raw).to_string();
                if !filter.is_empty() && !s.to_ascii_lowercase().contains(&filter) {
                    continue;
                }
                if literals.len() < limit {
                    literals.push(s);
                }
            }
        }
    }

    // Locate Images table & TypeDefinitions table reliably across v24..v39
    // Il2CppImageDefinition is 40 bytes (10 x i32/u32), starting with nameIndex pointing to "*.dll\0" in str_heap!
    let (images_off, images_sz) = probe_images_pair(&b, str_heap).unwrap_or((0, 0));
    let mut assemblies = Vec::new();
    if images_sz >= 40 {
        if let Some(img_slice) = b.get(images_off..images_off.saturating_add(images_sz)) {
            let stride = 40usize;
            for i in 0..(img_slice.len() / stride) {
                let name_idx = u32_le(img_slice, i * stride).unwrap_or(0) as usize;
                let type_start = i32_le(img_slice, i * stride + 8).unwrap_or(0);
                let type_count = u32_le(img_slice, i * stride + 12).unwrap_or(0);
                let name = read_heap_cstr(str_heap, name_idx);
                if !name.is_empty() {
                    assemblies.push(json!({
                        "name": name,
                        "type_start": type_start,
                        "type_count": type_count,
                    }));
                }
            }
        }
    }

    // TypeDefinitions sit immediately before Images in the header directory (offset pair at -8 from images pair)
    let (typedef_off, typedef_sz) = find_preceding_pair(&b, images_off).unwrap_or((
        u32_le(&b, 160).unwrap_or(0) as usize,
        u32_le(&b, 164).unwrap_or(0) as usize,
    ));
    let type_stride = match version {
        24 => 92usize,
        27 | 28 => 88usize,
        29 | 30 => 84usize,
        _ => 88usize, // v31..v39 typically 88 or 84; probed below
    };
    let actual_type_stride = probe_stride(typedef_sz, &[type_stride, 88, 84, 92, 96, 80]).unwrap_or(type_stride);
    let mut types_out = Vec::new();
    let total_types = if actual_type_stride > 0 { typedef_sz / actual_type_stride } else { 0 };
    if let Some(tslice) = b.get(typedef_off..typedef_off.saturating_add(typedef_sz)) {
        for i in 0..(tslice.len() / actual_type_stride) {
            let name_idx = u32_le(tslice, i * actual_type_stride).unwrap_or(0) as usize;
            let ns_idx = u32_le(tslice, i * actual_type_stride + 4).unwrap_or(0) as usize;
            let tname = read_heap_cstr(str_heap, name_idx);
            if tname.is_empty() {
                continue;
            }
            let ns = read_heap_cstr(str_heap, ns_idx);
            let full = if ns.is_empty() {
                tname.clone()
            } else {
                format!("{}.{}", ns, tname)
            };
            if !filter.is_empty() && !full.to_ascii_lowercase().contains(&filter) {
                continue;
            }
            if types_out.len() < limit {
                types_out.push(json!({
                    "type_index": i,
                    "namespace": ns,
                    "name": tname,
                }));
            }
        }
    }

    // Methods (`Il2CppMethodDefinition`: first field is `nameIndex`, second is `declaringType`)
    let method_stride = probe_stride(
        methods_sz,
        &[
            if version >= 31 { 52 } else if version >= 29 { 52 } else { 56 },
            52,
            56,
            60,
            64,
            48,
        ],
    )
    .unwrap_or(52);
    let total_methods = if method_stride > 0 { methods_sz / method_stride } else { 0 };
    let mut methods_out = Vec::new();
    if let Some(mslice) = b.get(methods_off..methods_off.saturating_add(methods_sz)) {
        for i in 0..(mslice.len() / method_stride) {
            let name_idx = u32_le(mslice, i * method_stride).unwrap_or(0) as usize;
            let decl_type = i32_le(mslice, i * method_stride + 4).unwrap_or(-1);
            let mname = read_heap_cstr(str_heap, name_idx);
            if mname.is_empty() {
                continue;
            }
            if !filter.is_empty() && !mname.to_ascii_lowercase().contains(&filter) {
                continue;
            }
            if methods_out.len() < limit {
                methods_out.push(json!({
                    "method_index": i,
                    "name": mname,
                    "declaring_type_index": decl_type,
                }));
            }
        }
    }

    Ok(json!({
        "format": "unity_il2cpp_metadata",
        "path": path_str,
        "file_size": b.len(),
        "metadata_version": version,
        "counts": {
            "assemblies": assemblies.len(),
            "types": total_types,
            "methods": total_methods,
            "string_literals": total_literals,
            "identifier_heap_bytes": str_sz,
        },
        "assemblies": assemblies,
        "types_sample": types_out,
        "methods_sample": methods_out,
        "string_literals_sample": literals,
    }))
}

fn read_heap_cstr(heap: &[u8], idx: usize) -> String {
    let Some(sub) = heap.get(idx..) else {
        return String::new();
    };
    let end = sub.iter().position(|&c| c == 0).unwrap_or(sub.len()).min(512);
    if end == 0 {
        return String::new();
    }
    String::from_utf8_lossy(&sub[..end]).to_string()
}

fn probe_images_pair(b: &[u8], str_heap: &[u8]) -> Option<(usize, usize)> {
    // Scan header directory offsets 144..248 for an (offset, size) pair whose first entry points to a `.dll` or `mscorlib`/`Assembly` name
    let mut h = 144usize;
    while h + 8 <= 256.min(b.len()) {
        let off = u32_le(b, h)? as usize;
        let sz = u32_le(b, h + 4)? as usize;
        if sz >= 40 && sz % 40 == 0 && off > 128 && off.saturating_add(sz) <= b.len() {
            let name_idx = u32_le(b, off).unwrap_or(u32::MAX) as usize;
            let name = read_heap_cstr(str_heap, name_idx);
            if name.ends_with(".dll") || name == "__Generated" || name.starts_with("UnityEngine") || name == "mscorlib" {
                return Some((off, sz));
            }
        }
        h += 4;
    }
    None
}

fn find_preceding_pair(b: &[u8], target_off: usize) -> Option<(usize, usize)> {
    if target_off == 0 {
        return None;
    }
    let mut h = 136usize;
    while h + 16 <= 256.min(b.len()) {
        let next_off = u32_le(b, h + 8)? as usize;
        if next_off == target_off {
            let off = u32_le(b, h)? as usize;
            let sz = u32_le(b, h + 4)? as usize;
            return Some((off, sz));
        }
        h += 4;
    }
    None
}

fn probe_stride(total_size: usize, candidates: &[usize]) -> Option<usize> {
    if total_size == 0 {
        return None;
    }
    candidates.iter().copied().find(|&s| s > 0 && total_size % s == 0)
}

// ============================================================================
// 4. Erlang / Elixir `.beam` Bytecode Inspector (`formats_beam_show`)
// ============================================================================

pub fn tool_formats_beam_show(args: &Value) -> Result<Value, String> {
    let path_str = args
        .get("path")
        .and_then(Value::as_str)
        .ok_or("Missing required string parameter 'path'")?;

    let b = fs::read(path_str).map_err(|e| format!("Failed reading '{}': {}", path_str, e))?;
    if b.len() < 12 || &b[0..4] != b"FOR1" || &b[8..12] != b"BEAM" {
        return Err("File is not an uncompressed FOR1/BEAM module (expected 'FOR1' + size + 'BEAM')".into());
    }

    let form_size = u32_be(&b, 4).unwrap_or(0) as usize;
    let mut cursor = 12usize;
    let mut chunks = Vec::new();
    let mut atoms: Vec<String> = Vec::new();
    let mut raw_exports: Vec<(u32, u32, u32)> = Vec::new();
    let mut raw_imports: Vec<(u32, u32, u32)> = Vec::new();
    let mut raw_lambdas: Vec<(u32, u32, u32, u32)> = Vec::new();
    let mut code_header = None;

    while cursor + 8 <= b.len() {
        let id = String::from_utf8_lossy(&b[cursor..cursor + 4]).to_string();
        let csize = u32_be(&b, cursor + 4).unwrap_or(0) as usize;
        let data_start = cursor + 8;
        let Some(cdata) = b.get(data_start..data_start.saturating_add(csize)) else { break };
        chunks.push(json!({ "id": id, "size": csize }));

        match id.as_str() {
            "AtU8" | "Atom" if !cdata.is_empty() => {
                let raw_count = u32_be(cdata, 0).unwrap_or(0) as i32;
                let mut p = 4usize;
                let otp28_varint = raw_count < 0;
                let count = raw_count.unsigned_abs() as usize;
                atoms.push("<nil>".into()); // 1-based atom table
                for _ in 0..count.min(50_000) {
                    if p >= cdata.len() {
                        break;
                    }
                    let alen = if otp28_varint {
                        let first = cdata[p] as usize;
                        p += 1;
                        if (first & 0x08) == 0 {
                            first >> 4
                        } else if p < cdata.len() {
                            let next = cdata[p] as usize;
                            p += 1;
                            ((first >> 5) << 8) | next
                        } else {
                            0
                        }
                    } else {
                        let l = cdata[p] as usize;
                        p += 1;
                        l
                    };
                    let Some(abytes) = cdata.get(p..p.saturating_add(alen)) else { break };
                    p += alen;
                    atoms.push(String::from_utf8_lossy(abytes).to_string());
                }
            }
            "ExpT" if cdata.len() >= 4 => {
                let cnt = u32_be(cdata, 0).unwrap_or(0) as usize;
                for i in 0..cnt.min((cdata.len() - 4) / 12) {
                    let fn_atom = u32_be(cdata, 4 + i * 12).unwrap_or(0);
                    let arity = u32_be(cdata, 8 + i * 12).unwrap_or(0);
                    let label = u32_be(cdata, 12 + i * 12).unwrap_or(0);
                    raw_exports.push((fn_atom, arity, label));
                }
            }
            "ImpT" if cdata.len() >= 4 => {
                let cnt = u32_be(cdata, 0).unwrap_or(0) as usize;
                for i in 0..cnt.min((cdata.len() - 4) / 12) {
                    let m_atom = u32_be(cdata, 4 + i * 12).unwrap_or(0);
                    let fn_atom = u32_be(cdata, 8 + i * 12).unwrap_or(0);
                    let arity = u32_be(cdata, 12 + i * 12).unwrap_or(0);
                    raw_imports.push((m_atom, fn_atom, arity));
                }
            }
            "FunT" if cdata.len() >= 4 => {
                let cnt = u32_be(cdata, 0).unwrap_or(0) as usize;
                for i in 0..cnt.min((cdata.len() - 4) / 24) {
                    let fn_atom = u32_be(cdata, 4 + i * 24).unwrap_or(0);
                    let arity = u32_be(cdata, 8 + i * 24).unwrap_or(0);
                    let label = u32_be(cdata, 12 + i * 24).unwrap_or(0);
                    let num_free = u32_be(cdata, 20 + i * 24).unwrap_or(0);
                    raw_lambdas.push((fn_atom, arity, label, num_free));
                }
            }
            "Code" if cdata.len() >= 20 => {
                code_header = Some(json!({
                    "sub_size": u32_be(cdata, 0).unwrap_or(0),
                    "instruction_set": u32_be(cdata, 4).unwrap_or(0),
                    "opcode_max": u32_be(cdata, 8).unwrap_or(0),
                    "label_count": u32_be(cdata, 12).unwrap_or(0),
                    "function_count": u32_be(cdata, 16).unwrap_or(0),
                    "bytecode_bytes": cdata.len().saturating_sub(20),
                }));
            }
            _ => {}
        }

        cursor = data_start + ((csize + 3) & !3);
    }

    let atom_at = |idx: u32| -> String {
        atoms
            .get(idx as usize)
            .cloned()
            .unwrap_or_else(|| format!("atom#{}", idx))
    };

    let module_name = atoms.get(1).cloned().unwrap_or_default();
    let exports: Vec<Value> = raw_exports
        .into_iter()
        .map(|(f, a, l)| json!({ "function": atom_at(f), "arity": a, "label": l }))
        .collect();
    let imports: Vec<Value> = raw_imports
        .into_iter()
        .map(|(m, f, a)| json!({ "module": atom_at(m), "function": atom_at(f), "arity": a }))
        .collect();
    let lambdas: Vec<Value> = raw_lambdas
        .into_iter()
        .map(|(f, a, l, nf)| json!({ "function": atom_at(f), "arity": a, "label": l, "free_vars": nf }))
        .collect();

    Ok(json!({
        "format": "erlang_beam",
        "path": path_str,
        "form_size": form_size,
        "module": module_name,
        "chunks": chunks,
        "code_header": code_header,
        "atom_count": atoms.len().saturating_sub(1),
        "atoms_sample": atoms.iter().skip(1).take(120).cloned().collect::<Vec<_>>(),
        "exports": exports,
        "imports": imports,
        "lambdas": lambdas,
    }))
}

// ============================================================================
// 5. JS / Electron / Web Release Exposure Auditor (`js_release_audit`)
// ============================================================================

pub fn tool_js_release_audit(args: &Value) -> Result<Value, String> {
    let path_str = args
        .get("path")
        .and_then(Value::as_str)
        .ok_or("Missing required string parameter 'path'")?;
    let max_files = args
        .get("max_files")
        .and_then(Value::as_u64)
        .unwrap_or(300)
        .min(2000) as usize;

    let root = Path::new(path_str);
    if !root.exists() {
        return Err(format!("Target '{}' does not exist", path_str));
    }

    let mut files = Vec::new();
    collect_js_files(root, &mut files, max_files);

    let mut source_maps = Vec::new();
    let mut secret_findings = Vec::new();
    let mut internal_endpoints: BTreeSet<String> = BTreeSet::new();
    let mut electron_risks = Vec::new();

    for fpath in &files {
        let ext = fpath
            .extension()
            .and_then(|e| e.to_str())
            .unwrap_or("")
            .to_ascii_lowercase();
        let rel = fpath
            .strip_prefix(root)
            .unwrap_or(fpath)
            .to_string_lossy()
            .to_string();
        let label = if rel.is_empty() {
            fpath.file_name().and_then(|n| n.to_str()).unwrap_or(path_str).to_string()
        } else {
            rel
        };

        let Ok(meta) = fs::metadata(fpath) else { continue };
        if meta.len() > 25 * 1024 * 1024 {
            continue;
        }
        let Ok(bytes) = fs::read(fpath) else { continue };
        let content = String::from_utf8_lossy(&bytes);

        if ext == "map" {
            let mut src_count = 0usize;
            let mut has_sources_content = false;
            if let Ok(v) = serde_json::from_str::<Value>(&content) {
                src_count = v
                    .get("sources")
                    .and_then(Value::as_array)
                    .map(|a| a.len())
                    .unwrap_or(0);
                has_sources_content = v
                    .get("sourcesContent")
                    .and_then(Value::as_array)
                    .map(|a| !a.is_empty())
                    .unwrap_or(false);
            }
            source_maps.push(json!({
                "file": label,
                "kind": "standalone_map",
                "sources_count": src_count,
                "embeds_original_source_code": has_sources_content,
            }));
            continue;
        }

        // Check sourceMappingURL comments
        for marker in ["//# sourceMappingURL=", "//@ sourceMappingURL="] {
            if let Some(pos) = content.rfind(marker) {
                let target_url: String = content[pos + marker.len()..]
                    .lines()
                    .next()
                    .unwrap_or("")
                    .trim()
                    .chars()
                    .take(160)
                    .collect();
                let is_inline = target_url.starts_with("data:application/json");
                source_maps.push(json!({
                    "file": label,
                    "kind": if is_inline { "inline_base64_sourcemap" } else { "external_sourcemap_ref" },
                    "target": if is_inline { "<inline base64>" } else { target_url.as_str() },
                }));
            }
        }

        // Scan Electron BrowserWindow security misconfigurations
        for &(needle, risk) in &[
            ("nodeIntegration:!0", "nodeIntegration enabled in bundle"),
            ("nodeIntegration: true", "nodeIntegration enabled"),
            ("contextIsolation:!1", "contextIsolation disabled in bundle"),
            ("contextIsolation: false", "contextIsolation disabled"),
            ("webSecurity:!1", "webSecurity disabled in bundle"),
            ("webSecurity: false", "webSecurity disabled"),
            ("enableRemoteModule:!0", "enableRemoteModule enabled"),
            ("enableRemoteModule: true", "enableRemoteModule enabled"),
        ] {
            if content.contains(needle) {
                electron_risks.push(json!({ "file": label, "issue": risk }));
            }
        }

        // Scan secret prefixes & internal endpoints
        scan_secrets_and_urls(&content, &label, &mut secret_findings, &mut internal_endpoints);
    }

    let severity = if !secret_findings.is_empty() || !electron_risks.is_empty() {
        "high"
    } else if !source_maps.is_empty() || !internal_endpoints.is_empty() {
        "medium"
    } else {
        "low"
    };

    Ok(json!({
        "target": path_str,
        "files_scanned": files.len(),
        "overall_exposure_risk": severity,
        "source_map_exposures": source_maps,
        "secret_candidates": secret_findings,
        "internal_or_api_endpoints": internal_endpoints.into_iter().take(150).collect::<Vec<_>>(),
        "electron_security_findings": electron_risks,
    }))
}

fn collect_js_files(dir: &Path, out: &mut Vec<std::path::PathBuf>, max: usize) {
    if out.len() >= max {
        return;
    }
    if dir.is_file() {
        out.push(dir.to_path_buf());
        return;
    }
    let Ok(rd) = fs::read_dir(dir) else { return };
    for entry in rd.flatten() {
        if out.len() >= max {
            break;
        }
        let p = entry.path();
        let fname = entry.file_name().to_string_lossy().to_string();
        if fname == "node_modules" || fname == ".git" {
            continue;
        }
        if p.is_dir() {
            collect_js_files(&p, out, max);
        } else if let Some(ext) = p.extension().and_then(|e| e.to_str()) {
            if matches!(
                ext.to_ascii_lowercase().as_str(),
                "js" | "mjs" | "cjs" | "map" | "html" | "json"
            ) {
                out.push(p);
            }
        }
    }
}

fn scan_secrets_and_urls(
    txt: &str,
    file_label: &str,
    secrets: &mut Vec<Value>,
    endpoints: &mut BTreeSet<String>,
) {
    let prefixes: &[(&str, &str, usize)] = &[
        ("AKIA", "aws_access_key_id", 20),
        ("AIzaSy", "google_api_key", 39),
        ("ghp_", "github_personal_token", 36),
        ("github_pat_", "github_fine_grained_pat", 40),
        ("sk_live_", "stripe_live_secret_key", 28),
        ("rk_live_", "stripe_live_restricted_key", 28),
        ("xoxb-", "slack_bot_token", 30),
        ("xoxp-", "slack_user_token", 30),
        ("-----BEGIN RSA PRIVATE KEY-----", "pem_rsa_private_key", 27),
        ("-----BEGIN PRIVATE KEY-----", "pem_pkcs8_private_key", 23),
    ];

    for &(pfx, kind, min_len) in prefixes {
        if secrets.len() >= 50 {
            break;
        }
        let mut search_from = 0usize;
        while let Some(rel) = txt[search_from..].find(pfx) {
            let pos = search_from + rel;
            let token: String = txt[pos..]
                .chars()
                .take_while(|c| {
                    c.is_ascii_alphanumeric() || matches!(*c, '_' | '-' | ' ' | '=' | '/')
                })
                .take(64)
                .collect();
            if token.len() >= min_len {
                let masked = if token.len() > 12 {
                    format!("{}...{}", &token[..8], &token[token.len() - 4..])
                } else {
                    token.clone()
                };
                secrets.push(json!({
                    "file": file_label,
                    "type": kind,
                    "preview_masked": masked,
                }));
            }
            search_from = pos + pfx.len();
            if secrets.len() >= 50 {
                break;
            }
        }
    }

    for scheme in ["https://", "http://", "wss://", "ws://"] {
        let mut from = 0usize;
        while let Some(rel) = txt[from..].find(scheme) {
            let pos = from + rel;
            let url: String = txt[pos..]
                .chars()
                .take_while(|c| {
                    c.is_ascii_alphanumeric()
                        || matches!(*c, ':' | '/' | '.' | '-' | '_' | '?' | '=' | '&')
                })
                .take(140)
                .collect();
            from = pos + scheme.len();
            let low = url.to_ascii_lowercase();
            if low.contains("localhost")
                || low.contains("127.0.0.1")
                || low.contains("staging")
                || low.contains("internal")
                || low.contains("/api/")
                || low.contains("/graphql")
                || low.contains("/v1/")
                || low.contains("/v2/")
                || low.contains("admin")
            {
                endpoints.insert(url);
                if endpoints.len() >= 200 {
                    return;
                }
            }
        }
    }
}
