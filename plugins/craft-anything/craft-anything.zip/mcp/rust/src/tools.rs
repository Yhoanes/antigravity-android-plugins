//! MCP Tool Catalog & Panic-Safe Dispatcher for `craft-plus-mcp` (12 Native Rust ARM64 Tools).

use crate::firmware::{tool_firmware_dtb_fit_show, tool_firmware_esp_uf2_show};
use crate::gpu_game_formats::{
    tool_formats_beam_show, tool_game_godot_pck_extract, tool_game_il2cpp_meta_show,
    tool_gpu_cuda_ptx_show, tool_js_release_audit,
};
use crate::retro_aot::{
    tool_ghidra_headless_run, tool_nativeaot_metadata_show, tool_retro_to_elf_convert,
};
use crate::rl_har::{tool_rl_har_env_build, tool_rl_har_env_serve};
use serde_json::{json, Value};
use std::panic::{catch_unwind, AssertUnwindSafe};

pub const PLUS_TOOL_NAMES: &[&str] = &[
    "firmware_esp_uf2_show",
    "firmware_dtb_fit_show",
    "gpu_cuda_ptx_show",
    "game_godot_pck_extract",
    "game_il2cpp_meta_show",
    "formats_beam_show",
    "js_release_audit",
    "retro_to_elf_convert",
    "ghidra_headless_run",
    "nativeaot_metadata_show",
    "rl_har_env_build",
    "rl_har_env_serve",
];

pub fn is_plus_tool(name: &str) -> bool {
    PLUS_TOOL_NAMES.contains(&name)
}

pub fn dispatch_plus_tool(name: &str, args: &Value) -> Result<Value, String> {
    let outcome = catch_unwind(AssertUnwindSafe(|| match name {
        "firmware_esp_uf2_show" => tool_firmware_esp_uf2_show(args),
        "firmware_dtb_fit_show" => tool_firmware_dtb_fit_show(args),
        "gpu_cuda_ptx_show" => tool_gpu_cuda_ptx_show(args),
        "game_godot_pck_extract" => tool_game_godot_pck_extract(args),
        "game_il2cpp_meta_show" => tool_game_il2cpp_meta_show(args),
        "formats_beam_show" => tool_formats_beam_show(args),
        "js_release_audit" => tool_js_release_audit(args),
        "retro_to_elf_convert" => tool_retro_to_elf_convert(args),
        "ghidra_headless_run" => tool_ghidra_headless_run(args),
        "nativeaot_metadata_show" => tool_nativeaot_metadata_show(args),
        "rl_har_env_build" => tool_rl_har_env_build(args),
        "rl_har_env_serve" => tool_rl_har_env_serve(args),
        _ => Err(format!("Unknown craft-plus tool '{}'", name)),
    }));

    match outcome {
        Ok(res) => res,
        Err(_) => Err(format!(
            "Internal parser panic caught safely while executing '{}'",
            name
        )),
    }
}

pub fn plus_tool_schemas() -> Vec<Value> {
    vec![
        json!({
            "name": "firmware_esp_uf2_show",
            "annotations": { "title": "ESP32 & UF2 Firmware Show", "readOnlyHint": false, "idempotentHint": true },
            "description": "Inspect ESP8266/ESP32/S2/S3/C2/C3/C6/H2/P4 firmware images (0xE9 magic, chip ID, IRAM/DRAM/IROM/DROM segments, XOR & SHA-256 verification, esp_app_desc_t metadata, and 0xAA50 partition tables) or Microsoft UF2 microcontroller images (30+ MCU family IDs, flash ranges, and optional payload extraction).",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "path": { "type": "string", "description": "Absolute path to ESP32 .bin, partition table, or .uf2 file." },
                    "extract_to": { "type": "string", "description": "Optional path to write reconstructed contiguous binary payload (for UF2)." }
                },
                "required": ["path"]
            }
        }),
        json!({
            "name": "firmware_dtb_fit_show",
            "annotations": { "title": "DeviceTree & U-Boot FIT Show", "readOnlyHint": false, "idempotentHint": true },
            "description": "Inspect Flattened Device Tree blobs (.dtb, 0xD00DFEED) and Das U-Boot FIT firmware images (uImage.FIT). Returns model, compatible strings, memory reservations, FDT node hierarchy, and FIT kernel/ramdisk/fdt sub-images with SHA-256 and optional extraction.",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "path": { "type": "string", "description": "Absolute path to .dtb, .itb, or firmware blob containing 0xD00DFEED." },
                    "extract_dir": { "type": "string", "description": "Optional directory to extract embedded U-Boot FIT sub-images." },
                    "max_nodes": { "type": "integer", "description": "Maximum FDT node paths to list (default 200)." }
                },
                "required": ["path"]
            }
        }),
        json!({
            "name": "gpu_cuda_ptx_show",
            "annotations": { "title": "CUDA Fatbin & PTX Show", "readOnlyHint": true, "idempotentHint": true },
            "description": "Inspect NVIDIA CUDA fatbin containers (0xBA55ED50), standalone cubin/ROCm HSACO ELFs, .ptx files, or host .so/.dll/ELF/PE binaries with embedded .nv_fatbin sections. Decompresses nvcc LZ4 fatbin streams in pure Rust to recover target SM architectures, PTX assembly, and .entry kernel signatures.",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "path": { "type": "string", "description": "Absolute path to .ptx, .cubin, .fatbin, .so, .dll, or host binary." },
                    "include_ptx": { "type": "boolean", "description": "Include decompressed PTX assembly preview (default true)." },
                    "max_ptx_chars": { "type": "integer", "description": "Max PTX characters per module (default 8000)." }
                },
                "required": ["path"]
            }
        }),
        json!({
            "name": "game_godot_pck_extract",
            "annotations": { "title": "Godot PCK Inspect & Extract", "readOnlyHint": false, "idempotentHint": true },
            "description": "Inspect and extract Godot 3.x / 4.x .pck archives (standalone .pck or self-contained game executables with embedded GDPC tail). Reports Godot version, res:// inventory, MD5 hashes, encryption flags, and optionally unpacks assets cleanly for Game Studio.",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "path": { "type": "string", "description": "Absolute path to .pck archive or self-contained Godot binary." },
                    "output_dir": { "type": "string", "description": "Optional directory to extract unencrypted res:// files into." },
                    "filter": { "type": "string", "description": "Optional case-insensitive substring filter on res:// paths." },
                    "limit": { "type": "integer", "description": "Max entries to return in JSON summary (default 200)." }
                },
                "required": ["path"]
            }
        }),
        json!({
            "name": "game_il2cpp_meta_show",
            "annotations": { "title": "Unity IL2CPP Metadata Show", "readOnlyHint": true, "idempotentHint": true },
            "description": "Decode Unity IL2CPP global-metadata.dat (0xFAB11BAF, versions 24 through 39) in pure Rust without external tools. Recovers C# assembly names, namespaces, class/type definitions, method names, and embedded string literals.",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "path": { "type": "string", "description": "Absolute path to global-metadata.dat." },
                    "filter": { "type": "string", "description": "Optional substring filter applied to types, methods, and string literals." },
                    "limit": { "type": "integer", "description": "Max items per category to return (default 100)." }
                },
                "required": ["path"]
            }
        }),
        json!({
            "name": "formats_beam_show",
            "annotations": { "title": "Erlang/Elixir BEAM Show", "readOnlyHint": true, "idempotentHint": true },
            "description": "Inspect Erlang/Elixir .beam bytecode modules (FOR1/BEAM IFF chunks). Decodes module name, AtU8/Atom table (including OTP 28 varint atoms), ExpT exports, ImpT imports, FunT lambdas, and Code header statistics.",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "path": { "type": "string", "description": "Absolute path to uncompressed .beam file." }
                },
                "required": ["path"]
            }
        }),
        json!({
            "name": "js_release_audit",
            "annotations": { "title": "JS & Electron Release Audit", "readOnlyHint": true, "idempotentHint": true },
            "description": "Audit a JavaScript, Web, or unpacked Electron release folder/bundle for shipped .map or inline base64 source maps, leaked API keys/tokens (masked), internal/staging endpoints, and unsafe Electron BrowserWindow flags.",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "path": { "type": "string", "description": "Absolute path to JS file or unpacked release/app directory." },
                    "max_files": { "type": "integer", "description": "Max files to scan (default 300)." }
                },
                "required": ["path"]
            }
        }),
        json!({
            "name": "retro_to_elf_convert",
            "annotations": { "title": "Retro/Console/Firmware -> ELF", "readOnlyHint": false, "idempotentHint": true },
            "description": "Pure-Rust loader & ELF32/ELF64 synthesizer: converts Nintendo GameCube/Wii .dol, 16-bit DOS .com, ESP32 0xE9 firmware, UF2 images, or raw console/MCU ROMs into a standard ELF with exact virtual addresses, sections, and symbols so Craft Anything's Rust pseudo-C engine (<50MB RAM, zero Java) and Ghidra can decompile them immediately.",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "path": { "type": "string", "description": "Absolute path to .dol, .com, ESP32 .bin, .uf2, or raw ROM binary." },
                    "format": { "type": "string", "description": "Input container: 'auto' (default), 'dol', 'dos_com', 'esp32', 'uf2', or 'raw'." },
                    "arch": { "type": "string", "description": "Architecture override (required for 'raw'): ppc, ppc64, x86, x86_64, arm, thumb, aarch64, mips, mipsel, riscv32, riscv64, xtensa, sh4, m68k." },
                    "base_addr": { "type": "string", "description": "Base load address in hex (e.g. '0x08000000' for STM32, '0x0100' for DOS .com)." },
                    "entry_addr": { "type": "string", "description": "Entry point address in hex (defaults to base_addr for raw)." },
                    "file_offset": { "type": "string", "description": "Optional byte offset inside raw ROM file." },
                    "output_path": { "type": "string", "description": "Optional output .elf path (defaults to dot-free $PREFIX/tmp/craft-elf/<name>.elf)." }
                },
                "required": ["path"]
            }
        }),
        json!({
            "name": "ghidra_headless_run",
            "annotations": { "title": "Ghidra 12.1.4 Headless Run", "readOnlyHint": true, "idempotentHint": true },
            "description": "Run native Android ARM64 Ghidra 12.1.4 analyzeHeadless safely with mobile RAM caps and dot-free temp paths (auto-converting .dol, .uf2, and ESP32 images to ELF first). Returns language/compiler metadata, discovered functions, and decompiled C pseudocode.",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "path": { "type": "string", "description": "Absolute path to binary (.so, .elf, .exe, .dll, .dol, .uf2, ESP32 .bin, etc.)." },
                    "processor": { "type": "string", "description": "Optional Ghidra SLEIGH language ID (e.g. 'PowerPC:BE:32:default', 'MIPS:LE:32:default', 'x86:LE:16:Real Mode')." },
                    "function_filter": { "type": "string", "description": "Optional substring filter on function names." },
                    "max_functions": { "type": "integer", "description": "Max functions to list (default 40)." },
                    "decompile_count": { "type": "integer", "description": "Number of matching non-thunk functions to decompile to C (default 3, max 15)." },
                    "max_ram": { "type": "string", "description": "JVM max heap for mobile safety (default '1536M')." },
                    "timeout_sec": { "type": "integer", "description": "Execution deadline in seconds (default 180)." }
                },
                "required": ["path"]
            }
        }),
        json!({
            "name": "nativeaot_metadata_show",
            "annotations": { "title": ".NET NativeAOT & R2R Show", "readOnlyHint": true, "idempotentHint": true },
            "description": "Inspect .NET 7/8/9/10 NativeAOT, ReadyToRun (RTR\\0), and Single-File AppHost native binaries (ELF, PE, Mach-O) in pure Rust. Detects AOT/hydration sections, RTR section tables, single-file bundle offsets, runtime banners, and symbolicated C# identifiers.",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "path": { "type": "string", "description": "Absolute path to compiled .NET NativeAOT / ReadyToRun ELF, PE, or Mach-O binary." },
                    "limit": { "type": "integer", "description": "Max recovered managed identifier strings to return (default 100)." }
                },
                "required": ["path"]
            }
        }),
        json!({
            "name": "rl_har_env_build",
            "annotations": { "title": "Build RL Env from HAR", "readOnlyHint": false, "idempotentHint": true },
            "description": "Build a deterministic Reinforcement Learning (RL) & API simulation environment from a recorded browser/mitmproxy .har file. Infers REST route templates, seeds stateful CRUD collections, and writes env_manifest.json, openapi.json, agent_tools.json, and reward_checks.json.",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "har_path": { "type": "string", "description": "Absolute path to recorded .har session file." },
                    "output_dir": { "type": "string", "description": "Directory where the RL environment package will be generated." },
                    "name": { "type": "string", "description": "Environment name (default 'craft-rl-env')." },
                    "include_static": { "type": "boolean", "description": "Include static assets like CSS/images (default false)." }
                },
                "required": ["har_path", "output_dir"]
            }
        }),
        json!({
            "name": "rl_har_env_serve",
            "annotations": { "title": "Serve & Evaluate RL Mock Env", "readOnlyHint": false, "idempotentHint": false },
            "description": "Manage the 100% native Rust in-memory stateful HTTP mock & RL evaluator server on 127.0.0.1 (<2MB RAM, no Docker or Python). Supports actions: 'start', 'status', 'evaluate' (computes 0.0..1.0 reward score), 'reset' (restores episode seed state), and 'stop'.",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "action": { "type": "string", "enum": ["start", "status", "evaluate", "reset", "stop"], "description": "Lifecycle or evaluation action." },
                    "env_dir": { "type": "string", "description": "Environment directory built by rl_har_env_build (required for 'start')." },
                    "port": { "type": "integer", "description": "Local TCP port on 127.0.0.1 (0 or omit for auto-assigned free port on start)." }
                },
                "required": ["action"]
            }
        }),
    ]
}
