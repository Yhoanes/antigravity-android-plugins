//! Pure-Rust ELF32 & ELF64 synthesizer (Little-Endian & Big-Endian) for converting
//! console/retro containers (.dol, DOS .com) and firmware images (ESP32, UF2, raw ROMs)
//! into standards-compliant ELF executables with exact virtual addresses, sections, and symbols.

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Endian {
    Little,
    Big,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ElfClass {
    Elf32,
    Elf64,
}

#[derive(Debug, Clone, Copy)]
pub struct ArchSpec {
    pub name: &'static str,
    pub e_machine: u16,
    pub class: ElfClass,
    pub endian: Endian,
    pub e_flags: u32,
}

impl ArchSpec {
    pub fn from_name(arch: &str) -> Result<Self, String> {
        match arch.trim().to_ascii_lowercase().as_str() {
            "ppc" | "powerpc" | "gekko" | "broadway" | "dol" => Ok(Self {
                name: "ppc32-be",
                e_machine: 20, // EM_PPC
                class: ElfClass::Elf32,
                endian: Endian::Big,
                e_flags: 0,
            }),
            "ppc64" => Ok(Self {
                name: "ppc64-be",
                e_machine: 21, // EM_PPC64
                class: ElfClass::Elf64,
                endian: Endian::Big,
                e_flags: 0,
            }),
            "x86" | "i386" | "dos" | "dos16" => Ok(Self {
                name: "x86-32",
                e_machine: 3, // EM_386
                class: ElfClass::Elf32,
                endian: Endian::Little,
                e_flags: 0,
            }),
            "x86_64" | "amd64" => Ok(Self {
                name: "x86_64",
                e_machine: 62, // EM_X86_64
                class: ElfClass::Elf64,
                endian: Endian::Little,
                e_flags: 0,
            }),
            "arm" | "arm32" | "armv7" => Ok(Self {
                name: "arm32-le",
                e_machine: 40, // EM_ARM
                class: ElfClass::Elf32,
                endian: Endian::Little,
                e_flags: 0x0500_0000, // EABI v5
            }),
            "thumb" | "cortex-m" => Ok(Self {
                name: "arm-thumb-le",
                e_machine: 40, // EM_ARM
                class: ElfClass::Elf32,
                endian: Endian::Little,
                e_flags: 0x0500_0000,
            }),
            "aarch64" | "arm64" => Ok(Self {
                name: "aarch64",
                e_machine: 183, // EM_AARCH64
                class: ElfClass::Elf64,
                endian: Endian::Little,
                e_flags: 0,
            }),
            "mips" | "mipsbe" => Ok(Self {
                name: "mips32-be",
                e_machine: 8, // EM_MIPS
                class: ElfClass::Elf32,
                endian: Endian::Big,
                e_flags: 0,
            }),
            "mipsel" | "psp" | "allegrex" | "ps2" => Ok(Self {
                name: "mips32-le",
                e_machine: 8, // EM_MIPS
                class: ElfClass::Elf32,
                endian: Endian::Little,
                e_flags: 0,
            }),
            "riscv32" | "rv32" | "rv32imc" => Ok(Self {
                name: "riscv32",
                e_machine: 243, // EM_RISCV
                class: ElfClass::Elf32,
                endian: Endian::Little,
                e_flags: 0x0001, // RVC
            }),
            "riscv64" | "rv64" => Ok(Self {
                name: "riscv64",
                e_machine: 243, // EM_RISCV
                class: ElfClass::Elf64,
                endian: Endian::Little,
                e_flags: 0x0005,
            }),
            "xtensa" | "lx6" | "lx7" | "esp32" => Ok(Self {
                name: "xtensa-le",
                e_machine: 94, // EM_XTENSA
                class: ElfClass::Elf32,
                endian: Endian::Little,
                e_flags: 0,
            }),
            "sh4" | "superh" => Ok(Self {
                name: "sh4-le",
                e_machine: 42, // EM_SH
                class: ElfClass::Elf32,
                endian: Endian::Little,
                e_flags: 0,
            }),
            "m68k" | "68000" | "genesis" => Ok(Self {
                name: "m68k-be",
                e_machine: 4, // EM_68K
                class: ElfClass::Elf32,
                endian: Endian::Big,
                e_flags: 0,
            }),
            other => Err(format!(
                "Unsupported architecture '{}'. Supported: ppc, ppc64, x86, x86_64, arm, thumb, aarch64, mips, mipsel/psp, riscv32, riscv64, xtensa, sh4, m68k",
                other
            )),
        }
    }
}

#[derive(Debug, Clone)]
pub struct SynthSection {
    pub name: String,
    pub vaddr: u64,
    pub mem_size: u64,
    pub data: Vec<u8>, // empty for SHT_NOBITS (.bss)
    pub executable: bool,
    pub writable: bool,
    pub nobits: bool,
    pub align: u64,
}

#[derive(Debug, Clone)]
pub struct SynthSymbol {
    pub name: String,
    pub value: u64,
    pub size: u64,
    pub is_func: bool,
    pub section_index: u16,
}

struct Writer {
    buf: Vec<u8>,
    endian: Endian,
}

impl Writer {
    fn new(endian: Endian) -> Self {
        Self {
            buf: Vec::with_capacity(4096),
            endian,
        }
    }
    fn u8(&mut self, v: u8) {
        self.buf.push(v);
    }
    fn u16(&mut self, v: u16) {
        match self.endian {
            Endian::Little => self.buf.extend_from_slice(&v.to_le_bytes()),
            Endian::Big => self.buf.extend_from_slice(&v.to_be_bytes()),
        }
    }
    fn u32(&mut self, v: u32) {
        match self.endian {
            Endian::Little => self.buf.extend_from_slice(&v.to_le_bytes()),
            Endian::Big => self.buf.extend_from_slice(&v.to_be_bytes()),
        }
    }
    fn u64(&mut self, v: u64) {
        match self.endian {
            Endian::Little => self.buf.extend_from_slice(&v.to_le_bytes()),
            Endian::Big => self.buf.extend_from_slice(&v.to_be_bytes()),
        }
    }
    fn pad_to(&mut self, align: usize) {
        if align <= 1 {
            return;
        }
        let rem = self.buf.len() % align;
        if rem != 0 {
            self.buf.resize(self.buf.len() + (align - rem), 0);
        }
    }
}

fn push_strtab(tab: &mut Vec<u8>, s: &str) -> u32 {
    let off = tab.len() as u32;
    tab.extend_from_slice(s.as_bytes());
    tab.push(0);
    off
}

/// Synthesize a complete ELF32 or ELF64 executable with PT_LOAD segments, section headers,
/// .shstrtab, .strtab, and .symtab so both Craft Anything's built-in Rust engine and Ghidra
/// open and decompile it immediately.
pub fn build_elf(
    arch: ArchSpec,
    entry_point: u64,
    sections: &[SynthSection],
    symbols: &[SynthSymbol],
) -> Result<Vec<u8>, String> {
    if sections.is_empty() {
        return Err("At least one loadable section is required to synthesize ELF".into());
    }

    let is_64 = arch.class == ElfClass::Elf64;
    let ehdr_size: usize = if is_64 { 64 } else { 52 };
    let phent_size: usize = if is_64 { 56 } else { 32 };
    let shent_size: usize = if is_64 { 64 } else { 40 };
    let phnum = sections.len();

    // Build .shstrtab: [0]="", [1..N]=user sections, [N+1]=".symtab", [N+2]=".strtab", [N+3]=".shstrtab"
    let mut shstrtab = vec![0u8];
    let mut sec_name_offs = Vec::with_capacity(sections.len());
    for sec in sections {
        sec_name_offs.push(push_strtab(&mut shstrtab, &sec.name));
    }
    let symtab_name_off = push_strtab(&mut shstrtab, ".symtab");
    let strtab_name_off = push_strtab(&mut shstrtab, ".strtab");
    let shstrtab_name_off = push_strtab(&mut shstrtab, ".shstrtab");

    // Build .strtab + .symtab
    let mut strtab = vec![0u8];
    let mut sym_w = Writer::new(arch.endian);
    // Null symbol (entry 0)
    sym_w.buf.resize(if is_64 { 24 } else { 16 }, 0);
    for sym in symbols {
        let name_off = push_strtab(&mut strtab, &sym.name);
        // STB_GLOBAL = 1 << 4, STT_FUNC = 2, STT_OBJECT = 1
        let st_info: u8 = (1 << 4) | if sym.is_func { 2 } else { 1 };
        let st_other: u8 = 0;
        let st_shndx: u16 = if (sym.section_index as usize) <= sections.len() && sym.section_index > 0 {
            sym.section_index
        } else {
            1
        };
        if is_64 {
            sym_w.u32(name_off);
            sym_w.u8(st_info);
            sym_w.u8(st_other);
            sym_w.u16(st_shndx);
            sym_w.u64(sym.value);
            sym_w.u64(sym.size);
        } else {
            sym_w.u32(name_off);
            sym_w.u32(sym.value as u32);
            sym_w.u32(sym.size as u32);
            sym_w.u8(st_info);
            sym_w.u8(st_other);
            sym_w.u16(st_shndx);
        }
    }
    let symtab_bytes = sym_w.buf;

    // Compute file layout:
    // [ELF Header][Program Headers][Aligned Section Payloads][.symtab][.strtab][.shstrtab][Aligned Section Headers]
    let mut body = Writer::new(arch.endian);
    body.buf.resize(ehdr_size + phnum * phent_size, 0);

    let mut sec_file_offs = Vec::with_capacity(sections.len());
    for sec in sections {
        if sec.nobits || sec.data.is_empty() {
            body.pad_to(16);
            sec_file_offs.push(body.buf.len() as u64);
        } else {
            body.pad_to(16);
            let off = body.buf.len() as u64;
            body.buf.extend_from_slice(&sec.data);
            sec_file_offs.push(off);
        }
    }

    body.pad_to(8);
    let symtab_off = body.buf.len() as u64;
    body.buf.extend_from_slice(&symtab_bytes);

    let strtab_off = body.buf.len() as u64;
    body.buf.extend_from_slice(&strtab);

    let shstrtab_off = body.buf.len() as u64;
    body.buf.extend_from_slice(&shstrtab);

    body.pad_to(8);
    let shoff = body.buf.len() as u64;

    // Total section headers = 1 (NULL) + sections.len() + 3 (.symtab, .strtab, .shstrtab)
    let shnum = 1 + sections.len() + 3;
    let shstrndx = (shnum - 1) as u16;
    let strtab_shndx = (shnum - 2) as u32;

    // Emit Section Headers into `sh_w`
    let mut sh_w = Writer::new(arch.endian);
    // [0] SHT_NULL
    sh_w.buf.resize(shent_size, 0);

    for (idx, sec) in sections.iter().enumerate() {
        let sh_type: u32 = if sec.nobits { 8 } else { 1 }; // SHT_NOBITS=8, SHT_PROGBITS=1
        // SHF_ALLOC = 0x2, SHF_WRITE = 0x1, SHF_EXECINSTR = 0x4
        let mut sh_flags: u64 = 0x2;
        if sec.writable {
            sh_flags |= 0x1;
        }
        if sec.executable {
            sh_flags |= 0x4;
        }
        let sh_size = if sec.nobits {
            sec.mem_size
        } else {
            sec.data.len().max(sec.mem_size as usize) as u64
        };
        let align = sec.align.max(4);
        write_shdr(
            &mut sh_w,
            is_64,
            sec_name_offs[idx],
            sh_type,
            sh_flags,
            sec.vaddr,
            sec_file_offs[idx],
            sh_size,
            0,
            0,
            align,
            0,
        );
    }

    // .symtab (SHT_SYMTAB = 2), sh_link = strtab_shndx, sh_info = 1 (first non-local symbol)
    let sym_entsize: u64 = if is_64 { 24 } else { 16 };
    write_shdr(
        &mut sh_w,
        is_64,
        symtab_name_off,
        2,
        0,
        0,
        symtab_off,
        symtab_bytes.len() as u64,
        strtab_shndx,
        1,
        8,
        sym_entsize,
    );

    // .strtab (SHT_STRTAB = 3)
    write_shdr(
        &mut sh_w,
        is_64,
        strtab_name_off,
        3,
        0,
        0,
        strtab_off,
        strtab.len() as u64,
        0,
        0,
        1,
        0,
    );

    // .shstrtab (SHT_STRTAB = 3)
    write_shdr(
        &mut sh_w,
        is_64,
        shstrtab_name_off,
        3,
        0,
        0,
        shstrtab_off,
        shstrtab.len() as u64,
        0,
        0,
        1,
        0,
    );

    body.buf.extend_from_slice(&sh_w.buf);

    // Now build ELF Header + Program Headers into `hdr_w` and copy into body[0..ehdr+phdrs]
    let mut hdr_w = Writer::new(arch.endian);
    hdr_w.buf.extend_from_slice(&[0x7f, b'E', b'L', b'F']);
    hdr_w.u8(if is_64 { 2 } else { 1 }); // EI_CLASS
    hdr_w.u8(match arch.endian {
        Endian::Little => 1,
        Endian::Big => 2,
    }); // EI_DATA
    hdr_w.u8(1); // EI_VERSION
    hdr_w.buf.extend_from_slice(&[0u8; 9]); // EI_OSABI + padding

    hdr_w.u16(2); // ET_EXEC
    hdr_w.u16(arch.e_machine);
    hdr_w.u32(1); // EV_CURRENT
    if is_64 {
        hdr_w.u64(entry_point);
        hdr_w.u64(ehdr_size as u64); // e_phoff
        hdr_w.u64(shoff); // e_shoff
    } else {
        hdr_w.u32(entry_point as u32);
        hdr_w.u32(ehdr_size as u32);
        hdr_w.u32(shoff as u32);
    }
    hdr_w.u32(arch.e_flags);
    hdr_w.u16(ehdr_size as u16);
    hdr_w.u16(phent_size as u16);
    hdr_w.u16(phnum as u16);
    hdr_w.u16(shent_size as u16);
    hdr_w.u16(shnum as u16);
    hdr_w.u16(shstrndx);

    // Program Headers (PT_LOAD = 1)
    for (idx, sec) in sections.iter().enumerate() {
        // PF_R = 4, PF_W = 2, PF_X = 1
        let mut p_flags: u32 = 4;
        if sec.writable {
            p_flags |= 2;
        }
        if sec.executable {
            p_flags |= 1;
        }
        let filesz = if sec.nobits { 0 } else { sec.data.len() as u64 };
        let memsz = sec.mem_size.max(filesz);
        let align = sec.align.max(16);
        if is_64 {
            hdr_w.u32(1); // PT_LOAD
            hdr_w.u32(p_flags);
            hdr_w.u64(sec_file_offs[idx]);
            hdr_w.u64(sec.vaddr);
            hdr_w.u64(sec.vaddr);
            hdr_w.u64(filesz);
            hdr_w.u64(memsz);
            hdr_w.u64(align);
        } else {
            hdr_w.u32(1); // PT_LOAD
            hdr_w.u32(sec_file_offs[idx] as u32);
            hdr_w.u32(sec.vaddr as u32);
            hdr_w.u32(sec.vaddr as u32);
            hdr_w.u32(filesz as u32);
            hdr_w.u32(memsz as u32);
            hdr_w.u32(p_flags);
            hdr_w.u32(align as u32);
        }
    }

    let hdr_len = hdr_w.buf.len();
    body.buf[..hdr_len].copy_from_slice(&hdr_w.buf);
    Ok(body.buf)
}

#[allow(clippy::too_many_arguments)]
fn write_shdr(
    w: &mut Writer,
    is_64: bool,
    sh_name: u32,
    sh_type: u32,
    sh_flags: u64,
    sh_addr: u64,
    sh_offset: u64,
    sh_size: u64,
    sh_link: u32,
    sh_info: u32,
    sh_addralign: u64,
    sh_entsize: u64,
) {
    w.u32(sh_name);
    w.u32(sh_type);
    if is_64 {
        w.u64(sh_flags);
        w.u64(sh_addr);
        w.u64(sh_offset);
        w.u64(sh_size);
        w.u32(sh_link);
        w.u32(sh_info);
        w.u64(sh_addralign);
        w.u64(sh_entsize);
    } else {
        w.u32(sh_flags as u32);
        w.u32(sh_addr as u32);
        w.u32(sh_offset as u32);
        w.u32(sh_size as u32);
        w.u32(sh_link);
        w.u32(sh_info);
        w.u32(sh_addralign as u32);
        w.u32(sh_entsize as u32);
    }
}
