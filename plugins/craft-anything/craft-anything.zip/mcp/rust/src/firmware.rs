//! Pure-Rust IoT & Embedded Firmware Analyzers:
//! - ESP8266 / ESP32 / S2 / S3 / C2 / C3 / C6 / H2 / P4 (`0xE9` App Image + `esp_app_desc_t` + Partition Table)
//! - Microsoft UF2 (`0x0A324655` / `0x9E5D5157` / `0x0AB16F30`) with 30+ MCU family IDs & payload extraction
//! - Flattened Device Tree (`.dtb`, `0xD00DFEED`) & Das U-Boot `FIT` (`uImage.FIT`) with sub-image extraction

use crate::sha256::{hex_encode, sha256};
use serde_json::{json, Value};
use std::collections::BTreeMap;
use std::fs;
use std::path::{Path, PathBuf};

fn read_u16_le(b: &[u8], off: usize) -> Option<u16> {
    Some(u16::from_le_bytes(b.get(off..off + 2)?.try_into().ok()?))
}
fn read_u32_le(b: &[u8], off: usize) -> Option<u32> {
    Some(u32::from_le_bytes(b.get(off..off + 4)?.try_into().ok()?))
}
fn read_u32_be(b: &[u8], off: usize) -> Option<u32> {
    Some(u32::from_be_bytes(b.get(off..off + 4)?.try_into().ok()?))
}
fn read_u64_be(b: &[u8], off: usize) -> Option<u64> {
    Some(u64::from_be_bytes(b.get(off..off + 8)?.try_into().ok()?))
}

fn cstr_lossy(bytes: &[u8]) -> String {
    let end = bytes.iter().position(|&c| c == 0).unwrap_or(bytes.len());
    String::from_utf8_lossy(&bytes[..end]).trim().to_string()
}

pub struct RawLoadedSegment {
    pub name: String,
    pub vaddr: u64,
    pub data: Vec<u8>,
    pub executable: bool,
    pub writable: bool,
}

pub struct ParsedFirmwareSegments {
    pub format: String,
    pub arch_hint: String,
    pub entry_point: u64,
    pub segments: Vec<RawLoadedSegment>,
}

pub fn esp_chip_info(chip_id: u16) -> (&'static str, &'static str) {
    match chip_id {
        0x0000 => ("ESP32", "xtensa"),
        0x0002 => ("ESP32-S2", "xtensa"),
        0x0005 => ("ESP32-C3", "riscv32"),
        0x0009 => ("ESP32-S3", "xtensa"),
        0x000C => ("ESP32-C2", "riscv32"),
        0x000D => ("ESP32-C6", "riscv32"),
        0x0010 => ("ESP32-H2", "riscv32"),
        0x0012 => ("ESP32-P4", "riscv32"),
        0x0017 => ("ESP32-C5", "riscv32"),
        0x0014 => ("ESP32-C61", "riscv32"),
        _ => ("Unknown-ESP", "xtensa"),
    }
}

fn classify_esp_region(chip_id: u16, addr: u32) -> (&'static str, bool, bool) {
    // Returns (region_name, executable, writable)
    match chip_id {
        0x0005 | 0x000C | 0x000D | 0x0010 | 0x0017 | 0x0014 => {
            // RISC-V ESP32-C3/C2/C6/H2 memory map
            if (0x3C00_0000..0x3E00_0000).contains(&addr) {
                ("DROM (Flash RO Data)", false, false)
            } else if (0x4200_0000..0x4400_0000).contains(&addr) {
                ("IROM (Flash Code)", true, false)
            } else if (0x3FC8_0000..0x3FD0_0000).contains(&addr) {
                ("DRAM (Internal SRAM Data)", false, true)
            } else if (0x4037_C000..0x403E_0000).contains(&addr) {
                ("IRAM (Internal SRAM Code)", true, true)
            } else if (0x5000_0000..0x5000_4000).contains(&addr) {
                ("RTC_FAST_MEM", true, true)
            } else {
                ("MAPPED_SEG", true, true)
            }
        }
        0x0012 => {
            // ESP32-P4 RISC-V high-perf map
            if (0x4000_0000..0x4400_0000).contains(&addr) {
                ("FLASH_XIP", true, false)
            } else if (0x4FF0_0000..0x5000_0000).contains(&addr) {
                ("L2MEM_SRAM", true, true)
            } else {
                ("P4_SEG", true, true)
            }
        }
        _ => {
            // Xtensa ESP32 / ESP32-S2 / ESP32-S3
            if (0x3F40_0000..0x3F80_0000).contains(&addr) || (0x3C00_0000..0x3E00_0000).contains(&addr) {
                ("DROM (Flash RO Data)", false, false)
            } else if (0x400D_0000..0x4040_0000).contains(&addr) || (0x4200_0000..0x4400_0000).contains(&addr) {
                ("IROM (Flash Code)", true, false)
            } else if (0x3FFB_0000..0x4000_0000).contains(&addr) || (0x3FC8_0000..0x3FD0_0000).contains(&addr) {
                ("DRAM (Internal SRAM Data)", false, true)
            } else if (0x4007_0000..0x400C_2000).contains(&addr) || (0x4037_0000..0x403E_0000).contains(&addr) {
                ("IRAM (Internal SRAM Code)", true, true)
            } else if (0x400C_0000..0x400C_2000).contains(&addr) || (0x5000_0000..0x5000_2000).contains(&addr) {
                ("RTC_MEM", true, true)
            } else {
                ("XTENSA_SEG", true, true)
            }
        }
    }
}

fn uf2_family_info(family_id: u32) -> (&'static str, &'static str) {
    match family_id {
        0xE48BFF56 => ("RP2040 (Raspberry Pi Pico)", "thumb"),
        0xE48BFF57 => ("RP2350-ARM-S", "thumb"),
        0xE48BFF58 => ("RP2350-DATA", "arm"),
        0xE48BFF59 => ("RP2350-ARM-NS", "thumb"),
        0xE48BFF5A => ("RP2350-RISCV (Hazard3)", "riscv32"),
        0x1C5F21B0 => ("ESP32", "xtensa"),
        0xBFDD4EEE => ("ESP32-S2", "xtensa"),
        0xC47E5767 => ("ESP32-S3", "xtensa"),
        0x2B88D29C => ("ESP32-C2", "riscv32"),
        0x6B846188 => ("ESP32-C3", "riscv32"),
        0x540DDF62 => ("ESP32-C6", "riscv32"),
        0x332726F6 => ("ESP32-H2", "riscv32"),
        0x3D308E94 => ("ESP32-P4", "riscv32"),
        0x5EE21072 => ("STM32F103", "thumb"),
        0x57755A57 => ("STM32F401", "thumb"),
        0x53B80F00 => ("STM32F407 / F4", "thumb"),
        0x4C71240A => ("STM32G4", "thumb"),
        0x6DB66082 => ("STM32H7", "thumb"),
        0xADA52840 => ("nRF52840", "thumb"),
        0x621E937A => ("nRF52833", "thumb"),
        0x68ED2B88 => ("ATSAMD21", "thumb"),
        0x55114460 => ("ATSAMD51", "thumb"),
        0x7EAB61ED => ("ESP8266", "xtensa"),
        _ => ("Generic-UF2-MCU", "thumb"),
    }
}

/// Extract loadable segments from ESP32 `0xE9` or UF2 images for `retro_to_elf_convert`.
pub fn extract_firmware_segments(data: &[u8]) -> Result<ParsedFirmwareSegments, String> {
    if data.len() >= 512
        && read_u32_le(data, 0) == Some(0x0A32_4655)
        && read_u32_le(data, 4) == Some(0x9E5D_5157)
    {
        return extract_uf2_segments(data);
    }
    if data.first() == Some(&0xE9) && data.len() >= 24 {
        return extract_esp_segments(data, 0);
    }
    // Check common combined flash image offsets (0x1000 bootloader, 0x10000 factory app)
    for &off in &[0x10000usize, 0x1000usize, 0x0usize] {
        if off + 24 < data.len() && data[off] == 0xE9 && (1..=16).contains(&data[off + 1]) {
            if let Ok(parsed) = extract_esp_segments(data, off) {
                return Ok(parsed);
            }
        }
    }
    Err("File is neither a valid UF2 image (0x0A324655) nor an ESP32/ESP-IDF 0xE9 firmware image".into())
}

fn extract_esp_segments(data: &[u8], base_off: usize) -> Result<ParsedFirmwareSegments, String> {
    let slice = data.get(base_off..).ok_or("Invalid offset")?;
    if slice.len() < 24 || slice[0] != 0xE9 {
        return Err("Missing ESP 0xE9 magic".into());
    }
    let seg_count = slice[1] as usize;
    if seg_count == 0 || seg_count > 24 {
        return Err(format!("Invalid ESP segment count: {}", seg_count));
    }
    let entry = read_u32_le(slice, 4).ok_or("Truncated ESP header")? as u64;
    let chip_id = read_u16_le(slice, 12).unwrap_or(0);
    let (_chip_name, arch_hint) = esp_chip_info(chip_id);

    let mut cursor = 24usize;
    let mut segments = Vec::with_capacity(seg_count);
    for idx in 0..seg_count {
        let load_addr = read_u32_le(slice, cursor).ok_or("Truncated ESP segment header")?;
        let seg_len = read_u32_le(slice, cursor + 4).ok_or("Truncated ESP segment length")? as usize;
        cursor += 8;
        let payload = slice
            .get(cursor..cursor.saturating_add(seg_len))
            .ok_or_else(|| format!("ESP segment {} truncated (wanted {} bytes)", idx, seg_len))?;
        cursor += seg_len;
        let (region, exec, writ) = classify_esp_region(chip_id, load_addr);
        let short_tag = region.split_whitespace().next().unwrap_or("seg").to_ascii_lowercase();
        segments.push(RawLoadedSegment {
            name: format!(".esp_{}_{}", short_tag, idx),
            vaddr: load_addr as u64,
            data: payload.to_vec(),
            executable: exec,
            writable: writ,
        });
    }

    Ok(ParsedFirmwareSegments {
        format: "esp32_image".into(),
        arch_hint: arch_hint.into(),
        entry_point: entry,
        segments,
    })
}

fn extract_uf2_segments(data: &[u8]) -> Result<ParsedFirmwareSegments, String> {
    let mut blocks: BTreeMap<u32, &[u8]> = BTreeMap::new();
    let mut detected_family = 0u32;
    let mut off = 0usize;
    while off + 512 <= data.len() {
        let blk = &data[off..off + 512];
        off += 512;
        if read_u32_le(blk, 0) != Some(0x0A32_4655)
            || read_u32_le(blk, 4) != Some(0x9E5D_5157)
            || read_u32_le(blk, 508) != Some(0x0AB1_6F30)
        {
            continue;
        }
        let flags = read_u32_le(blk, 8).unwrap_or(0);
        if (flags & 0x0000_0001) != 0 || (flags & 0x0000_1000) != 0 {
            // Skip non-main-flash or file-container blocks when synthesizing code segments
            continue;
        }
        let target_addr = read_u32_le(blk, 12).unwrap_or(0);
        let payload_size = (read_u32_le(blk, 16).unwrap_or(0) as usize).min(476);
        if (flags & 0x0000_2000) != 0 && detected_family == 0 {
            detected_family = read_u32_le(blk, 28).unwrap_or(0);
        }
        if payload_size > 0 {
            blocks.insert(target_addr, &blk[32..32 + payload_size]);
        }
    }

    if blocks.is_empty() {
        return Err("UF2 file contains no flashable payload blocks".into());
    }

    let (_mcu, arch_hint) = uf2_family_info(detected_family);
    let mut segments: Vec<RawLoadedSegment> = Vec::new();
    for (&addr, &chunk) in &blocks {
        if let Some(last) = segments.last_mut() {
            let expected_next = last.vaddr + last.data.len() as u64;
            if addr as u64 == expected_next {
                last.data.extend_from_slice(chunk);
                continue;
            }
        }
        let idx = segments.len();
        segments.push(RawLoadedSegment {
            name: format!(".uf2_flash_{}", idx),
            vaddr: addr as u64,
            data: chunk.to_vec(),
            executable: true,
            writable: false,
        });
    }

    // Cortex-M vector table check: [0] = initial_sp, [4] = reset_handler
    let first = &segments[0];
    let entry_point = if arch_hint == "thumb" && first.data.len() >= 8 {
        let sp = read_u32_le(&first.data, 0).unwrap_or(0);
        let reset = read_u32_le(&first.data, 4).unwrap_or(0);
        if (0x2000_0000..0x3000_0000).contains(&sp) && reset != 0 {
            (reset & !1) as u64
        } else {
            first.vaddr
        }
    } else {
        first.vaddr
    };

    Ok(ParsedFirmwareSegments {
        format: "uf2".into(),
        arch_hint: arch_hint.into(),
        entry_point,
        segments,
    })
}

/// MCP Tool: `firmware_esp_uf2_show`
pub fn tool_firmware_esp_uf2_show(args: &Value) -> Result<Value, String> {
    let path_str = args
        .get("path")
        .and_then(Value::as_str)
        .ok_or("Missing required string parameter 'path'")?;
    let extract_to = args.get("extract_to").and_then(Value::as_str);

    let data = fs::read(path_str).map_err(|e| format!("Failed to read '{}': {}", path_str, e))?;
    if data.is_empty() {
        return Err("Target file is empty".into());
    }

    // 1. Check UF2
    if data.len() >= 512
        && read_u32_le(&data, 0) == Some(0x0A32_4655)
        && read_u32_le(&data, 4) == Some(0x9E5D_5157)
    {
        return inspect_uf2(&data, path_str, extract_to);
    }

    // 2. Check standalone ESP-IDF Partition Table (magic 0xAA 0x50)
    if data.len() >= 32 && data[0] == 0xAA && data[1] == 0x50 {
        let parts = parse_esp_partition_table(&data, 0);
        return Ok(json!({
            "format": "esp_partition_table",
            "path": path_str,
            "file_size": data.len(),
            "partitions": parts,
        }));
    }

    // 3. Check ESP32 / ESP-IDF 0xE9 image (either at offset 0 or combined flash image with bootloader/partitions/app)
    let mut detected_offsets = Vec::new();
    if data[0] == 0xE9 && data.len() >= 24 && (1..=24).contains(&data[1]) {
        detected_offsets.push(("image_at_0x0", 0usize));
    } else {
        for &(label, off) in &[
            ("bootloader_0x0", 0x0usize),
            ("bootloader_0x1000", 0x1000usize),
            ("bootloader_0x2000", 0x2000usize),
            ("app_0x10000", 0x10000usize),
            ("app_0x20000", 0x20000usize),
        ] {
            if off + 24 < data.len() && data[off] == 0xE9 && (1..=24).contains(&data[off + 1]) {
                detected_offsets.push((label, off));
            }
        }
    }

    if !detected_offsets.is_empty() {
        let mut images = Vec::new();
        for (label, off) in detected_offsets {
            if let Ok(img) = inspect_esp_image(&data, off) {
                images.push(json!({
                    "slot": label,
                    "file_offset": format!("0x{:x}", off),
                    "details": img,
                }));
            }
        }
        let partitions = if data.len() >= 0x8000 + 64 && data[0x8000] == 0xAA && data[0x8000 + 1] == 0x50 {
            parse_esp_partition_table(&data, 0x8000)
        } else if data.len() >= 0x9000 + 64 && data[0x9000] == 0xAA && data[0x9000 + 1] == 0x50 {
            parse_esp_partition_table(&data, 0x9000)
        } else {
            Vec::new()
        };

        return Ok(json!({
            "format": if images.len() > 1 || !partitions.is_empty() { "esp_combined_flash_image" } else { "esp_app_image" },
            "path": path_str,
            "file_size": data.len(),
            "partition_table": partitions,
            "images": images,
            "elf_conversion_hint": "Call retro_to_elf_convert on this file to synthesize a multi-segment Xtensa/RISC-V ELF for immediate Craft Anything pseudo-C or Ghidra decompilation."
        }));
    }

    Err("Unrecognized firmware header: expected ESP32/ESP-IDF image (0xE9), ESP partition table (0xAA50), or Microsoft UF2 (0x0A324655).".into())
}

fn inspect_esp_image(full_data: &[u8], base_off: usize) -> Result<Value, String> {
    let slice = full_data.get(base_off..).ok_or("Offset out of range")?;
    if slice.len() < 24 || slice[0] != 0xE9 {
        return Err("Not an ESP 0xE9 header".into());
    }
    let seg_count = slice[1] as usize;
    let spi_mode = match slice[2] {
        0 => "QIO",
        1 => "QOUT",
        2 => "DIO",
        3 => "DOUT",
        4 => "FAST_READ",
        5 => "SLOW_READ",
        _ => "UNKNOWN",
    };
    let spi_speed = match slice[3] & 0x0F {
        0 => "40MHz",
        1 => "26MHz",
        2 => "20MHz",
        0xF => "80MHz",
        _ => "Custom",
    };
    let spi_size = match (slice[3] >> 4) & 0x0F {
        0 => "1MB",
        1 => "2MB",
        2 => "4MB",
        3 => "8MB",
        4 => "16MB",
        5 => "32MB",
        6 => "64MB",
        7 => "128MB",
        _ => "Unknown",
    };
    let entry_addr = read_u32_le(slice, 4).unwrap_or(0);
    let wp_pin = slice[8];
    let chip_id = read_u16_le(slice, 12).unwrap_or(0);
    let (chip_name, arch) = esp_chip_info(chip_id);
    let min_rev_legacy = slice[15];
    let min_rev_full = read_u16_le(slice, 16).unwrap_or(0);
    let max_rev_full = read_u16_le(slice, 18).unwrap_or(0);
    let hash_appended = slice[23] == 1;

    let mut cursor = 24usize;
    let mut xor_checksum: u8 = 0xEF;
    let mut segments_json = Vec::new();
    let mut app_desc: Option<Value> = None;

    for idx in 0..seg_count {
        let Some(load_addr) = read_u32_le(slice, cursor) else { break };
        let Some(seg_len_u32) = read_u32_le(slice, cursor + 4) else { break };
        let seg_len = seg_len_u32 as usize;
        let data_start = cursor + 8;
        let Some(seg_bytes) = slice.get(data_start..data_start.saturating_add(seg_len)) else {
            return Err(format!("Segment {} truncated at +0x{:x}", idx, data_start));
        };
        for &b in seg_bytes {
            xor_checksum ^= b;
        }
        let (region, exec, writ) = classify_esp_region(chip_id, load_addr);

        // Check for esp_app_desc_t (magic 0xABCD5432, usually at offset 0 of DROM segment 0)
        if app_desc.is_none() && seg_bytes.len() >= 256 {
            for probe in [0usize, 0x10, 0x20] {
                if probe + 256 <= seg_bytes.len()
                    && read_u32_le(seg_bytes, probe) == Some(0xABCD_5432)
                {
                    let secure_ver = read_u32_le(seg_bytes, probe + 4).unwrap_or(0);
                    let version = cstr_lossy(&seg_bytes[probe + 16..probe + 48]);
                    let project_name = cstr_lossy(&seg_bytes[probe + 48..probe + 80]);
                    let compile_time = cstr_lossy(&seg_bytes[probe + 80..probe + 96]);
                    let compile_date = cstr_lossy(&seg_bytes[probe + 96..probe + 112]);
                    let idf_ver = cstr_lossy(&seg_bytes[probe + 112..probe + 144]);
                    let elf_sha256 = hex_encode(&seg_bytes[probe + 144..probe + 176]);
                    app_desc = Some(json!({
                        "project_name": project_name,
                        "version": version,
                        "idf_version": idf_ver,
                        "compile_date": compile_date,
                        "compile_time": compile_time,
                        "secure_version": secure_ver,
                        "app_elf_sha256": elf_sha256,
                    }));
                    break;
                }
            }
        }

        segments_json.push(json!({
            "index": idx,
            "file_offset": format!("0x{:x}", base_off + data_start),
            "load_addr": format!("0x{:08x}", load_addr),
            "size": seg_len,
            "region": region,
            "executable": exec,
            "writable": writ,
        }));
        cursor = data_start + seg_len;
    }

    // Align to 16 bytes (last byte of 16B padded block is the XOR checksum)
    let padded_end = ((cursor + 1) + 15) & !15;
    let checksum_pos = padded_end.saturating_sub(1);
    let stored_checksum = slice.get(checksum_pos).copied();
    let checksum_valid = stored_checksum == Some(xor_checksum);

    let sha256_status = if hash_appended && slice.len() >= padded_end + 32 {
        let expected = &slice[padded_end..padded_end + 32];
        let actual = sha256(&slice[..padded_end]);
        json!({
            "present": true,
            "expected": hex_encode(expected),
            "computed": hex_encode(&actual),
            "valid": expected == actual.as_slice(),
        })
    } else {
        json!({ "present": false })
    };

    Ok(json!({
        "chip_id": format!("0x{:04x}", chip_id),
        "chip_name": chip_name,
        "architecture": arch,
        "entry_point": format!("0x{:08x}", entry_addr),
        "spi_mode": spi_mode,
        "spi_speed": spi_speed,
        "spi_flash_size": spi_size,
        "wp_pin": wp_pin,
        "min_chip_rev": if min_rev_full > 0 { min_rev_full } else { min_rev_legacy as u16 },
        "max_chip_rev": max_rev_full,
        "segment_count": seg_count,
        "segments": segments_json,
        "xor_checksum": {
            "stored": stored_checksum.map(|b| format!("0x{:02x}", b)),
            "computed": format!("0x{:02x}", xor_checksum),
            "valid": checksum_valid,
        },
        "sha256": sha256_status,
        "esp_app_desc": app_desc,
    }))
}

fn parse_esp_partition_table(data: &[u8], base_off: usize) -> Vec<Value> {
    let mut out = Vec::new();
    let mut off = base_off;
    for _ in 0..96 {
        let Some(ent) = data.get(off..off + 32) else { break };
        off += 32;
        if ent[0] == 0xEB && ent[1] == 0xEB {
            // MD5 checksum row at end of partition table
            break;
        }
        if ent[0] != 0xAA || ent[1] != 0x50 {
            break;
        }
        let ptype = ent[2];
        let subtype = ent[3];
        let p_offset = read_u32_le(ent, 4).unwrap_or(0);
        let p_size = read_u32_le(ent, 8).unwrap_or(0);
        let label = cstr_lossy(&ent[12..28]);
        let flags = read_u32_le(ent, 28).unwrap_or(0);
        let type_name = match ptype {
            0x00 => "app",
            0x01 => "data",
            _ => "custom",
        };
        let subtype_name = match (ptype, subtype) {
            (0x00, 0x00) => "factory",
            (0x00, 0x10..=0x1F) => "ota",
            (0x00, 0x20) => "test",
            (0x01, 0x00) => "ota_data",
            (0x01, 0x01) => "phy",
            (0x01, 0x02) => "nvs",
            (0x01, 0x03) => "coredump",
            (0x01, 0x04) => "nvs_keys",
            (0x01, 0x81) => "fat",
            (0x01, 0x82) => "spiffs",
            (0x01, 0x83) => "littlefs",
            _ => "other",
        };
        out.push(json!({
            "label": label,
            "type": type_name,
            "subtype": subtype_name,
            "offset": format!("0x{:x}", p_offset),
            "size": p_size,
            "encrypted": (flags & 1) != 0,
        }));
    }
    out
}

fn inspect_uf2(data: &[u8], path_str: &str, extract_to: Option<&str>) -> Result<Value, String> {
    let total_blocks_raw = data.len() / 512;
    let mut valid_blocks = 0usize;
    let mut families: BTreeMap<u32, usize> = BTreeMap::new();
    let mut flash_map: BTreeMap<u32, &[u8]> = BTreeMap::new();
    let mut embedded_files: Vec<String> = Vec::new();

    for i in 0..total_blocks_raw {
        let blk = &data[i * 512..(i + 1) * 512];
        if read_u32_le(blk, 0) != Some(0x0A32_4655)
            || read_u32_le(blk, 4) != Some(0x9E5D_5157)
            || read_u32_le(blk, 508) != Some(0x0AB1_6F30)
        {
            continue;
        }
        valid_blocks += 1;
        let flags = read_u32_le(blk, 8).unwrap_or(0);
        let addr = read_u32_le(blk, 12).unwrap_or(0);
        let sz = (read_u32_le(blk, 16).unwrap_or(0) as usize).min(476);
        if (flags & 0x2000) != 0 {
            let fam = read_u32_le(blk, 28).unwrap_or(0);
            *families.entry(fam).or_insert(0) += 1;
        }
        if (flags & 0x1000) != 0 {
            // File container: null-terminated filename lies right after payload
            let name = cstr_lossy(&blk[32 + sz..508]);
            if !name.is_empty() && !embedded_files.contains(&name) {
                embedded_files.push(name);
            }
        } else if (flags & 0x0001) == 0 && sz > 0 {
            flash_map.insert(addr, &blk[32..32 + sz]);
        }
    }

    let mut ranges: Vec<(u32, Vec<u8>)> = Vec::new();
    for (&addr, &payload) in &flash_map {
        if let Some((base, buf)) = ranges.last_mut() {
            if *base + (buf.len() as u32) == addr {
                buf.extend_from_slice(payload);
                continue;
            }
        }
        ranges.push((addr, payload.to_vec()));
    }

    let family_list: Vec<Value> = families
        .iter()
        .map(|(&fid, &cnt)| {
            let (mcu, arch) = uf2_family_info(fid);
            json!({
                "family_id": format!("0x{:08x}", fid),
                "mcu": mcu,
                "architecture": arch,
                "blocks": cnt,
            })
        })
        .collect();

    let range_json: Vec<Value> = ranges
        .iter()
        .map(|(base, buf)| {
            json!({
                "start_addr": format!("0x{:08x}", base),
                "end_addr": format!("0x{:08x}", *base as u64 + buf.len() as u64),
                "size_bytes": buf.len(),
                "sha256": hex_encode(&sha256(buf)),
            })
        })
        .collect();

    let extracted_info = if let Some(out_path) = extract_to {
        if let Some((base, buf)) = ranges.first() {
            if let Some(parent) = Path::new(out_path).parent() {
                let _ = fs::create_dir_all(parent);
            }
            fs::write(out_path, buf)
                .map_err(|e| format!("Failed writing extracted payload to '{}': {}", out_path, e))?;
            Some(json!({
                "output_path": out_path,
                "base_addr": format!("0x{:08x}", base),
                "bytes_written": buf.len(),
            }))
        } else {
            None
        }
    } else {
        None
    };

    Ok(json!({
        "format": "uf2",
        "path": path_str,
        "file_size": data.len(),
        "valid_blocks": valid_blocks,
        "families": family_list,
        "contiguous_flash_ranges": range_json,
        "embedded_container_files": embedded_files,
        "extracted_payload": extracted_info,
        "elf_conversion_hint": "Call retro_to_elf_convert on this UF2 file to synthesize an ARM/RISC-V ELF with exact flash addresses and entry point."
    }))
}

/// MCP Tool: `firmware_dtb_fit_show` — Flattened Device Tree (.dtb) & U-Boot FIT image parser
pub fn tool_firmware_dtb_fit_show(args: &Value) -> Result<Value, String> {
    let path_str = args
        .get("path")
        .and_then(Value::as_str)
        .ok_or("Missing required string parameter 'path'")?;
    let extract_dir = args.get("extract_dir").and_then(Value::as_str);
    let max_nodes = args
        .get("max_nodes")
        .and_then(Value::as_u64)
        .unwrap_or(200)
        .min(2000) as usize;

    let full = fs::read(path_str).map_err(|e| format!("Failed reading '{}': {}", path_str, e))?;
    // Locate 0xD00DFEED either at offset 0 or embedded inside a bootloader/kernel blob
    let fdt_off = if read_u32_be(&full, 0) == Some(0xD00D_FEED) {
        0usize
    } else {
        find_fdt_magic(&full).ok_or("Missing FDT/FIT magic 0xD00DFEED in file")?
    };

    let b = &full[fdt_off..];
    if b.len() < 40 {
        return Err("Truncated FDT header (<40 bytes)".into());
    }
    let totalsize = read_u32_be(b, 4).unwrap_or(0) as usize;
    let off_dt_struct = read_u32_be(b, 8).unwrap_or(0) as usize;
    let off_dt_strings = read_u32_be(b, 12).unwrap_or(0) as usize;
    let off_mem_rsvmap = read_u32_be(b, 16).unwrap_or(0) as usize;
    let version = read_u32_be(b, 20).unwrap_or(0);
    let last_comp_version = read_u32_be(b, 24).unwrap_or(0);
    let boot_cpuid_phys = read_u32_be(b, 28).unwrap_or(0);
    let size_dt_strings = read_u32_be(b, 32).unwrap_or(0) as usize;
    let size_dt_struct = read_u32_be(b, 36).unwrap_or(0) as usize;

    let bounded_total = totalsize.min(b.len());
    let b = &b[..bounded_total];

    // Parse reservation map
    let mut mem_rsv = Vec::new();
    let mut r_off = off_mem_rsvmap;
    while r_off + 16 <= b.len() && mem_rsv.len() < 32 {
        let addr = read_u64_be(b, r_off).unwrap_or(0);
        let sz = read_u64_be(b, r_off + 8).unwrap_or(0);
        if addr == 0 && sz == 0 {
            break;
        }
        mem_rsv.push(json!({
            "address": format!("0x{:x}", addr),
            "size": sz,
        }));
        r_off += 16;
    }

    let strings_slice = b
        .get(off_dt_strings..off_dt_strings.saturating_add(size_dt_strings).min(b.len()))
        .unwrap_or(&[]);
    let struct_end = if size_dt_struct > 0 {
        off_dt_struct.saturating_add(size_dt_struct).min(b.len())
    } else {
        b.len()
    };

    let mut path_stack: Vec<String> = Vec::new();
    let mut cursor = off_dt_struct;
    let mut node_summaries = Vec::new();
    let mut root_model = Option::<String>::None;
    let mut root_compatible: Vec<String> = Vec::new();
    let mut fit_images: BTreeMap<String, BTreeMap<String, Value>> = BTreeMap::new();
    let mut extracted_files = Vec::new();
    let mut total_nodes = 0usize;

    while cursor + 4 <= struct_end {
        let token = read_u32_be(b, cursor).unwrap_or(9);
        cursor += 4;
        match token {
            1 => {
                // FDT_BEGIN_NODE
                let name_end = b[cursor..struct_end]
                    .iter()
                    .position(|&c| c == 0)
                    .map(|p| cursor + p)
                    .unwrap_or(struct_end);
                let name = String::from_utf8_lossy(&b[cursor..name_end]).to_string();
                cursor = ((name_end + 1) + 3) & !3;
                path_stack.push(name);
                total_nodes += 1;
                if node_summaries.len() < max_nodes {
                    let full_path = build_fdt_path(&path_stack);
                    node_summaries.push(full_path);
                }
            }
            2 => {
                // FDT_END_NODE
                path_stack.pop();
            }
            3 => {
                // FDT_PROP
                let Some(prop_len_u32) = read_u32_be(b, cursor) else { break };
                let Some(name_off_u32) = read_u32_be(b, cursor + 4) else { break };
                cursor += 8;
                let prop_len = prop_len_u32 as usize;
                let name_off = name_off_u32 as usize;
                let Some(val_bytes) = b.get(cursor..cursor.saturating_add(prop_len)) else { break };
                cursor = (cursor + prop_len + 3) & !3;

                let prop_name = if name_off < strings_slice.len() {
                    cstr_lossy(&strings_slice[name_off..])
                } else {
                    format!("prop_{}", name_off)
                };

                let cur_path = build_fdt_path(&path_stack);
                if cur_path == "/" {
                    if prop_name == "model" || prop_name == "description" {
                        root_model = Some(cstr_lossy(val_bytes));
                    } else if prop_name == "compatible" {
                        root_compatible = split_strlist(val_bytes);
                    }
                }

                // Capture U-Boot FIT `/images/<img_name>` properties
                if path_stack.len() == 3 && path_stack[0].is_empty() && path_stack[1] == "images" {
                    let img_name = path_stack[2].clone();
                    let entry = fit_images.entry(img_name.clone()).or_default();
                    if prop_name == "data" {
                        entry.insert("data_size".into(), json!(val_bytes.len()));
                        entry.insert("sha256".into(), json!(hex_encode(&sha256(val_bytes))));
                        if let Some(dir) = extract_dir {
                            let safe_name = sanitize_filename(&img_name);
                            let _ = fs::create_dir_all(dir);
                            let dst = Path::new(dir).join(format!("{}.bin", safe_name));
                            if fs::write(&dst, val_bytes).is_ok() {
                                extracted_files.push(dst.to_string_lossy().to_string());
                            }
                        }
                    } else if matches!(prop_name.as_str(), "description" | "type" | "arch" | "os" | "compression") {
                        entry.insert(prop_name, json!(cstr_lossy(val_bytes)));
                    } else if matches!(prop_name.as_str(), "load" | "entry") && val_bytes.len() >= 4 {
                        let addr = if val_bytes.len() == 8 {
                            read_u64_be(val_bytes, 0).unwrap_or(0)
                        } else {
                            read_u32_be(val_bytes, 0).unwrap_or(0) as u64
                        };
                        entry.insert(prop_name, json!(format!("0x{:x}", addr)));
                    }
                }
            }
            4 => {
                // FDT_NOP
            }
            9 => {
                // FDT_END
                break;
            }
            _ => break,
        }
    }

    let is_fit = !fit_images.is_empty();
    Ok(json!({
        "format": if is_fit { "uboot_fit_image" } else { "flattened_device_tree" },
        "path": path_str,
        "fdt_offset": format!("0x{:x}", fdt_off),
        "totalsize": totalsize,
        "version": version,
        "last_comp_version": last_comp_version,
        "boot_cpuid_phys": boot_cpuid_phys,
        "model_or_description": root_model,
        "compatible": root_compatible,
        "memory_reservations": mem_rsv,
        "total_nodes": total_nodes,
        "nodes_preview": node_summaries,
        "fit_images": fit_images,
        "extracted_images": extracted_files,
    }))
}

fn find_fdt_magic(data: &[u8]) -> Option<usize> {
    let limit = data.len().saturating_sub(40);
    let mut i = 4usize;
    while i < limit {
        if data[i] == 0xD0 && data[i + 1] == 0x0D && data[i + 2] == 0xFE && data[i + 3] == 0xED {
            let sz = read_u32_be(data, i + 4).unwrap_or(0) as usize;
            let ver = read_u32_be(data, i + 20).unwrap_or(0);
            if sz >= 40 && ver >= 16 && ver <= 20 {
                return Some(i);
            }
        }
        i += 4;
    }
    None
}

fn build_fdt_path(stack: &[String]) -> String {
    if stack.len() <= 1 {
        return "/".into();
    }
    let mut s = String::new();
    for part in stack.iter().skip(1) {
        s.push('/');
        s.push_str(part);
    }
    s
}

fn split_strlist(bytes: &[u8]) -> Vec<String> {
    bytes
        .split(|&b| b == 0)
        .filter(|s| !s.is_empty())
        .map(|s| String::from_utf8_lossy(s).to_string())
        .collect()
}

pub fn sanitize_filename(raw: &str) -> String {
    let cleaned: String = raw
        .chars()
        .map(|c| {
            if c.is_ascii_alphanumeric() || c == '-' || c == '_' || c == '.' {
                c
            } else {
                '_'
            }
        })
        .collect();
    let trimmed = cleaned.trim_matches('.');
    if trimmed.is_empty() {
        "item".into()
    } else {
        trimmed.into()
    }
}

pub fn safe_join_under(base: &Path, rel: &str) -> Option<PathBuf> {
    let stripped = rel.trim_start_matches("res://").trim_start_matches(['/', '\\']);
    let mut out = base.to_path_buf();
    for comp in Path::new(stripped).components() {
        match comp {
            std::path::Component::Normal(seg) => out.push(seg),
            std::path::Component::CurDir => {}
            _ => return None,
        }
    }
    Some(out)
}
