#!/system/bin/sh
# install-plugin.sh - Instala y configura Craft Anything + Ghidra ARM64 (v0.5.0) activo en Android sin tocar $HOME/runtime/bin.
set -eu

SRC_DIR="$(CDPATH= cd -- "$(/system/bin/dirname -- "$0")" && pwd)"
case "$SRC_DIR" in
    */.gemini/*) HOME="${SRC_DIR%%/.gemini/*}" ;;
    *) HOME="${HOME:-/data/user/0/com.agy/files}" ;;
esac
PREFIX="${PREFIX:-$HOME/usr}"
CONFIG_DIR="$HOME/.gemini/config"
TARGET_DIR="$CONFIG_DIR/plugins/craft-anything"

/system/bin/mkdir -p "$CONFIG_DIR/plugins"

if [ "$SRC_DIR" != "$TARGET_DIR" ]; then
    /system/bin/rm -rf "$TARGET_DIR"
    /system/bin/mkdir -p "$TARGET_DIR"
    /system/bin/cp -Rf "$SRC_DIR"/. "$TARGET_DIR"/
fi

/system/bin/chmod 0755 \
    "$TARGET_DIR/install-plugin.sh" \
    "$TARGET_DIR/mcp/bin/start-mcp.sh" \
    "$TARGET_DIR/mcp/bin/craft-plus-mcp" \
    "$TARGET_DIR/mcp/bin/craft-anything-cli" \
    "$TARGET_DIR/mcp/bin/craft-ghidra-setup" \
    "$TARGET_DIR/mcp/bin/ghidra-arm64/decompile" \
    "$TARGET_DIR/mcp/bin/ghidra-arm64/sleigh"

/system/bin/mkdir -p "$PREFIX/share/ghidra-arm64/os/linux_arm_64"
/system/bin/cp -f "$TARGET_DIR/mcp/bin/ghidra-arm64/decompile" "$PREFIX/share/ghidra-arm64/os/linux_arm_64/decompile"
/system/bin/cp -f "$TARGET_DIR/mcp/bin/ghidra-arm64/sleigh" "$PREFIX/share/ghidra-arm64/os/linux_arm_64/sleigh"
/system/bin/chmod 0755 "$PREFIX/share/ghidra-arm64/os/linux_arm_64/decompile" "$PREFIX/share/ghidra-arm64/os/linux_arm_64/sleigh"

/system/bin/mkdir -p "$PREFIX/tmp/run" "$PREFIX/tmp/craft-elf" "$PREFIX/tmp/ghidra-temp" "$PREFIX/tmp/ghidra-cache" "$PREFIX/tmp/ghidra-settings"
/system/bin/chmod 0700 "$PREFIX/tmp/run" 2>/dev/null || true

/system/bin/mkdir -p "$HOME/.config/craft-anything"
if [ ! -f "$HOME/.config/craft-anything/config.toml" ]; then
    cat > "$HOME/.config/craft-anything/config.toml" <<'TOML'
deep_mode = true
first_run_done = true
TOML
fi

# Crear wrappers atomicos unicamente en $PREFIX/bin (nunca modificar $HOME/runtime/bin)
/system/bin/mkdir -p "$PREFIX/bin" 2>/dev/null || true
for pair in \
    "craft-anything-cli:craft-anything-cli" \
    "craft-ghidra-setup:craft-ghidra-setup" \
    "craft-plus:craft-plus-mcp"
do
    name="${pair%%:*}"
    bin="${pair#*:}"
    dst="$PREFIX/bin/$name"
    tmp="$PREFIX/bin/.$name.install.$$"
    cat > "$tmp" <<EOF
#!/system/bin/sh
export HOME="$HOME"
export PREFIX="$PREFIX"
export XDG_CONFIG_HOME="$HOME/.config"
exec "$TARGET_DIR/mcp/bin/$bin" "\$@"
EOF
    /system/bin/chmod 0755 "$tmp"
    /system/bin/mv -f "$tmp" "$dst"
done

# Si Ghidra 12.1.4 ya esta extraido, configurar wrapper analyzeHeadless en $PREFIX/bin
GHIDRA_ROOT="$PREFIX/opt/ghidra/ghidra_12.1.4_PUBLIC"
if [ -f "$GHIDRA_ROOT/support/analyzeHeadless" ]; then
    dst="$PREFIX/bin/analyzeHeadless"
    tmp="$PREFIX/bin/.analyzeHeadless.install.$$"
    cat > "$tmp" <<EOF
#!/system/bin/sh
export HOME="$HOME"
export PREFIX="$PREFIX"
export JAVA_HOME="$PREFIX/lib/jvm/java-21-openjdk"
export LD_LIBRARY_PATH="$PREFIX/lib\${LD_LIBRARY_PATH:+:\$LD_LIBRARY_PATH}"
export PATH="$PREFIX/bin:$HOME/runtime/bin:\$JAVA_HOME/bin:/system/bin"
export TMPDIR="\${TMPDIR:-$PREFIX/tmp}"
export JDK_JAVA_OPTIONS="-Duser.home=$HOME -Djava.io.tmpdir=$PREFIX/tmp"
/system/bin/mkdir -p "\$TMPDIR/ghidra-temp" "\$TMPDIR/ghidra-cache" "\$TMPDIR/ghidra-settings"
exec "$PREFIX/bin/bash" "$GHIDRA_ROOT/support/analyzeHeadless" "\$@"
EOF
    /system/bin/chmod 0755 "$tmp"
    /system/bin/mv -f "$tmp" "$dst"
fi

echo "============================================================"
echo " Plugin Craft Anything + Ghidra ARM64 v0.5.0 (335 Rust tools)"
echo " Ruta: $TARGET_DIR"
echo "============================================================"
