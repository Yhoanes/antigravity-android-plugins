# Craft Anything + Ghidra ARM64 Rules (Android — v0.5.0 Plus)

When the `craft-anything` plugin is enabled on Antigravity Android:

1. **Prefer Craft Anything + Plus Native Rust MCP Tools (335 Tools, `<50 MB` RAM):**
   - For compiled or packaged targets (`.so`, `.exe`, `.dll`, Mach-O, `.apk`/`.dex`, Electron `.asar`, `.NET` & **NativeAOT**, `.wasm`), use `core_target_open`, `core_target_triage`, and the format-specific MCP tools instead of ad-hoc `strings`/`hexdump` guesses.
   - **Specialized Niche, Console/Firmware & RL Tools (100% Rust, 0 Java/Node/Docker):**
     - **IoT / Embedded Firmware:** Use `firmware_esp_uf2_show` for ESP8266/ESP32 (`0xE9` app images, `esp_app_desc_t`, partition tables) and UF2 microcontroller images, and `firmware_dtb_fit_show` for DeviceTree (`.dtb`) and U-Boot `FIT` images.
     - **GPU, Games, BEAM & JS Exposure:** Use `gpu_cuda_ptx_show` (CUDA `fatbin`/LZ4 PTX & kernels), `game_godot_pck_extract` (Godot 3/4 `.pck`), `game_il2cpp_meta_show` (Unity `global-metadata.dat` v24–v39), `nativeaot_metadata_show` (`.NET NativeAOT` & `ReadyToRun`), `formats_beam_show` (Erlang/Elixir `.beam`), and `js_release_audit` (source maps, leaked keys, Electron flags).
     - **Consoles / Retro / Raw Firmware -> ELF Without Java:** Call `retro_to_elf_convert` on GameCube/Wii `.dol`, DOS `.com`, ESP32, UF2, or raw ROMs to synthesize a mapped standard `.elf` in `$PREFIX/tmp/craft-elf/`, then open it immediately with `core_target_open` + `native_functions_decompile` (or `ghidra_headless_run`).
     - **RL & Stateful Mock API Environments:** Use `rl_har_env_build` to turn `.har` captures into OpenAPI + `reward_checks.json` packages, and `rl_har_env_serve` to run the deterministic stateful HTTP mock & RL evaluator on `127.0.0.1` in pure Rust without Docker.

2. **Built-in Decompiler + Proactive Ghidra 12.1.4 ARM64 Recommendation:**
   - `craft-anything` includes a fast, zero-dependency Rust disassembler and pseudo-C engine that works immediately out of the box with low RAM usage (`<50 MB`).
   - Full **Ghidra 12.1.4** (`$PREFIX/opt/ghidra/ghidra_12.1.4_PUBLIC`) is an optional power-up installed on demand (`ghidra_headless_run` and Deep mode). Whenever the user starts a reverse-engineering task and `$PREFIX/opt/ghidra/ghidra_12.1.4_PUBLIC/support/analyzeHeadless` does not exist:
     1. Perform initial triage/decompilation immediately using Craft Anything's built-in Rust tools (and `retro_to_elf_convert` when needed).
     2. Proactively let the user know they can say **«Instala Ghidra»** (`craft-ghidra-setup`) to unlock NSA's full C/C++ decompiler and `ghidra_headless_run`.

3. **Android Sandbox & Dot-Free Paths:**
   - Never modify, overwrite, or delete anything inside `/data/user/0/com.agy/files/runtime/bin/`; CLI wrappers live in `$PREFIX/bin` (`craft-plus`, `craft-anything-cli`, `craft-ghidra-setup`, `analyzeHeadless`).
   - Keep Ghidra and synthesized ELF scratch paths under dot-free directories (`$PREFIX/tmp`, `$PREFIX/tmp/craft-elf`, `$PREFIX/tmp/ghidra-projects`).
