# Craft Anything + Ghidra 12.1.4 (Android ARM64 — v0.5.0 Plus)

Plugin nativo oficial para **Antigravity for Android (`aarch64-linux-android`)** que combina el motor completo de **Craft Anything** con el motor especializado **`craft-plus-mcp` en Rust puro (`ARMv8.1-A + LSE`)** — sumando **335 herramientas MCP 100% en Rust** — junto con los binarios nativos **ARM64 de Ghidra 12.1.4** (`decompile` y `sleigh`).

> [!TIP]
> **¿Cómo funciona por niveles sin gastar RAM ni almacenamiento innecesario?**
> 1. **Nivel 1 — Motor Rápido 100% Rust (Activo al instante, 0 descargas extra, `<50 MB` RAM):** Las **335 herramientas MCP** funcionan desde el primer segundo sin Java, Python ni Node.js: desensamblador y pseudo-C en Rust, DEX/APK, Electron/JS, `.NET` + **NativeAOT**, **WASM**, **CUDA/PTX**, **ESP32/UF2/DeviceTree**, **Godot `.pck`**, **Unity `IL2CPP`**, convertidor **`.dol`/retro/firmware -> ELF** y servidor mock **RL desde `.har`**.
> 2. **Nivel 2 — Superpotencia Ghidra 12.1.4 Nativo ARM64 (Bajo demanda):** Cuando necesites recuperación profunda de structs/`vtables` C++, SLEIGH o ejecución por lotes con `ghidra_headless_run`, escribe en el chat **«Instala Ghidra»** (o ejecuta `craft-ghidra-setup`).

---

## Qué incluye la versión `v0.5.0`

| Componente | Descripción |
| :--- | :--- |
| **`craft-anything-cli` + `craft-plus-mcp`** | Multiplexor `stdio` y motor binario **100% Rust ARM64** (`PIE`, `16 KB` page-aligned, enlazado solo a Bionic `libc.so`/`libdl.so`) exponiendo **335 herramientas MCP** unificadas (`100% <= 64` caracteres prefijados; traduce automáticamente `native_fn_references_list`, `native_fn_instructions_list` y `native_rizin_session_cmd_run` para que ninguna herramienta quede deshabilitada). |
| **Sintetizador `retro_to_elf_convert` (0 Java)** | Convierte contenedores **GameCube/Wii (`.dol`)**, **DOS 16-bit (`.com`)**, **ESP32 (`0xE9`)**, **UF2** y **ROMs raw** en un ejecutable **ELF estándar** con direcciones virtuales y símbolos reales para decompilarlos al instante en Rust o Ghidra. |
| **Parsers Especializados IoT, GPU & Juegos** | `firmware_esp_uf2_show`, `firmware_dtb_fit_show` (`.dtb` y U-Boot `FIT`), `gpu_cuda_ptx_show` (descompresor LZ4 `nvcc` + kernels `PTX`), `game_godot_pck_extract`, `game_il2cpp_meta_show` (`v24–v39`), `nativeaot_metadata_show`, `formats_beam_show` y `js_release_audit`. |
| **Entornos RL sin Docker (`rl_har_env_*`)** | `rl_har_env_build` convierte capturas `.har` en paquetes OpenAPI + `reward_checks.json`, y `rl_har_env_serve` levanta en memoria un servidor HTTP mock determinista en Rust (`127.0.0.1`, `<2 MB` RAM) con endpoints `/__rl/reset`, `/__rl/trace` y `/__rl/evaluate`. |
| **Ghidra 12.1.4 ARM64 + `ghidra_headless_run`** | Binarios C++ ARM64 `decompile` y `sleigh`, instalador `craft-ghidra-setup` y runner seguro `ghidra_headless_run` con límite de RAM móvil (`1536M`) y rutas sin puntos en `$PREFIX/tmp`. |
