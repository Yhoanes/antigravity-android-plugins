# ARTEX Blue-Team Defense & Triage Rules (Android ARM64)

When the `artex-defense` plugin is enabled:

1. **Prefer Native `artex-defense` Rust MCP Tools for Detection & Incident Triage:**
   - Use `artex_host_triage` (read-only) to inspect local ports (`8787`, `127.0.0.1:8788`), `_ca/mitmproxy-ca-cert.pem` MITM root CAs, and `HTTP_PROXY` + `SSL_CERT_FILE`/`NODE_EXTRA_CA_CERTS` process injections (`use_rish: true` optional on Android).
   - Use `artex_sigma_scan` and `artex_suricata_inspect` to evaluate web/proxy/process logs against ARTEX's 9 Sigma rules (atomic + velocity/fan-out correlations) and Suricata SIDs `1000001`–`1000003`.
   - Use `artex_ioc_lookup` and `artex_attack_coverage` to export MISP/CSV indicators and generate Blue-Team hardening guides grounded in MITRE ATT&CK v16.

2. **Honest Attribution Caveats:**
   - Static User-Agents (`artex-enrich/1.0`, `norma/`) and default ports (`8787`/`8788`) can be changed by an operator, and `mitmproxy-ca-cert.pem` is shared with standalone mitmproxy — always treat hits as triage leads and pair static indicators with behavioral velocity/fan-out correlations and object-level API hardening.
