# ARTEX Blue-Team Defense & Triage (`v1.0.0`) — Detección Sigma/Suricata, MITRE ATT&CK v16 y Triage Forense en Rust ARM64

Plugin nativo **ARM64 (`aarch64` + `LSE`)** para **Antigravity for Android** que porta el directorio completo `detections/` y la guía defensiva de [`jiwoochris/artex-global`](https://github.com/jiwoochris/artex-global) (`AGPL-3.0`) a un motor de respuesta a incidentes y caza de amenazas en **Rust puro (`451 KB`)**.

> [!NOTE]
> **Enfoque Defensivo y Forense (Solo Lectura):**
> Ayuda a equipos Blue-Team y desarrolladores a entender, detectar y bloquear ataques automatizados por agentes IA mediante firmas verificadas en código fuente, correlaciones de comportamiento (velocidad y *fan-out*) y triage local sin modificar el sistema.

---

## Las 6 Herramientas MCP Nativas en Rust

| Herramienta | Categoría | Función Nativa ARM64 |
| :--- | :--- | :--- |
| `artex_defense_status` | Diagnóstico | Inventario de reglas Sigma atómicas/correlación, Suricata SIDs, atributos MISP, técnicas ATT&CK y Shizuku `rish`. |
| `artex_host_triage` | Forense Host | Triage de solo lectura (puertos `8787`/`8788`, CA MITM `_ca/mitmproxy-ca-cert.pem`, inyección `HTTP_PROXY` + `SSL_CERT_FILE`/`NODE_EXTRA_CA_CERTS` en `/proc` y marcadores en logs; soporta `use_rish: true`). |
| `artex_sigma_scan` | Motor Sigma | Evalúa las **9 reglas Sigma** de ARTEX (5 atómicas + 4 correlaciones: *Scan Velocity*, *Distinct-Host Fan-Out*, *Guard Burst* y *Destructive Co-occurrence*) sobre logs o JSONL. |
| `artex_suricata_inspect` | Red / IDS | Inspecciona/exporta `artex.rules` (SIDs `1000001`–`1000003`) y audita logs HTTP de acceso en busca de agentes `artex-enrich/` y `norma/`. |
| `artex_ioc_lookup` | Threat Intel | Consulta o exporta indicadores verificados en formato **MISP (`artex_indicators.misp.json`)** o **CSV (`artex_indicators.csv`)** para SIEM. |
| `artex_attack_coverage` | MITRE ATT&CK | Devuelve la capa **ATT&CK Navigator v16** (`T1595`, `T1592`, `T1105`, `T1059`, `T1485`, `T1561.002`, `T1489`, `T1557`) y genera un checklist de hardening anti-IDOR y *rate-limiting*. |

---

## CLI en Terminal (`$PREFIX/bin/artex-defense`)

```bash
artex-defense status
artex-defense triage
```
