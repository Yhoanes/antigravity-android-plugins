---
name: artex-blue-team
description: Blue-Team detection engineering, Sigma/Suricata log hunting, MISP/CSV threat intelligence export, MITRE ATT&CK v16 coverage analysis, and read-only host forensic triage against autonomous AI attacks (ported from jiwoochris/artex-global).
---

# ARTEX Blue-Team Defense & Host Triage (`artex-blue-team`)

Ported from `detections/` and `docs/defense-en.md` of [`jiwoochris/artex-global`](https://github.com/jiwoochris/artex-global) (AGPL-3.0).

## Core Workflows

1. **Suspected Host Forensic Triage (`artex_host_triage`):**
   - Checks the 5 grounded forensic fingerprints from `artex_host_triage.py`:
     1. Listening TCP ports `:8787` (UI) and `127.0.0.1:8788` (recording proxy).
     2. `_ca/mitmproxy-ca-cert.pem` AiTM trust anchor (`T1557`).
     3. `/proc/<pid>/environ` carrying `HTTP(S)_PROXY` + `SSL_CERT_FILE` / `NODE_EXTRA_CA_CERTS` / `CURL_CA_BUNDLE` pointing at `mitmproxy-ca-cert.pem` (survives binary renaming and custom ports).
     4. Log markers (`artex-enrich/1.0`, `artex-selfupdate`, `norma/`, `【ARTEX 平台管控·非目标防御】`).
     5. Dual-graph database presence (`exploration_nodes`).
2. **SIEM & Network Log Hunting (`artex_sigma_scan` & `artex_suricata_inspect`):**
   - Evaluates atomic Sigma rules (`T1595`, `T1592`, `T1105`, `T1059`, `T1485`, `T1561.002`, `T1489`, `T1557`) plus behavioral correlations (Enrichment Velocity `>=30`, Distinct-Host Fan-Out `>=20`, Guard-Block Burst `>=5`, and Guard Marker + Destructive Command).
3. **Threat Intel & Hardening (`artex_ioc_lookup` & `artex_attack_coverage`):**
   - Exports ready-to-import `artex_indicators.misp.json` or `artex_indicators.csv` and produces concrete API hardening steps (anti-IDOR, rate limiting, JWT signing-key binding to password hash).
