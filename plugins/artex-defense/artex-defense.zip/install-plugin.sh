#!/system/bin/sh
# install-plugin.sh — Installs and configures ARTEX Blue-Team Defense & Triage (v1.0.0, Native Rust ARM64)
set -eu

SRC_DIR="$(CDPATH= cd -- "$(/system/bin/dirname -- "$0")" && pwd)"
case "$SRC_DIR" in
    */.gemini/*) HOME="${SRC_DIR%%/.gemini/*}" ;;
    *) HOME="${HOME:-/data/user/0/com.agy/files}" ;;
esac
PREFIX="${PREFIX:-$HOME/usr}"
CONFIG_DIR="$HOME/.gemini/config"
TARGET_DIR="$CONFIG_DIR/plugins/artex-defense"

/system/bin/mkdir -p "$CONFIG_DIR/plugins" "$PREFIX/tmp" "$PREFIX/bin"

if [ "$SRC_DIR" != "$TARGET_DIR" ]; then
    /system/bin/rm -rf "$TARGET_DIR"
    /system/bin/mkdir -p "$TARGET_DIR"
    /system/bin/cp -Rf "$SRC_DIR"/. "$TARGET_DIR"/
fi

/system/bin/chmod 0755 \
    "$TARGET_DIR/install-plugin.sh" \
    "$TARGET_DIR/mcp/bin/start-mcp.sh" \
    "$TARGET_DIR/mcp/bin/artex-defense-mcp"

/system/bin/rm -f "$PREFIX/bin/artex-defense"
cat > "$PREFIX/bin/artex-defense" <<EOF
#!/system/bin/sh
export HOME="$HOME"
export PREFIX="$PREFIX"
exec "$TARGET_DIR/mcp/bin/artex-defense-mcp" "\$@"
EOF
/system/bin/chmod 0755 "$PREFIX/bin/artex-defense"

echo "================================================================="
echo " Plugin ARTEX Blue-Team Defense & Triage v1.0.0 (Rust ARM64) ready"
echo " Path: $TARGET_DIR"
echo "================================================================="
