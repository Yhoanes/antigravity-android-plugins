// main.rs — ARTEX Blue-Team Defense & Host Triage (artex-defense v1.0.0)
// Native Android ARM64 Rust MCP Server: Sigma, Suricata, MISP IoCs, MITRE ATT&CK v16 & Forensic Host Triage
mod json;

use json::{make_tool, n_i64, parse_json, prop_bool, prop_str, prop_str_enum, s, JsonVal};
use std::collections::{BTreeMap, BTreeSet};
use std::env;
use std::fs;
use std::io::{self, BufRead, BufReader, Write};
use std::path::{Path, PathBuf};
use std::process::Command;

const SERVER_NAME: &str = "artex-defense";
const SERVER_VERSION: &str = "1.0.0";

struct EnvPaths {
    home: PathBuf,
    prefix: PathBuf,
    plugin_dir: PathBuf,
    det_dir: PathBuf,
}

impl EnvPaths {
    fn resolve() -> Self {
        let home = env::var("HOME")
            .map(PathBuf::from)
            .unwrap_or_else(|_| PathBuf::from("/data/user/0/com.agy/files"));
        let prefix = env::var("PREFIX")
            .map(PathBuf::from)
            .unwrap_or_else(|_| home.join("usr"));
        let plugin_dir = home.join(".gemini/config/plugins/artex-defense");
        let det_dir = plugin_dir.join("detections");
        Self {
            home,
            prefix,
            plugin_dir,
            det_dir,
        }
    }

    fn rish_bin(&self) -> Option<PathBuf> {
        let p1 = self.prefix.join("bin/rish");
        let p2 = self.home.join("runtime/bin/rish");
        if p1.exists() {
            Some(p1)
        } else if p2.exists() {
            Some(p2)
        } else {
            None
        }
    }
}

struct SigmaRuleDef {
    id: &'static str,
    title: &'static str,
    level: &'static str,
    attack_tags: &'static [&'static str],
    patterns: &'static [&'static str],
}

const SIGMA_RULES: &[SigmaRuleDef] = &[
    SigmaRuleDef {
        id: "34adfa15-1696-4322-afc0-f69988e9cc1e",
        title: "ARTEX Asset Enrichment Probe User-Agent",
        level: "high",
        attack_tags: &["T1595", "T1592"],
        patterns: &["artex-enrich/1.0", "artex-enrich/"],
    },
    SigmaRuleDef {
        id: "e96380a3-2a34-4237-be2b-088ad9cc947d",
        title: "ARTEX Self-Update Egress User-Agent",
        level: "medium",
        attack_tags: &["T1105"],
        patterns: &["artex-selfupdate"],
    },
    SigmaRuleDef {
        id: "3add497e-36cb-47c4-8993-df8f98585ef7",
        title: "ARTEX Platform Guard Audit-Log Framing",
        level: "high",
        attack_tags: &["T1059"],
        patterns: &["【ARTEX 平台管控·非目标防御】"],
    },
    SigmaRuleDef {
        id: "3bac40a5-a780-4d1f-a7e8-5d0daa29ef47",
        title: "ARTEX Recording-Proxy MITM CA Certificate Artifact",
        level: "medium",
        attack_tags: &["T1557"],
        patterns: &["mitmproxy-ca-cert.pem"],
    },
    SigmaRuleDef {
        id: "f510564f-2958-4dc8-a188-3300a2f6f5a7",
        title: "Destructive Command Execution (ARTEX Guard-List Hunting)",
        level: "medium",
        attack_tags: &["T1485", "T1561.002", "T1489"],
        patterns: &[
            "rm -rf",
            "--no-preserve-root",
            "mkfs",
            "dd of=/dev/",
            "shred ",
            "wipe /dev/",
            "drop database",
            "drop table",
            "drop schema",
            "flushall",
            "flushdb",
            "iptables -f",
            "nft flush ruleset",
            "kill -9 -1",
            "killall -9",
        ],
    },
];

fn tool_status(paths: &EnvPaths) -> Result<JsonVal, String> {
    let mut res = JsonVal::obj();
    res.insert("ok", JsonVal::Bool(true));
    res.insert("plugin", s(SERVER_NAME));
    res.insert("version", s(SERVER_VERSION));
    res.insert("detections_dir", s(&paths.det_dir.display().to_string()));
    res.insert("sigma_atomic_rules", n_i64(SIGMA_RULES.len() as i64));
    res.insert("sigma_correlation_rules", n_i64(4));
    res.insert("suricata_rules", n_i64(3));
    res.insert("misp_ioc_attributes", n_i64(7));
    res.insert("mitre_attack_techniques", n_i64(8));
    res.insert("shizuku_rish_available", JsonVal::Bool(paths.rish_bin().is_some()));
    Ok(res)
}

fn parse_proc_net_ports(content: &str) -> Vec<u16> {
    let mut ports = BTreeSet::new();
    for line in content.lines().skip(1) {
        let cols: Vec<&str> = line.split_whitespace().collect();
        if cols.len() >= 4 && cols[3] == "0A" {
            // 0A = TCP_LISTEN
            if let Some((_, hex_port)) = cols[1].split_once(':') {
                if let Ok(p) = u16::from_str_radix(hex_port, 16) {
                    ports.insert(p);
                }
            }
        }
    }
    ports.into_iter().collect()
}

fn tool_host_triage(paths: &EnvPaths, args: &JsonVal) -> Result<JsonVal, String> {
    let use_rish = args.get_bool("use_rish").unwrap_or(false);
    let data_dir = args
        .get_str("data_dir")
        .map(PathBuf::from)
        .unwrap_or_else(|| paths.home.join(".gemini/artex"));
    let log_file = args.get_str("log_path").map(PathBuf::from);

    let mut leads = Vec::new();
    let mut listen_ports = BTreeSet::new();

    for tcp_p in ["/proc/net/tcp", "/proc/net/tcp6"] {
        if let Ok(txt) = fs::read_to_string(tcp_p) {
            for p in parse_proc_net_ports(&txt) {
                listen_ports.insert(p);
            }
        }
    }

    if use_rish {
        if let Some(rish) = paths.rish_bin() {
            if let Ok(out) = Command::new(rish).arg("-c").arg("ss -tln 2>/dev/null || netstat -tln 2>/dev/null").output() {
                let txt = String::from_utf8_lossy(&out.stdout);
                if txt.contains(":8787") {
                    listen_ports.insert(8787);
                }
                if txt.contains(":8788") {
                    listen_ports.insert(8788);
                }
            }
        }
    }

    if listen_ports.contains(&8787) {
        let mut l = JsonVal::obj();
        l.insert("indicator_id", s("server-listen-port"));
        l.insert("value", s(":8787"));
        l.insert("detail", s("TCP port 8787 is listening (default ARTEX admin UI / local console port)."));
        leads.push(l);
    }
    if listen_ports.contains(&8788) {
        let mut l = JsonVal::obj();
        l.insert("indicator_id", s("recording-proxy-endpoint"));
        l.insert("value", s("127.0.0.1:8788"));
        l.insert("detail", s("TCP port 8788 is listening (default ARTEX loopback MITM recording proxy)."));
        leads.push(l);
    }

    // Check MITM CA artifact & SQLite Dual-Graph DB
    let ca_candidate = data_dir.join("traffic/_ca/mitmproxy-ca-cert.pem");
    if ca_candidate.exists() {
        let mut l = JsonVal::obj();
        l.insert("indicator_id", s("recording-proxy-ca"));
        l.insert("attack", s("T1557"));
        l.insert("value", s(&ca_candidate.display().to_string()));
        l.insert("detail", s("Found _ca/mitmproxy-ca-cert.pem recording proxy CA artifact."));
        leads.push(l);
    }

    let db_candidate = data_dir.join("artex.db");
    if db_candidate.exists() {
        let mut l = JsonVal::obj();
        l.insert("indicator_id", s("dual-graph-store"));
        l.insert("value", s(&db_candidate.display().to_string()));
        l.insert("detail", s("Local ARTEX Dual-Graph SQLite database detected (authorized plugin store)."));
        leads.push(l);
    }

    // Check /proc/*/environ for proxy + CA injection (agent/worker.go proxyEnv signature)
    if let Ok(proc_entries) = fs::read_dir("/proc") {
        for ent in proc_entries.flatten() {
            let fname = ent.file_name().to_string_lossy().to_string();
            if !fname.chars().all(|c| c.is_ascii_digit()) {
                continue;
            }
            let env_p = ent.path().join("environ");
            if let Ok(bytes) = fs::read(&env_p) {
                let text = String::from_utf8_lossy(&bytes);
                let has_proxy = text.contains("HTTP_PROXY=") || text.contains("HTTPS_PROXY=");
                let has_mitm_ca = text.contains("mitmproxy-ca-cert.pem")
                    && (text.contains("SSL_CERT_FILE=")
                        || text.contains("NODE_EXTRA_CA_CERTS=")
                        || text.contains("CURL_CA_BUNDLE="));
                if has_proxy && has_mitm_ca {
                    let mut l = JsonVal::obj();
                    l.insert("indicator_id", s("worker-proxyenv-injection"));
                    l.insert("attack", s("T1557"));
                    l.insert("pid", s(&fname));
                    l.insert("detail", s("Process carries HTTP(S)_PROXY + mitmproxy-ca-cert.pem trust injection."));
                    leads.push(l);
                }
            }
        }
    }

    if let Some(lp) = log_file {
        if let Ok(txt) = fs::read_to_string(&lp) {
            for marker in ["artex-enrich/1.0", "artex-selfupdate", "norma/", "【ARTEX 平台管控·非目标防御】"] {
                let cnt = txt.matches(marker).count();
                if cnt > 0 {
                    let mut l = JsonVal::obj();
                    l.insert("indicator_id", s("log-marker"));
                    l.insert("marker", s(marker));
                    l.insert("occurrences", n_i64(cnt as i64));
                    leads.push(l);
                }
            }
        }
    }

    let mut res = JsonVal::obj();
    res.insert("ok", JsonVal::Bool(true));
    res.insert("mode", s("read_only_host_triage"));
    res.insert(
        "listening_ports_sample",
        JsonVal::Arr(listen_ports.into_iter().take(40).map(|p| n_i64(p as i64)).collect()),
    );
    res.insert("leads_count", n_i64(leads.len() as i64));
    res.insert("leads", JsonVal::Arr(leads));
    res.insert(
        "caveat",
        s("Every hit is a forensic triage lead grounded in artex-global source indicators, not standalone attribution; absence of hits does not guarantee absence of modified operators."),
    );
    Ok(res)
}

fn tool_sigma_scan(_paths: &EnvPaths, args: &JsonVal) -> Result<JsonVal, String> {
    let text_input = if let Some(lp) = args.get_str("log_path") {
        fs::read_to_string(lp).map_err(|e| format!("Cannot read log_path {}: {}", lp, e))?
    } else if let Some(inline) = args.get_str("events_text") {
        inline.to_string()
    } else {
        return Err("Provide either 'log_path' or 'events_text' to scan against Sigma rules.".into());
    };

    let mut matches_arr = Vec::new();
    let mut rule_hit_counts: BTreeMap<&str, usize> = BTreeMap::new();
    let mut enrich_hosts = BTreeSet::new();

    for (idx, line) in text_input.lines().enumerate() {
        if line.trim().is_empty() {
            continue;
        }
        let lower = line.to_lowercase();
        for rule in SIGMA_RULES {
            let matched_pat = rule.patterns.iter().find(|pat| {
                if pat.is_ascii() {
                    lower.contains(&pat.to_lowercase())
                } else {
                    line.contains(*pat)
                }
            });
            if let Some(pat) = matched_pat {
                *rule_hit_counts.entry(rule.id).or_insert(0) += 1;
                if rule.id == "34adfa15-1696-4322-afc0-f69988e9cc1e" {
                    if let Ok(jv) = parse_json(line) {
                        if let Some(h) = jv.get_str("cs-host").or_else(|| jv.get_str("host")) {
                            enrich_hosts.insert(h.to_string());
                        }
                    }
                }
                if matches_arr.len() < 80 {
                    let mut hit = JsonVal::obj();
                    hit.insert("line", n_i64((idx + 1) as i64));
                    hit.insert("rule_id", s(rule.id));
                    hit.insert("title", s(rule.title));
                    hit.insert("level", s(rule.level));
                    hit.insert("matched_pattern", s(pat));
                    hit.insert("attack", JsonVal::Arr(rule.attack_tags.iter().map(|t| s(t)).collect()));
                    hit.insert("excerpt", s(&line.chars().take(180).collect::<String>()));
                    matches_arr.push(hit);
                }
            }
        }
    }

    // Evaluate ARTEX's 4 Sigma correlation rules
    let mut correlations = Vec::new();
    let enrich_cnt = *rule_hit_counts
        .get("34adfa15-1696-4322-afc0-f69988e9cc1e")
        .unwrap_or(&0);
    if enrich_cnt >= 30 {
        let mut c = JsonVal::obj();
        c.insert("id", s("1d07c5f1-e0ff-4a6a-8017-6008fa790889"));
        c.insert("title", s("ARTEX Enrichment Scan Velocity (>=30 probes)"));
        c.insert("count", n_i64(enrich_cnt as i64));
        correlations.push(c);
    }
    if enrich_hosts.len() >= 20 {
        let mut c = JsonVal::obj();
        c.insert("id", s("6fba3b7c-1dd9-4e18-bf55-d93fc1d2e2e0"));
        c.insert("title", s("ARTEX Enrichment Fan-Out (>=20 distinct cs-host)"));
        c.insert("distinct_hosts", n_i64(enrich_hosts.len() as i64));
        correlations.push(c);
    }
    let guard_cnt = *rule_hit_counts
        .get("3add497e-36cb-47c4-8993-df8f98585ef7")
        .unwrap_or(&0);
    let destr_cnt = *rule_hit_counts
        .get("f510564f-2958-4dc8-a188-3300a2f6f5a7")
        .unwrap_or(&0);
    if guard_cnt >= 5 {
        let mut c = JsonVal::obj();
        c.insert("id", s("065c11b5-4dcf-48ae-84fe-e8301346d5b4"));
        c.insert("title", s("ARTEX Guard-Block Burst (>=5 guard markers)"));
        c.insert("count", n_i64(guard_cnt as i64));
        correlations.push(c);
    }
    if guard_cnt >= 1 && destr_cnt >= 1 {
        let mut c = JsonVal::obj();
        c.insert("id", s("1a03bfb8-7893-4730-9422-dd50c2dd91e8"));
        c.insert("title", s("ARTEX Guard Marker Co-Occurring With Destructive Command"));
        correlations.push(c);
    }

    let mut res = JsonVal::obj();
    res.insert("ok", JsonVal::Bool(true));
    res.insert("atomic_hits_count", n_i64(matches_arr.len() as i64));
    res.insert("atomic_hits", JsonVal::Arr(matches_arr));
    res.insert("correlation_alerts", JsonVal::Arr(correlations));
    Ok(res)
}

fn tool_suricata_inspect(paths: &EnvPaths, args: &JsonVal) -> Result<JsonVal, String> {
    let rules_file = paths.det_dir.join("suricata/artex.rules");
    let raw_rules = fs::read_to_string(&rules_file)
        .map_err(|e| format!("Missing suricata rules: {}", e))?;

    let mut res = JsonVal::obj();
    res.insert("ok", JsonVal::Bool(true));
    res.insert("rules_path", s(&rules_file.display().to_string()));
    res.insert("suricata_rules", s(&raw_rules));

    if let Some(log_p) = args.get_str("http_log_path") {
        let log_txt = fs::read_to_string(log_p).map_err(|e| format!("Read error: {}", e))?;
        let sid_1 = log_txt.matches("artex-enrich/").count();
        let sid_3 = log_txt.matches("norma/").count();
        let mut alerts = Vec::new();
        if sid_1 > 0 {
            let mut a = JsonVal::obj();
            a.insert("sid", n_i64(1000001));
            a.insert("msg", s("ARTEX enrichment prober User-Agent (artex-enrich)"));
            a.insert("hits", n_i64(sid_1 as i64));
            alerts.push(a);
        }
        if sid_1 >= 30 {
            let mut a = JsonVal::obj();
            a.insert("sid", n_i64(1000002));
            a.insert("msg", s("ARTEX enrichment prober high-rate enumeration (>=30)"));
            a.insert("hits", n_i64(sid_1 as i64));
            alerts.push(a);
        }
        if sid_3 > 0 {
            let mut a = JsonVal::obj();
            a.insert("sid", n_i64(1000003));
            a.insert("msg", s("ARTEX worker WebFetch User-Agent (norma)"));
            a.insert("hits", n_i64(sid_3 as i64));
            alerts.push(a);
        }
        res.insert("log_alerts", JsonVal::Arr(alerts));
    }
    Ok(res)
}

fn tool_ioc_lookup(paths: &EnvPaths, args: &JsonVal) -> Result<JsonVal, String> {
    let misp_path = paths.det_dir.join("indicators/artex_indicators.misp.json");
    let csv_path = paths.det_dir.join("indicators/artex_indicators.csv");
    let misp_raw = fs::read_to_string(&misp_path).map_err(|e| format!("MISP read error: {}", e))?;
    let misp_json = parse_json(&misp_raw)?;

    if let Some(export_to) = args.get_str("export_path") {
        let fmt = args.get_str("format").unwrap_or("misp");
        let src = if fmt == "csv" { &csv_path } else { &misp_path };
        fs::copy(src, Path::new(export_to)).map_err(|e| format!("Export copy failed: {}", e))?;
    }

    let filter_q = args.get_str("query").unwrap_or("").to_lowercase();
    let mut matched_attrs = Vec::new();
    if let Some(attrs) = misp_json
        .get("Event")
        .and_then(|ev| ev.get("Attribute"))
        .and_then(|a| a.as_arr())
    {
        for attr in attrs {
            if filter_q.is_empty() || attr.to_json_string().to_lowercase().contains(&filter_q) {
                matched_attrs.push(attr.clone());
            }
        }
    }

    let mut res = JsonVal::obj();
    res.insert("ok", JsonVal::Bool(true));
    res.insert("csv_path", s(&csv_path.display().to_string()));
    res.insert("misp_path", s(&misp_path.display().to_string()));
    res.insert("count", n_i64(matched_attrs.len() as i64));
    res.insert("indicators", JsonVal::Arr(matched_attrs));
    Ok(res)
}

fn tool_attack_coverage(paths: &EnvPaths, args: &JsonVal) -> Result<JsonVal, String> {
    let layer_path = paths.det_dir.join("attack/artex_navigator_layer.json");
    let raw = fs::read_to_string(&layer_path).map_err(|e| format!("Layer read error: {}", e))?;
    let mut layer = parse_json(&raw)?;
    let lang = args.get_str("lang").unwrap_or("es");

    let checklist = if lang == "en" {
        vec![
            s("1. Enforce object-level authorization (IDOR checks) on every API route rather than relying on frontend RBAC menu hiding."),
            s("2. Add rate-limiting & distinct-endpoint velocity alerts at WAF/API Gateway to catch multi-worker AI fan-out (T1595)."),
            s("3. Bind session JWT signing keys to password hashes so credential rotation immediately invalidates active tokens."),
            s("4. Deploy Sigma correlation rules (scan velocity, fan-out, guard markers) and Suricata SIDs 1000001-1000003 on TLS-terminating proxies."),
            s("5. Audit outbound egress for unexpected self-update agents and inspect hosts for unauthorized MITM root CAs (T1557)."),
        ]
    } else {
        vec![
            s("1. Validar autorizacion a nivel de objeto (anti-IDOR) en cada endpoint del backend; nunca depender de ocultar menus RBAC en el frontend."),
            s("2. Aplicar limites de velocidad (rate-limit) y alertas por abanico de rutas distintas en WAF/API Gateway frente a escaneos IA multi-worker (T1595)."),
            s("3. Vincular la clave de firma de sesiones/JWT al hash de contrasena para invalidar tokens al instante tras un cambio de clave."),
            s("4. Desplegar las 9 reglas Sigma (atomicas + correlacion de velocidad/fan-out) y Suricata SIDs 1000001-1000003 en el proxy inverso."),
            s("5. Auditar certificados CA locales (_ca/mitmproxy-ca-cert.pem) y variables NODE_EXTRA_CA_CERTS/SSL_CERT_FILE en servidores sospechosos (T1557)."),
        ]
    };

    layer.insert("ok", JsonVal::Bool(true));
    layer.insert("navigator_layer_path", s(&layer_path.display().to_string()));
    layer.insert("hardening_checklist", JsonVal::Arr(checklist));
    Ok(layer)
}

fn build_tools_list() -> JsonVal {
    let tools = vec![
        make_tool(
            "artex_defense_status",
            "Check ARTEX Blue-Team Defense plugin status (bundled Sigma atomic/correlation rules, Suricata SIDs, MISP/CSV IoCs, MITRE ATT&CK v16 layer, and Shizuku rish).",
            vec![],
            &[],
        ),
        make_tool(
            "artex_host_triage",
            "Read-only forensic host triage ported from artex_host_triage.py: checks ports 8787/8788, _ca/mitmproxy-ca-cert.pem artifacts, process HTTP_PROXY+CA env injections, and log markers.",
            vec![
                ("data_dir", prop_str("Optional directory to inspect for traffic/_ca or artex stores")),
                ("log_path", prop_str("Optional log file path to scan for ARTEX markers")),
                ("use_rish", prop_bool("Use Shizuku rish on Android to inspect system-wide listening sockets")),
            ],
            &[],
        ),
        make_tool(
            "artex_sigma_scan",
            "Evaluate ARTEX's 9 Sigma atomic & correlation rules (User-Agents, Guard audit markers, MITM CA creation, destructive commands, velocity & fan-out) against logs or JSONL events.",
            vec![
                ("log_path", prop_str("Path to log or JSONL file to scan")),
                ("events_text", prop_str("Inline log lines or JSONL events to scan")),
            ],
            &[],
        ),
        make_tool(
            "artex_suricata_inspect",
            "Inspect/export ARTEX Suricata IDS rules (SIDs 1000001-1000003) or evaluate an HTTP access log against them.",
            vec![("http_log_path", prop_str("Optional HTTP access log file to test against Suricata signatures"))],
            &[],
        ),
        make_tool(
            "artex_ioc_lookup",
            "Search verified ARTEX Indicators of Compromise (MISP JSON & SIEM CSV) or export them for SIEM/MISP ingestion.",
            vec![
                ("query", prop_str("Optional filter keyword (e.g. 'user-agent', '8788', 'mitmproxy')")),
                ("format", prop_str_enum("Export format if export_path is set", &["misp", "csv"])),
                ("export_path", prop_str("Optional destination file path to export MISP JSON or CSV")),
            ],
            &[],
        ),
        make_tool(
            "artex_attack_coverage",
            "Return the MITRE ATT&CK v16 Enterprise Navigator layer for autonomous AI attacks plus a Blue-Team defensive hardening checklist (ES/EN).",
            vec![("lang", prop_str_enum("Checklist language", &["es", "en"]))],
            &[],
        ),
    ];
    let mut out = JsonVal::obj();
    out.insert("tools", JsonVal::Arr(tools));
    out
}

fn dispatch_tool(paths: &EnvPaths, name: &str, args: &JsonVal) -> Result<JsonVal, String> {
    match name {
        "artex_defense_status" => tool_status(paths),
        "artex_host_triage" => tool_host_triage(paths, args),
        "artex_sigma_scan" => tool_sigma_scan(paths, args),
        "artex_suricata_inspect" => tool_suricata_inspect(paths, args),
        "artex_ioc_lookup" => tool_ioc_lookup(paths, args),
        "artex_attack_coverage" => tool_attack_coverage(paths, args),
        _ => Err(format!("Unknown tool: {}", name)),
    }
}

#[derive(Clone, Copy)]
enum Framing {
    Line,
    ContentLength,
}

fn read_rpc_message<R: BufRead>(reader: &mut R) -> io::Result<Option<(String, Framing)>> {
    loop {
        let mut line = String::new();
        let n = reader.read_line(&mut line)?;
        if n == 0 {
            return Ok(None);
        }
        let trimmed = line.trim();
        if trimmed.is_empty() {
            continue;
        }
        if trimmed.starts_with('{') {
            return Ok(Some((trimmed.to_string(), Framing::Line)));
        }
        let lower = trimmed.to_ascii_lowercase();
        if let Some(rest) = lower.strip_prefix("content-length:") {
            let len: usize = rest
                .trim()
                .parse()
                .map_err(|_| io::Error::new(io::ErrorKind::InvalidData, "Bad Content-Length"))?;
            loop {
                let mut hdr = String::new();
                let hn = reader.read_line(&mut hdr)?;
                if hn == 0 || hdr.trim().is_empty() {
                    break;
                }
            }
            let mut buf = vec![0u8; len];
            reader.read_exact(&mut buf)?;
            return Ok(Some((String::from_utf8_lossy(&buf).to_string(), Framing::ContentLength)));
        }
    }
}

fn write_rpc_message<W: Write>(writer: &mut W, payload: &JsonVal, framing: Framing) -> io::Result<()> {
    let serialized = payload.to_json_string();
    match framing {
        Framing::Line => {
            writer.write_all(serialized.as_bytes())?;
            writer.write_all(b"\n")?;
        }
        Framing::ContentLength => {
            let header = format!("Content-Length: {}\r\n\r\n", serialized.len());
            writer.write_all(header.as_bytes())?;
            writer.write_all(serialized.as_bytes())?;
        }
    }
    writer.flush()
}

fn handle_rpc_request(paths: &EnvPaths, req: &JsonVal) -> Option<JsonVal> {
    let method = req.get_str("method").unwrap_or("");
    if method.starts_with("notifications/") {
        return None;
    }
    let id = req.get("id")?.clone();
    let mut resp = JsonVal::obj();
    resp.insert("jsonrpc", s("2.0"));
    resp.insert("id", id);

    match method {
        "initialize" => {
            let mut server_info = JsonVal::obj();
            server_info.insert("name", s(SERVER_NAME));
            server_info.insert("version", s(SERVER_VERSION));
            let mut caps = JsonVal::obj();
            caps.insert("tools", JsonVal::obj());
            let proto = req
                .get("params")
                .and_then(|p| p.get_str("protocolVersion"))
                .unwrap_or("2024-11-05");
            let mut result = JsonVal::obj();
            result.insert("protocolVersion", s(proto));
            result.insert("capabilities", caps);
            result.insert("serverInfo", server_info);
            resp.insert("result", result);
        }
        "ping" => {
            resp.insert("result", JsonVal::obj());
        }
        "tools/list" => {
            resp.insert("result", build_tools_list());
        }
        "tools/call" => {
            let params = req.get("params").cloned().unwrap_or_else(JsonVal::obj);
            let tname = params.get_str("name").unwrap_or("");
            let targs = params.get("arguments").cloned().unwrap_or_else(JsonVal::obj);
            match dispatch_tool(paths, tname, &targs) {
                Ok(val) => {
                    let mut citem = JsonVal::obj();
                    citem.insert("type", s("text"));
                    citem.insert("text", s(&val.to_json_string()));
                    let mut result = JsonVal::obj();
                    result.insert("content", JsonVal::Arr(vec![citem]));
                    resp.insert("result", result);
                }
                Err(e) => {
                    let mut err_obj = JsonVal::obj();
                    err_obj.insert("ok", JsonVal::Bool(false));
                    err_obj.insert("error", s(&e));
                    let mut citem = JsonVal::obj();
                    citem.insert("type", s("text"));
                    citem.insert("text", s(&err_obj.to_json_string()));
                    let mut result = JsonVal::obj();
                    result.insert("content", JsonVal::Arr(vec![citem]));
                    result.insert("isError", JsonVal::Bool(true));
                    resp.insert("result", result);
                }
            }
        }
        _ => {
            let mut err = JsonVal::obj();
            err.insert("code", JsonVal::Num(-32601.0));
            err.insert("message", s(&format!("Method not found: {}", method)));
            resp.insert("error", err);
        }
    }
    Some(resp)
}

fn main() {
    let paths = EnvPaths::resolve();
    let argv: Vec<String> = env::args().collect();
    if argv.len() > 1 {
        match argv[1].as_str() {
            "status" => match tool_status(&paths) {
                Ok(v) => println!("{}", v.to_json_string()),
                Err(e) => {
                    eprintln!("{}", e);
                    std::process::exit(1);
                }
            },
            "triage" => match tool_host_triage(&paths, &JsonVal::obj()) {
                Ok(v) => println!("{}", v.to_json_string()),
                Err(e) => {
                    eprintln!("{}", e);
                    std::process::exit(1);
                }
            },
            _ => println!("Usage: artex-defense [status | triage]"),
        }
        return;
    }

    let stdin = io::stdin();
    let stdout = io::stdout();
    let mut reader = BufReader::new(stdin.lock());
    let mut writer = stdout.lock();

    while let Ok(Some((raw, framing))) = read_rpc_message(&mut reader) {
        if let Ok(req) = parse_json(&raw) {
            if let Some(resp) = handle_rpc_request(&paths, &req) {
                if write_rpc_message(&mut writer, &resp, framing).is_err() {
                    break;
                }
            }
        }
    }
}
