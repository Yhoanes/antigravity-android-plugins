// json.rs — Zero-dependency RFC 8259 JSON Parser & Serializer for ARTEX Rust ARM64 MCP
#![allow(dead_code)]

use std::collections::BTreeMap;

#[derive(Clone, Debug, PartialEq)]
pub enum JsonVal {
    Null,
    Bool(bool),
    Num(f64),
    Str(String),
    Arr(Vec<JsonVal>),
    Obj(BTreeMap<String, JsonVal>),
}

pub fn s(val: &str) -> JsonVal {
    JsonVal::Str(val.to_string())
}

pub fn n_i64(val: i64) -> JsonVal {
    JsonVal::Num(val as f64)
}

impl JsonVal {
    pub fn obj() -> Self {
        JsonVal::Obj(BTreeMap::new())
    }

    pub fn insert(&mut self, k: &str, v: JsonVal) {
        if let JsonVal::Obj(map) = self {
            map.insert(k.to_string(), v);
        }
    }

    pub fn get(&self, k: &str) -> Option<&JsonVal> {
        match self {
            JsonVal::Obj(map) => map.get(k),
            _ => None,
        }
    }

    pub fn as_str(&self) -> Option<&str> {
        match self {
            JsonVal::Str(v) => Some(v.as_str()),
            _ => None,
        }
    }

    pub fn as_bool(&self) -> Option<bool> {
        match self {
            JsonVal::Bool(b) => Some(*b),
            _ => None,
        }
    }

    pub fn as_f64(&self) -> Option<f64> {
        match self {
            JsonVal::Num(n) => Some(*n),
            _ => None,
        }
    }

    pub fn as_i64(&self) -> Option<i64> {
        self.as_f64().map(|n| n as i64)
    }

    pub fn as_arr(&self) -> Option<&Vec<JsonVal>> {
        match self {
            JsonVal::Arr(a) => Some(a),
            _ => None,
        }
    }

    pub fn get_str<'a>(&'a self, k: &str) -> Option<&'a str> {
        self.get(k).and_then(|v| v.as_str())
    }

    pub fn get_bool(&self, k: &str) -> Option<bool> {
        self.get(k).and_then(|v| v.as_bool())
    }

    pub fn get_f64(&self, k: &str) -> Option<f64> {
        self.get(k).and_then(|v| v.as_f64())
    }

    pub fn get_i64(&self, k: &str) -> Option<i64> {
        self.get(k).and_then(|v| v.as_i64())
    }

    pub fn to_json_string(&self) -> String {
        let mut out = String::with_capacity(256);
        self.write_to(&mut out);
        out
    }

    fn write_to(&self, out: &mut String) {
        match self {
            JsonVal::Null => out.push_str("null"),
            JsonVal::Bool(b) => out.push_str(if *b { "true" } else { "false" }),
            JsonVal::Num(n) => {
                if n.is_finite() {
                    if n.fract() == 0.0 && n.abs() < 9_007_199_254_740_991.0 {
                        out.push_str(&format!("{}", *n as i64));
                    } else {
                        out.push_str(&format!("{}", n));
                    }
                } else {
                    out.push_str("null");
                }
            }
            JsonVal::Str(st) => escape_json_str(st, out),
            JsonVal::Arr(items) => {
                out.push('[');
                for (i, item) in items.iter().enumerate() {
                    if i > 0 {
                        out.push(',');
                    }
                    item.write_to(out);
                }
                out.push(']');
            }
            JsonVal::Obj(map) => {
                out.push('{');
                for (i, (k, v)) in map.iter().enumerate() {
                    if i > 0 {
                        out.push(',');
                    }
                    escape_json_str(k, out);
                    out.push(':');
                    v.write_to(out);
                }
                out.push('}');
            }
        }
    }
}

pub fn escape_json_str(s: &str, out: &mut String) {
    out.push('"');
    for ch in s.chars() {
        match ch {
            '"' => out.push_str("\\\""),
            '\\' => out.push_str("\\\\"),
            '\n' => out.push_str("\\n"),
            '\r' => out.push_str("\\r"),
            '\t' => out.push_str("\\t"),
            '\u{08}' => out.push_str("\\b"),
            '\u{0C}' => out.push_str("\\f"),
            c if (c as u32) < 0x20 => {
                out.push_str(&format!("\\u{:04x}", c as u32));
            }
            c => out.push(c),
        }
    }
    out.push('"');
}

pub fn parse_json(input: &str) -> Result<JsonVal, String> {
    let mut p = Parser {
        bytes: input.as_bytes(),
        pos: 0,
    };
    p.skip_ws();
    let v = p.parse_val()?;
    p.skip_ws();
    Ok(v)
}

struct Parser<'a> {
    bytes: &'a [u8],
    pos: usize,
}

impl<'a> Parser<'a> {
    fn skip_ws(&mut self) {
        while self.pos < self.bytes.len() {
            match self.bytes[self.pos] {
                b' ' | b'\t' | b'\r' | b'\n' => self.pos += 1,
                _ => break,
            }
        }
    }

    fn peek(&self) -> Option<u8> {
        self.bytes.get(self.pos).copied()
    }

    fn parse_val(&mut self) -> Result<JsonVal, String> {
        self.skip_ws();
        match self.peek() {
            Some(b'{') => self.parse_obj(),
            Some(b'[') => self.parse_arr(),
            Some(b'"') => self.parse_str().map(JsonVal::Str),
            Some(b't') => {
                if self.bytes[self.pos..].starts_with(b"true") {
                    self.pos += 4;
                    Ok(JsonVal::Bool(true))
                } else {
                    Err("Invalid literal".into())
                }
            }
            Some(b'f') => {
                if self.bytes[self.pos..].starts_with(b"false") {
                    self.pos += 5;
                    Ok(JsonVal::Bool(false))
                } else {
                    Err("Invalid literal".into())
                }
            }
            Some(b'n') => {
                if self.bytes[self.pos..].starts_with(b"null") {
                    self.pos += 4;
                    Ok(JsonVal::Null)
                } else {
                    Err("Invalid literal".into())
                }
            }
            Some(c) if c == b'-' || c.is_ascii_digit() => self.parse_num(),
            Some(c) => Err(format!("Unexpected byte '{}' at {}", c as char, self.pos)),
            None => Err("Unexpected EOF".into()),
        }
    }

    fn parse_obj(&mut self) -> Result<JsonVal, String> {
        self.pos += 1;
        self.skip_ws();
        let mut map = BTreeMap::new();
        if self.peek() == Some(b'}') {
            self.pos += 1;
            return Ok(JsonVal::Obj(map));
        }
        loop {
            self.skip_ws();
            if self.peek() != Some(b'"') {
                return Err(format!("Expected string key at {}", self.pos));
            }
            let key = self.parse_str()?;
            self.skip_ws();
            if self.peek() != Some(b':') {
                return Err(format!("Expected ':' at {}", self.pos));
            }
            self.pos += 1;
            let val = self.parse_val()?;
            map.insert(key, val);
            self.skip_ws();
            match self.peek() {
                Some(b',') => self.pos += 1,
                Some(b'}') => {
                    self.pos += 1;
                    break;
                }
                _ => return Err(format!("Expected ',' or '}}' at {}", self.pos)),
            }
        }
        Ok(JsonVal::Obj(map))
    }

    fn parse_arr(&mut self) -> Result<JsonVal, String> {
        self.pos += 1;
        self.skip_ws();
        let mut arr = Vec::new();
        if self.peek() == Some(b']') {
            self.pos += 1;
            return Ok(JsonVal::Arr(arr));
        }
        loop {
            let val = self.parse_val()?;
            arr.push(val);
            self.skip_ws();
            match self.peek() {
                Some(b',') => self.pos += 1,
                Some(b']') => {
                    self.pos += 1;
                    break;
                }
                _ => return Err(format!("Expected ',' or ']' at {}", self.pos)),
            }
        }
        Ok(JsonVal::Arr(arr))
    }

    fn parse_hex4(&mut self) -> Result<u16, String> {
        if self.pos + 4 > self.bytes.len() {
            return Err("Truncated \\u escape".into());
        }
        let slice = std::str::from_utf8(&self.bytes[self.pos..self.pos + 4])
            .map_err(|_| "Invalid hex utf8")?;
        let code = u16::from_str_radix(slice, 16).map_err(|_| "Invalid hex escape")?;
        self.pos += 4;
        Ok(code)
    }

    fn parse_str(&mut self) -> Result<String, String> {
        self.pos += 1;
        let mut out = String::new();
        while self.pos < self.bytes.len() {
            let b = self.bytes[self.pos];
            if b == b'"' {
                self.pos += 1;
                return Ok(out);
            }
            if b == b'\\' {
                self.pos += 1;
                if self.pos >= self.bytes.len() {
                    return Err("Unterminated escape".into());
                }
                match self.bytes[self.pos] {
                    b'"' => {
                        out.push('"');
                        self.pos += 1;
                    }
                    b'\\' => {
                        out.push('\\');
                        self.pos += 1;
                    }
                    b'/' => {
                        out.push('/');
                        self.pos += 1;
                    }
                    b'b' => {
                        out.push('\u{08}');
                        self.pos += 1;
                    }
                    b'f' => {
                        out.push('\u{0C}');
                        self.pos += 1;
                    }
                    b'n' => {
                        out.push('\n');
                        self.pos += 1;
                    }
                    b'r' => {
                        out.push('\r');
                        self.pos += 1;
                    }
                    b't' => {
                        out.push('\t');
                        self.pos += 1;
                    }
                    b'u' => {
                        self.pos += 1;
                        let u1 = self.parse_hex4()?;
                        if (0xD800..=0xDBFF).contains(&u1) {
                            if self.pos + 2 <= self.bytes.len()
                                && &self.bytes[self.pos..self.pos + 2] == b"\\u"
                            {
                                self.pos += 2;
                                let u2 = self.parse_hex4()?;
                                let combined = 0x10000
                                    + (((u1 as u32 - 0xD800) << 10) | (u2 as u32 - 0xDC00));
                                if let Some(ch) = char::from_u32(combined) {
                                    out.push(ch);
                                }
                            }
                        } else if let Some(ch) = char::from_u32(u1 as u32) {
                            out.push(ch);
                        }
                    }
                    other => {
                        out.push(other as char);
                        self.pos += 1;
                    }
                }
            } else {
                let start = self.pos;
                self.pos += 1;
                while self.pos < self.bytes.len()
                    && self.bytes[self.pos] != b'"'
                    && self.bytes[self.pos] != b'\\'
                {
                    self.pos += 1;
                }
                let chunk = std::str::from_utf8(&self.bytes[start..self.pos])
                    .map_err(|_| "Invalid UTF-8 in JSON string")?;
                out.push_str(chunk);
            }
        }
        Err("Unterminated string".into())
    }

    fn parse_num(&mut self) -> Result<JsonVal, String> {
        let start = self.pos;
        if self.peek() == Some(b'-') {
            self.pos += 1;
        }
        while let Some(c) = self.peek() {
            if c.is_ascii_digit() || c == b'.' || c == b'e' || c == b'E' || c == b'+' || c == b'-' {
                self.pos += 1;
            } else {
                break;
            }
        }
        let st = std::str::from_utf8(&self.bytes[start..self.pos]).map_err(|_| "Bad number")?;
        let n: f64 = st.parse().map_err(|_| format!("Invalid number: {}", st))?;
        Ok(JsonVal::Num(n))
    }
}

pub fn prop_str(desc: &str) -> JsonVal {
    let mut p = JsonVal::obj();
    p.insert("type", s("string"));
    p.insert("description", s(desc));
    p
}

pub fn prop_str_enum(desc: &str, vals: &[&str]) -> JsonVal {
    let mut p = prop_str(desc);
    p.insert("enum", JsonVal::Arr(vals.iter().map(|v| s(v)).collect()));
    p
}

pub fn prop_int(desc: &str) -> JsonVal {
    let mut p = JsonVal::obj();
    p.insert("type", s("integer"));
    p.insert("description", s(desc));
    p
}

pub fn prop_num(desc: &str) -> JsonVal {
    let mut p = JsonVal::obj();
    p.insert("type", s("number"));
    p.insert("description", s(desc));
    p
}

pub fn prop_bool(desc: &str) -> JsonVal {
    let mut p = JsonVal::obj();
    p.insert("type", s("boolean"));
    p.insert("description", s(desc));
    p
}

pub fn prop_arr_int(desc: &str) -> JsonVal {
    let mut item = JsonVal::obj();
    item.insert("type", s("integer"));
    let mut p = JsonVal::obj();
    p.insert("type", s("array"));
    p.insert("items", item);
    p.insert("description", s(desc));
    p
}

pub fn prop_arr_str(desc: &str) -> JsonVal {
    let mut item = JsonVal::obj();
    item.insert("type", s("string"));
    let mut p = JsonVal::obj();
    p.insert("type", s("array"));
    p.insert("items", item);
    p.insert("description", s(desc));
    p
}

pub fn make_tool(name: &str, desc: &str, props: Vec<(&str, JsonVal)>, req: &[&str]) -> JsonVal {
    let mut pobj = JsonVal::obj();
    for (k, v) in props {
        pobj.insert(k, v);
    }
    let mut schema = JsonVal::obj();
    schema.insert("type", s("object"));
    schema.insert("properties", pobj);
    if !req.is_empty() {
        schema.insert("required", JsonVal::Arr(req.iter().map(|r| s(r)).collect()));
    }
    let mut t = JsonVal::obj();
    t.insert("name", s(name));
    t.insert("description", s(desc));
    t.insert("inputSchema", schema);
    t
}
