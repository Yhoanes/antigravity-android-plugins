# PeakCut Pro: Live & AI Clipper Studio (`v1.0.0`) — Clipping en Caliente & Shorts `9:16` en Rust ARM64

Plugin nativo **ARM64 (`aarch64` + `LSE`)** para **Antigravity for Android** que porta y potencia [`haziqahmedqasmi/PeakCut`](https://github.com/haziqahmedqasmi/PeakCut) (`MIT`) con un servidor MCP en **Rust puro (`509 KB`, `<10 MB` RAM, `0` crates externas)**, aceleración por hardware **GPU `h264_mediacodec`**, seguimiento activo de hablante (**`auto_face`**), **Español nativo (`es`)** y **Clipping en Caliente** sobre *streams* en vivo.

---

## 5 Mejoras Pro Exclusivas Frente al PeakCut Original

1. **Clipping en Caliente (`YouTube Live`, `Twitch` y `Kick` en Vivo):**
   - Graba transmisiones en directo en un búfer rotativo continuo, monitorea picos de volumen (`LOUD`), explosiones de chat en vivo (`CHAT`) y comandos de voz en inglés y español (`"clip that"`, `"clipea"`, `"saca clip"`), o recorta al instante los últimos `N` segundos con `peakcut_live_clip_now`.
2. **Seguimiento Facial Inteligente `9:16` (`auto_face`) + `gameplay` PiP + `split`:**
   - Nuevo modo `auto_face` que rastrea horizontalmente el rostro/hablante activo con filtro suavizado EMA + banda muerta en una sola pasada de `ffmpeg`, evitando rostros cortados por la mitad en podcasts y reacciones.
3. **Español (`es`) y Multilingüe 100% Nativos (Offline Bionic + Cloud Instantáneo):**
   - Integra **`sherpa-onnx v2.0.2` nativo para Android ARM64 Bionic** (`$PREFIX/opt/sherpa-onnx`, cero errores `glibc` y cero `libsndfile`) con modelos compactos **NVIDIA FastConformer Español (`102 MB`)**, **Parakeet Inglés (`103 MB`)** y **Parakeet v3 25 Idiomas (`464 MB`)**, además de acelerador opcional **Groq / OpenAI Whisper (`<2 s`, `0 MB`)** y ganchos/títulos virales con tildes y `ñ` intactas.
4. **Codificación por Hardware GPU (`h264_mediacodec`) + Exportación a Galería:**
   - Renderiza Shorts `1080x1920` con subtítulos karaoke `libass` (`bounce`, `hype`, `clean`) y normalización `-14 LUFS` usando la GPU de Android e indexa los `.mp4` en `/storage/emulated/0/Movies/PeakCut/`.
5. **Preparación Lista para Whop Content Rewards:**
   - Incluye `peakcut_whop_campaign_prep` para validar requisitos de campaña (`9:16`, cero marcas de agua, duración, hashtags obligatorios) y calcular proyecciones de pago por CPM.

---

## Las 12 Herramientas MCP Nativas en Rust

| Herramienta | Categoría | Función Nativa ARM64 |
| :--- | :--- | :--- |
| `peakcut_status` | Diagnóstico | Estado del servidor `:8765`, GPU `h264_mediacodec`, `sherpa-onnx` Bionic, `yt-dlp` + `node`, IA y modelos de voz. |
| `peakcut_setup` | Bootstrap 1-Click | Instala `FastAPI`/`Uvicorn`/`SQLAlchemy`, configura `sherpa-onnx` Android ARM64 e inicia el estudio web. |
| `peakcut_studio_server` | Consola Web | Inicia, detiene o abre (`xdg-open`) el Dashboard completo en `http://127.0.0.1:8765/app`. |
| `peakcut_ai_configure` | Cerebro IA | Configura y prueba `gemini`, `groq`, `openai`, `openrouter`, `anthropic`, `xai` u `ollama`. |
| `peakcut_speech_models` | Voz Offline | Lista, descarga o elimina modelos locales `int8` (`es` 102 MB, `en` 103 MB, `multi` 464 MB, `ar` 107 MB). |
| `peakcut_clip_vod` | Videos / Podcasts | Recorta URLs (`YouTube`, `Twitch`, `Kick`) o archivos locales en Android con `auto_face`, `split` o `gameplay`. |
| `peakcut_live_monitor` | Live en Caliente | Inicia, lista o detiene el monitoreo y recorte automático en vivo mientras el streamer sigue transmitiendo. |
| `peakcut_live_clip_now` | Botón "¡Clipea!" | Corta, subtitula y renderiza al instante los últimos `5–180 s` de un *stream* activo. |
| `peakcut_jobs_list` | Cola & Puntajes | Inspecciona trabajos, puntajes de viralidad (`0–100`), hooks y rutas `.mp4` en disco. |
| `peakcut_clip_rerender` | Re-edición | Re-renderiza cualquier clip cambiando layout (`auto_face`, `split`), estilo (`hype`, `bounce`), hook o tiempos. |
| `peakcut_export_gallery` | Galería Android | Copia clips terminados a `/storage/emulated/0/Movies/PeakCut/` y dispara el escaneo de `MediaStore`. |
| `peakcut_whop_campaign_prep` | Monetización | Prepara copys, verifica reglas anti-rechazo y proyecta ganancias CPM para campañas de **Whop Content Rewards**. |

---

## CLI en Terminal (`$PREFIX/bin/peakcut`)

```bash
peakcut status
peakcut setup
peakcut studio open                        # Abre http://127.0.0.1:8765/app en el navegador Android
peakcut live start https://kick.com/canal  # Clipping en caliente mientras transmite
peakcut live clip-now 45                   # Saca clip inmediato de los últimos 45 segundos
peakcut clip /sdcard/Download/podcast.mp4 es
peakcut export <job_id>
```
