---
name: peakcut
description: Turn live streams ("clipping en caliente" on Kick, Twitch, YouTube Live while broadcasting) and long VODs/podcasts into viral 9:16 Shorts/TikToks/Reels with active-speaker face tracking (auto_face), gameplay+facecam PiP, split-screen, Spanish/English bouncy libass karaoke captions, GPU h264_mediacodec encoding, and Whop Content Rewards prep.
---

# PeakCut Pro: Live & AI Clipper Studio Guide (Android ARM64)

Use this skill whenever the user wants to **clip long videos, podcasts, or active live streams into viral `9:16` vertical Shorts/Reels/TikToks**, open the **PeakCut Web Studio (`127.0.0.1:8765`)**, or prepare clips for **Whop Content Rewards / creator clipping campaigns**.

---

## 1. Quick Setup & AI / Speech Configuration

1. Call **`peakcut_status`** first; if `python_modules.fastapi` is `false` or `sherpa_onnx_bionic_ready` is `false`, call **`peakcut_setup`**.
2. **Choose AI + Speech Mode:**
   - **Fastest Zero-Download Mode (Recommended to start in `<10s`):** Call **`peakcut_ai_configure`** with `provider: "groq"` (`model: "llama-3.3-70b-versatile"`) or `provider: "gemini"` (`model: "gemini-2.5-flash"`). With a `groq` or `openai` key, PeakCut Pro also unlocks **2-second Cloud Whisper (`whisper-large-v3-turbo`)** word-by-word timestamps in 99 languages without downloading any local speech model!
   - **100% Free Offline Speech Models:** Call **`peakcut_speech_models`** (`action: "download"`, `lang: "es"` for `102 MB` Spanish FastConformer `int8`, `"en"` for `103 MB` English Parakeet `int8`, or `"multi"` for `464 MB` 25-language Parakeet v3).
   - **Zero-Key Mode (`$0`):** Even without an AI key, PeakCut still clips by audio loudness peaks + live chat bursts!

---

## 2. "Clipping en Caliente" (Hot Live Stream Clipping)

When a streamer is live right now on **Kick, Twitch, or YouTube Live**:
1. Call **`peakcut_live_monitor`**:
   - `action: "start"`
   - `channel_url`: e.g. `"https://kick.com/westcol"`, `"https://twitch.tv/ibai"`, `"https://youtube.com/@IShowSpeed/live"`
   - `lang`: `"es"` or `"en"`
   - `layout`:
     - `"auto_face"` — active-speaker horizontal tracking in `9:16` (IRL, Just Chatting, solo reactions)
     - `"gameplay"` — full-bleed gameplay with auto-detected streamer webcam PiP in top corner
     - `"split"` — 2-panel top/bottom split screen (debates, duos, podcasts)
   - `style`: `"hype"` (Anton 2-word punch), `"bounce"` (Poppins 3-word pop), or `"clean"`
2. **Instant Manual Grab:** At any moment while recording, call **`peakcut_live_clip_now`** (`seconds: 45`) to immediately cut & render the last 45 seconds! Streamers saying `"clip that"` or `"clipea"` / `"saca clip"` on stream also trigger an automatic check.
3. Monitor progress with **`peakcut_live_monitor`** (`action: "list"`) or open the live Web Studio in the Android browser with **`peakcut_studio_server`** (`action: "open"`).

---

## 3. VOD Clipping, Re-Framing & Whop Campaign Handoff

1. **Submit VOD or Local Video:** Call **`peakcut_clip_vod`** with `url_or_path`, `lang`, `layout: "auto_face"`, and `style: "bounce"` or `"hype"`. (For YouTube VODs, PeakCut automatically pulls YouTube's `json3` word timestamps in `<1s`!).
2. **Inspect & Refine:** Call **`peakcut_jobs_list`** to review virality scores (`0–100`), hooks, and `.mp4` paths. To adjust framing, trim timestamps, or test a stronger hook, call **`peakcut_clip_rerender`**.
3. **Whop / Social Export:**
   - Call **`peakcut_whop_campaign_prep`** (`job_id`, `clip_id`, `cpm_rate`, `required_hashtag`) to generate compliant captions + CPM revenue estimates.
   - Call **`peakcut_export_gallery`** (`job_id`) to place all finished `1080x1920` `.mp4` clips at the top of Android Gallery (`/storage/emulated/0/Movies/PeakCut/`).
   - *Pro Tip for Higher Retention & Originality:* Combine exported PeakCut clips with **`agy-remotion`** (animated B-roll overlays / SaaS callouts) or **`agy-video-studio`** (`capcut_export_draft`) when targeting premium \$2–\$5 CPM campaigns!
