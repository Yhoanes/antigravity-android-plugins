#!/system/bin/sh
# install-plugin.sh — Installs and configures PeakCut Pro: Live & AI Clipper Studio (v1.0.0, Native Rust ARM64)
set -eu

SRC_DIR="$(CDPATH= cd -- "$(/system/bin/dirname -- "$0")" && pwd)"
case "$SRC_DIR" in
    */.gemini/*) HOME="${SRC_DIR%%/.gemini/*}" ;;
    *) HOME="${HOME:-/data/user/0/com.agy/files}" ;;
esac
PREFIX="${PREFIX:-$HOME/usr}"
CONFIG_DIR="$HOME/.gemini/config"
TARGET_DIR="$CONFIG_DIR/plugins/peakcut"

/system/bin/mkdir -p "$CONFIG_DIR/plugins" "$HOME/.gemini/peakcut" "$PREFIX/tmp" "$PREFIX/bin"

if [ "$SRC_DIR" != "$TARGET_DIR" ]; then
    /system/bin/rm -rf "$TARGET_DIR"
    /system/bin/mkdir -p "$TARGET_DIR"
    /system/bin/cp -Rf "$SRC_DIR"/. "$TARGET_DIR"/
fi

/system/bin/chmod 0755 \
    "$TARGET_DIR/install-plugin.sh" \
    "$TARGET_DIR/mcp/bin/start-mcp.sh" \
    "$TARGET_DIR/mcp/bin/peakcut-mcp"

/system/bin/rm -f "$PREFIX/bin/peakcut"
cat > "$PREFIX/bin/peakcut" <<EOF
#!/system/bin/sh
export HOME="$HOME"
export PREFIX="$PREFIX"
LD_EXTRA=""
[ -d "$PREFIX/opt/sherpa-onnx/lib" ] && LD_EXTRA="$PREFIX/opt/sherpa-onnx/lib"
[ -d "$PREFIX/lib" ] && LD_EXTRA="\${LD_EXTRA:+\$LD_EXTRA:}$PREFIX/lib"
[ -n "\$LD_EXTRA" ] && export LD_LIBRARY_PATH="\$LD_EXTRA\${LD_LIBRARY_PATH:+:\$LD_LIBRARY_PATH}"
exec "$TARGET_DIR/mcp/bin/peakcut-mcp" "\$@"
EOF
/system/bin/chmod 0755 "$PREFIX/bin/peakcut"

echo "================================================================="
echo " Plugin PeakCut Pro: Live & AI Clipper v1.0.0 (Rust ARM64) ready"
echo " Path: $TARGET_DIR"
echo " CLI:  $PREFIX/bin/peakcut"
echo "================================================================="
