from starlette.concurrency import run_in_threadpool

__all__ = ["run_in_threadpool"]
