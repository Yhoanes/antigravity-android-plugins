"""Zero-Pydantic Pure-Starlette FastAPI Compatibility Layer for PeakCut Android ARM64.

Eliminates the 6-minute pydantic-core PyO3/Maturin compilation on Android Bionic while
preserving 100% of PeakCut's ASGI middleware, routing, Body/Form/File injection, and contextvars.
"""
from __future__ import annotations

import inspect
from typing import Any, Callable

from starlette.applications import Starlette
from starlette.concurrency import run_in_threadpool
from starlette.datastructures import UploadFile
from starlette.requests import Request
from starlette.responses import JSONResponse, Response
from starlette.routing import Route


class HTTPException(Exception):
    def __init__(self, status_code: int, detail: Any = None, headers: dict[str, str] | None = None):
        super().__init__(detail or f"HTTP {status_code}")
        self.status_code = int(status_code)
        self.detail = detail if detail is not None else f"HTTP {status_code}"
        self.headers = headers


class _Marker:
    def __init__(self, default: Any = ...):
        self.default = default


class _BodyMarker(_Marker):
    pass


class _FormMarker(_Marker):
    pass


class _FileMarker(_Marker):
    pass


def Body(default: Any = ...) -> Any:
    return _BodyMarker(default)


def Form(default: Any = ...) -> Any:
    return _FormMarker(default)


def File(default: Any = ...) -> Any:
    return _FileMarker(default)


def _coerce_scalar(val: Any, annotation: Any) -> Any:
    if val is None:
        return None
    if annotation is int or annotation == "int":
        return int(val)
    if annotation is float or annotation == "float":
        return float(val)
    if annotation is bool or annotation == "bool":
        if isinstance(val, bool):
            return val
        return str(val).lower() in ("1", "true", "yes", "on")
    return str(val)


def _wrap_endpoint(fn: Callable[..., Any]) -> Callable[[Request], Any]:
    sig = inspect.signature(fn)
    is_coro = inspect.iscoroutinefunction(fn)
    params = list(sig.parameters.values())

    async def endpoint(request: Request) -> Response:
        try:
            kwargs: dict[str, Any] = {}
            json_cache: Any = None
            json_loaded = False
            form_cache: Any = None

            for p in params:
                name = p.name
                ann = p.annotation
                default = p.default

                if name == "request" or ann is Request or ann == "Request":
                    kwargs[name] = request
                    continue

                if isinstance(default, _BodyMarker):
                    if not json_loaded:
                        raw = await request.body()
                        if raw:
                            try:
                                json_cache = await request.json()
                            except Exception as exc:
                                raise HTTPException(400, f"Invalid JSON body: {exc}") from exc
                        else:
                            json_cache = {} if default.default is ... else default.default
                        json_loaded = True
                    if json_cache is None and default.default is not ...:
                        json_cache = default.default
                    kwargs[name] = json_cache if json_cache is not None else {}
                    continue

                if isinstance(default, (_FormMarker, _FileMarker)) or ann is UploadFile or ann == "UploadFile":
                    if form_cache is None:
                        form_cache = await request.form()
                    if name in form_cache:
                        kwargs[name] = form_cache[name]
                    elif isinstance(default, _Marker) and default.default is not ...:
                        kwargs[name] = default.default
                    elif default is not inspect.Parameter.empty and not isinstance(default, _Marker):
                        kwargs[name] = default
                    else:
                        raise HTTPException(422, f"Missing form field: {name}")
                    continue

                if name in request.path_params:
                    kwargs[name] = _coerce_scalar(request.path_params[name], ann)
                    continue

                if name in request.query_params:
                    kwargs[name] = _coerce_scalar(request.query_params[name], ann)
                    continue

                if default is not inspect.Parameter.empty:
                    kwargs[name] = default
                else:
                    kwargs[name] = ""

            result = await fn(**kwargs) if is_coro else await run_in_threadpool(fn, **kwargs)
            if isinstance(result, Response):
                return result
            if result is None:
                return Response(status_code=204)
            return JSONResponse(result)
        except HTTPException as he:
            return JSONResponse({"detail": he.detail}, status_code=he.status_code, headers=he.headers)

    return endpoint


class FastAPI(Starlette):
    def __init__(self, title: str = "FastAPI", docs_url: str | None = None, redoc_url: str | None = None,
                 openapi_url: str | None = None, **kwargs: Any):
        import contextlib
        self._startup_handlers: list[Callable[[], Any]] = []
        self._shutdown_handlers: list[Callable[[], Any]] = []

        @contextlib.asynccontextmanager
        async def _lifespan(_app: Starlette):
            for h in self._startup_handlers:
                if inspect.iscoroutinefunction(h):
                    await h()
                else:
                    await run_in_threadpool(h)
            try:
                yield
            finally:
                for h in self._shutdown_handlers:
                    if inspect.iscoroutinefunction(h):
                        await h()
                    else:
                        await run_in_threadpool(h)

        kwargs.setdefault("lifespan", _lifespan)
        super().__init__(**kwargs)
        self.title = title

    def on_event(self, event_type: str) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
        def decorator(fn: Callable[..., Any]) -> Callable[..., Any]:
            if event_type == "startup":
                self._startup_handlers.append(fn)
            elif event_type == "shutdown":
                self._shutdown_handlers.append(fn)
            return fn

        return decorator

    def _register(self, path: str, methods: list[str]) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
        def decorator(fn: Callable[..., Any]) -> Callable[..., Any]:
            # Unwrap if stacked @app.get("/a") + @app.get("/b")
            raw_fn = getattr(fn, "__peakcut_raw__", fn)
            wrapped = _wrap_endpoint(raw_fn)
            self.router.routes.append(Route(path, endpoint=wrapped, methods=methods))
            setattr(raw_fn, "__peakcut_raw__", raw_fn)
            return raw_fn

        return decorator

    def get(self, path: str, **kwargs: Any):
        return self._register(path, ["GET", "HEAD"])

    def post(self, path: str, **kwargs: Any):
        return self._register(path, ["POST"])

    def put(self, path: str, **kwargs: Any):
        return self._register(path, ["PUT"])

    def delete(self, path: str, **kwargs: Any):
        return self._register(path, ["DELETE"])

    def patch(self, path: str, **kwargs: Any):
        return self._register(path, ["PATCH"])


__all__ = ["Body", "FastAPI", "File", "Form", "HTTPException", "Request", "UploadFile"]
