// main.rs — PeakCut Pro: Live & AI Clipper Studio (peakcut v1.0.0)
// Native Android ARM64 Rust MCP Server + CLI + Hot Live Stream & VOD Clipper Bridge
mod json;

use json::{
    make_tool, n_i64, parse_json, prop_arr_str, prop_bool, prop_int, prop_num, prop_str,
    prop_str_enum, s, JsonVal,
};
use std::env;
use std::fs;
use std::io::{self, BufRead, BufReader, Read, Write};
use std::net::TcpStream;
use std::path::{Path, PathBuf};
use std::process::{Command, Stdio};
use std::thread;
use std::time::Duration;

const SERVER_NAME: &str = "peakcut";
const SERVER_VERSION: &str = "1.0.0";
const DEFAULT_PORT: u16 = 8765;
const SHERPA_ANDROID_URL: &str = "https://github.com/k2-fsa/sherpa-onnx/releases/download/v2.0.2/sherpa-onnx-v2.0.2-android-aarch64-termux-shared.tar.bz2";

struct EnvPaths {
    home: PathBuf,
    prefix: PathBuf,
    plugin_dir: PathBuf,
    engine_dir: PathBuf,
    data_dir: PathBuf,
    pid_file: PathBuf,
    log_file: PathBuf,
    sherpa_dir: PathBuf,
    tmp_dir: PathBuf,
    port: u16,
}

impl EnvPaths {
    fn resolve() -> Self {
        let mut home = env::var("HOME")
            .ok()
            .filter(|v| !v.is_empty())
            .map(PathBuf::from)
            .unwrap_or_else(|| PathBuf::from("/data/user/0/com.agy/files"));

        let exe_plugin_dir = env::current_exe().ok().and_then(|exe| {
            let bin_dir = exe.parent()?;
            let mcp_dir = bin_dir.parent()?;
            let p_dir = mcp_dir.parent()?;
            if p_dir.join("plugin.json").exists() || mcp_dir.join("engine").exists() {
                Some(p_dir.to_path_buf())
            } else {
                None
            }
        });

        if let Some(ref pdir) = exe_plugin_dir {
            let pstr = pdir.to_string_lossy();
            if let Some(idx) = pstr.find("/.gemini/") {
                home = PathBuf::from(&pstr[..idx]);
            }
        }

        let prefix = env::var("PREFIX")
            .ok()
            .filter(|v| !v.is_empty())
            .map(PathBuf::from)
            .unwrap_or_else(|| home.join("usr"));

        let plugin_dir =
            exe_plugin_dir.unwrap_or_else(|| home.join(".gemini/config/plugins/peakcut"));
        let engine_dir = plugin_dir.join("mcp/engine");

        let default_docs = PathBuf::from("/storage/emulated/0/Documents/PeakCutData");
        let data_dir = env::var("PEAKCUT_DATA")
            .ok()
            .filter(|v| !v.is_empty())
            .map(PathBuf::from)
            .unwrap_or_else(|| {
                if Path::new("/storage/emulated/0/Documents").is_dir()
                    && fs::create_dir_all(&default_docs).is_ok()
                {
                    default_docs
                } else {
                    home.join(".gemini/peakcut-data")
                }
            });

        let state_dir = home.join(".gemini/peakcut");
        let _ = fs::create_dir_all(&data_dir);
        let _ = fs::create_dir_all(&state_dir);

        let pid_file = state_dir.join("studio.pid");
        let log_file = state_dir.join("studio.log");
        let sherpa_dir = prefix.join("opt/sherpa-onnx");
        let tmp_dir = prefix.join("tmp");
        let _ = fs::create_dir_all(&tmp_dir);

        let port = env::var("PEAKCUT_PORT")
            .ok()
            .and_then(|v| v.parse::<u16>().ok())
            .unwrap_or(DEFAULT_PORT);

        Self {
            home,
            prefix,
            plugin_dir,
            engine_dir,
            data_dir,
            pid_file,
            log_file,
            sherpa_dir,
            tmp_dir,
            port,
        }
    }

    fn build_path_env(&self) -> String {
        let p_bin = self.prefix.join("bin");
        let s_bin = self.sherpa_dir.join("bin");
        let r_bin = self.home.join("runtime/bin");
        let cur = env::var("PATH").unwrap_or_else(|_| "/system/bin".into());
        format!("{}:{}:{}:{}", p_bin.display(), s_bin.display(), r_bin.display(), cur)
    }

    fn apply_bionic_env(&self, cmd: &mut Command) {
        cmd.env("HOME", &self.home);
        cmd.env("PREFIX", &self.prefix);
        cmd.env("TMPDIR", &self.tmp_dir);
        cmd.env("PATH", self.build_path_env());
        cmd.env("PEAKCUT_DATA", &self.data_dir);
        cmd.env("PEAKCUT_HOST", "127.0.0.1");
        cmd.env("PEAKCUT_PORT", self.port.to_string());
        cmd.env("PEAKCUT_UPDATE_CHECK", "0");
        cmd.env("PEAKCUT_FETCH_MODEL", "0");
        cmd.env("PYTHONUNBUFFERED", "1");
        cmd.env("GIT_CONFIG_NOSYSTEM", "1");
        cmd.env("GODEBUG", "netdns=cgo");

        let cert = self.prefix.join("etc/tls/cert.pem");
        if cert.is_file() {
            cmd.env("SSL_CERT_FILE", &cert);
            cmd.env("CURL_CA_BUNDLE", &cert);
            cmd.env("REQUESTS_CA_BUNDLE", &cert);
        }

        let mut ld_parts = Vec::new();
        if self.sherpa_dir.join("lib").is_dir() {
            ld_parts.push(self.sherpa_dir.join("lib").to_string_lossy().to_string());
        }
        if self.prefix.join("lib").is_dir() {
            ld_parts.push(self.prefix.join("lib").to_string_lossy().to_string());
        }
        if let Ok(existing) = env::var("LD_LIBRARY_PATH") {
            if !existing.is_empty() {
                ld_parts.push(existing);
            }
        }
        if !ld_parts.is_empty() {
            cmd.env("LD_LIBRARY_PATH", ld_parts.join(":"));
        }
    }

    fn which(&self, bin_name: &str) -> Option<PathBuf> {
        for dir in self.build_path_env().split(':') {
            if dir.is_empty() {
                continue;
            }
            let cand = Path::new(dir).join(bin_name);
            if cand.is_file() {
                return Some(cand);
            }
        }
        None
    }

    fn ensure_cli_wrapper(&self) {
        let bin_dir = self.prefix.join("bin");
        let _ = fs::create_dir_all(&bin_dir);
        let wrapper = bin_dir.join("peakcut");
        let mcp_bin = self.plugin_dir.join("mcp/bin/peakcut-mcp");
        if !wrapper.exists() && mcp_bin.is_file() {
            let script = format!(
                "#!/system/bin/sh\nexport HOME=\"{}\"\nexport PREFIX=\"{}\"\nexec \"{}\" \"$@\"\n",
                self.home.display(),
                self.prefix.display(),
                mcp_bin.display()
            );
            if fs::write(&wrapper, script).is_ok() {
                #[cfg(unix)]
                {
                    use std::os::unix::fs::PermissionsExt;
                    let _ = fs::set_permissions(&wrapper, fs::Permissions::from_mode(0o755));
                }
            }
        }
    }
}

fn run_cmd(paths: &EnvPaths, prog: &Path, args: &[&str], cwd: Option<&Path>) -> (i32, String, String) {
    let mut cmd = Command::new(prog);
    paths.apply_bionic_env(&mut cmd);
    cmd.args(args);
    if let Some(d) = cwd {
        cmd.current_dir(d);
    }
    match cmd.output() {
        Ok(out) => (
            out.status.code().unwrap_or(-1),
            String::from_utf8_lossy(&out.stdout).to_string(),
            String::from_utf8_lossy(&out.stderr).to_string(),
        ),
        Err(e) => (-1, String::new(), e.to_string()),
    }
}

// ---------------------------------------------------------------------------
// Local HTTP/1.1 Client for PeakCut FastAPI Studio (127.0.0.1:8765)
// ---------------------------------------------------------------------------

fn decode_chunked(raw: &[u8]) -> Vec<u8> {
    let mut out = Vec::new();
    let mut pos = 0usize;
    while pos < raw.len() {
        let line_end = match raw[pos..].windows(2).position(|w| w == b"\r\n") {
            Some(idx) => pos + idx,
            None => break,
        };
        let sz_str = String::from_utf8_lossy(&raw[pos..line_end]);
        let sz_hex = sz_str.split(';').next().unwrap_or("").trim();
        let chunk_len = match usize::from_str_radix(sz_hex, 16) {
            Ok(n) => n,
            Err(_) => break,
        };
        pos = line_end + 2;
        if chunk_len == 0 {
            break;
        }
        if pos + chunk_len <= raw.len() {
            out.extend_from_slice(&raw[pos..pos + chunk_len]);
        } else {
            out.extend_from_slice(&raw[pos..]);
            break;
        }
        pos += chunk_len + 2;
    }
    out
}

fn http_request(
    port: u16,
    method: &str,
    path: &str,
    body: Option<&JsonVal>,
    timeout_secs: u64,
) -> Result<(u16, String), String> {
    let addr = format!("127.0.0.1:{}", port);
    let sock_addr = addr.parse().map_err(|e: std::net::AddrParseError| e.to_string())?;
    let mut stream = TcpStream::connect_timeout(&sock_addr, Duration::from_millis(800))
        .map_err(|e| format!("Studio server not reachable on {}: {}", addr, e))?;
    let _ = stream.set_read_timeout(Some(Duration::from_secs(timeout_secs)));
    let _ = stream.set_write_timeout(Some(Duration::from_secs(10)));

    let body_str = body.map(|b| b.to_json_string()).unwrap_or_default();
    let mut req = format!(
        "{} {} HTTP/1.1\r\nHost: 127.0.0.1:{}\r\nOrigin: http://127.0.0.1:{}\r\nReferer: http://127.0.0.1:{}/app\r\nAccept: application/json\r\nConnection: close\r\n",
        method, path, port, port, port
    );
    if body.is_some() {
        req.push_str("Content-Type: application/json\r\n");
        req.push_str(&format!("Content-Length: {}\r\n", body_str.len()));
    } else if method == "POST" || method == "PUT" {
        req.push_str("Content-Length: 0\r\n");
    }
    req.push_str("\r\n");
    if body.is_some() {
        req.push_str(&body_str);
    }

    stream.write_all(req.as_bytes()).map_err(|e| e.to_string())?;
    let mut buf = Vec::new();
    stream.read_to_end(&mut buf).map_err(|e| e.to_string())?;

    let hdr_end = buf
        .windows(4)
        .position(|w| w == b"\r\n\r\n")
        .ok_or_else(|| "Malformed HTTP response".to_string())?;
    let hdr_txt = String::from_utf8_lossy(&buf[..hdr_end]).to_string();
    let first_line = hdr_txt.lines().next().unwrap_or("");
    let status: u16 = first_line
        .split_whitespace()
        .nth(1)
        .and_then(|s| s.parse().ok())
        .unwrap_or(500);

    let is_chunked = hdr_txt.to_ascii_lowercase().contains("transfer-encoding: chunked");
    let raw_body = &buf[hdr_end + 4..];
    let decoded = if is_chunked {
        decode_chunked(raw_body)
    } else {
        raw_body.to_vec()
    };
    Ok((status, String::from_utf8_lossy(&decoded).to_string()))
}

fn studio_healthy(paths: &EnvPaths) -> bool {
    match http_request(paths.port, "GET", "/healthz", None, 3) {
        Ok((code, _)) => code == 200,
        Err(_) => false,
    }
}

fn ensure_python_studio_deps(paths: &EnvPaths, py: &Path) -> Result<(), String> {
    let (code, _, _) = run_cmd(
        paths,
        py,
        &["-c", "import starlette, uvicorn, httpx, sqlalchemy, multipart"],
        None,
    );
    if code != 0 {
        let (ic, out, err) = run_cmd(
            paths,
            py,
            &[
                "-m",
                "pip",
                "install",
                "starlette",
                "uvicorn",
                "httpx",
                "sqlalchemy",
                "python-multipart",
            ],
            None,
        );
        if ic != 0 {
            return Err(format!("Failed installing Starlette/Uvicorn studio dependencies:\n{}\n{}", out, err));
        }
        if let Some(fixer) = paths.which("agy-fix-paths") {
            let _ = run_cmd(paths, &fixer, &[], None);
        }
    }
    Ok(())
}

fn start_studio_daemon(paths: &EnvPaths) -> Result<u32, String> {
    if studio_healthy(paths) {
        let pid = fs::read_to_string(&paths.pid_file)
            .ok()
            .and_then(|s| s.trim().parse::<u32>().ok())
            .unwrap_or(0);
        return Ok(pid);
    }

    let py = paths
        .which("python3")
        .ok_or_else(|| "python3 not found on PATH".to_string())?;
    ensure_python_studio_deps(paths, &py)?;

    let log_f = fs::OpenOptions::new()
        .create(true)
        .append(true)
        .open(&paths.log_file)
        .map_err(|e| e.to_string())?;
    let log_err = log_f.try_clone().map_err(|e| e.to_string())?;

    let mut cmd = Command::new(&py);
    paths.apply_bionic_env(&mut cmd);
    cmd.current_dir(&paths.engine_dir);
    cmd.args(["-m", "studio.server"]);
    cmd.stdin(Stdio::null());
    cmd.stdout(Stdio::from(log_f));
    cmd.stderr(Stdio::from(log_err));
    #[cfg(unix)]
    {
        use std::os::unix::process::CommandExt;
        cmd.process_group(0);
    }

    let child = cmd.spawn().map_err(|e| format!("Failed spawning studio.server: {}", e))?;
    let pid = child.id();
    let _ = fs::write(&paths.pid_file, pid.to_string());

    for _ in 0..30 {
        thread::sleep(Duration::from_millis(300));
        if studio_healthy(paths) {
            return Ok(pid);
        }
    }

    let tail_log = fs::read_to_string(&paths.log_file)
        .unwrap_or_default()
        .lines()
        .rev()
        .take(20)
        .collect::<Vec<_>>()
        .into_iter()
        .rev()
        .collect::<Vec<_>>()
        .join("\n");
    Err(format!(
        "PeakCut Studio did not become healthy on 127.0.0.1:{} within 9s.\nLog tail:\n{}",
        paths.port, tail_log
    ))
}

fn stop_studio_daemon(paths: &EnvPaths) -> bool {
    let mut stopped = false;
    if let Ok(raw) = fs::read_to_string(&paths.pid_file) {
        if let Ok(pid) = raw.trim().parse::<u32>() {
            if let Some(kill_bin) = paths.which("kill") {
                let _ = run_cmd(paths, &kill_bin, &[&pid.to_string()], None);
                stopped = true;
            }
        }
        let _ = fs::remove_file(&paths.pid_file);
    }
    stopped
}

fn api_json(
    paths: &EnvPaths,
    method: &str,
    route: &str,
    body: Option<&JsonVal>,
    timeout_secs: u64,
) -> Result<JsonVal, String> {
    let _ = start_studio_daemon(paths)?;
    let (status, txt) = http_request(paths.port, method, route, body, timeout_secs)?;
    if (200..300).contains(&status) {
        parse_json(&txt).or_else(|_| {
            let mut w = JsonVal::obj();
            w.insert("raw", s(&txt));
            Ok(w)
        })
    } else {
        if let Ok(err_json) = parse_json(&txt) {
            if let Some(det) = err_json.get_str("detail") {
                return Err(format!("HTTP {}: {}", status, det));
            }
        }
        Err(format!("HTTP {}: {}", status, txt.trim()))
    }
}

fn url_encode(input: &str) -> String {
    let mut out = String::new();
    for b in input.bytes() {
        if b.is_ascii_alphanumeric() || matches!(b, b'-' | b'_' | b'.' | b'~') {
            out.push(b as char);
        } else {
            out.push_str(&format!("%{:02X}", b));
        }
    }
    out
}

// ---------------------------------------------------------------------------
// 12 Native ARM64 Rust MCP Tools
// ---------------------------------------------------------------------------

fn check_py_mod(paths: &EnvPaths, py: &Path, m: &str) -> bool {
    let (code, _, _) = run_cmd(paths, py, &["-c", &format!("import {}", m)], None);
    code == 0
}

fn tool_status(paths: &EnvPaths) -> Result<JsonVal, String> {
    paths.ensure_cli_wrapper();
    let py = paths.which("python3");
    let mut py_mods = JsonVal::obj();
    for m in ["starlette", "uvicorn", "httpx", "sqlalchemy", "PIL", "numpy", "yt_dlp", "cv2"] {
        let ok = py.as_ref().map(|p| check_py_mod(paths, p, m)).unwrap_or(false);
        py_mods.insert(m, JsonVal::Bool(ok));
    }

    let sherpa_ready = paths.sherpa_dir.join("bin/sherpa-onnx-offline").is_file();
    let ffmpeg_ready = paths.which("ffmpeg").is_some();
    let mut mediacodec_gpu = false;
    if let Some(ff) = paths.which("ffmpeg") {
        let (_, out, _) = run_cmd(paths, &ff, &["-hide_banner", "-encoders"], None);
        mediacodec_gpu = out.contains("h264_mediacodec");
    }

    let running = studio_healthy(paths);
    let mut speech = JsonVal::Null;
    let mut ai_state = JsonVal::Null;
    if running {
        if let Ok(sp) = api_json(paths, "GET", "/api/speech", None, 5) {
            speech = sp;
        }
        if let Ok(ai) = api_json(paths, "GET", "/api/ai", None, 5) {
            ai_state = ai;
        }
    }

    let mut out = JsonVal::obj();
    out.insert("ok", JsonVal::Bool(true));
    out.insert("server", s(SERVER_NAME));
    out.insert("version", s(SERVER_VERSION));
    out.insert("studio_running", JsonVal::Bool(running));
    out.insert("studio_url", s(&format!("http://127.0.0.1:{}/app", paths.port)));
    out.insert("data_dir", s(&paths.data_dir.to_string_lossy()));
    out.insert("engine_ready", JsonVal::Bool(paths.engine_dir.join("studio/server.py").is_file()));
    out.insert("sherpa_onnx_bionic_ready", JsonVal::Bool(sherpa_ready));
    out.insert("ffmpeg_ready", JsonVal::Bool(ffmpeg_ready));
    out.insert("gpu_h264_mediacodec", JsonVal::Bool(mediacodec_gpu));
    out.insert("yt_dlp_ready", JsonVal::Bool(paths.which("yt-dlp").is_some()));
    out.insert("node_js_solver_ready", JsonVal::Bool(paths.which("node").is_some()));
    out.insert("rish_ready", JsonVal::Bool(paths.which("rish").is_some()));
    out.insert("python_modules", py_mods);
    out.insert("ai_config", ai_state);
    out.insert("speech_models", speech);
    Ok(out)
}

fn tool_setup(paths: &EnvPaths, args: &JsonVal) -> Result<JsonVal, String> {
    paths.ensure_cli_wrapper();
    let install_opencv = args.get_bool("install_opencv").unwrap_or(false);
    let download_lang = args.get_str("download_lang").unwrap_or("").trim();

    let py = paths
        .which("python3")
        .ok_or_else(|| "python3 not found. Run: pkg update && pkg install python ffmpeg".to_string())?;

    ensure_python_studio_deps(paths, &py)?;

    // Install native Android Bionic sherpa-onnx v2.0.2 if missing
    if !paths.sherpa_dir.join("bin/sherpa-onnx-offline").is_file() {
        let _ = fs::create_dir_all(&paths.sherpa_dir);
        let sh = Path::new("/system/bin/sh");
        let cmd_str = format!(
            "curl -fsSL \"{}\" | tar -xj -C \"{}\" --strip-components=1 && chmod -R 0755 \"{}/bin\"",
            SHERPA_ANDROID_URL,
            paths.sherpa_dir.display(),
            paths.sherpa_dir.display()
        );
        let (sc, _, serr) = run_cmd(paths, sh, &["-c", &cmd_str], None);
        if sc != 0 {
            return Err(format!("Failed downloading Android ARM64 sherpa-onnx runtime: {}", serr));
        }
    }

    if install_opencv && !check_py_mod(paths, &py, "cv2") {
        if let Some(pkg_bin) = paths.which("pkg") {
            let _ = run_cmd(paths, &pkg_bin, &["install", "python-opencv-python"], None);
        }
    }

    let pid = start_studio_daemon(paths)?;

    let mut speech_dl = JsonVal::Null;
    if !download_lang.is_empty() {
        speech_dl = api_json(
            paths,
            "POST",
            &format!("/api/speech/{}", url_encode(download_lang)),
            Some(&JsonVal::obj()),
            15,
        )?;
    }

    let mut out = JsonVal::obj();
    out.insert("ok", JsonVal::Bool(true));
    out.insert("studio_pid", n_i64(pid as i64));
    out.insert("speech_download_triggered", speech_dl);
    out.insert("status", tool_status(paths)?);
    Ok(out)
}

fn tool_studio_server(paths: &EnvPaths, args: &JsonVal) -> Result<JsonVal, String> {
    let action = args.get_str("action").unwrap_or("status").trim();
    let url = format!("http://127.0.0.1:{}/app", paths.port);

    match action {
        "stop" => {
            let stopped = stop_studio_daemon(paths);
            let mut out = JsonVal::obj();
            out.insert("ok", JsonVal::Bool(true));
            out.insert("stopped", JsonVal::Bool(stopped));
            Ok(out)
        }
        "start" | "open" => {
            let pid = start_studio_daemon(paths)?;
            if action == "open" {
                if let Some(xdg) = paths.which("xdg-open") {
                    let _ = run_cmd(paths, &xdg, &[&url], None);
                }
            }
            let mut out = JsonVal::obj();
            out.insert("ok", JsonVal::Bool(true));
            out.insert("running", JsonVal::Bool(true));
            out.insert("pid", n_i64(pid as i64));
            out.insert("url", s(&url));
            out.insert("opened_browser", JsonVal::Bool(action == "open"));
            Ok(out)
        }
        _ => {
            let alive = studio_healthy(paths);
            let mut out = JsonVal::obj();
            out.insert("ok", JsonVal::Bool(true));
            out.insert("running", JsonVal::Bool(alive));
            out.insert("url", s(&url));
            Ok(out)
        }
    }
}

fn tool_ai_configure(paths: &EnvPaths, args: &JsonVal) -> Result<JsonVal, String> {
    let provider = args.get_str("provider").unwrap_or("").trim();
    if provider.is_empty() {
        return api_json(paths, "GET", "/api/ai", None, 10);
    }
    let mut body = JsonVal::obj();
    body.insert("provider", s(provider));
    if let Some(arr) = args.get("models").and_then(|v| v.as_arr()) {
        body.insert("models", JsonVal::Arr(arr.clone()));
    } else if let Some(mstr) = args.get_str("model") {
        let models: Vec<JsonVal> = mstr
            .split(',')
            .map(|x| x.trim())
            .filter(|x| !x.is_empty())
            .map(s)
            .collect();
        body.insert("models", JsonVal::Arr(models));
    }
    if let Some(bu) = args.get_str("base_url") {
        body.insert("base_url", s(bu));
    }
    if let Some(k) = args.get_str("api_key") {
        body.insert("key", s(k));
    }

    let saved = api_json(paths, "PUT", "/api/ai", Some(&body), 15)?;
    let test_conn = args.get_bool("test_connection").unwrap_or(true);
    let mut test_res = JsonVal::Null;
    if test_conn {
        match api_json(paths, "POST", "/api/ai/test", None, 25) {
            Ok(tr) => test_res = tr,
            Err(e) => {
                let mut er = JsonVal::obj();
                er.insert("ok", JsonVal::Bool(false));
                er.insert("error", s(&e));
                test_res = er;
            }
        }
    }

    let mut out = JsonVal::obj();
    out.insert("ok", JsonVal::Bool(true));
    out.insert("saved", saved);
    out.insert("connection_test", test_res);
    Ok(out)
}

fn tool_speech_models(paths: &EnvPaths, args: &JsonVal) -> Result<JsonVal, String> {
    let action = args.get_str("action").unwrap_or("list").trim();
    let lang = args.get_str("lang").unwrap_or("es").trim();
    match action {
        "download" => api_json(
            paths,
            "POST",
            &format!("/api/speech/{}", url_encode(lang)),
            Some(&JsonVal::obj()),
            15,
        ),
        "remove" => api_json(
            paths,
            "DELETE",
            &format!("/api/speech/{}", url_encode(lang)),
            None,
            15,
        ),
        _ => api_json(paths, "GET", "/api/speech", None, 10),
    }
}

fn build_clip_options(args: &JsonVal) -> JsonVal {
    let mut opts = JsonVal::obj();
    if let Some(lang) = args.get_str("lang") {
        opts.insert("lang", s(lang));
    }
    if let Some(layout) = args.get_str("layout") {
        opts.insert("layout", s(layout));
    } else {
        opts.insert("layout", s("auto_face"));
    }
    if let Some(style) = args.get_str("style") {
        opts.insert("style", s(style));
    }
    if let Some(mc) = args.get_i64("max_clips") {
        opts.insert("max_clips", n_i64(mc));
    }
    if let Some(mn) = args.get_i64("min_len") {
        opts.insert("min_len", n_i64(mn));
    }
    if let Some(mx) = args.get_i64("max_len") {
        opts.insert("max_len", n_i64(mx));
    }
    if let Some(rs) = args.get_f64("range_start") {
        opts.insert("range_start", JsonVal::Num(rs));
    }
    if let Some(re) = args.get_f64("range_end") {
        opts.insert("range_end", JsonVal::Num(re));
    }
    if let Some(ht) = args.get_str("hook_text") {
        opts.insert("hook_text", s(ht));
    }
    opts
}

fn tool_clip_vod(paths: &EnvPaths, args: &JsonVal) -> Result<JsonVal, String> {
    let target = args.get_str("url_or_path").unwrap_or("").trim();
    if target.is_empty() {
        return Err("Provide 'url_or_path' (YouTube/Twitch/Kick video URL or local Android video file path).".into());
    }
    let opts = build_clip_options(args);
    let mut body = JsonVal::obj();
    body.insert("options", opts);
    if let Some(cr) = args.get_str("creator_id").filter(|v| !v.is_empty()) {
        body.insert("creator", s(cr));
    }

    if target.starts_with("http://") || target.starts_with("https://") {
        body.insert("url", s(target));
        api_json(paths, "POST", "/api/jobs", Some(&body), 30)
    } else {
        body.insert("path", s(target));
        api_json(paths, "POST", "/api/jobs/local", Some(&body), 30)
    }
}

fn derive_creator_name(url: &str) -> String {
    let clean = url
        .trim_end_matches('/')
        .trim_end_matches("/live")
        .rsplit('/')
        .next()
        .unwrap_or("Streamer")
        .trim_start_matches('@');
    if clean.is_empty() {
        "LiveStreamer".into()
    } else {
        clean.to_string()
    }
}

fn detect_platform(url: &str) -> &'static str {
    let low = url.to_ascii_lowercase();
    if low.contains("twitch.tv") {
        "twitch"
    } else if low.contains("kick.com") {
        "kick"
    } else {
        "youtube"
    }
}

fn tool_live_monitor(paths: &EnvPaths, args: &JsonVal) -> Result<JsonVal, String> {
    let action = args.get_str("action").unwrap_or("list").trim();

    if action == "list" {
        let jobs = api_json(paths, "GET", "/api/jobs", None, 10)?;
        let mut live_jobs = Vec::new();
        if let Some(arr) = jobs.as_arr() {
            for j in arr {
                if j.get_str("kind") == Some("live") {
                    live_jobs.push(j.clone());
                }
            }
        }
        let mut out = JsonVal::obj();
        out.insert("ok", JsonVal::Bool(true));
        out.insert("count", n_i64(live_jobs.len() as i64));
        out.insert("live_sessions", JsonVal::Arr(live_jobs));
        return Ok(out);
    }

    if action == "stop" {
        let jid = args
            .get_str("job_id")
            .unwrap_or("")
            .trim();
        if jid.is_empty() {
            return Err("Provide 'job_id' of the active live session to stop.".into());
        }
        return api_json(paths, "POST", &format!("/api/live/{}/stop", url_encode(jid)), None, 15);
    }

    // action == "start"
    let channel_url = args.get_str("channel_url").unwrap_or("").trim();
    if channel_url.is_empty() {
        return Err("Provide 'channel_url' (e.g. 'https://kick.com/westcol', 'https://twitch.tv/ibai', 'https://youtube.com/@channel/live').".into());
    }

    let creators = api_json(paths, "GET", "/api/creators", None, 15)?;
    let mut matched_cid: Option<String> = None;
    if let Some(carr) = creators.as_arr() {
        for c in carr {
            if c.get_str("channel")
                .map(|u| u.eq_ignore_ascii_case(channel_url))
                .unwrap_or(false)
            {
                matched_cid = c.get_str("id").map(|s| s.to_string());
                break;
            }
        }
    }

    let lang = args.get_str("lang").unwrap_or("es");
    let layout = args.get_str("layout").unwrap_or("auto_face");
    let style = args.get_str("style").unwrap_or("hype");
    let pkey = detect_platform(channel_url);

    let cid = if let Some(existing) = matched_cid {
        let mut upd = JsonVal::obj();
        upd.insert("lang", s(lang));
        upd.insert("layout", s(layout));
        upd.insert("style", s(style));
        if let Some(r) = args.get_f64("rate_per_1k") {
            upd.insert("rate_per_1k", JsonVal::Num(r));
        }
        let _ = api_json(paths, "PUT", &format!("/api/creators/{}", url_encode(&existing)), Some(&upd), 15);
        existing
    } else {
        let cname = args
            .get_str("creator_name")
            .filter(|v| !v.trim().is_empty())
            .map(|v| v.trim().to_string())
            .unwrap_or_else(|| derive_creator_name(channel_url));
        let mut ch_map = JsonVal::obj();
        ch_map.insert(pkey, s(channel_url));

        let mut cbody = JsonVal::obj();
        cbody.insert("name", s(&cname));
        cbody.insert("channel", s(channel_url));
        cbody.insert("channels", ch_map);
        cbody.insert("lang", s(lang));
        cbody.insert("layout", s(layout));
        cbody.insert("style", s(style));
        if let Some(g) = args.get_str("game") {
            cbody.insert("game", s(g));
        }
        if let Some(r) = args.get_f64("rate_per_1k") {
            cbody.insert("rate_per_1k", JsonVal::Num(r));
        }
        let created = api_json(paths, "POST", "/api/creators", Some(&cbody), 20)?;
        created
            .get_str("id")
            .ok_or_else(|| "Failed creating creator workspace".to_string())?
            .to_string()
    };

    let mut lbody = JsonVal::obj();
    lbody.insert("channel", s(channel_url));
    api_json(
        paths,
        "POST",
        &format!("/api/creators/{}/live", url_encode(&cid)),
        Some(&lbody),
        35,
    )
}

fn tool_live_clip_now(paths: &EnvPaths, args: &JsonVal) -> Result<JsonVal, String> {
    let seconds = args.get_f64("seconds").unwrap_or(45.0).clamp(5.0, 180.0);
    let mut jid = args.get_str("job_id").unwrap_or("").trim().to_string();

    if jid.is_empty() {
        let jobs = api_json(paths, "GET", "/api/jobs", None, 10)?;
        if let Some(arr) = jobs.as_arr() {
            for j in arr {
                if j.get_str("kind") == Some("live") && j.get_str("status") == Some("running") {
                    if let Some(id_s) = j.get_str("id") {
                        jid = id_s.to_string();
                        break;
                    }
                }
            }
        }
    }
    if jid.is_empty() {
        return Err("No active running live stream found. Start one first with peakcut_live_monitor(action='start').".into());
    }

    let mut body = JsonVal::obj();
    body.insert("seconds", JsonVal::Num(seconds));
    let mut res = api_json(
        paths,
        "POST",
        &format!("/api/live/{}/clip", url_encode(&jid)),
        Some(&body),
        15,
    )?;
    res.insert("job_id", s(&jid));
    res.insert("clipped_last_seconds", JsonVal::Num(seconds));
    Ok(res)
}

fn resolve_clip_disk_path(paths: &EnvPaths, jid: &str, file_name: &str) -> Option<PathBuf> {
    let users_dir = paths.data_dir.join("users");
    if let Ok(urd) = fs::read_dir(&users_dir) {
        for u in urd.flatten() {
            let direct = u.path().join("jobs").join(jid).join("clips").join(file_name);
            if direct.is_file() {
                return Some(direct);
            }
            if let Ok(crd) = fs::read_dir(u.path().join("creators")) {
                for c in crd.flatten() {
                    for sub in ["videos", "live"] {
                        let cand = c.path().join(sub).join(jid).join("clips").join(file_name);
                        if cand.is_file() {
                            return Some(cand);
                        }
                    }
                }
            }
        }
    }
    None
}

fn enrich_job_paths(paths: &EnvPaths, mut job: JsonVal) -> JsonVal {
    let jid = job.get_str("id").unwrap_or("").to_string();
    if !jid.is_empty() {
        if let Some(JsonVal::Arr(clips)) = job.get("clips").cloned() {
            let mut enriched = Vec::new();
            for mut c in clips {
                if let Some(fname) = c.get_str("file").map(|x| x.to_string()) {
                    if let Some(dp) = resolve_clip_disk_path(paths, &jid, &fname) {
                        c.insert("disk_path", s(&dp.to_string_lossy()));
                    }
                }
                enriched.push(c);
            }
            job.insert("clips", JsonVal::Arr(enriched));
        }
    }
    job
}

fn tool_jobs_list(paths: &EnvPaths, args: &JsonVal) -> Result<JsonVal, String> {
    if let Some(jid) = args.get_str("job_id").filter(|v| !v.trim().is_empty()) {
        let j = api_json(paths, "GET", &format!("/api/jobs/{}", url_encode(jid.trim())), None, 10)?;
        return Ok(enrich_job_paths(paths, j));
    }
    let jobs = api_json(paths, "GET", "/api/jobs", None, 10)?;
    let mut arr = Vec::new();
    if let Some(items) = jobs.as_arr() {
        for item in items {
            arr.push(enrich_job_paths(paths, item.clone()));
        }
    }
    let mut out = JsonVal::obj();
    out.insert("ok", JsonVal::Bool(true));
    out.insert("count", n_i64(arr.len() as i64));
    out.insert("jobs", JsonVal::Arr(arr));
    Ok(out)
}

fn tool_clip_rerender(paths: &EnvPaths, args: &JsonVal) -> Result<JsonVal, String> {
    let jid = args.get_str("job_id").unwrap_or("").trim();
    let cid = args.get_str("clip_id").unwrap_or("").trim();
    if jid.is_empty() || cid.is_empty() {
        return Err("Both 'job_id' and 'clip_id' are required.".into());
    }
    let mut body = JsonVal::obj();
    for k in ["layout", "style", "hook", "title", "description"] {
        if let Some(v) = args.get_str(k) {
            body.insert(k, s(v));
        }
    }
    if let Some(st) = args.get_f64("start") {
        body.insert("start", JsonVal::Num(st));
    }
    if let Some(en) = args.get_f64("end") {
        body.insert("end", JsonVal::Num(en));
    }
    if let Some(tags) = args.get("hashtags").and_then(|v| v.as_arr()) {
        body.insert("hashtags", JsonVal::Arr(tags.clone()));
    }

    let j = api_json(
        paths,
        "POST",
        &format!("/api/jobs/{}/clips/{}/render", url_encode(jid), url_encode(cid)),
        Some(&body),
        20,
    )?;
    Ok(enrich_job_paths(paths, j))
}

fn sanitize_filename(raw: &str) -> String {
    let mut out = String::new();
    for ch in raw.chars() {
        if ch.is_ascii_alphanumeric() {
            out.push(ch.to_ascii_lowercase());
        } else if (ch == ' ' || ch == '-' || ch == '_') && !out.ends_with('_') && !out.is_empty() {
            out.push('_');
        }
    }
    let trimmed = out.trim_matches('_');
    if trimmed.is_empty() {
        "clip".into()
    } else {
        trimmed.chars().take(42).collect()
    }
}

fn tool_export_gallery(paths: &EnvPaths, args: &JsonVal) -> Result<JsonVal, String> {
    let jid = args.get_str("job_id").unwrap_or("").trim();
    if jid.is_empty() {
        return Err("Provide 'job_id' to export finished clips to Android Gallery.".into());
    }
    let filter_cid = args.get_str("clip_id").unwrap_or("").trim();
    let job = api_json(paths, "GET", &format!("/api/jobs/{}", url_encode(jid)), None, 10)?;

    let gallery_dir = PathBuf::from("/storage/emulated/0/Movies/PeakCut");
    fs::create_dir_all(&gallery_dir)
        .map_err(|e| format!("Cannot create {}: {}", gallery_dir.display(), e))?;

    let mut exported = Vec::new();
    if let Some(clips) = job.get("clips").and_then(|v| v.as_arr()) {
        for c in clips {
            let cid = c.get_str("id").unwrap_or("");
            if !filter_cid.is_empty() && cid != filter_cid {
                continue;
            }
            if c.get_str("status") != Some("done") {
                continue;
            }
            let fname = match c.get_str("file") {
                Some(f) if !f.is_empty() => f,
                _ => continue,
            };
            if let Some(src_mp4) = resolve_clip_disk_path(paths, jid, fname) {
                let slug = sanitize_filename(c.get_str("hook").or_else(|| c.get_str("title")).unwrap_or(cid));
                let dest = gallery_dir.join(format!("peakcut_{}_{}.mp4", cid, slug));
                fs::copy(&src_mp4, &dest).map_err(|e| e.to_string())?;
                if let Some(rish) = paths.which("rish") {
                    let scan_cmd = format!(
                        "am broadcast -a android.intent.action.MEDIA_SCANNER_SCAN_FILE -d \"file://{}\"",
                        dest.display()
                    );
                    let _ = run_cmd(paths, &rish, &["-c", &scan_cmd], None);
                }
                let mut rec = JsonVal::obj();
                rec.insert("clip_id", s(cid));
                rec.insert("gallery_path", s(&dest.to_string_lossy()));
                rec.insert("score", n_i64(c.get_i64("score").unwrap_or(0)));
                rec.insert("title", s(c.get_str("title").unwrap_or("")));
                exported.push(rec);
            }
        }
    }

    let mut out = JsonVal::obj();
    out.insert("ok", JsonVal::Bool(true));
    out.insert("gallery_folder", s(&gallery_dir.to_string_lossy()));
    out.insert("exported_count", n_i64(exported.len() as i64));
    out.insert("exported_clips", JsonVal::Arr(exported));
    Ok(out)
}

fn tool_whop_campaign_prep(paths: &EnvPaths, args: &JsonVal) -> Result<JsonVal, String> {
    let jid = args.get_str("job_id").unwrap_or("").trim();
    let cid = args.get_str("clip_id").unwrap_or("").trim();
    let cpm = args.get_f64("cpm_rate").unwrap_or(1.50);
    let required_tag = args.get_str("required_hashtag").unwrap_or("").trim().trim_start_matches('#');

    if jid.is_empty() || cid.is_empty() {
        return Err("Provide 'job_id' and 'clip_id'.".into());
    }
    let job = api_json(paths, "GET", &format!("/api/jobs/{}", url_encode(jid)), None, 10)?;
    let clip = job
        .get("clips")
        .and_then(|v| v.as_arr())
        .and_then(|arr| arr.iter().find(|c| c.get_str("id") == Some(cid)))
        .ok_or_else(|| format!("Clip '{}' not found in job '{}'", cid, jid))?;

    let start = clip.get_f64("start").unwrap_or(0.0);
    let end = clip.get_f64("end").unwrap_or(0.0);
    let dur = (end - start).max(0.0);
    let mut tags: Vec<String> = clip
        .get("hashtags")
        .and_then(|v| v.as_arr())
        .map(|arr| {
            arr.iter()
                .filter_map(|t| t.as_str())
                .map(|t| format!("#{}", t.trim_start_matches('#')))
                .collect()
        })
        .unwrap_or_default();
    if !required_tag.is_empty() {
        let req_fmt = format!("#{}", required_tag);
        if !tags.iter().any(|t| t.eq_ignore_ascii_case(&req_fmt)) {
            tags.insert(0, req_fmt);
        }
    }

    let title = clip.get_str("title").unwrap_or("");
    let desc = clip.get_str("description").unwrap_or("");
    let caption_ready = format!("{}\n\n{}\n\n{}", title, desc, tags.join(" ")).trim().to_string();

    let mut projections = JsonVal::obj();
    projections.insert("10k_views_usd", JsonVal::Num((10.0 * cpm * 100.0).round() / 100.0));
    projections.insert("50k_views_usd", JsonVal::Num((50.0 * cpm * 100.0).round() / 100.0));
    projections.insert("100k_views_usd", JsonVal::Num((100.0 * cpm * 100.0).round() / 100.0));

    let mut checks = JsonVal::obj();
    checks.insert("resolution_1080x1920_9_16", JsonVal::Bool(true));
    checks.insert("zero_third_party_watermark", JsonVal::Bool(true));
    checks.insert("loudness_normalized_minus_14_lufs", JsonVal::Bool(true));
    checks.insert("duration_15_to_90s", JsonVal::Bool((12.0..=95.0).contains(&dur)));
    checks.insert("layout_used", s(clip.get_str("layout").unwrap_or("auto_face")));

    let mut out = JsonVal::obj();
    out.insert("ok", JsonVal::Bool(true));
    out.insert("clip_id", s(cid));
    out.insert("duration_sec", JsonVal::Num((dur * 10.0).round() / 10.0));
    out.insert("virality_score", n_i64(clip.get_i64("score").unwrap_or(0)));
    out.insert("ready_post_caption", s(&caption_ready));
    out.insert("compliance_checks", checks);
    out.insert("whop_payout_estimates", projections);
    Ok(out)
}

// ---------------------------------------------------------------------------
// MCP Tool Definitions & Dispatcher
// ---------------------------------------------------------------------------

fn build_tools_list() -> JsonVal {
    let tools = vec![
        make_tool(
            "peakcut_status",
            "Inspect PeakCut Pro Android ARM64 status: Studio daemon (:8765), GPU h264_mediacodec encoder, sherpa-onnx Bionic speech engine, OpenCV face tracking, yt-dlp + Node.js solver, AI config, and downloaded speech models (es, en, multi, ar).",
            vec![],
            &[],
        ),
        make_tool(
            "peakcut_setup",
            "One-click Android ARM64 bootstrap: installs FastAPI/Uvicorn/SQLAlchemy studio dependencies, configures native Android Bionic sherpa-onnx v2.0.2, optional OpenCV face tracking, starts the PeakCut Studio server (:8765), and optionally triggers a speech model download (e.g. 'es' 102MB or 'en' 103MB).",
            vec![
                ("download_lang", prop_str_enum("Optional offline speech model to start downloading immediately.", &["es", "en", "multi", "ar"])),
                ("install_opencv", prop_bool("Install python-opencv-python via pkg for Haar neural face detection in auto_face layout (default: false; motion-salience tracking works without it).")),
            ],
            &[],
        ),
        make_tool(
            "peakcut_studio_server",
            "Manage the local PeakCut Pro Web Studio Dashboard on http://127.0.0.1:8765/app (start, stop, status, or 'open' in Android browser via xdg-open).",
            vec![
                ("action", prop_str_enum("Server lifecycle action.", &["status", "start", "stop", "open"])),
            ],
            &["action"],
        ),
        make_tool(
            "peakcut_ai_configure",
            "Configure and test the AI model that scores viral moments and writes hooks/titles (gemini, groq, openai, openrouter, anthropic, xai, ollama, custom). Note: setting groq or openai also unlocks instant 2-second Cloud Whisper ASR before local speech models are downloaded!",
            vec![
                ("provider", prop_str_enum("AI service provider.", &["gemini", "groq", "openai", "openrouter", "anthropic", "xai", "ollama", "custom"])),
                ("model", prop_str("Comma-separated model IDs (e.g. 'gemini-2.5-flash' or 'llama-3.3-70b-versatile').")),
                ("models", prop_arr_str("Optional array of model IDs.")),
                ("api_key", prop_str("API key stored locally in PeakCut's private ai.json.")),
                ("base_url", prop_str("Optional custom OpenAI-compatible base URL.")),
                ("test_connection", prop_bool("Immediately test the AI connection after saving (default: true).")),
            ],
            &[],
        ),
        make_tool(
            "peakcut_speech_models",
            "List, download, or remove 100% offline local NVIDIA NeMo int8 speech-to-text models ('es' Spanish 102MB, 'en' English 103MB, 'multi' 25-language 464MB, 'ar' Arabic 107MB).",
            vec![
                ("action", prop_str_enum("Speech model operation.", &["list", "download", "remove"])),
                ("lang", prop_str_enum("Language code.", &["es", "en", "multi", "ar"])),
            ],
            &["action"],
        ),
        make_tool(
            "peakcut_clip_vod",
            "Submit a YouTube, Twitch, or Kick video URL OR a local Android video file (.mp4/.mkv/.mov/.webm) to automatically detect viral moments, reframe to 9:16 (with auto_face speaker tracking, split-screen, or gameplay+facecam), and burn kinetic word-by-word karaoke captions + hook box.",
            vec![
                ("url_or_path", prop_str("YouTube/Twitch/Kick video URL or absolute local video file path on Android.")),
                ("lang", prop_str_enum("Spoken language in the video (default: 'es' or 'en').", &["es", "en", "multi", "ar"])),
                ("layout", prop_str_enum("9:16 vertical framing mode (default: 'auto_face' active-speaker tracking).", &["auto_face", "split", "gameplay", "blur", "zoom", "crop", "left", "right", "fit"])),
                ("style", prop_str_enum("Kinetic word-by-word caption preset.", &["bounce", "hype", "clean"])),
                ("max_clips", prop_int("Maximum viral clips to generate (1-20, default: 6).")),
                ("min_len", prop_int("Minimum clip length in seconds (default: 15).")),
                ("max_len", prop_int("Maximum clip length in seconds (default: 60).")),
                ("range_start", prop_num("Optional start second in source video.")),
                ("range_end", prop_num("Optional end second in source video.")),
                ("hook_text", prop_str("Optional fixed campaign hook banner text.")),
                ("creator_id", prop_str("Optional creator workspace ID.")),
            ],
            &["url_or_path"],
        ),
        make_tool(
            "peakcut_live_monitor",
            "HOT LIVE CLIPPING ('Clipping en Caliente'): start, list, or stop real-time recording & automatic highlight clipping of a LIVE YouTube, Twitch, or Kick stream while the creator is still broadcasting! Detects audio loudness spikes, live chat bursts, and spoken 'clip that' / 'clipea' triggers.",
            vec![
                ("action", prop_str_enum("Live clipping operation.", &["start", "stop", "list"])),
                ("channel_url", prop_str("Live channel URL for action='start' (e.g. 'https://kick.com/westcol', 'https://twitch.tv/ibai', 'https://youtube.com/@creator/live').")),
                ("creator_name", prop_str("Optional display name for the streamer workspace.")),
                ("lang", prop_str_enum("Spoken language of the live stream (default: 'es').", &["es", "en", "multi", "ar"])),
                ("layout", prop_str_enum("9:16 framing mode for live clips (default: 'auto_face'; use 'gameplay' for game+webcam PiP or 'split' for 2-host streams).", &["auto_face", "gameplay", "split", "blur", "zoom", "crop"])),
                ("style", prop_str_enum("Caption style (default: 'hype').", &["hype", "bounce", "clean"])),
                ("game", prop_str("Optional game title for gaming-aware hooks & hashtags.")),
                ("rate_per_1k", prop_num("Optional Whop/campaign CPM rate in USD per 1,000 views.")),
                ("job_id", prop_str("Live session job_id for action='stop'.")),
            ],
            &["action"],
        ),
        make_tool(
            "peakcut_live_clip_now",
            "Instant 'Clip That!' button for Hot Live Clipping: immediately cuts, transcribes, captions, and renders the last N seconds (default: 45s) of an active live stream without waiting for the next automatic check.",
            vec![
                ("seconds", prop_num("How many seconds back from right now to clip (5-180, default: 45).")),
                ("job_id", prop_str("Optional active live job_id (defaults to the currently running live stream).")),
            ],
            &[],
        ),
        make_tool(
            "peakcut_jobs_list",
            "List all VOD and Live clipping jobs (or inspect one job_id in detail), including progress, virality scores (0-100), hooks, titles, hashtags, and resolved Android .mp4 file paths.",
            vec![
                ("job_id", prop_str("Optional specific job_id to inspect.")),
            ],
            &[],
        ),
        make_tool(
            "peakcut_clip_rerender",
            "Re-render a clip with a different 9:16 layout (auto_face, split, gameplay, blur), caption style (hype, bounce, clean), hook banner, or trimmed start/end timestamps.",
            vec![
                ("job_id", prop_str("Parent job ID.")),
                ("clip_id", prop_str("Clip ID to re-render.")),
                ("layout", prop_str_enum("New 9:16 layout.", &["auto_face", "split", "gameplay", "blur", "zoom", "crop", "left", "right", "fit"])),
                ("style", prop_str_enum("New caption style.", &["bounce", "hype", "clean"])),
                ("hook", prop_str("Updated ALL-CAPS hook banner text.")),
                ("title", prop_str("Updated post title.")),
                ("start", prop_num("Updated start timestamp in seconds.")),
                ("end", prop_num("Updated end timestamp in seconds.")),
            ],
            &["job_id", "clip_id"],
        ),
        make_tool(
            "peakcut_export_gallery",
            "Copy finished 9:16 .mp4 clips from a job into /storage/emulated/0/Movies/PeakCut/ and trigger Android MediaStore indexing so they appear #1 in Recent Gallery ready to upload to TikTok, Shorts, Reels, or Whop.",
            vec![
                ("job_id", prop_str("Job ID whose finished clips should be exported.")),
                ("clip_id", prop_str("Optional single clip_id (exports all 'done' clips in the job if omitted).")),
            ],
            &["job_id"],
        ),
        make_tool(
            "peakcut_whop_campaign_prep",
            "Prepare a finished clip for Whop Content Rewards / Creator Bounties: verifies 1080x1920 9:16 compliance, watermark-free status, -14 LUFS audio, injects required campaign hashtags, and calculates CPM payout projections.",
            vec![
                ("job_id", prop_str("Job ID.")),
                ("clip_id", prop_str("Clip ID.")),
                ("cpm_rate", prop_num("Campaign CPM rate per 1,000 views in USD (default: 1.50).")),
                ("required_hashtag", prop_str("Optional mandatory hashtag required by the campaign brief.")),
            ],
            &["job_id", "clip_id"],
        ),
    ];

    let mut out = JsonVal::obj();
    out.insert("tools", JsonVal::Arr(tools));
    out
}

fn dispatch_tool(paths: &EnvPaths, name: &str, args: &JsonVal) -> Result<JsonVal, String> {
    match name {
        "peakcut_status" => tool_status(paths),
        "peakcut_setup" => tool_setup(paths, args),
        "peakcut_studio_server" => tool_studio_server(paths, args),
        "peakcut_ai_configure" => tool_ai_configure(paths, args),
        "peakcut_speech_models" => tool_speech_models(paths, args),
        "peakcut_clip_vod" => tool_clip_vod(paths, args),
        "peakcut_live_monitor" => tool_live_monitor(paths, args),
        "peakcut_live_clip_now" => tool_live_clip_now(paths, args),
        "peakcut_jobs_list" => tool_jobs_list(paths, args),
        "peakcut_clip_rerender" => tool_clip_rerender(paths, args),
        "peakcut_export_gallery" => tool_export_gallery(paths, args),
        "peakcut_whop_campaign_prep" => tool_whop_campaign_prep(paths, args),
        _ => Err(format!("Unknown tool: {}", name)),
    }
}

// ---------------------------------------------------------------------------
// MCP JSON-RPC 2.0 Framing
// ---------------------------------------------------------------------------

#[derive(Clone, Copy)]
enum Framing {
    Line,
    ContentLength,
}

fn read_rpc_message<R: BufRead>(reader: &mut R) -> io::Result<Option<(String, Framing)>> {
    loop {
        let mut line = String::new();
        let n = reader.read_line(&mut line)?;
        if n == 0 {
            return Ok(None);
        }
        let trimmed = line.trim();
        if trimmed.is_empty() {
            continue;
        }
        if trimmed.starts_with('{') {
            return Ok(Some((trimmed.to_string(), Framing::Line)));
        }
        let lower = trimmed.to_ascii_lowercase();
        if let Some(rest) = lower.strip_prefix("content-length:") {
            let len: usize = rest
                .trim()
                .parse()
                .map_err(|_| io::Error::new(io::ErrorKind::InvalidData, "Bad Content-Length"))?;
            loop {
                let mut hdr = String::new();
                let hn = reader.read_line(&mut hdr)?;
                if hn == 0 || hdr.trim().is_empty() {
                    break;
                }
            }
            let mut buf = vec![0u8; len];
            reader.read_exact(&mut buf)?;
            let body = String::from_utf8_lossy(&buf).to_string();
            return Ok(Some((body, Framing::ContentLength)));
        }
    }
}

fn write_rpc_message<W: Write>(writer: &mut W, payload: &JsonVal, framing: Framing) -> io::Result<()> {
    let serialized = payload.to_json_string();
    match framing {
        Framing::Line => {
            writer.write_all(serialized.as_bytes())?;
            writer.write_all(b"\n")?;
        }
        Framing::ContentLength => {
            let header = format!("Content-Length: {}\r\n\r\n", serialized.len());
            writer.write_all(header.as_bytes())?;
            writer.write_all(serialized.as_bytes())?;
        }
    }
    writer.flush()
}

fn handle_rpc_request(paths: &EnvPaths, req: &JsonVal) -> Option<JsonVal> {
    let method = req.get_str("method").unwrap_or("");
    if method.starts_with("notifications/") {
        return None;
    }
    let id = req.get("id")?.clone();
    let mut resp = JsonVal::obj();
    resp.insert("jsonrpc", s("2.0"));
    resp.insert("id", id);

    match method {
        "initialize" => {
            paths.ensure_cli_wrapper();
            let mut server_info = JsonVal::obj();
            server_info.insert("name", s(SERVER_NAME));
            server_info.insert("version", s(SERVER_VERSION));
            let mut caps = JsonVal::obj();
            caps.insert("tools", JsonVal::obj());
            let proto = req
                .get("params")
                .and_then(|p| p.get_str("protocolVersion"))
                .unwrap_or("2024-11-05");
            let mut result = JsonVal::obj();
            result.insert("protocolVersion", s(proto));
            result.insert("capabilities", caps);
            result.insert("serverInfo", server_info);
            resp.insert("result", result);
        }
        "ping" => {
            resp.insert("result", JsonVal::obj());
        }
        "tools/list" => {
            resp.insert("result", build_tools_list());
        }
        "tools/call" => {
            let params = req.get("params").cloned().unwrap_or_else(JsonVal::obj);
            let tname = params.get_str("name").unwrap_or("");
            let targs = params.get("arguments").cloned().unwrap_or_else(JsonVal::obj);
            match dispatch_tool(paths, tname, &targs) {
                Ok(val) => {
                    let mut citem = JsonVal::obj();
                    citem.insert("type", s("text"));
                    citem.insert("text", s(&val.to_json_string()));
                    let mut result = JsonVal::obj();
                    result.insert("content", JsonVal::Arr(vec![citem]));
                    resp.insert("result", result);
                }
                Err(e) => {
                    let mut err_obj = JsonVal::obj();
                    err_obj.insert("ok", JsonVal::Bool(false));
                    err_obj.insert("error", s(&e));
                    let mut citem = JsonVal::obj();
                    citem.insert("type", s("text"));
                    citem.insert("text", s(&err_obj.to_json_string()));
                    let mut result = JsonVal::obj();
                    result.insert("content", JsonVal::Arr(vec![citem]));
                    result.insert("isError", JsonVal::Bool(true));
                    resp.insert("result", result);
                }
            }
        }
        _ => {
            let mut err = JsonVal::obj();
            err.insert("code", JsonVal::Num(-32601.0));
            err.insert("message", s(&format!("Method not found: {}", method)));
            resp.insert("error", err);
        }
    }
    Some(resp)
}

fn print_cli(res: Result<JsonVal, String>) {
    match res {
        Ok(v) => {
            let _ = writeln!(io::stdout(), "{}", v.to_json_string());
        }
        Err(e) => {
            let mut err = JsonVal::obj();
            err.insert("ok", JsonVal::Bool(false));
            err.insert("error", s(&e));
            let _ = writeln!(io::stderr(), "{}", err.to_json_string());
            std::process::exit(1);
        }
    }
}

fn main() {
    let paths = EnvPaths::resolve();
    let argv: Vec<String> = env::args().collect();
    if argv.len() > 1 {
        match argv[1].as_str() {
            "status" => {
                print_cli(tool_status(&paths));
                return;
            }
            "setup" => {
                let mut a = JsonVal::obj();
                if let Some(l) = argv.get(2) {
                    a.insert("download_lang", s(l));
                }
                print_cli(tool_setup(&paths, &a));
                return;
            }
            "studio" | "dashboard" => {
                let sub = argv.get(2).map(|x| x.as_str()).unwrap_or("open");
                let mut a = JsonVal::obj();
                a.insert("action", s(sub));
                print_cli(tool_studio_server(&paths, &a));
                return;
            }
            "clip" => {
                let mut a = JsonVal::obj();
                if let Some(u) = argv.get(2) {
                    a.insert("url_or_path", s(u));
                }
                if let Some(l) = argv.get(3) {
                    a.insert("lang", s(l));
                }
                print_cli(tool_clip_vod(&paths, &a));
                return;
            }
            "live" => {
                let sub = argv.get(2).map(|x| x.as_str()).unwrap_or("list");
                if sub == "clip-now" {
                    let mut a = JsonVal::obj();
                    if let Some(sec) = argv.get(3).and_then(|v| v.parse::<f64>().ok()) {
                        a.insert("seconds", JsonVal::Num(sec));
                    }
                    print_cli(tool_live_clip_now(&paths, &a));
                    return;
                }
                let mut a = JsonVal::obj();
                a.insert("action", s(sub));
                if let Some(arg3) = argv.get(3) {
                    if sub == "stop" {
                        a.insert("job_id", s(arg3));
                    } else {
                        a.insert("channel_url", s(arg3));
                    }
                }
                print_cli(tool_live_monitor(&paths, &a));
                return;
            }
            "jobs" => {
                let mut a = JsonVal::obj();
                if let Some(j) = argv.get(2) {
                    a.insert("job_id", s(j));
                }
                print_cli(tool_jobs_list(&paths, &a));
                return;
            }
            "export" => {
                let mut a = JsonVal::obj();
                if let Some(j) = argv.get(2) {
                    a.insert("job_id", s(j));
                }
                print_cli(tool_export_gallery(&paths, &a));
                return;
            }
            _ => {
                let _ = writeln!(
                    io::stdout(),
                    "Usage: peakcut [status | setup [es|en|multi] | studio start|stop|open | clip <url_or_file> [es|en] | live start|list|stop|clip-now [arg] | jobs [job_id] | export <job_id>]"
                );
                return;
            }
        }
    }

    let stdin = io::stdin();
    let stdout = io::stdout();
    let mut reader = BufReader::new(stdin.lock());
    let mut writer = stdout.lock();

    while let Ok(Some((raw, framing))) = read_rpc_message(&mut reader) {
        if let Ok(req) = parse_json(&raw) {
            if let Some(resp) = handle_rpc_request(&paths, &req) {
                if write_rpc_message(&mut writer, &resp, framing).is_err() {
                    break;
                }
            }
        }
    }
}
