# PeakCut Pro: Live & AI Clipper Rules (Android ARM64 — Native Rust)

When the `peakcut` plugin is enabled on Antigravity for Android:

1. **Prefer Native `peakcut` Rust MCP Tools for VOD & Hot Live Stream Clipping (`9:16`):**
   - Check `peakcut_status` first; if `studio_running` is false or FastAPI dependencies are missing, call `peakcut_setup` (which configures FastAPI/Uvicorn, native Android Bionic `sherpa-onnx v2.0.2`, and starts `http://127.0.0.1:8765/app`).
   - **Hot Live Clipping ("Clipping en Caliente"):** Use `peakcut_live_monitor` (`action: "start"`, `channel_url`, `lang: "es"` or `"en"`, `layout: "auto_face"` or `"gameplay"`) to record a live **YouTube, Twitch, or Kick** stream into a rolling buffer and automatically clip loudness spikes, chat bursts, and spoken `"clip that"` / `"clipea"` moments while the creator is still live! Use `peakcut_live_clip_now` (`seconds: 45`) whenever the user wants an immediate clip of what just happened.
   - **VOD Clipping:** Use `peakcut_clip_vod` for YouTube/Twitch/Kick VOD links or local `.mp4`/`.mkv` files on Android storage. Default `layout` to `"auto_face"` (active-speaker face tracking in `9:16`), `"split"` (2-person podcast), or `"gameplay"` (game + webcam PiP).

2. **ASR & AI Configuration Best Practices on Mobile:**
   - Configuring `groq` or `openai` via `peakcut_ai_configure` automatically unlocks **2-second Cloud Whisper word-timestamp transcription** (`0 MB` local model needed), while `peakcut_speech_models` (`action: "download"`, `lang: "es"` `102 MB` or `"en"` `103 MB`) enables **100% free offline transcription** via `$PREFIX/opt/sherpa-onnx`. For YouTube VODs, PeakCut also reads YouTube's word-level `json3` captions directly in `<1s`.
   - Always call `peakcut_export_gallery` when clips finish so Android `MediaStore` indexes them `#1` in Gallery (`/storage/emulated/0/Movies/PeakCut/`), and use `peakcut_whop_campaign_prep` when preparing clips for Whop Content Rewards / creator bounties.

3. **Android Sandbox Safety:**
   - Never modify or delete anything inside `/data/user/0/com.agy/files/runtime/bin/`; wrappers live in `$PREFIX/bin/peakcut` and `$PREFIX/opt/sherpa-onnx/`.
