use crate::util::{find_bin, opt_bool, opt_i64, opt_str, req_str, round2};
use serde_json::{json, Value};
use std::path::PathBuf;
use std::process::Command;

fn sanitize_pkg_id(raw: &str) -> String {
    raw.chars()
        .filter(|c| c.is_ascii_alphanumeric() || *c == '_' || *c == '.')
        .collect()
}

pub fn probe_adb_and_unity_packages() -> (bool, Vec<String>) {
    let rish = match find_bin("rish") {
        Some(b) => b,
        None => return (false, Vec::new()),
    };
    let out = match Command::new(rish).args(["-c", "pm list packages -3"]).output() {
        Ok(o) if o.status.success() => o,
        _ => return (false, Vec::new()),
    };
    let txt = String::from_utf8_lossy(&out.stdout);
    let pkgs: Vec<String> = txt
        .lines()
        .filter_map(|l| l.strip_prefix("package:").map(|s| s.trim().to_string()))
        .take(40)
        .collect();
    (true, pkgs)
}

/// Stage APK in `/data/local/tmp`, install via Android `pm`, and optionally launch on screen.
pub fn apk_deploy(args: &Value) -> Result<Value, String> {
    let apk_path = PathBuf::from(req_str(args, "apk_path")?);
    if !apk_path.is_file() {
        return Err(format!("APK file not found: {}", apk_path.display()));
    }
    let pkg_id = sanitize_pkg_id(&opt_str(args, "package_name", ""));
    let launch_after = opt_bool(args, "launch_after_install", true);
    let clear_logs = opt_bool(args, "clear_logcat_before_launch", true);

    let rish = find_bin("rish").ok_or("`rish` not found in PATH — enable AGY ADB Bridge or Shizuku.")?;
    let staged = format!("/data/local/tmp/agy_unity_{}.apk", std::process::id());
    let src_escaped = apk_path.to_string_lossy().replace('\'', "'\\''");

    let log_clear = if clear_logs { "logcat -c 2>/dev/null || true; " } else { "" };
    let uninstall_retry = if !pkg_id.is_empty() {
        format!(
            "out=$(pm install -r -g '{staged}' 2>&1); rc=$?; if echo \"$out\" | grep -q 'UPDATE_INCOMPATIBLE'; then pm uninstall {pkg_id} >/dev/null 2>&1 || true; out=$(pm install -r -g '{staged}' 2>&1); rc=$?; fi; echo \"$out\""
        )
    } else {
        format!("pm install -r -g '{staged}'")
    };

    let mut script = format!(
        "cp '{src_escaped}' '{staged}' && {uninstall_retry}; rm -f '{staged}'; exit $rc"
    );
    if launch_after && !pkg_id.is_empty() {
        script = format!(
            "cp '{src_escaped}' '{staged}' && {uninstall_retry}; rm -f '{staged}'; if [ $rc -eq 0 ]; then {log_clear}monkey -p {pkg_id} -c android.intent.category.LAUNCHER 1 >/dev/null 2>&1 || true; fi; exit $rc"
        );
    }

    let out = Command::new(&rish)
        .args(["-c", &script])
        .output()
        .map_err(|e| e.to_string())?;

    let ok = out.status.success();
    Ok(json!({
        "installed": ok,
        "apk_path": apk_path.to_string_lossy(),
        "package_name": pkg_id,
        "launched": ok && launch_after && !pkg_id.is_empty(),
        "pm_output": format!("{}{}", String::from_utf8_lossy(&out.stdout), String::from_utf8_lossy(&out.stderr)).trim()
    }))
}

/// Live Unity Android Logcat C#/IL2CPP exception filter + Shizuku FPS & PSS RAM profiler.
pub fn live_debug(args: &Value) -> Result<Value, String> {
    let pkg_id = sanitize_pkg_id(&req_str(args, "package_name")?);
    let log_lines = opt_i64(args, "max_log_lines", 120).clamp(20, 500);
    let reset_gfx = opt_bool(args, "reset_gfx_stats", false);
    let rish = find_bin("rish").ok_or("`rish` not found in PATH — enable AGY ADB Bridge or Shizuku.")?;

    let rst = if reset_gfx { " reset" } else { "" };
    let cmd_str = format!(
        "pidof {pkg_id} 2>/dev/null || echo 'NOT_RUNNING'; echo '===GFX==='; dumpsys gfxinfo {pkg_id}{rst} 2>/dev/null; echo '===SF==='; dumpsys SurfaceFlinger 2>/dev/null | grep -iE '{pkg_id}|refresh-rate|FPS min:' | head -n 15; echo '===MEM==='; dumpsys meminfo {pkg_id} 2>/dev/null | grep -E 'TOTAL PSS:|Graphics:|Native Heap:'; echo '===TEMP==='; dumpsys battery 2>/dev/null | grep temperature; echo '===UNITYLOG==='; logcat -d -t {log_lines} -s Unity:V CRASH:V AndroidRuntime:E"
    );

    let out = Command::new(rish)
        .args(["-c", &cmd_str])
        .output()
        .map_err(|e| e.to_string())?;
    if !out.status.success() {
        return Err(format!(
            "Failed querying Android telemetry via rish: {}",
            String::from_utf8_lossy(&out.stderr)
        ));
    }

    let text = String::from_utf8_lossy(&out.stdout);
    let pid_section = text.split("===GFX===").next().unwrap_or("").trim();
    let gfx_section = text
        .split("===GFX===")
        .nth(1)
        .and_then(|s| s.split("===SF===").next())
        .unwrap_or("");
    let sf_section = text
        .split("===SF===")
        .nth(1)
        .and_then(|s| s.split("===MEM===").next())
        .unwrap_or("");
    let mem_section = text
        .split("===MEM===")
        .nth(1)
        .and_then(|s| s.split("===TEMP===").next())
        .unwrap_or("");
    let temp_section = text
        .split("===TEMP===")
        .nth(1)
        .and_then(|s| s.split("===UNITYLOG===").next())
        .unwrap_or("");
    let log_section = text.split("===UNITYLOG===").nth(1).unwrap_or("").trim();

    let total_frames: i64 = after_label(gfx_section, "Total frames rendered:")
        .parse()
        .unwrap_or(0);
    let janky = after_label(gfx_section, "Janky frames:");
    let p50 = parse_ms(gfx_section, "50th percentile:");
    let p90 = parse_ms(gfx_section, "90th percentile:");
    let p95 = parse_ms(gfx_section, "95th percentile:");
    let p99 = parse_ms(gfx_section, "99th percentile:");
    let sf_cur_fps: f64 = sf_section
        .lines()
        .find_map(|l| l.find("cur:").and_then(|i| l[i + 4..].split_whitespace().next()?.parse::<f64>().ok()))
        .or_else(|| {
            sf_section.lines().find_map(|l| {
                l.find("refresh-rate")
                    .and_then(|i| l[i..].split(':').nth(1)?.split_whitespace().next()?.parse::<f64>().ok())
            })
        })
        .unwrap_or(0.0);
    let median_fps = if total_frames > 0 && p50 > 0.1 {
        (1000.0 / p50).min(144.0)
    } else if sf_cur_fps > 0.0 && sf_section.contains(&pkg_id) {
        sf_cur_fps.min(120.0)
    } else {
        0.0
    };

    let pss_kb = first_num(mem_section, "TOTAL PSS:");
    let gfx_kb = first_num(mem_section, "Graphics:");
    let native_kb = first_num(mem_section, "Native Heap:");
    let temp_c = first_num(temp_section, "temperature:") / 10.0;

    let mut exceptions = Vec::new();
    let mut unity_logs = Vec::new();
    for line in log_section.lines() {
        if line.starts_with("---------") {
            continue;
        }
        if line.contains("Exception")
            || line.contains("Error")
            || line.contains("FATAL")
            || line.contains(" E Unity")
        {
            exceptions.push(line.to_string());
        } else {
            unity_logs.push(line.to_string());
        }
    }

    Ok(json!({
        "package_name": pkg_id,
        "process_pid": pid_section,
        "is_running": pid_section != "NOT_RUNNING" && !pid_section.is_empty(),
        "performance": {
            "total_frames_sampled": total_frames,
            "janky_frames": janky,
            "frame_time_ms": { "p50": p50, "p90": p90, "p95": p95, "p99": p99 },
            "estimated_median_fps": round2(median_fps),
            "total_pss_ram_mb": round2(pss_kb / 1024.0),
            "gpu_graphics_ram_mb": round2(gfx_kb / 1024.0),
            "native_il2cpp_heap_mb": round2(native_kb / 1024.0),
            "battery_temp_celsius": round2(temp_c)
        },
        "exceptions_and_errors": exceptions,
        "unity_debug_logs": unity_logs
    }))
}

fn after_label(text: &str, label: &str) -> String {
    text.lines()
        .find_map(|l| l.find(label).map(|i| l[i + label.len()..].trim().to_string()))
        .unwrap_or_default()
}

fn parse_ms(text: &str, label: &str) -> f64 {
    after_label(text, label)
        .trim_end_matches("ms")
        .trim()
        .parse()
        .unwrap_or(0.0)
}

fn first_num(text: &str, label: &str) -> f64 {
    after_label(text, label)
        .split_whitespace()
        .next()
        .and_then(|w| w.parse::<f64>().ok())
        .unwrap_or(0.0)
}
