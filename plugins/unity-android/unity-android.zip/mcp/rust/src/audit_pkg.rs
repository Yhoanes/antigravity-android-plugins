use crate::util::{ensure_meta_for_path, find_bin, opt_bool, opt_f64, opt_i64, opt_str, prefix_dir, read_meta_guid, req_str, round2, unity_guid_from_seed};
use serde_json::{json, Value};
use std::collections::{HashMap, HashSet};
use std::fs;
use std::path::{Path, PathBuf};
use std::process::Command;

/// Multi-pass Unity project `.meta`, GUID, `%YAML 1.1` scene/prefab, and C# script auditor & healer.
pub fn yaml_audit(args: &Value) -> Result<Value, String> {
    let root = PathBuf::from(req_str(args, "project_dir")?);
    let assets_dir = root.join("Assets");
    if !assets_dir.is_dir() {
        return Err(format!("No `Assets/` directory found in {}", root.display()));
    }
    let auto_fix_meta = opt_bool(args, "auto_fix_meta", true);

    let mut all_assets = Vec::new();
    collect_files_and_dirs(&assets_dir, &mut all_assets);

    let mut missing_meta = Vec::new();
    let mut healed_meta = 0usize;
    let mut guid_to_path: HashMap<String, String> = HashMap::new();
    let mut duplicate_guids = Vec::new();
    let mut cs_issues = Vec::new();
    let mut yaml_files = Vec::new();

    for p in &all_assets {
        let rel = p
            .strip_prefix(&root)
            .map(|r| r.to_string_lossy().replace('\\', "/"))
            .unwrap_or_default();
        let meta_path = PathBuf::from(format!("{}.meta", p.display()));

        if !meta_path.is_file() {
            if auto_fix_meta {
                if let Ok(g) = ensure_meta_for_path(p, &rel) {
                    guid_to_path.insert(g, rel.clone());
                    healed_meta += 1;
                }
            } else {
                missing_meta.push(rel.clone());
            }
        } else if let Some(g) = read_meta_guid(&meta_path) {
            if let Some(prev) = guid_to_path.insert(g.clone(), rel.clone()) {
                duplicate_guids.push(json!({ "guid": g, "first": prev, "second": rel }));
            }
        }

        if p.is_file() {
            let ext = p
                .extension()
                .and_then(|s| s.to_str())
                .unwrap_or("")
                .to_ascii_lowercase();
            if ext == "cs" {
                if let Ok(code) = fs::read_to_string(p) {
                    let ob = code.chars().filter(|&c| c == '{').count();
                    let cb = code.chars().filter(|&c| c == '}').count();
                    if ob != cb {
                        cs_issues.push(format!("{rel}: unbalanced braces (`{{`={ob}, `}}`={cb})"));
                    }
                    let stem = p.file_stem().and_then(|s| s.to_str()).unwrap_or("");
                    if (code.contains(": MonoBehaviour") || code.contains(": ScriptableObject"))
                        && !code.contains(&format!("class {stem}"))
                    {
                        cs_issues.push(format!(
                            "{rel}: MonoBehaviour/ScriptableObject filename `{stem}.cs` does not match `class {stem}`"
                        ));
                    }
                }
            } else if matches!(ext.as_str(), "unity" | "prefab" | "mat" | "asset") {
                yaml_files.push((p.clone(), rel));
            }
        }
    }

    // Also index PackageCache / Packages GUIDs if present so external package GUIDs aren't false positives
    let mut external_guids = HashSet::new();
    let mut pkg_files = Vec::new();
    if root.join("Packages").is_dir() {
        collect_files_and_dirs(&root.join("Packages"), &mut pkg_files);
        for p in pkg_files {
            let mp = PathBuf::from(format!("{}.meta", p.display()));
            if let Some(g) = read_meta_guid(&mp) {
                external_guids.insert(g);
            }
        }
    }

    let mut scene_summaries = Vec::new();
    let mut broken_local_refs = Vec::new();
    let mut unknown_asset_guids = Vec::new();

    for (yp, rel) in &yaml_files {
        let txt = match fs::read_to_string(yp) {
            Ok(t) => t,
            Err(_) => continue,
        };
        if !txt.starts_with("%YAML") {
            continue;
        }
        let mut defined_ids = HashSet::new();
        let mut go_count = 0usize;
        let mut comp_count = 0usize;

        for line in txt.lines() {
            if let Some(rest) = line.strip_prefix("--- !u!") {
                let parts: Vec<&str> = rest.split_whitespace().collect();
                if parts.len() >= 2 {
                    let class_id = parts[0];
                    if class_id == "1" {
                        go_count += 1;
                    } else {
                        comp_count += 1;
                    }
                    if let Some(fid) = parts[1].strip_prefix('&') {
                        defined_ids.insert(fid.to_string());
                    }
                }
            }
        }

        // Scan inline `{fileID: X}` and `{fileID: X, guid: Y, ...}`
        for (line_no, line) in txt.lines().enumerate() {
            if let Some(idx) = line.find("{fileID:") {
                let tail = &line[idx + 8..];
                if let Some(end_brace) = tail.find('}') {
                    let inside = &tail[..end_brace];
                    let has_guid = inside.contains("guid:");
                    if !has_guid {
                        let fid = inside.split(',').next().unwrap_or("").trim();
                        if !fid.is_empty() && fid != "0" && !defined_ids.contains(fid) {
                            broken_local_refs.push(format!("{rel}:{} missing local &{fid}", line_no + 1));
                        }
                    } else if let Some(gpos) = inside.find("guid:") {
                        let gpart = inside[gpos + 5..]
                            .split(',')
                            .next()
                            .unwrap_or("")
                            .trim();
                        // Builtin Unity resources start with 0000000000000000
                        if gpart.len() == 32
                            && !gpart.starts_with("0000000000000000")
                            && !guid_to_path.contains_key(gpart)
                            && !external_guids.contains(gpart)
                        {
                            // Note: UPM package scripts (e.g. InputSystem, URP) live in Library/PackageCache when compiled
                            if unknown_asset_guids.len() < 40 {
                                unknown_asset_guids.push(format!("{rel}:{} external/unindexed guid {gpart}", line_no + 1));
                            }
                        }
                    }
                }
            }
        }

        if rel.ends_with(".unity") || rel.ends_with(".prefab") {
            scene_summaries.push(json!({
                "path": rel,
                "gameobjects": go_count,
                "components_and_settings": comp_count
            }));
        }
    }

    let healthy = missing_meta.is_empty()
        && duplicate_guids.is_empty()
        && cs_issues.is_empty()
        && broken_local_refs.is_empty();

    Ok(json!({
        "project_dir": root.to_string_lossy(),
        "healthy": healthy,
        "total_indexed_guids": guid_to_path.len(),
        "auto_healed_missing_meta": healed_meta,
        "missing_meta": missing_meta,
        "duplicate_guids": duplicate_guids,
        "csharp_issues": cs_issues,
        "broken_local_file_ids": broken_local_refs,
        "unindexed_or_upm_guids_note": unknown_asset_guids,
        "scenes_and_prefabs": scene_summaries
    }))
}

/// Offline `.unitypackage` (`inspect`, `import`, `export`) engine using `.tar.gz` GUID layout.
pub fn package_io(args: &Value) -> Result<Value, String> {
    let op = req_str(args, "operation")?.to_ascii_lowercase();
    let pkg_path = PathBuf::from(req_str(args, "package_path")?);
    let tar_bin = find_bin("tar").ok_or("`tar` binary not found in $PREFIX/bin")?;

    let tmp_base = prefix_dir().join(format!("tmp/upkg_{}", std::process::id()));
    let _ = fs::remove_dir_all(&tmp_base);
    fs::create_dir_all(&tmp_base).map_err(|e| e.to_string())?;

    let result = match op.as_str() {
        "inspect" => {
            extract_tar_gz(&tar_bin, &pkg_path, &tmp_base)?;
            let items = read_upkg_staging(&tmp_base)?;
            let list: Vec<Value> = items
                .iter()
                .map(|it| {
                    json!({
                        "guid": it.guid,
                        "pathname": it.pathname,
                        "bytes": it.asset_bytes,
                        "has_meta": it.has_meta
                    })
                })
                .collect();
            Ok(json!({
                "operation": "inspect",
                "package_path": pkg_path.to_string_lossy(),
                "total_assets": list.len(),
                "assets": list
            }))
        }
        "import" => {
            let proj = PathBuf::from(req_str(args, "project_dir")?);
            let filter_prefix = opt_str(args, "include_prefix", "");
            extract_tar_gz(&tar_bin, &pkg_path, &tmp_base)?;
            let items = read_upkg_staging(&tmp_base)?;
            let mut imported = Vec::new();

            for it in items {
                if !filter_prefix.is_empty() && !it.pathname.starts_with(&filter_prefix) {
                    continue;
                }
                if it.pathname.contains("..") || it.pathname.starts_with('/') {
                    continue;
                }
                let dst = proj.join(&it.pathname);
                if it.has_asset_file {
                    if let Some(parent) = dst.parent() {
                        fs::create_dir_all(parent).map_err(|e| e.to_string())?;
                    }
                    fs::copy(tmp_base.join(&it.guid).join("asset"), &dst).map_err(|e| e.to_string())?;
                } else {
                    fs::create_dir_all(&dst).map_err(|e| e.to_string())?;
                }

                let meta_dst = PathBuf::from(format!("{}.meta", dst.display()));
                let staged_meta = tmp_base.join(&it.guid).join("asset.meta");
                if staged_meta.is_file() {
                    fs::copy(&staged_meta, &meta_dst).map_err(|e| e.to_string())?;
                } else {
                    let _ = ensure_meta_for_path(&dst, &it.pathname);
                }
                imported.push(it.pathname);
            }
            Ok(json!({
                "operation": "import",
                "project_dir": proj.to_string_lossy(),
                "imported_count": imported.len(),
                "imported_paths": imported
            }))
        }
        "export" => {
            let proj = PathBuf::from(req_str(args, "project_dir")?);
            let source_rel = opt_str(args, "source_rel_path", "Assets").replace('\\', "/");
            let src_target = proj.join(&source_rel);
            if !src_target.exists() {
                return Err(format!("Source path does not exist: {}", src_target.display()));
            }
            let mut targets = Vec::new();
            if src_target.is_file() {
                targets.push(src_target);
            } else {
                collect_files_and_dirs(&src_target, &mut targets);
            }

            let mut exported = 0usize;
            for item in targets {
                let rel = item
                    .strip_prefix(&proj)
                    .map(|r| r.to_string_lossy().replace('\\', "/"))
                    .unwrap_or_default();
                if rel.is_empty() || rel.ends_with(".meta") {
                    continue;
                }
                let guid = ensure_meta_for_path(&item, &rel).unwrap_or_else(|_| unity_guid_from_seed(&rel));
                let gdir = tmp_base.join(&guid);
                fs::create_dir_all(&gdir).map_err(|e| e.to_string())?;
                fs::write(gdir.join("pathname"), format!("{rel}\n")).map_err(|e| e.to_string())?;
                let meta_src = PathBuf::from(format!("{}.meta", item.display()));
                if meta_src.is_file() {
                    fs::copy(&meta_src, gdir.join("asset.meta")).map_err(|e| e.to_string())?;
                }
                if item.is_file() {
                    fs::copy(&item, gdir.join("asset")).map_err(|e| e.to_string())?;
                }
                exported += 1;
            }

            if let Some(parent) = pkg_path.parent() {
                fs::create_dir_all(parent).map_err(|e| e.to_string())?;
            }
            let out = Command::new(&tar_bin)
                .current_dir(&tmp_base)
                .args(["-czf"])
                .arg(&pkg_path)
                .arg(".")
                .output()
                .map_err(|e| e.to_string())?;
            if !out.status.success() {
                return Err(format!("tar export failed: {}", String::from_utf8_lossy(&out.stderr)));
            }
            let bytes = fs::metadata(&pkg_path).map(|m| m.len()).unwrap_or(0);
            Ok(json!({
                "operation": "export",
                "package_path": pkg_path.to_string_lossy(),
                "exported_entries": exported,
                "package_bytes": bytes
            }))
        }
        _ => Err("Invalid `operation`: expected 'inspect', 'import', or 'export'.".to_string()),
    };

    let _ = fs::remove_dir_all(&tmp_base);
    result
}

/// Self-contained mobile 3D `.glb` binary inspector & zero-latency WAV/FFmpeg audio processor.
pub fn asset_opt(args: &Value) -> Result<Value, String> {
    let op = req_str(args, "operation")?.to_ascii_lowercase();
    let in_path = PathBuf::from(req_str(args, "input_path")?);

    match op.as_str() {
        "glb_inspect" => inspect_glb_binary(&in_path),
        "wav_master" => {
            let out_path = PathBuf::from(req_str(args, "output_path")?);
            let trim_silence = opt_bool(args, "trim_silence", true);
            let threshold_db = opt_f64(args, "threshold_db", -42.0);
            let normalize = opt_bool(args, "normalize_peak", true);
            let loop_ms = opt_i64(args, "seamless_loop_fade_ms", 0).max(0) as usize;
            master_wav_or_ffmpeg(&in_path, &out_path, trim_silence, threshold_db, normalize, loop_ms)
        }
        _ => Err("Supported `operation`: 'glb_inspect' or 'wav_master'.".to_string()),
    }
}

fn inspect_glb_binary(path: &Path) -> Result<Value, String> {
    let raw = fs::read(path).map_err(|e| format!("{}: {e}", path.display()))?;
    let json_val: Value = if path
        .extension()
        .and_then(|s| s.to_str())
        .map(|s| s.eq_ignore_ascii_case("gltf"))
        .unwrap_or(false)
    {
        serde_json::from_slice(&raw).map_err(|e| e.to_string())?
    } else {
        if raw.len() < 20 || &raw[0..4] != b"glTF" {
            return Err("Invalid GLB magic header (expected `glTF` binary v2.0).".to_string());
        }
        let chunk0_len = u32::from_le_bytes([raw[12], raw[13], raw[14], raw[15]]) as usize;
        let chunk0_type = &raw[16..20];
        if chunk0_type != b"JSON" || 20 + chunk0_len > raw.len() {
            return Err("Malformed GLB JSON chunk.".to_string());
        }
        serde_json::from_slice(&raw[20..20 + chunk0_len]).map_err(|e| e.to_string())?
    };

    let empty = Vec::new();
    let meshes = json_val.get("meshes").and_then(|v| v.as_array()).unwrap_or(&empty);
    let accessors = json_val.get("accessors").and_then(|v| v.as_array()).unwrap_or(&empty);
    let skins = json_val.get("skins").and_then(|v| v.as_array()).unwrap_or(&empty);
    let animations = json_val.get("animations").and_then(|v| v.as_array()).unwrap_or(&empty);
    let images = json_val.get("images").and_then(|v| v.as_array()).unwrap_or(&empty);
    let materials = json_val.get("materials").and_then(|v| v.as_array()).unwrap_or(&empty);

    let mut verts = 0u64;
    let mut tris = 0u64;
    let mut draw_calls = 0usize;
    for m in meshes {
        if let Some(prims) = m.get("primitives").and_then(|v| v.as_array()) {
            for pr in prims {
                draw_calls += 1;
                let mut vc = 0u64;
                if let Some(pi) = pr.pointer("/attributes/POSITION").and_then(|v| v.as_u64()) {
                    if let Some(acc) = accessors.get(pi as usize) {
                        vc = acc.get("count").and_then(|c| c.as_u64()).unwrap_or(0);
                        verts += vc;
                    }
                }
                if let Some(ii) = pr.get("indices").and_then(|v| v.as_u64()) {
                    if let Some(acc) = accessors.get(ii as usize) {
                        tris += acc.get("count").and_then(|c| c.as_u64()).unwrap_or(0) / 3;
                    }
                } else {
                    tris += vc / 3;
                }
            }
        }
    }
    let joints: usize = skins
        .iter()
        .map(|s| s.get("joints").and_then(|j| j.as_array()).map(|a| a.len()).unwrap_or(0))
        .sum();

    let mut warnings = Vec::new();
    if tris > 50_000 {
        warnings.push(format!("High triangle count ({tris}) for mobile character/prop; consider LOD group (<25k tris for hero, <5k for props)."));
    }
    if draw_calls > 12 {
        warnings.push(format!("{draw_calls} submesh draw calls detected; merge materials/atlases to maximize Unity URP SRP Batcher efficiency."));
    }
    if joints > 75 {
        warnings.push(format!("{joints} skinning bones; keep mobile humanoid rigs <= 65 bones for 120 FPS GPU skinning."));
    }

    Ok(json!({
        "input_path": path.to_string_lossy(),
        "file_size_kb": round2(raw.len() as f64 / 1024.0),
        "meshes": meshes.len(),
        "draw_calls": draw_calls,
        "vertices": verts,
        "triangles": tris,
        "skeleton_joints": joints,
        "animations": animations.len(),
        "materials": materials.len(),
        "embedded_textures": images.len(),
        "unity_mobile_recommendations": warnings
    }))
}

fn master_wav_or_ffmpeg(
    in_path: &Path,
    out_path: &Path,
    trim_silence: bool,
    threshold_db: f64,
    normalize: bool,
    loop_fade_ms: usize,
) -> Result<Value, String> {
    if let Some(p) = out_path.parent() {
        fs::create_dir_all(p).map_err(|e| e.to_string())?;
    }
    let in_ext = in_path.extension().and_then(|s| s.to_str()).unwrap_or("").to_ascii_lowercase();
    let out_ext = out_path.extension().and_then(|s| s.to_str()).unwrap_or("").to_ascii_lowercase();

    if in_ext != "wav" || out_ext != "wav" {
        let ffmpeg = find_bin("ffmpeg").ok_or("FFmpeg not installed; use `.wav` for pure-Rust DSP or `pkg install ffmpeg` for `.ogg`/`.mp3`.")?;
        let mut filters = Vec::new();
        if trim_silence {
            filters.push(format!(
                "silenceremove=start_periods=1:start_duration=0.002:start_threshold={threshold_db:.1}dB,areverse,silenceremove=start_periods=1:start_duration=0.01:start_threshold={threshold_db:.1}dB,areverse"
            ));
        }
        if normalize {
            filters.push(" volume=0dB,alimiter=limit=0.891".to_string());
        }
        let mut cmd = Command::new(ffmpeg);
        cmd.args(["-y", "-hide_banner", "-loglevel", "error", "-i"]).arg(in_path);
        if !filters.is_empty() {
            cmd.arg("-af").arg(filters.join(","));
        }
        cmd.arg(out_path);
        let res = cmd.output().map_err(|e| e.to_string())?;
        if !res.status.success() {
            return Err(format!("FFmpeg error: {}", String::from_utf8_lossy(&res.stderr)));
        }
        return Ok(json!({
            "engine": "ffmpeg_arm64",
            "output_path": out_path.to_string_lossy(),
            "bytes": fs::metadata(out_path).map(|m| m.len()).unwrap_or(0)
        }));
    }

    // Pure-Rust 16-bit PCM WAV parser & writer
    let raw = fs::read(in_path).map_err(|e| e.to_string())?;
    if raw.len() < 44 || &raw[0..4] != b"RIFF" || &raw[8..12] != b"WAVE" {
        return Err("Invalid RIFF WAVE header.".to_string());
    }
    let mut pos = 12usize;
    let mut channels = 1u16;
    let mut sample_rate = 44100u32;
    let mut bits_per_sample = 16u16;
    let mut audio_fmt = 1u16;
    let mut pcm_slice: &[u8] = &[];

    while pos + 8 <= raw.len() {
        let cid = &raw[pos..pos + 4];
        let clen = u32::from_le_bytes([raw[pos + 4], raw[pos + 5], raw[pos + 6], raw[pos + 7]]) as usize;
        pos += 8;
        if pos + clen > raw.len() {
            break;
        }
        if cid == b"fmt " && clen >= 16 {
            audio_fmt = u16::from_le_bytes([raw[pos], raw[pos + 1]]);
            channels = u16::from_le_bytes([raw[pos + 2], raw[pos + 3]]).max(1);
            sample_rate = u32::from_le_bytes([raw[pos + 4], raw[pos + 5], raw[pos + 6], raw[pos + 7]]);
            bits_per_sample = u16::from_le_bytes([raw[pos + 14], raw[pos + 15]]);
        } else if cid == b"data" {
            pcm_slice = &raw[pos..pos + clen];
            break;
        }
        pos += clen + (clen % 2);
    }

    let mut samples: Vec<f32> = match (audio_fmt, bits_per_sample) {
        (1, 16) => pcm_slice
            .chunks_exact(2)
            .map(|b| (i16::from_le_bytes([b[0], b[1]]) as f32) / 32768.0)
            .collect(),
        (3, 32) => pcm_slice
            .chunks_exact(4)
            .map(|b| f32::from_le_bytes([b[0], b[1], b[2], b[3]]))
            .collect(),
        (1, 8) => pcm_slice.iter().map(|&b| ((b as f32) - 128.0) / 128.0).collect(),
        _ => return Err(format!("Unsupported WAV encoding fmt={audio_fmt} bits={bits_per_sample}")),
    };

    let ch = channels as usize;
    let mut frames = samples.len() / ch;
    if trim_silence && frames > 0 {
        let gate = 10.0f32.powf((threshold_db as f32) / 20.0);
        let mut first = 0usize;
        while first < frames {
            if (0..ch).any(|c| samples[first * ch + c].abs() >= gate) {
                break;
            }
            first += 1;
        }
        let mut last = frames;
        while last > first {
            if (0..ch).any(|c| samples[(last - 1) * ch + c].abs() >= gate) {
                break;
            }
            last -= 1;
        }
        if first < last {
            samples = samples[first * ch..last * ch].to_vec();
            frames = samples.len() / ch;
        }
    }

    if loop_fade_ms > 0 && frames > 16 {
        let fade_frames = (((sample_rate as usize) * loop_fade_ms) / 1000).min(frames / 3);
        if fade_frames > 1 {
            let keep = frames - fade_frames;
            for f in 0..fade_frames {
                let t = (f as f32) / (fade_frames as f32);
                for c in 0..ch {
                    let head = samples[f * ch + c];
                    let tail = samples[(keep + f) * ch + c];
                    samples[f * ch + c] = tail * (1.0 - t) + head * t;
                }
            }
            samples.truncate(keep * ch);
            frames = keep;
        }
    }

    if normalize && !samples.is_empty() {
        let peak = samples.iter().fold(0.0f32, |m, &v| m.max(v.abs()));
        if peak > 1e-5 {
            let target = 0.89125f32 / peak; // -1.0 dBFS
            for s in &mut samples {
                *s = (*s * target).clamp(-1.0, 1.0);
            }
        }
    }

    // Emit clean 16-bit PCM WAV
    let data_bytes = (samples.len() * 2) as u32;
    let mut out = Vec::with_capacity(44 + data_bytes as usize);
    out.extend_from_slice(b"RIFF");
    out.extend_from_slice(&(36 + data_bytes).to_le_bytes());
    out.extend_from_slice(b"WAVEfmt ");
    out.extend_from_slice(&16u32.to_le_bytes());
    out.extend_from_slice(&1u16.to_le_bytes());
    out.extend_from_slice(&channels.to_le_bytes());
    out.extend_from_slice(&sample_rate.to_le_bytes());
    out.extend_from_slice(&(sample_rate * (channels as u32) * 2).to_le_bytes());
    out.extend_from_slice(&(channels * 2).to_le_bytes());
    out.extend_from_slice(&16u16.to_le_bytes());
    out.extend_from_slice(b"data");
    out.extend_from_slice(&data_bytes.to_le_bytes());
    for s in &samples {
        let q = (s.clamp(-1.0, 1.0) * 32767.0) as i16;
        out.extend_from_slice(&q.to_le_bytes());
    }
    fs::write(out_path, &out).map_err(|e| e.to_string())?;

    let meta_guid = if out_path.to_string_lossy().contains("/Assets/") {
        ensure_meta_for_path(out_path, &out_path.to_string_lossy()).ok()
    } else {
        None
    };

    Ok(json!({
        "engine": "pure_rust_pcm16_dsp",
        "output_path": out_path.to_string_lossy(),
        "channels": channels,
        "sample_rate_hz": sample_rate,
        "duration_sec": round2((frames as f64) / (sample_rate.max(1) as f64)),
        "meta_guid": meta_guid
    }))
}

struct UpkgEntry {
    guid: String,
    pathname: String,
    asset_bytes: u64,
    has_asset_file: bool,
    has_meta: bool,
}

fn extract_tar_gz(tar_bin: &Path, archive: &Path, dest: &Path) -> Result<(), String> {
    let out = Command::new(tar_bin)
        .args(["-xzf"])
        .arg(archive)
        .arg("-C")
        .arg(dest)
        .output()
        .map_err(|e| e.to_string())?;
    if !out.status.success() {
        return Err(format!(
            "Failed extracting .unitypackage: {}",
            String::from_utf8_lossy(&out.stderr)
        ));
    }
    Ok(())
}

fn read_upkg_staging(staging: &Path) -> Result<Vec<UpkgEntry>, String> {
    let mut items = Vec::new();
    let entries = fs::read_dir(staging).map_err(|e| e.to_string())?;
    for entry in entries.flatten() {
        let p = entry.path();
        if !p.is_dir() {
            continue;
        }
        let guid = entry.file_name().to_string_lossy().to_string();
        let pn_file = p.join("pathname");
        if !pn_file.is_file() {
            continue;
        }
        let raw_pn = fs::read_to_string(&pn_file).unwrap_or_default();
        let pathname = raw_pn
            .lines()
            .next()
            .unwrap_or("")
            .trim()
            .trim_matches('\0')
            .replace('\\', "/");
        if pathname.is_empty() {
            continue;
        }
        let asset_file = p.join("asset");
        let has_asset_file = asset_file.is_file();
        let asset_bytes = fs::metadata(&asset_file).map(|m| m.len()).unwrap_or(0);
        let has_meta = p.join("asset.meta").is_file();
        items.push(UpkgEntry {
            guid,
            pathname,
            asset_bytes,
            has_asset_file,
            has_meta,
        });
    }
    items.sort_by(|a, b| a.pathname.cmp(&b.pathname));
    Ok(items)
}

fn collect_files_and_dirs(dir: &Path, out: &mut Vec<PathBuf>) {
    let entries = match fs::read_dir(dir) {
        Ok(e) => e,
        Err(_) => return,
    };
    for entry in entries.flatten() {
        let p = entry.path();
        let name = entry.file_name().to_string_lossy().to_string();
        if name.starts_with('.') || name.ends_with(".meta") {
            continue;
        }
        out.push(p.clone());
        if p.is_dir() {
            collect_files_and_dirs(&p, out);
        }
    }
}
