mod android_dev;
mod audit_pkg;
mod cloud_ci;
mod project;
mod unity_cli;
mod util;

use serde_json::{json, Value};
use std::env;
use std::fs;
use std::io::{self, BufRead, BufReader, BufWriter, Write};
use std::os::unix::fs::PermissionsExt;

const SERVER_NAME: &str = "unity-android";
const SERVER_VERSION: &str = "1.0.0";
const DEFAULT_PROTO: &str = "2024-11-05";

fn main() {
    let args: Vec<String> = env::args().collect();
    if args.len() > 1 {
        run_cli_mode(&args[1..]);
        return;
    }

    ensure_wrappers_installed();
    run_mcp_server();
}

fn run_cli_mode(args: &[String]) {
    let sub = args[0].as_str();
    let res = match sub {
        "--selftest" | "status" => unity_status(),
        "--setup" | "setup" => unity_cli::cli_setup(&json!({ "force_download": args.iter().any(|a| a == "--force") })),
        "audit" => {
            let dir = args.get(1).cloned().unwrap_or_else(|| ".".to_string());
            audit_pkg::yaml_audit(&json!({ "project_dir": dir, "auto_fix_meta": true }))
        }
        "scaffold-ci" => {
            let dir = args.get(1).cloned().unwrap_or_else(|| ".".to_string());
            let pkg = args.get(2).cloned().unwrap_or_else(|| "com.agystudio.unitygame".to_string());
            let slug = args.get(3).cloned().unwrap_or_else(|| "unity-game".to_string());
            cloud_ci::ci_workflow(&json!({
                "action": "scaffold",
                "project_dir": dir,
                "android_package": pkg,
                "artifact_name": slug
            }))
        }
        "deploy" => {
            let apk = args.get(1).cloned().unwrap_or_default();
            let pkg = args.get(2).cloned().unwrap_or_default();
            android_dev::apk_deploy(&json!({
                "apk_path": apk,
                "package_name": pkg,
                "launch_after_install": true,
                "clear_logcat_before_launch": true
            }))
        }
        "debug" => {
            let pkg = args.get(1).cloned().unwrap_or_default();
            android_dev::live_debug(&json!({
                "package_name": pkg,
                "max_log_lines": 120
            }))
        }
        "cli" => {
            let rest: Vec<Value> = args[1..].iter().map(|s| Value::String(s.clone())).collect();
            unity_cli::cli_exec(&json!({ "args": rest, "json_output": false }))
        }
        "--help" | "-h" | "help" => Ok(json!({
            "binary": "agy-unity / unity-android-mcp",
            "version": SERVER_VERSION,
            "usage": [
                "agy-unity status                        # Full Rust ARM64 + ported Unity CLI + ADB status",
                "agy-unity setup                         # Download/repair ported unity-linux-arm64 v1.0.0 + glibc",
                "agy-unity audit <dir>                   # Audit & heal .meta GUIDs, YAML scenes, and C# scripts",
                "agy-unity scaffold-ci <dir> <pkg> <slug># Generate Zero-PC GitHub Actions Android IL2CPP workflow",
                "agy-unity deploy <apk> [package_id]     # Install & launch APK on Android via rish",
                "agy-unity debug <package_id>            # Live Unity Logcat + 120 FPS & PSS RAM telemetry",
                "agy-unity cli <args>                    # Run official Unity CLI directly",
                "unity <args>                            # Direct wrapper to ported Unity CLI v1.0.0"
            ]
        })),
        _ => Err(format!("Unknown CLI subcommand `{sub}`. Try `agy-unity help`.")),
    };

    match res {
        Ok(v) => println!("{}", serde_json::to_string_pretty(&v).unwrap_or_default()),
        Err(e) => {
            eprintln!("Error: {e}");
            std::process::exit(1);
        }
    }
}

/// Atomically create/heal `$PREFIX/bin/unity` and `$PREFIX/bin/agy-unity` wrappers.
/// Never touches `$HOME/runtime/bin/`.
pub fn ensure_wrappers_installed() {
    let pfx = util::prefix_dir();
    let home = util::home_dir();
    let bin_dir = pfx.join("bin");
    let _ = fs::create_dir_all(&bin_dir);

    let unity_bin = unity_cli::unity_bin_path();
    let mcp_bin = home.join(".gemini/config/plugins/unity-android/mcp/bin/unity-android-mcp");
    let cert = pfx.join("etc/tls/cert.pem");
    let cert_dir = pfx.join("etc/tls/certs");

    // 1. Direct `$PREFIX/bin/unity` wrapper for terminal & official Unity skills (`unity-cli`), with auto-bootstrap on first run
    let unity_wrapper = format!(
        "#!/system/bin/sh\nexport HOME=\"{}\"\nexport PREFIX=\"{}\"\nexport TMPDIR=\"{}/tmp\"\nexport PATH=\"{}/bin:{}/runtime/bin:/system/bin\"\nexport BROWSER=\"{}/bin/xdg-open\"\nexport SSL_CERT_FILE=\"{}\"\nexport CURL_CA_BUNDLE=\"{}\"\nexport SSL_CERT_DIR=\"{}\"\nexport UNITY_NO_UPDATE_CHECK=1\nexport UNITY_NO_CRASH_REPORT=1\nexport UNITY_NO_CLI_INVOKED_TELEMETRY=1\nexport DO_NOT_TRACK=1\nif [ ! -x \"{}\" ]; then\n    echo \"[unity-android] First-time setup: installing & patching official Unity CLI v1.0.0 for Android ARM64...\" >&2\n    \"{}\" setup >&2\nfi\nunset LD_PRELOAD LD_LIBRARY_PATH 2>/dev/null || true\nexec \"{}\" \"$@\"\n",
        home.display(),
        pfx.display(),
        pfx.display(),
        pfx.display(),
        home.display(),
        pfx.display(),
        cert.display(),
        cert.display(),
        cert_dir.display(),
        unity_bin.display(),
        mcp_bin.display(),
        unity_bin.display()
    );
    write_atomic_executable(&bin_dir.join("unity"), &unity_wrapper);

    // 2. `$PREFIX/bin/agy-unity` wrapper pointing to our native Rust engine
    let agy_wrapper = format!(
        "#!/system/bin/sh\nexport HOME=\"{}\"\nexport PREFIX=\"{}\"\nexport TMPDIR=\"{}/tmp\"\nexport LD_LIBRARY_PATH=\"{}/lib${{LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}}\"\nexport PATH=\"{}/bin:{}/runtime/bin:/system/bin\"\nexec \"{}\" \"$@\"\n",
        home.display(),
        pfx.display(),
        pfx.display(),
        pfx.display(),
        pfx.display(),
        home.display(),
        mcp_bin.display()
    );
    write_atomic_executable(&bin_dir.join("agy-unity"), &agy_wrapper);
}

fn write_atomic_executable(target: &std::path::Path, content: &str) {
    if let Ok(existing) = fs::read_to_string(target) {
        if existing == content {
            return;
        }
    }
    let tmp = target.with_extension(format!("tmp.{}", std::process::id()));
    if fs::write(&tmp, content).is_ok() {
        let _ = fs::set_permissions(&tmp, fs::Permissions::from_mode(0o755));
        let _ = fs::rename(&tmp, target);
    }
}

fn unity_status() -> Result<Value, String> {
    let cli_info = unity_cli::cli_probe_quick();
    let (adb_live, third_party_pkgs) = android_dev::probe_adb_and_unity_packages();
    let has_gh = util::find_bin("gh").is_some();
    let has_git = util::find_bin("git").is_some();
    let has_dotnet = util::find_bin("dotnet").is_some();
    let has_ffmpeg = util::find_bin("ffmpeg").is_some();

    Ok(json!({
        "plugin": SERVER_NAME,
        "version": SERVER_VERSION,
        "runtime": "native_rust_arm64_bionic",
        "arch": env::consts::ARCH,
        "ported_official_unity_cli": cli_info,
        "android_bridge": {
            "rish_adb_active": adb_live,
            "installed_user_packages_count": third_party_pkgs.len(),
            "sample_packages": third_party_pkgs.into_iter().take(15).collect::<Vec<_>>()
        },
        "cloud_and_local_toolchains": {
            "gh_cli": has_gh,
            "git": has_git,
            "dotnet_sdk_arm64": has_dotnet,
            "ffmpeg_arm64": has_ffmpeg,
            "unity_terminal_wrapper": util::prefix_dir().join("bin/unity").is_file()
        }
    }))
}

fn run_mcp_server() {
    let stdin = io::stdin();
    let stdout = io::stdout();
    let mut reader = BufReader::new(stdin.lock());
    let mut writer = BufWriter::new(stdout.lock());
    let mut use_content_length = false;

    loop {
        let payload = match read_next_message(&mut reader, &mut use_content_length) {
            Ok(Some(msg)) => msg,
            Ok(None) | Err(_) => break,
        };
        let trimmed = payload.trim();
        if trimmed.is_empty() {
            continue;
        }
        if let Some(resp) = handle_rpc(trimmed) {
            if let Ok(bytes) = serde_json::to_vec(&resp) {
                if use_content_length {
                    let _ = write!(writer, "Content-Length: {}\r\n\r\n", bytes.len());
                    let _ = writer.write_all(&bytes);
                } else {
                    let _ = writer.write_all(&bytes);
                    let _ = writer.write_all(b"\n");
                }
                let _ = writer.flush();
            }
        }
    }
}

fn read_next_message<R: BufRead>(
    reader: &mut R,
    use_content_length: &mut bool,
) -> io::Result<Option<String>> {
    loop {
        let mut line = String::new();
        let n = reader.read_line(&mut line)?;
        if n == 0 {
            return Ok(None);
        }
        let t = line.trim();
        if t.is_empty() {
            continue;
        }
        if t.len() >= 15 && t[..15].eq_ignore_ascii_case("content-length:") {
            *use_content_length = true;
            let len: usize = t[15..].trim().parse().unwrap_or(0);
            loop {
                let mut hdr = String::new();
                if reader.read_line(&mut hdr)? == 0 || hdr.trim().is_empty() {
                    break;
                }
            }
            let mut body = vec![0u8; len];
            reader.read_exact(&mut body)?;
            return Ok(Some(String::from_utf8_lossy(&body).to_string()));
        }
        return Ok(Some(t.to_string()));
    }
}

fn handle_rpc(raw: &str) -> Option<Value> {
    let req: Value = match serde_json::from_str(raw) {
        Ok(v) => v,
        Err(_) => {
            return Some(json!({
                "jsonrpc": "2.0",
                "id": Value::Null,
                "error": { "code": -32700, "message": "Parse error" }
            }));
        }
    };

    let id = req.get("id")?.clone();
    let method = req.get("method").and_then(|m| m.as_str()).unwrap_or("");
    let params = req.get("params").cloned().unwrap_or_else(|| json!({}));

    match method {
        "initialize" => {
            let proto = params
                .get("protocolVersion")
                .and_then(|p| p.as_str())
                .filter(|s| !s.is_empty())
                .unwrap_or(DEFAULT_PROTO);
            Some(json!({
                "jsonrpc": "2.0",
                "id": id,
                "result": {
                    "protocolVersion": proto,
                    "capabilities": { "tools": {} },
                    "serverInfo": { "name": SERVER_NAME, "version": SERVER_VERSION }
                }
            }))
        }
        "ping" => Some(json!({ "jsonrpc": "2.0", "id": id, "result": {} })),
        "resources/list" => Some(json!({ "jsonrpc": "2.0", "id": id, "result": { "resources": [] } })),
        "prompts/list" => Some(json!({ "jsonrpc": "2.0", "id": id, "result": { "prompts": [] } })),
        "tools/list" => Some(json!({
            "jsonrpc": "2.0",
            "id": id,
            "result": { "tools": tools_catalog() }
        })),
        "tools/call" => {
            let name = params.get("name").and_then(|n| n.as_str()).unwrap_or("");
            let args = params.get("arguments").cloned().unwrap_or_else(|| json!({}));
            let outcome = match name {
                "unity_status" => unity_status(),
                "unity_cli_exec" => unity_cli::cli_exec(&args),
                "unity_cli_setup" => unity_cli::cli_setup(&args),
                "unity_project_create" => project::project_create(&args),
                "unity_script_create" => project::script_create(&args),
                "unity_scene_build" => project::scene_build(&args),
                "unity_yaml_audit" => audit_pkg::yaml_audit(&args),
                "unity_package_io" => audit_pkg::package_io(&args),
                "unity_asset_opt" => audit_pkg::asset_opt(&args),
                "unity_ci_workflow" => cloud_ci::ci_workflow(&args),
                "unity_apk_deploy" => android_dev::apk_deploy(&args),
                "unity_live_debug" => android_dev::live_debug(&args),
                "unity_remote_mcp" => cloud_ci::remote_mcp(&args),
                _ => Err(format!("Unknown tool: {name}")),
            };
            match outcome {
                Ok(val) => Some(json!({
                    "jsonrpc": "2.0",
                    "id": id,
                    "result": {
                        "content": [{ "type": "text", "text": serde_json::to_string_pretty(&val).unwrap_or_default() }],
                        "isError": false
                    }
                })),
                Err(err) => Some(json!({
                    "jsonrpc": "2.0",
                    "id": id,
                    "result": {
                        "content": [{ "type": "text", "text": serde_json::to_string_pretty(&json!({ "error": err, "tool": name })).unwrap_or(err) }],
                        "isError": true
                    }
                })),
            }
        }
        _ => Some(json!({
            "jsonrpc": "2.0",
            "id": id,
            "error": { "code": -32601, "message": format!("Method not found: {method}") }
        })),
    }
}

fn tools_catalog() -> Value {
    json!([
        {
            "name": "unity_status",
            "description": "Inspect the native Rust ARM64 Unity Studio engine, ported official `unity-cli` v1.0.0 status/auth, live Android `rish`/ADB bridge, and Cloud CI toolchains.",
            "inputSchema": { "type": "object", "properties": {}, "additionalProperties": false }
        },
        {
            "name": "unity_cli_exec",
            "description": "Execute any official Unity CLI v1.0.0 command natively on Android ARM64 (`releases`, `docs`, `auth`, `license`, `vcs diff/blame/guid/explain`, `assets`, `pipeline cloud-build`, `commands --grep`) with clean JSON parsing.",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "args": { "type": "array", "items": { "type": "string" }, "description": "Array of Unity CLI arguments (e.g. [\"releases\"] or [\"commands\", \"--grep\", \"android\"])." },
                    "command": { "type": "string", "description": "Alternative space-separated command string if `args` is omitted." },
                    "project_dir": { "type": "string", "description": "Optional Unity project root directory." },
                    "json_output": { "type": "boolean", "description": "Automatically append `--format json` (default true)." },
                    "timeout_sec": { "type": "integer", "description": "Max execution time in seconds (default 60)." }
                },
                "additionalProperties": false
            }
        },
        {
            "name": "unity_cli_setup",
            "description": "Self-healing Rust installer and 31-byte Android `glibc` patcher for Unity's official `unity-linux-arm64` CLI binary + `$PREFIX/bin/unity` wrapper.",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "force_download": { "type": "boolean", "description": "Re-download latest binary from Unity CDN even if already installed (default false)." },
                    "channel": { "type": "string", "enum": ["stable", "beta", "alpha"], "description": "Release channel (default 'stable')." }
                },
                "additionalProperties": false
            }
        },
        {
            "name": "unity_project_create",
            "description": "Scaffold a complete Unity 6 LTS (URP, Android ARM64 IL2CPP, 120 FPS, New Input System) 2D or 3D project on Android storage with playable starter scene, touch controller C#, deterministic `.meta` GUIDs, and free GitHub GameCI workflow.",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "project_name": { "type": "string", "description": "Title of the Unity game." },
                    "project_dir": { "type": "string", "description": "Target directory (defaults to `/storage/emulated/0/Documents/UnityProjects/<Name>`)." },
                    "dimension": { "type": "string", "enum": ["3d", "2d"], "description": "Project mode ('3d' or '2d', default '3d')." },
                    "company_name": { "type": "string", "description": "Company/studio name (default 'AGYStudio')." },
                    "android_package": { "type": "string", "description": "Android applicationId (e.g. `com.studio.game`)." },
                    "editor_version": { "type": "string", "description": "Target Unity 6 LTS version (default '6000.3.28f1', free Personal compatible)." },
                    "include_github_ci": { "type": "boolean", "description": "Include `$0` GitHub Actions GameCI Android build workflow (default true)." }
                },
                "required": ["project_name"],
                "additionalProperties": false
            }
        },
        {
            "name": "unity_script_create",
            "description": "Create or update a Unity C# script (`.cs`), UI Toolkit (`.uxml`/`.uss`), or Shader inside `Assets/`, validating MonoBehaviour class-filename rules and generating a deterministic `.meta` GUID.",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "project_dir": { "type": "string", "description": "Root directory of the Unity project." },
                    "rel_path": { "type": "string", "description": "Path inside `Assets/` (e.g. `Assets/Scripts/EnemyController.cs`)." },
                    "content": { "type": "string", "description": "Full C# or asset source content." }
                },
                "required": ["project_dir", "rel_path", "content"],
                "additionalProperties": false
            }
        },
        {
            "name": "unity_scene_build",
            "description": "Generate a valid Unity `%YAML 1.1` Scene (`.unity`) or Prefab (`.prefab`) in pure Rust with Camera, Light, 2D/3D primitives, Colliders, Rigidbodies, and bound `MonoBehaviour` scripts by `guid`.",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "project_dir": { "type": "string", "description": "Root directory of the Unity project." },
                    "scene_rel_path": { "type": "string", "description": "Relative path under `Assets/` ending in `.unity` or `.prefab`." },
                    "dimension": { "type": "string", "enum": ["3d", "2d"], "description": "Scene camera/physics mode ('3d' or '2d')." },
                    "objects": {
                        "type": "array",
                        "description": "List of GameObjects to serialize (`name`, `primitive`: cube|sphere|capsule|plane|sprite|empty, `position`: [x,y,z], `scale`: [x,y,z], `collider`: bool, `rigidbody`: bool, `script_guid`: 32-hex string, `fields`: object).",
                        "items": { "type": "object" }
                    }
                },
                "required": ["project_dir", "scene_rel_path"],
                "additionalProperties": false
            }
        },
        {
            "name": "unity_yaml_audit",
            "description": "Audit and auto-heal a Unity project before Cloud/CI compilation: fixes missing `.meta` files, detects duplicate GUIDs, checks broken `{fileID}` references in `.unity`/`.prefab`, and validates C# brace & MonoBehaviour naming rules.",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "project_dir": { "type": "string", "description": "Root directory of the Unity project." },
                    "auto_fix_meta": { "type": "boolean", "description": "Automatically generate missing `.meta` files (default true)." }
                },
                "required": ["project_dir"],
                "additionalProperties": false
            }
        },
        {
            "name": "unity_package_io",
            "description": "Pure-Rust offline `.unitypackage` engine: `inspect` contents, `import` assets + `.meta` GUIDs into a Unity project, or `export` `Assets/` folders into a distributable `.unitypackage`.",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "operation": { "type": "string", "enum": ["inspect", "import", "export"] },
                    "package_path": { "type": "string", "description": "Path to the `.unitypackage` file." },
                    "project_dir": { "type": "string", "description": "Target/source Unity project root (required for `import` and `export`)." },
                    "include_prefix": { "type": "string", "description": "Optional path filter for `import` (e.g. `Assets/Sprites/`)." },
                    "source_rel_path": { "type": "string", "description": "Relative folder/file for `export` (default `Assets`)." }
                },
                "required": ["operation", "package_path"],
                "additionalProperties": false
            }
        },
        {
            "name": "unity_asset_opt",
            "description": "Native Rust mobile asset inspector & DSP optimizer for Unity Android: inspect 3D `.glb` draw-call/triangle/bone budgets (`glb_inspect`) or strip 0-ms WAV audio silence, normalize to -1 dBFS, and build seamless BGM loops (`wav_master`).",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "operation": { "type": "string", "enum": ["glb_inspect", "wav_master"] },
                    "input_path": { "type": "string", "description": "Source `.glb`/`.gltf` or `.wav`/`.ogg` file." },
                    "output_path": { "type": "string", "description": "Destination audio path (required for `wav_master`)." },
                    "trim_silence": { "type": "boolean", "description": "Strip leading/trailing silence (default true)." },
                    "threshold_db": { "type": "number", "description": "Silence gate in dBFS (default -42.0)." },
                    "normalize_peak": { "type": "boolean", "description": "Normalize peak to -1.0 dBFS (default true)." },
                    "seamless_loop_fade_ms": { "type": "integer", "description": "Crossfade tail-to-head in ms for BGM loops (default 0)." }
                },
                "required": ["operation", "input_path"],
                "additionalProperties": false
            }
        },
        {
            "name": "unity_ci_workflow",
            "description": "Manage `$0` Cloud Android APK/AAB builds via GitHub Actions (`GameCI`): `scaffold` workflow + `AndroidAutoBuilder.cs`, `trigger` remote build, check `status`, read C# compiler `logs`, or `download_apk` directly to Android.",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "action": { "type": "string", "enum": ["scaffold", "trigger", "status", "logs", "download_apk"] },
                    "project_dir": { "type": "string", "description": "Local Unity project path (for `scaffold`)." },
                    "github_repo": { "type": "string", "description": "`owner/repo` on GitHub (for `trigger`, `status`, `logs`, `download_apk`)." },
                    "run_id": { "type": "string", "description": "GitHub Actions workflow run ID (for `logs` and `download_apk`)." },
                    "editor_version": { "type": "string", "description": "Unity version (default '6000.3.28f1', free Personal compatible)." },
                    "android_package": { "type": "string", "description": "Android package ID (for `scaffold`)." },
                    "download_dir": { "type": "string", "description": "Target directory on Android for `download_apk`." }
                },
                "required": ["action"],
                "additionalProperties": false
            }
        },
        {
            "name": "unity_apk_deploy",
            "description": "Install a compiled Unity `.apk` directly on this Android device via `rish` (`AGY ADB Bridge` / Shizuku) and launch the game on screen.",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "apk_path": { "type": "string", "description": "Absolute path to the `.apk` file on Android." },
                    "package_name": { "type": "string", "description": "Android `applicationId` to auto-launch after install." },
                    "launch_after_install": { "type": "boolean", "description": "Launch game immediately after `pm install` (default true)." },
                    "clear_logcat_before_launch": { "type": "boolean", "description": "Clear stale logcat buffer before launching so fresh Unity logs are captured (default true)." }
                },
                "required": ["apk_path"],
                "additionalProperties": false
            }
        },
        {
            "name": "unity_live_debug",
            "description": "Live on-device Unity Android debugger & 60-120 FPS profiler via `rish`: captures `logcat -s Unity` C# exceptions/logs alongside `gfxinfo` frame times, FPS, jank, GPU/IL2CPP PSS RAM MB, and battery temp.",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "package_name": { "type": "string", "description": "Installed Unity game Android package name." },
                    "max_log_lines": { "type": "integer", "description": "Recent Unity/Crash log lines to inspect (default 120)." },
                    "reset_gfx_stats": { "type": "boolean", "description": "Reset frame counters after sampling (default false)." }
                },
                "required": ["package_name"],
                "additionalProperties": false
            }
        },
        {
            "name": "unity_remote_mcp",
            "description": "Optional HTTP JSON-RPC bridge to control a desktop Unity 6 Editor MCP server running on LAN or Tailscale.",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "endpoint_url": { "type": "string", "description": "HTTP URL of the remote Unity Editor MCP relay (e.g. `http://192.168.1.50:8080/mcp`)." },
                    "rpc_method": { "type": "string", "description": "JSON-RPC method (`tools/list`, `tools/call`, etc.)." },
                    "rpc_params": { "type": "object", "description": "JSON-RPC parameters payload." }
                },
                "required": ["endpoint_url"],
                "additionalProperties": false
            }
        }
    ])
}
