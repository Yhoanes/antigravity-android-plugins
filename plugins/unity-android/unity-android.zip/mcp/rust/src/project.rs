use crate::util::{ensure_meta_for_path, opt_bool, opt_str, req_str, unity_guid_from_seed};
use serde_json::{json, Value};
use std::fs;
use std::path::{Path, PathBuf};

const DEFAULT_UNITY_VERSION: &str = "6000.3.28f1";

pub fn project_create(args: &Value) -> Result<Value, String> {
    let project_name = req_str(args, "project_name")?;
    let safe_ident: String = project_name
        .chars()
        .filter(|c| c.is_ascii_alphanumeric())
        .collect();
    let pascal_name = if safe_ident.is_empty() {
        "MyUnityGame".to_string()
    } else {
        let mut ch = safe_ident.chars();
        match ch.next() {
            Some(f) => f.to_ascii_uppercase().to_string() + ch.as_str(),
            None => "MyUnityGame".to_string(),
        }
    };

    let base_dir = opt_str(
        args,
        "project_dir",
        &format!("/storage/emulated/0/Documents/UnityProjects/{pascal_name}"),
    );
    let root = PathBuf::from(&base_dir);
    let dimension = opt_str(args, "dimension", "3d").to_ascii_lowercase();
    let is_2d = dimension == "2d";
    let company = opt_str(args, "company_name", "AGYStudio");
    let pkg_slug: String = pascal_name.to_ascii_lowercase();
    let company_slug: String = company
        .chars()
        .filter(|c| c.is_ascii_alphanumeric())
        .collect::<String>()
        .to_ascii_lowercase();
    let default_pkg = format!(
        "com.{}.{}",
        if company_slug.is_empty() { "agystudio" } else { &company_slug },
        pkg_slug
    );
    let package_id = opt_str(args, "android_package", &default_pkg);
    let editor_version = opt_str(args, "editor_version", DEFAULT_UNITY_VERSION);
    let with_ci = opt_bool(args, "include_github_ci", true);

    // Create folder hierarchy
    let dirs = [
        "Assets",
        "Assets/Resources",
        "Assets/Scenes",
        "Assets/Scripts",
        "Assets/Prefabs",
        "Assets/Materials",
        "Assets/Art",
        "Assets/Audio",
        "Assets/UI",
        "Assets/Editor",
        "Packages",
        "ProjectSettings",
    ];
    for d in &dirs {
        fs::create_dir_all(root.join(d)).map_err(|e| format!("mkdir {d}: {e}"))?;
    }

    // 1. ProjectVersion.txt
    fs::write(
        root.join("ProjectSettings/ProjectVersion.txt"),
        format!("m_EditorVersion: {editor_version}\nm_EditorVersionWithRevision: {editor_version} (arm64-android-ready)\n"),
    )
    .map_err(|e| e.to_string())?;

    // 2. Packages/manifest.json (Unity 6 URP + InputSystem + UI Toolkit + Test Framework)
    let extra_2d = if is_2d {
        ",\n    \"com.unity.feature.2d\": \"2.0.1\",\n    \"com.unity.2d.tilemap\": \"1.0.0\",\n    \"com.unity.2d.sprite\": \"1.0.0\""
    } else {
        ""
    };
    let manifest = format!(
        r#"{{
  "dependencies": {{
    "com.unity.inputsystem": "1.11.2",
    "com.unity.ugui": "2.0.0",
    "com.unity.modules.ai": "1.0.0",
    "com.unity.modules.androidjni": "1.0.0",
    "com.unity.modules.animation": "1.0.0",
    "com.unity.modules.audio": "1.0.0",
    "com.unity.modules.imageconversion": "1.0.0",
    "com.unity.modules.imgui": "1.0.0",
    "com.unity.modules.jsonserialize": "1.0.0",
    "com.unity.modules.particlesystem": "1.0.0",
    "com.unity.modules.physics": "1.0.0",
    "com.unity.modules.physics2d": "1.0.0",
    "com.unity.modules.screencapture": "1.0.0",
    "com.unity.modules.ui": "1.0.0",
    "com.unity.modules.uielements": "1.0.0"{extra_2d}
  }}
}}
"#
    );
    fs::write(root.join("Packages/manifest.json"), manifest).map_err(|e| e.to_string())?;

    // 3. Assembly Definition
    let asmdef_path = root.join(format!("Assets/Scripts/{pascal_name}.Runtime.asmdef"));
    let asmdef = format!(
        r#"{{
  "name": "{pascal_name}.Runtime",
  "rootNamespace": "{pascal_name}",
  "references": [
    "Unity.InputSystem"
  ],
  "includePlatforms": [],
  "excludePlatforms": [],
  "allowUnsafeCode": false,
  "overrideReferences": false,
  "precompiledReferences": [],
  "autoReferenced": true,
  "defineConstraints": [],
  "versionDefines": [],
  "noEngineReferences": false
}}
"#
    );
    fs::write(&asmdef_path, asmdef).map_err(|e| e.to_string())?;

    // 4. Mobile 120 FPS Bootstrap + Touch Controller C# scripts
    let bootstrap_path = root.join("Assets/Scripts/MobileBootstrap.cs");
    let bootstrap_cs = format!(
        r#"using UnityEngine;

namespace {pascal_name}
{{
    /// <summary>
    /// Configures mobile 60-120 FPS frame pacing, disables sleep timeout, and tunes touch responsiveness on Android.
    /// </summary>
    public static class MobileBootstrap
    {{
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
        private static void InitializeAndroidRuntime()
        {{
            RefreshRate best = Screen.currentResolution.refreshRateRatio;
            foreach (var r in Screen.resolutions)
            {{
                if (r.refreshRateRatio.value > best.value)
                    best = r.refreshRateRatio;
            }}
            if (best.value > 61.0)
                Screen.SetResolution(Screen.width, Screen.height, FullScreenMode.FullScreenWindow, best);
            Application.targetFrameRate = 144;
            QualitySettings.vSyncCount = 0;
            Screen.sleepTimeout = SleepTimeout.NeverSleep;
            Debug.Log("[{pascal_name}] Android ARM64 Runtime initialized (targetFrameRate=144).");
        }}
    }}
}}
"#
    );
    fs::write(&bootstrap_path, bootstrap_cs).map_err(|e| e.to_string())?;

    // Unstrippable Vulkan/GLES3 3D shader in Assets/Resources/ so runtime materials never turn magenta (#FF00FF)
    let shader_path = root.join("Assets/Resources/NeonLit.shader");
    let shader_hlsl = r#"Shader "AGY/NeonLit"
{
    Properties
    {
        _BaseColor ("Base Color", Color) = (0.1, 0.8, 1.0, 1.0)
        _EmissionColor ("Emission Color", Color) = (0.0, 0.4, 0.8, 1.0)
        _GridIntensity ("Grid Intensity", Float) = 0.0
    }
    SubShader
    {
        Tags { "RenderType"="Opaque" "Queue"="Geometry" }
        LOD 100
        Pass
        {
            CGPROGRAM
            #pragma target 3.0
            #pragma vertex vert
            #pragma fragment frag
            #include "UnityCG.cginc"
            struct appdata { float4 vertex : POSITION; float3 normal : NORMAL; };
            struct v2f { float4 pos : SV_POSITION; float3 worldNormal : TEXCOORD0; float3 worldPos : TEXCOORD1; };
            fixed4 _BaseColor; fixed4 _EmissionColor; float _GridIntensity;
            v2f vert (appdata v) {
                v2f o;
                o.pos = UnityObjectToClipPos(v.vertex);
                o.worldNormal = UnityObjectToWorldNormal(v.normal);
                o.worldPos = mul(unity_ObjectToWorld, v.vertex).xyz;
                return o;
            }
            fixed4 frag (v2f i) : SV_Target {
                float3 N = normalize(i.worldNormal);
                float3 L = normalize(float3(0.45, 0.82, -0.35));
                float3 V = normalize(_WorldSpaceCameraPos.xyz - i.worldPos);
                float3 H = normalize(L + V);
                float ndotl = saturate(dot(N, L));
                float hemi = N.y * 0.5 + 0.5;
                float3 ambient = lerp(float3(0.06, 0.09, 0.16), float3(0.24, 0.30, 0.45), hemi);
                float spec = pow(saturate(dot(N, H)), 28.0) * 0.45;
                float rim = pow(1.0 - saturate(dot(N, V)), 2.6);
                float3 col = _BaseColor.rgb * (ambient + ndotl * 0.85) + _EmissionColor.rgb * (0.42 + rim * 1.15) + spec;
                if (_GridIntensity > 0.01) {
                    float2 gp = abs(frac(i.worldPos.xz * 0.5 - 0.5) - 0.5) / max(fwidth(i.worldPos.xz * 0.5), 0.0001);
                    float lineMask = 1.0 - saturate(min(gp.x, gp.y));
                    col += float3(0.0, 0.85, 1.0) * (lineMask * _GridIntensity);
                }
                return fixed4(col, 1.0);
            }
            ENDCG
        }
    }
}
"#;
    fs::write(&shader_path, shader_hlsl).map_err(|e| e.to_string())?;

    let controller_path = root.join("Assets/Scripts/TouchPlayerController.cs");
    let controller_cs = if is_2d {
        format!(
            r#"using UnityEngine;
using UnityEngine.InputSystem;

namespace {pascal_name}
{{
    public class TouchPlayerController : MonoBehaviour
    {{
        [SerializeField] private float moveSpeed = 6.5f;
        private Vector2 _startTouch;
        private Vector2 _moveDir;

        private void Update()
        {{
            ReadInput();
            transform.Translate(new Vector3(_moveDir.x, _moveDir.y, 0f) * (moveSpeed * Time.deltaTime));
        }}

        private void ReadInput()
        {{
            _moveDir = Vector2.zero;
            if (Touchscreen.current != null && Touchscreen.current.primaryTouch.press.isPressed)
            {{
                Vector2 pos = Touchscreen.current.primaryTouch.position.ReadValue();
                if (Touchscreen.current.primaryTouch.press.wasPressedThisFrame)
                    _startTouch = pos;
                Vector2 delta = pos - _startTouch;
                if (delta.sqrMagnitude > 64f)
                    _moveDir = Vector2.ClampMagnitude(delta / 120f, 1f);
            }}
            else if (Keyboard.current != null)
            {{
                float x = (Keyboard.current.dKey.isPressed ? 1f : 0f) - (Keyboard.current.aKey.isPressed ? 1f : 0f);
                float y = (Keyboard.current.wKey.isPressed ? 1f : 0f) - (Keyboard.current.sKey.isPressed ? 1f : 0f);
                _moveDir = Vector2.ClampMagnitude(new Vector2(x, y), 1f);
            }}
        }}
    }}
}}
"#
        )
    } else {
        format!(
            r#"using UnityEngine;
using UnityEngine.InputSystem;

namespace {pascal_name}
{{
    public class TouchPlayerController : MonoBehaviour
    {{
        [SerializeField] private float moveSpeed = 7.0f;
        [SerializeField] private float turnSpeed = 10.0f;
        private Vector2 _startTouch;
        private Vector2 _moveDir;

        private void Update()
        {{
            ReadInput();
            if (_moveDir.sqrMagnitude > 0.001f)
            {{
                Vector3 worldMove = new Vector3(_moveDir.x, 0f, _moveDir.y);
                transform.position += worldMove * (moveSpeed * Time.deltaTime);
                Quaternion targetRot = Quaternion.LookRotation(worldMove, Vector3.up);
                transform.rotation = Quaternion.Slerp(transform.rotation, targetRot, turnSpeed * Time.deltaTime);
            }}
        }}

        private void ReadInput()
        {{
            _moveDir = Vector2.zero;
            if (Touchscreen.current != null && Touchscreen.current.primaryTouch.press.isPressed)
            {{
                Vector2 pos = Touchscreen.current.primaryTouch.position.ReadValue();
                if (Touchscreen.current.primaryTouch.press.wasPressedThisFrame)
                    _startTouch = pos;
                Vector2 delta = pos - _startTouch;
                if (delta.sqrMagnitude > 64f)
                    _moveDir = Vector2.ClampMagnitude(delta / 120f, 1f);
            }}
            else if (Keyboard.current != null)
            {{
                float x = (Keyboard.current.dKey.isPressed ? 1f : 0f) - (Keyboard.current.aKey.isPressed ? 1f : 0f);
                float z = (Keyboard.current.wKey.isPressed ? 1f : 0f) - (Keyboard.current.sKey.isPressed ? 1f : 0f);
                _moveDir = Vector2.ClampMagnitude(new Vector2(x, z), 1f);
            }}
        }}
    }}
}}
"#
        )
    };
    fs::write(&controller_path, controller_cs).map_err(|e| e.to_string())?;

    // 5. Generate `.meta` files first so we get deterministic GUID for TouchPlayerController.cs
    let ctrl_guid = ensure_meta_for_path(&controller_path, "Assets/Scripts/TouchPlayerController.cs")?;

    // 6. Build starter `Assets/Scenes/Main.unity`
    let scene_args = json!({
        "project_dir": root.to_string_lossy(),
        "scene_rel_path": "Assets/Scenes/Main.unity",
        "dimension": if is_2d { "2d" } else { "3d" },
        "objects": [
            {
                "name": "Player",
                "primitive": if is_2d { "sprite" } else { "capsule" },
                "position": [0.0, if is_2d { 0.0 } else { 1.0 }, 0.0],
                "collider": true,
                "script_guid": ctrl_guid,
                "fields": { "moveSpeed": 7.0 }
            },
            {
                "name": "Ground",
                "primitive": if is_2d { "sprite" } else { "cube" },
                "position": [0.0, if is_2d { -3.0 } else { -0.5 }, 0.0],
                "scale": if is_2d { [16.0, 1.0, 1.0] } else { [24.0, 1.0, 24.0] },
                "collider": true
            }
        ]
    });
    let scene_res = scene_build(&scene_args)?;
    let main_scene_guid = scene_res
        .get("guid")
        .and_then(|v| v.as_str())
        .unwrap_or("00000000000000000000000000000000")
        .to_string();

    // 7. EditorBuildSettings.asset + minimal ProjectSettings.asset with Android ARM64 IL2CPP + package ID
    let build_settings = format!(
        "%YAML 1.1\n%TAG !u! tag:unity3d.com,2011:\n--- !u!1045 &1\nEditorBuildSettings:\n  m_ObjectHideFlags: 0\n  serializedVersion: 2\n  m_Scenes:\n  - enabled: 1\n    path: Assets/Scenes/Main.unity\n    guid: {main_scene_guid}\n  m_configObjects: {{}}\n"
    );
    fs::write(
        root.join("ProjectSettings/EditorBuildSettings.asset"),
        build_settings,
    )
    .map_err(|e| e.to_string())?;

    let proj_settings = format!(
        "%YAML 1.1\n%TAG !u! tag:unity3d.com,2011:\n--- !u!129 &1\nPlayerSettings:\n  m_ObjectHideFlags: 0\n  serializedVersion: 26\n  companyName: {company}\n  productName: {project_name}\n  cloudProjectId: \n  projectName: {project_name}\n  organizationId: \n  defaultScreenOrientation: 3\n  bundleVersion: 0.1.0\n  AndroidBundleVersionCode: 1\n  AndroidMinSdkVersion: 26\n  AndroidTargetSdkVersion: 0\n  AndroidPreferredInstallLocation: 1\n  AndroidTargetArchitectures: 2\n  activeInputHandler: 2\n  scriptingBackend:\n    Android: 1\n  applicationIdentifier:\n    Android: {package_id}\n    Standalone: {package_id}\n"
    );
    fs::write(root.join("ProjectSettings/ProjectSettings.asset"), proj_settings)
        .map_err(|e| e.to_string())?;

    // 8. Headless Editor AutoBuilder + optional GitHub Actions GameCI workflow ($0 Cloud Build)
    crate::cloud_ci::write_editor_autobuilder(&root, &package_id)?;
    if with_ci {
        crate::cloud_ci::write_gameci_workflow(&root, &editor_version, &pascal_name)?;
    }

    // 9. Unity .gitignore & .gitattributes
    fs::write(
        root.join(".gitignore"),
        "/[Ll]ibrary/\n/[Tt]emp/\n/[Oo]bj/\n/[Bb]uild/\n/[Bb]uilds/\n/[Ll]ogs/\n/[Uu]ser[Ss]ettings/\n*.csproj\n*.sln\n*.apk\n*.aab\n.gradle/\n",
    )
    .map_err(|e| e.to_string())?;
    fs::write(
        root.join(".gitattributes"),
        "*.unity merge=unityyamlmerge eol=lf\n*.prefab merge=unityyamlmerge eol=lf\n*.asset merge=unityyamlmerge eol=lf\n*.glb filter=lfs diff=lfs merge=lfs -text\n*.png filter=lfs diff=lfs merge=lfs -text\n*.wav filter=lfs diff=lfs merge=lfs -text\n*.ogg filter=lfs diff=lfs merge=lfs -text\n",
    )
    .map_err(|e| e.to_string())?;

    // 10. Ensure every folder & asset inside Assets/ has a deterministic `.meta` file
    let meta_count = ensure_all_assets_meta(&root.join("Assets"), &root)?;

    Ok(json!({
        "project_dir": root.to_string_lossy(),
        "project_name": project_name,
        "dimension": if is_2d { "2d" } else { "3d" },
        "editor_version": editor_version,
        "android_package": package_id,
        "main_scene": "Assets/Scenes/Main.unity",
        "main_scene_guid": main_scene_guid,
        "meta_files_generated": meta_count,
        "github_gameci_workflow": if with_ci { ".github/workflows/unity-android-build.yml" } else { "skipped" }
    }))
}

pub fn script_create(args: &Value) -> Result<Value, String> {
    let proj = PathBuf::from(req_str(args, "project_dir")?);
    let rel_path = req_str(args, "rel_path")?.replace('\\', "/");
    if rel_path.contains("..") || !rel_path.starts_with("Assets/") {
        return Err("`rel_path` must be inside `Assets/` (e.g. `Assets/Scripts/EnemyAI.cs`).".to_string());
    }
    let content = req_str(args, "content")?;
    let full_path = proj.join(&rel_path);
    if let Some(parent) = full_path.parent() {
        fs::create_dir_all(parent).map_err(|e| e.to_string())?;
    }

    let mut warnings = Vec::new();
    if rel_path.ends_with(".cs") {
        let stem = full_path
            .file_stem()
            .and_then(|s| s.to_str())
            .unwrap_or("");
        if (content.contains(": MonoBehaviour") || content.contains(": ScriptableObject"))
            && !content.contains(&format!("class {stem}"))
        {
            warnings.push(format!(
                "Unity requires MonoBehaviour/ScriptableObject filename `{stem}.cs` to match `public class {stem}`!"
            ));
        }
        let open_braces = content.chars().filter(|&c| c == '{').count();
        let close_braces = content.chars().filter(|&c| c == '}').count();
        if open_braces != close_braces {
            return Err(format!(
                "Unbalanced C# braces in `{rel_path}` (`{{`={open_braces}, `}}`={close_braces}). Refusing to write broken script."
            ));
        }
    }

    fs::write(&full_path, &content).map_err(|e| format!("Failed writing {rel_path}: {e}"))?;

    // Ensure parent directories inside Assets/ also have `.meta`
    let mut cur = full_path.parent();
    while let Some(dir) = cur {
        if dir == proj || !dir.starts_with(&proj) {
            break;
        }
        if let Ok(r) = dir.strip_prefix(&proj) {
            let rk = r.to_string_lossy().to_string();
            if rk.starts_with("Assets") && rk != "Assets" {
                let _ = ensure_meta_for_path(dir, &rk);
            }
        }
        cur = dir.parent();
    }

    let guid = ensure_meta_for_path(&full_path, &rel_path)?;
    Ok(json!({
        "rel_path": rel_path,
        "absolute_path": full_path.to_string_lossy(),
        "meta_path": format!("{}.meta", full_path.display()),
        "guid": guid,
        "bytes_written": content.len(),
        "warnings": warnings
    }))
}

/// Pure-Rust Unity `%YAML 1.1` Scene (`.unity`) and Prefab (`.prefab`) generator.
pub fn scene_build(args: &Value) -> Result<Value, String> {
    let proj = PathBuf::from(req_str(args, "project_dir")?);
    let rel_path = req_str(args, "scene_rel_path")?.replace('\\', "/");
    if rel_path.contains("..") || !rel_path.starts_with("Assets/") {
        return Err("`scene_rel_path` must start with `Assets/` and end with `.unity` or `.prefab`.".to_string());
    }
    let is_prefab = rel_path.ends_with(".prefab");
    let dim = opt_str(args, "dimension", "3d").to_ascii_lowercase();
    let is_2d = dim == "2d";

    let mut yaml = String::from("%YAML 1.1\n%TAG !u! tag:unity3d.com,2011:\n");
    let mut next_id: u64 = 100000;

    if !is_prefab {
        // Scene core settings: OcclusionCullingSettings (29), RenderSettings (104), LightmapSettings (157), NavMeshSettings (196)
        yaml.push_str(
            "--- !u!29 &1\nOcclusionCullingSettings:\n  m_ObjectHideFlags: 0\n  serializedVersion: 2\n  m_OcclusionBakeSettings:\n    smallestOccluder: 5\n    smallestHole: 0.25\n    backfaceThreshold: 100\n  m_SceneGUID: 00000000000000000000000000000000\n  m_OcclusionCullingData: {fileID: 0}\n",
        );
        yaml.push_str(
            "--- !u!104 &2\nRenderSettings:\n  m_ObjectHideFlags: 0\n  serializedVersion: 10\n  m_Fog: 0\n  m_AmbientSkyColor: {r: 0.25, g: 0.28, b: 0.35, a: 1}\n  m_SkyboxMaterial: {fileID: 10304, guid: 0000000000000000f000000000000000, type: 0}\n",
        );
        yaml.push_str(
            "--- !u!157 &3\nLightmapSettings:\n  m_ObjectHideFlags: 0\n  serializedVersion: 13\n  m_GIWorkflowMode: 1\n",
        );
        yaml.push_str(
            "--- !u!196 &4\nNavMeshSettings:\n  serializedVersion: 2\n  m_ObjectHideFlags: 0\n  m_NavMeshData: {fileID: 0}\n",
        );

        // Main Camera
        let cam_go = next_id;
        let cam_tr = next_id + 1;
        let cam_cp = next_id + 2;
        let cam_al = next_id + 3;
        next_id += 10;
        let (cz, ortho) = if is_2d { (-10.0, 1) } else { (-8.5, 0) };
        let cy = if is_2d { 0.0 } else { 5.5 };
        let rx = if is_2d { 0.0 } else { 0.26 };
        let rw = if is_2d { 1.0 } else { 0.965 };
        yaml.push_str(&format!(
            "--- !u!1 &{cam_go}\nGameObject:\n  m_ObjectHideFlags: 0\n  serializedVersion: 6\n  m_Component:\n  - component: {{fileID: {cam_tr}}}\n  - component: {{fileID: {cam_cp}}}\n  - component: {{fileID: {cam_al}}}\n  m_Layer: 0\n  m_Name: Main Camera\n  m_TagString: MainCamera\n  m_IsActive: 1\n"
        ));
        yaml.push_str(&format!(
            "--- !u!4 &{cam_tr}\nTransform:\n  m_ObjectHideFlags: 0\n  m_GameObject: {{fileID: {cam_go}}}\n  serializedVersion: 2\n  m_LocalRotation: {{x: {rx}, y: 0, z: 0, w: {rw}}}\n  m_LocalPosition: {{x: 0, y: {cy}, z: {cz}}}\n  m_LocalScale: {{x: 1, y: 1, z: 1}}\n  m_Children: []\n  m_Father: {{fileID: 0}}\n"
        ));
        yaml.push_str(&format!(
            "--- !u!20 &{cam_cp}\nCamera:\n  m_ObjectHideFlags: 0\n  m_GameObject: {{fileID: {cam_go}}}\n  m_Enabled: 1\n  serializedVersion: 2\n  m_ClearFlags: 2\n  m_BackGroundColor: {{r: 0.08, g: 0.10, b: 0.15, a: 1}}\n  orthographic: {ortho}\n  orthographic size: 5\n  field of view: 60\n  near clip plane: 0.3\n  far clip plane: 1000\n  m_Depth: -1\n"
        ));
        yaml.push_str(&format!(
            "--- !u!81 &{cam_al}\nAudioListener:\n  m_ObjectHideFlags: 0\n  m_GameObject: {{fileID: {cam_go}}}\n  m_Enabled: 1\n"
        ));

        if !is_2d {
            // Directional Light
            let lg_go = next_id;
            let lg_tr = next_id + 1;
            let lg_cp = next_id + 2;
            next_id += 10;
            yaml.push_str(&format!(
                "--- !u!1 &{lg_go}\nGameObject:\n  m_ObjectHideFlags: 0\n  serializedVersion: 6\n  m_Component:\n  - component: {{fileID: {lg_tr}}}\n  - component: {{fileID: {lg_cp}}}\n  m_Layer: 0\n  m_Name: Directional Light\n  m_TagString: Untagged\n  m_IsActive: 1\n"
            ));
            yaml.push_str(&format!(
                "--- !u!4 &{lg_tr}\nTransform:\n  m_ObjectHideFlags: 0\n  m_GameObject: {{fileID: {lg_go}}}\n  serializedVersion: 2\n  m_LocalRotation: {{x: 0.40821788, y: -0.23456968, z: 0.10938163, w: 0.8754261}}\n  m_LocalPosition: {{x: 0, y: 10, z: 0}}\n  m_LocalScale: {{x: 1, y: 1, z: 1}}\n  m_Children: []\n  m_Father: {{fileID: 0}}\n"
            ));
            yaml.push_str(&format!(
                "--- !u!108 &{lg_cp}\nLight:\n  m_ObjectHideFlags: 0\n  m_GameObject: {{fileID: {lg_go}}}\n  m_Enabled: 1\n  serializedVersion: 11\n  m_Type: 1\n  m_Color: {{r: 1, g: 0.96, b: 0.9, a: 1}}\n  m_Intensity: 1.2\n  m_Shadows:\n    m_Type: 2\n"
            ));
        }
    }

    let mut created_objects = 0usize;
    if let Some(objs) = args.get("objects").and_then(|v| v.as_array()) {
        for obj in objs {
            let name = obj.get("name").and_then(|v| v.as_str()).unwrap_or("Entity");
            let prim = obj
                .get("primitive")
                .and_then(|v| v.as_str())
                .unwrap_or("empty")
                .to_ascii_lowercase();
            let pos = vec3_from_json(obj.get("position"), [0.0, 0.0, 0.0]);
            let scale = vec3_from_json(obj.get("scale"), [1.0, 1.0, 1.0]);
            let want_collider = obj.get("collider").and_then(|v| v.as_bool()).unwrap_or(false);
            let want_rb = obj.get("rigidbody").and_then(|v| v.as_bool()).unwrap_or(false);
            let script_guid = obj
                .get("script_guid")
                .and_then(|v| v.as_str())
                .unwrap_or("")
                .trim();

            let go_id = next_id;
            let tr_id = next_id + 1;
            next_id += 2;
            let mut comps = vec![tr_id];
            let mut extra_blocks = String::new();

            // Built-in Unity primitive mesh GUID: 0000000000000000e000000000000000
            // Cube=10202, Sphere=10207, Capsule=10208, Plane=10209
            let mesh_fid: Option<u64> = match prim.as_str() {
                "cube" => Some(10202),
                "sphere" => Some(10207),
                "capsule" => Some(10208),
                "plane" => Some(10209),
                _ => None,
            };

            if let Some(mf_builtin) = mesh_fid {
                let mf_id = next_id;
                let mr_id = next_id + 1;
                next_id += 2;
                comps.push(mf_id);
                comps.push(mr_id);
                extra_blocks.push_str(&format!(
                    "--- !u!33 &{mf_id}\nMeshFilter:\n  m_ObjectHideFlags: 0\n  m_GameObject: {{fileID: {go_id}}}\n  m_Mesh: {{fileID: {mf_builtin}, guid: 0000000000000000e000000000000000, type: 0}}\n"
                ));
                extra_blocks.push_str(&format!(
                    "--- !u!23 &{mr_id}\nMeshRenderer:\n  m_ObjectHideFlags: 0\n  m_GameObject: {{fileID: {go_id}}}\n  m_Enabled: 1\n  m_Materials:\n  - {{fileID: 10303, guid: 0000000000000000f000000000000000, type: 0}}\n"
                ));
            } else if prim == "sprite" {
                let sr_id = next_id;
                next_id += 1;
                comps.push(sr_id);
                extra_blocks.push_str(&format!(
                    "--- !u!212 &{sr_id}\nSpriteRenderer:\n  m_ObjectHideFlags: 0\n  m_GameObject: {{fileID: {go_id}}}\n  m_Enabled: 1\n  m_Color: {{r: 1, g: 1, b: 1, a: 1}}\n"
                ));
            }

            if want_collider {
                let col_id = next_id;
                next_id += 1;
                comps.push(col_id);
                if prim == "sprite" || is_2d {
                    extra_blocks.push_str(&format!(
                        "--- !u!61 &{col_id}\nBoxCollider2D:\n  m_ObjectHideFlags: 0\n  m_GameObject: {{fileID: {go_id}}}\n  m_Enabled: 1\n  m_Size: {{x: 1, y: 1}}\n"
                    ));
                } else if prim == "capsule" {
                    extra_blocks.push_str(&format!(
                        "--- !u!136 &{col_id}\nCapsuleCollider:\n  m_ObjectHideFlags: 0\n  m_GameObject: {{fileID: {go_id}}}\n  m_Enabled: 1\n  m_Radius: 0.5\n  m_Height: 2\n"
                    ));
                } else if prim == "sphere" {
                    extra_blocks.push_str(&format!(
                        "--- !u!135 &{col_id}\nSphereCollider:\n  m_ObjectHideFlags: 0\n  m_GameObject: {{fileID: {go_id}}}\n  m_Enabled: 1\n  m_Radius: 0.5\n"
                    ));
                } else {
                    extra_blocks.push_str(&format!(
                        "--- !u!65 &{col_id}\nBoxCollider:\n  m_ObjectHideFlags: 0\n  m_GameObject: {{fileID: {go_id}}}\n  m_Enabled: 1\n  m_Size: {{x: 1, y: 1, z: 1}}\n"
                    ));
                }
            }

            if want_rb {
                let rb_id = next_id;
                next_id += 1;
                comps.push(rb_id);
                if prim == "sprite" || is_2d {
                    extra_blocks.push_str(&format!(
                        "--- !u!50 &{rb_id}\nRigidbody2D:\n  serializedVersion: 4\n  m_ObjectHideFlags: 0\n  m_GameObject: {{fileID: {go_id}}}\n  m_BodyType: 0\n  m_Simulated: 1\n  m_Mass: 1\n  m_GravityScale: 1\n"
                    ));
                } else {
                    extra_blocks.push_str(&format!(
                        "--- !u!54 &{rb_id}\nRigidbody:\n  serializedVersion: 4\n  m_ObjectHideFlags: 0\n  m_GameObject: {{fileID: {go_id}}}\n  m_Mass: 1\n  m_UseGravity: 1\n  m_IsKinematic: 0\n"
                    ));
                }
            }

            if script_guid.len() == 32 {
                let mb_id = next_id;
                next_id += 1;
                comps.push(mb_id);
                let mut custom_fields = String::new();
                if let Some(fmap) = obj.get("fields").and_then(|v| v.as_object()) {
                    for (fk, fv) in fmap {
                        let rendered = match fv {
                            Value::Number(n) => n.to_string(),
                            Value::Bool(b) => if *b { "1" } else { "0" }.to_string(),
                            Value::String(s) => s.clone(),
                            _ => fv.to_string(),
                        };
                        custom_fields.push_str(&format!("  {fk}: {rendered}\n"));
                    }
                }
                extra_blocks.push_str(&format!(
                    "--- !u!114 &{mb_id}\nMonoBehaviour:\n  m_ObjectHideFlags: 0\n  m_GameObject: {{fileID: {go_id}}}\n  m_Enabled: 1\n  m_EditorHideFlags: 0\n  m_Script: {{fileID: 11500000, guid: {script_guid}, type: 3}}\n  m_Name: \n  m_EditorClassIdentifier: \n{custom_fields}"
                ));
            }

            let comp_lines: String = comps
                .iter()
                .map(|cid| format!("  - component: {{fileID: {cid}}}\n"))
                .collect();
            yaml.push_str(&format!(
                "--- !u!1 &{go_id}\nGameObject:\n  m_ObjectHideFlags: 0\n  serializedVersion: 6\n  m_Component:\n{comp_lines}  m_Layer: 0\n  m_Name: {name}\n  m_TagString: Untagged\n  m_IsActive: 1\n"
            ));
            yaml.push_str(&format!(
                "--- !u!4 &{tr_id}\nTransform:\n  m_ObjectHideFlags: 0\n  m_GameObject: {{fileID: {go_id}}}\n  serializedVersion: 2\n  m_LocalRotation: {{x: 0, y: 0, z: 0, w: 1}}\n  m_LocalPosition: {{x: {}, y: {}, z: {}}}\n  m_LocalScale: {{x: {}, y: {}, z: {}}}\n  m_Children: []\n  m_Father: {{fileID: 0}}\n",
                pos[0], pos[1], pos[2], scale[0], scale[1], scale[2]
            ));
            yaml.push_str(&extra_blocks);
            created_objects += 1;
        }
    }

    let full_path = proj.join(&rel_path);
    if let Some(parent) = full_path.parent() {
        fs::create_dir_all(parent).map_err(|e| e.to_string())?;
    }
    fs::write(&full_path, &yaml).map_err(|e| e.to_string())?;
    let guid = ensure_meta_for_path(&full_path, &rel_path)?;

    Ok(json!({
        "scene_rel_path": rel_path,
        "absolute_path": full_path.to_string_lossy(),
        "guid": guid,
        "kind": if is_prefab { "prefab" } else { "scene" },
        "custom_gameobjects_written": created_objects,
        "yaml_bytes": yaml.len()
    }))
}

fn vec3_from_json(v: Option<&Value>, def: [f64; 3]) -> [f64; 3] {
    if let Some(arr) = v.and_then(|x| x.as_array()) {
        if arr.len() >= 3 {
            return [
                arr[0].as_f64().unwrap_or(def[0]),
                arr[1].as_f64().unwrap_or(def[1]),
                arr[2].as_f64().unwrap_or(def[2]),
            ];
        }
    }
    def
}

pub fn ensure_all_assets_meta(dir: &Path, project_root: &Path) -> Result<usize, String> {
    let mut count = 0usize;
    let entries = match fs::read_dir(dir) {
        Ok(e) => e,
        Err(_) => return Ok(0),
    };
    for entry in entries.flatten() {
        let p = entry.path();
        let name = entry.file_name().to_string_lossy().to_string();
        if name.starts_with('.') || name.ends_with(".meta") {
            continue;
        }
        let rel = p
            .strip_prefix(project_root)
            .map(|r| r.to_string_lossy().replace('\\', "/"))
            .unwrap_or_else(|_| unity_guid_from_seed(&name));
        ensure_meta_for_path(&p, &rel)?;
        count += 1;
        if p.is_dir() {
            count += ensure_all_assets_meta(&p, project_root)?;
        }
    }
    Ok(count)
}
