use crate::util::{ensure_meta_for_path, find_bin, opt_str, prefix_dir, req_str};
use serde_json::{json, Value};
use std::fs;
use std::path::{Path, PathBuf};
use std::process::Command;

pub fn write_editor_autobuilder(project_root: &Path, package_id: &str) -> Result<(), String> {
    let editor_dir = project_root.join("Assets/Editor");
    fs::create_dir_all(&editor_dir).map_err(|e| e.to_string())?;
    let script_path = editor_dir.join("AndroidAutoBuilder.cs");
    let code = format!(
        r#"using System;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEditor.Build;
using UnityEditor.Build.Reporting;
using UnityEngine;

public static class AndroidAutoBuilder
{{
    public static void BuildApk()
    {{
        RunAndroidBuild(false);
    }}

    public static void BuildAab()
    {{
        RunAndroidBuild(true);
    }}

    private static void ConfigureAndroidToolchains()
    {{
        string sdk = Environment.GetEnvironmentVariable("ANDROID_SDK_ROOT")
            ?? Environment.GetEnvironmentVariable("ANDROID_HOME")
            ?? "/opt/unity/Editor/Data/PlaybackEngines/AndroidPlayer/SDK";
        if (Directory.Exists(sdk))
            EditorPrefs.SetString("AndroidSdkRoot", sdk);

        string ndk = Environment.GetEnvironmentVariable("ANDROID_NDK_HOME")
            ?? Environment.GetEnvironmentVariable("ANDROID_NDK_ROOT")
            ?? "/opt/unity/Editor/Data/PlaybackEngines/AndroidPlayer/NDK";
        if (Directory.Exists(ndk))
            EditorPrefs.SetString("AndroidNdkRoot", ndk);

        string jdk = Environment.GetEnvironmentVariable("JAVA_HOME")
            ?? "/opt/unity/Editor/Data/PlaybackEngines/AndroidPlayer/OpenJDK";
        if (Directory.Exists(jdk))
            EditorPrefs.SetString("JdkPath", jdk);

        Debug.Log($"[AndroidAutoBuilder] Toolchains -> SDK={{sdk}}, NDK={{ndk}}, JDK={{jdk}}");
    }}

    private static void RunAndroidBuild(bool appBundle)
    {{
        ConfigureAndroidToolchains();

        string[] scenes = EditorBuildSettings.scenes
            .Where(s => s.enabled)
            .Select(s => s.path)
            .ToArray();

        if (scenes.Length == 0)
            throw new Exception("No enabled scenes found in EditorBuildSettings.asset!");

        EditorUserBuildSettings.buildAppBundle = appBundle;
        PlayerSettings.Android.useCustomKeystore = false;
        PlayerSettings.Android.optimizedFramePacing = false;
        PlayerSettings.Android.minSdkVersion = AndroidSdkVersions.AndroidApiLevel26;
        PlayerSettings.Android.targetSdkVersion = AndroidSdkVersions.AndroidApiLevelAuto;
        PlayerSettings.SetApplicationIdentifier(NamedBuildTarget.Android, "{package_id}");
        PlayerSettings.SetScriptingBackend(NamedBuildTarget.Android, ScriptingImplementation.IL2CPP);
        PlayerSettings.Android.targetArchitectures = AndroidArchitecture.ARM64;

        string outDir = "build/Android";
        Directory.CreateDirectory(outDir);
        string outFile = Path.Combine(outDir, appBundle ? "game-release.aab" : "game-arm64.apk");

        var opts = new BuildPlayerOptions
        {{
            scenes = scenes,
            locationPathName = outFile,
            target = BuildTarget.Android,
            options = BuildOptions.None
        }};

        BuildReport report = BuildPipeline.BuildPlayer(opts);
        if (report.summary.result != BuildResult.Succeeded)
            throw new Exception($"Android build failed: {{report.summary.result}} ({{report.summary.totalErrors}} errors)");

        Debug.Log($"[AndroidAutoBuilder] Build succeeded -> {{outFile}} ({{report.summary.totalSize}} bytes)");
    }}
}}
"#
    );
    fs::write(&script_path, code).map_err(|e| e.to_string())?;
    let _ = ensure_meta_for_path(&editor_dir, "Assets/Editor");
    let _ = ensure_meta_for_path(&script_path, "Assets/Editor/AndroidAutoBuilder.cs");
    Ok(())
}

pub fn write_gameci_workflow(project_root: &Path, editor_version: &str, artifact_slug: &str) -> Result<PathBuf, String> {
    let wf_dir = project_root.join(".github/workflows");
    fs::create_dir_all(&wf_dir).map_err(|e| e.to_string())?;
    let wf_path = wf_dir.join("unity-android-build.yml");
    let yml = format!(
        r#"name: Unity Android ARM64 Build (Zero-PC Cloud CI)

on:
  workflow_dispatch:
    inputs:
      build_aab:
        description: "Build Google Play .aab instead of .apk"
        required: false
        default: "false"
  push:
    branches: [ "main", "master" ]

permissions:
  contents: write
  issues: write

jobs:
  build-android:
    name: Build Android ARM64 IL2CPP APK
    runs-on: ubuntu-latest
    steps:
      - name: Free GitHub Runner Disk Space
        run: |
          df -h /
          for d in /usr/share/dotnet /opt/ghc /usr/local/share/boost /usr/local/lib/android /opt/hostedtoolcache/CodeQL; do
            sudo rm -rf "$d" &
          done
          wait
          docker system prune -af || true
          df -h /

      - name: Checkout repository
        uses: actions/checkout@v4
        with:
          lfs: true

      - name: Cache Unity Library
        uses: actions/cache@v4
        with:
          path: Library
          key: Library-Android-{editor_version}-${{{{ hashFiles('Assets/**', 'Packages/**', 'ProjectSettings/**') }}}}
          restore-keys: |
            Library-Android-{editor_version}-
            Library-Android-

      - name: Pull Unity 6 Android Editor Image
        run: |
          docker pull unityci/editor:ubuntu-{editor_version}-android-3
          df -h /

      - name: Activate Free Unity Personal License & Compile Android ARM64 APK
        env:
          UNITY_LICENSE: ${{{{ secrets.UNITY_LICENSE }}}}
          GH_TOKEN: ${{{{ secrets.GITHUB_TOKEN }}}}
          GITHUB_REPO: ${{{{ github.repository }}}}
          BUILD_AAB: ${{{{ github.event.inputs.build_aab }}}}
        run: |
          HOST_UID="$(id -u)"
          HOST_GID="$(id -g)"
          docker run --rm -i \
            --shm-size=2g \
            -v "$GITHUB_WORKSPACE:/workspace" \
            -w /workspace \
            -e UNITY_LICENSE \
            -e GH_TOKEN \
            -e GITHUB_REPO \
            -e BUILD_AAB \
            -e HOST_UID="$HOST_UID" \
            -e HOST_GID="$HOST_GID" \
            unityci/editor:ubuntu-{editor_version}-android-3 \
            bash -s << 'EOSCRIPT'
          set -euo pipefail
          export HOME="/root"
          mkdir -p /root/.cache /root/.config /root/.local/share
          unset XDG_CONFIG_HOME XDG_DATA_HOME CI GITHUB_ACTIONS UNITY_NON_INTERACTIVE || true

          if [ ! -s /etc/machine-id ]; then
            cat /proc/sys/kernel/random/uuid | tr -d '-' > /etc/machine-id || true
          fi
          if [ ! -e /var/lib/dbus/machine-id ]; then
            mkdir -p /var/lib/dbus
            ln -sf /etc/machine-id /var/lib/dbus/machine-id || true
          fi

          cleanup() {{
            set +e
            if [ -n "${{HOST_UID:-}}" ] && [ -n "${{HOST_GID:-}}" ]; then
              chown -R "${{HOST_UID}}:${{HOST_GID}}" /workspace/Library /workspace/build 2>/dev/null || true
            fi
          }}
          trap cleanup EXIT

          git config --global --add safe.directory /workspace || true

          if [ -n "${{UNITY_LICENSE:-}}" ]; then
            mkdir -p /root/.local/share/unity3d/Unity
            printf '%s' "$UNITY_LICENSE" > /root/.local/share/unity3d/Unity/Unity_lic.ulf
            echo "Activated from UNITY_LICENSE secret."
          else
            if ! command -v brotli >/dev/null 2>&1 || ! command -v jq >/dev/null 2>&1; then
              apt-get update -y || true
              DEBIAN_FRONTEND=noninteractive apt-get install -y --no-install-recommends brotli ca-certificates curl coreutils jq
            fi
            curl -fsSL https://public-cdn.cloud.unity3d.com/hub/prod/cli/1.0.0/unity-linux-x64.br | brotli -d > /usr/local/bin/unity-cli
            chmod 755 /usr/local/bin/unity-cli

            LIC_BIN="$(find /opt/unity -name 'Unity.Licensing.Client' -type f -print -quit)"
            echo "Found Unity.Licensing.Client at: $LIC_BIN"
            export UNITY_CLI_INTERNAL_LICENSING_CLIENT_PATH="$LIC_BIN"
            export UNITY_INSECURE_STORAGE=1
            export UNITY_NO_UPDATE_CHECK=1
            export UNITY_NO_CRASH_REPORT=1
            export UNITY_NO_CLI_INVOKED_TELEMETRY=1
            export DO_NOT_TRACK=1
            export BROWSER="/bin/true"

            rm -f /tmp/unity-login.log
            stdbuf -oL -eL /usr/local/bin/unity-cli auth login --insecure-storage --no-banner --no-color > /tmp/unity-login.log 2>&1 &
            LOGIN_PID=$!

            ISSUE_URL=""
            for i in $(seq 1 45); do
              SIGNIN_URL="$(grep -m 1 -Eo 'https://(services\.api|id|login)\.unity\.com[^[:space:]]+' /tmp/unity-login.log 2>/dev/null || true)"
              if [ -n "$SIGNIN_URL" ]; then
                echo "OAuth URL generated, posting confirmation notification..."
                BODY="$(jq -n --arg u "$SIGNIN_URL" '{{"title":"Unity CI OAuth Confirmation","body":$u}}')"
                ISSUE_URL="$(curl -fsSL -X POST \
                  -H "Authorization: Bearer $GH_TOKEN" \
                  -H "Accept: application/vnd.github+json" \
                  "https://api.github.com/repos/${{GITHUB_REPO}}/issues" \
                  -d "$BODY" | jq -r '.url // empty' || true)"
                break
              fi
              if ! kill -0 "$LOGIN_PID" 2>/dev/null; then
                echo "unity-cli auth login exited early:"
                cat /tmp/unity-login.log || true
                break
              fi
              sleep 1
            done

            wait "$LOGIN_PID" || {{
              echo "unity-cli auth login failed:"
              cat /tmp/unity-login.log || true
              exit 1
            }}

            if [ -n "$ISSUE_URL" ]; then
              curl -fsSL -X PATCH \
                -H "Authorization: Bearer $GH_TOKEN" \
                -H "Accept: application/vnd.github+json" \
                "$ISSUE_URL" \
                -d '{{"state":"closed","body":"OAuth confirmed and consumed."}}' >/dev/null 2>&1 || true
            fi

            /usr/local/bin/unity-cli auth status --no-color || true
            /usr/local/bin/unity-cli license activate --personal --accept-eula --no-color --verbose
            /usr/local/bin/unity-cli license status --no-color || true
          fi

          METHOD="AndroidAutoBuilder.BuildApk"
          if [ "${{BUILD_AAB:-false}}" = "true" ]; then
            METHOD="AndroidAutoBuilder.BuildAab"
          fi

          echo "Starting Unity 6 Android ARM64 IL2CPP build ($METHOD)..."
          xvfb-run --auto-servernum --server-args='-screen 0 640x480x24' \
            /opt/unity/Editor/Unity \
            -batchmode \
            -nographics \
            -quit \
            -projectPath /workspace \
            -buildTarget Android \
            -executeMethod "$METHOD" \
            -logFile /tmp/unity-build.log || {{
              echo "=== UNITY COMPILER / BUILD ERRORS ==="
              grep -iE "error CS|BuildFailedException|Exception:|Licensing|Error" /tmp/unity-build.log | tail -n 100 || true
              echo "=== LOG TAIL ==="
              tail -n 150 /tmp/unity-build.log || true
              exit 1
            }}
          ls -lh /workspace/build/Android/
          EOSCRIPT

      - name: Upload Compiled Android Artifact
        uses: actions/upload-artifact@v4
        with:
          name: {artifact_slug}-android-arm64
          path: |
            build/Android/*.apk
            build/Android/*.aab
          retention-days: 14
"#
    );
    fs::write(&wf_path, yml).map_err(|e| e.to_string())?;
    Ok(wf_path)
}

pub fn ci_workflow(args: &Value) -> Result<Value, String> {
    let action = req_str(args, "action")?.to_ascii_lowercase();
    match action.as_str() {
        "scaffold" => {
            let proj = PathBuf::from(req_str(args, "project_dir")?);
            let editor_ver = opt_str(args, "editor_version", "6000.3.28f1");
            let pkg_id = opt_str(args, "android_package", "com.agystudio.unitygame");
            let slug = opt_str(args, "artifact_name", "unity-game");
            write_editor_autobuilder(&proj, &pkg_id)?;
            let wf = write_gameci_workflow(&proj, &editor_ver, &slug)?;
            Ok(json!({
                "action": "scaffold",
                "workflow_path": wf.to_string_lossy(),
                "editor_builder_script": proj.join("Assets/Editor/AndroidAutoBuilder.cs").to_string_lossy(),
                "free_tier_notes": "Public GitHub repos have UNLIMITED $0 free minutes; private repos include 2,000 free min/month. Supports `UNITY_LICENSE` secret or interactive OAuth Personal activation via official `unity-cli`."
            }))
        }
        "trigger" | "status" | "logs" | "download_apk" => {
            let repo = req_str(args, "github_repo")?;
            let gh = find_bin("gh").ok_or("`gh` CLI not found in $PREFIX/bin")?;
            let pfx = prefix_dir();
            let mut cmd = Command::new(&gh);
            cmd.env("GODEBUG", "netdns=cgo")
                .env("SSL_CERT_FILE", pfx.join("etc/tls/cert.pem"));

            match action.as_str() {
                "trigger" => {
                    let wf_file = opt_str(args, "workflow_file", "unity-android-build.yml");
                    let out = cmd
                        .args(["workflow", "run", &wf_file, "--repo", &repo])
                        .output()
                        .map_err(|e| e.to_string())?;
                    Ok(json!({
                        "action": "trigger",
                        "repo": repo,
                        "success": out.status.success(),
                        "output": format!("{}{}", String::from_utf8_lossy(&out.stdout), String::from_utf8_lossy(&out.stderr)).trim()
                    }))
                }
                "status" => {
                    let out = cmd
                        .args([
                            "run",
                            "list",
                            "--repo",
                            &repo,
                            "--limit",
                            "5",
                            "--json",
                            "databaseId,status,conclusion,workflowName,createdAt,url",
                        ])
                        .output()
                        .map_err(|e| e.to_string())?;
                    let parsed = serde_json::from_slice::<Value>(&out.stdout).unwrap_or(Value::Null);
                    Ok(json!({
                        "action": "status",
                        "repo": repo,
                        "runs": parsed,
                        "stderr": String::from_utf8_lossy(&out.stderr).trim()
                    }))
                }
                "logs" => {
                    let run_id = req_str(args, "run_id")?;
                    let out = cmd
                        .args(["run", "view", &run_id, "--repo", &repo, "--log-failed"])
                        .output()
                        .map_err(|e| e.to_string())?;
                    let raw = String::from_utf8_lossy(&out.stdout);
                    let cs_errors: Vec<&str> = raw
                        .lines()
                        .filter(|l| l.contains("error CS") || l.contains("BuildFailedException") || l.contains("Exception:"))
                        .take(50)
                        .collect();
                    Ok(json!({
                        "action": "logs",
                        "run_id": run_id,
                        "csharp_compiler_errors": cs_errors,
                        "tail_log": raw.chars().rev().take(4000).collect::<String>().chars().rev().collect::<String>()
                    }))
                }
                "download_apk" => {
                    let run_id = req_str(args, "run_id")?;
                    let dest = opt_str(args, "download_dir", "/storage/emulated/0/Download/UnityBuilds");
                    fs::create_dir_all(&dest).map_err(|e| e.to_string())?;
                    let out = cmd
                        .args(["run", "download", &run_id, "--repo", &repo, "--dir", &dest])
                        .output()
                        .map_err(|e| e.to_string())?;
                    Ok(json!({
                        "action": "download_apk",
                        "run_id": run_id,
                        "download_dir": dest,
                        "success": out.status.success(),
                        "details": format!("{}{}", String::from_utf8_lossy(&out.stdout), String::from_utf8_lossy(&out.stderr)).trim()
                    }))
                }
                _ => unreachable!(),
            }
        }
        _ => Err("Invalid `action`: expected 'scaffold', 'trigger', 'status', 'logs', or 'download_apk'.".to_string()),
    }
}

/// Optional HTTP JSON-RPC bridge to a desktop Unity Editor MCP server on LAN or Tailscale.
pub fn remote_mcp(args: &Value) -> Result<Value, String> {
    let endpoint = req_str(args, "endpoint_url")?;
    let method = opt_str(args, "rpc_method", "tools/list");
    let params = args.get("rpc_params").cloned().unwrap_or_else(|| json!({}));
    let curl = find_bin("curl").ok_or("`curl` binary not found")?;

    let body = serde_json::to_string(&json!({
        "jsonrpc": "2.0",
        "id": 1,
        "method": method,
        "params": params
    }))
    .map_err(|e| e.to_string())?;

    let out = Command::new(curl)
        .args([
            "-sS",
            "--max-time",
            "15",
            "-X",
            "POST",
            &endpoint,
            "-H",
            "Content-Type: application/json",
            "-d",
            &body,
        ])
        .output()
        .map_err(|e| e.to_string())?;

    if !out.status.success() {
        return Err(format!(
            "Failed reaching remote Unity Editor endpoint {endpoint}: {}",
            String::from_utf8_lossy(&out.stderr)
        ));
    }
    let resp_str = String::from_utf8_lossy(&out.stdout).trim().to_string();
    let parsed = serde_json::from_str::<Value>(&resp_str).ok();
    Ok(json!({
        "endpoint_url": endpoint,
        "rpc_method": method,
        "response": parsed.unwrap_or(Value::String(resp_str))
    }))
}
