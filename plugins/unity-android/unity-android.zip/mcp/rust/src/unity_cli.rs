use crate::util::{find_bin, home_dir, opt_bool, opt_i64, opt_str, prefix_dir};
use serde_json::{json, Value};
use std::collections::HashSet;
use std::fs;
use std::os::unix::fs::{symlink, PermissionsExt};
use std::path::{Path, PathBuf};
use std::process::Command;

const CDN_BASE: &str = "https://public-cdn.cloud.unity3d.com/hub/prod/cli";
const OLD_TERMUX_PFX: &[u8; 31] = b"/data/data/com.termux/files/usr";
const NEW_AGY_PFX: &[u8; 31] = b"/data/user/0/com.agy//files/usr";

pub fn unity_opt_dir() -> PathBuf {
    prefix_dir().join("opt/unity-cli")
}

pub fn unity_bin_path() -> PathBuf {
    unity_opt_dir().join("unity-bin")
}

/// Configure clean glibc execution environment for the ported `unity-linux-arm64` binary.
/// Must strip Bionic `LD_PRELOAD` (`libtermux-exec.so`) and `LD_LIBRARY_PATH` so glibc `ld-linux-aarch64.so.1` never loads Bionic `.so` files.
pub fn build_unity_command() -> Result<Command, String> {
    let bin = unity_bin_path();
    if !bin.is_file() {
        return Err(
            "Ported `unity-cli` binary is not installed yet. Call `unity_cli_setup` (or run `agy-unity setup` in terminal) to download and patch `unity-linux-arm64`.".to_string(),
        );
    }
    let pfx = prefix_dir();
    let home = home_dir();
    let mut cmd = Command::new(&bin);
    cmd.env_remove("LD_PRELOAD")
        .env_remove("LD_LIBRARY_PATH")
        .env("HOME", &home)
        .env("PREFIX", &pfx)
        .env("TMPDIR", pfx.join("tmp"))
        .env("BROWSER", pfx.join("bin/xdg-open"))
        .env(
            "PATH",
            format!(
                "{}:{}:/system/bin",
                pfx.join("bin").display(),
                home.join("runtime/bin").display()
            ),
        )
        .env("UNITY_NO_UPDATE_CHECK", "1")
        .env("UNITY_NO_CRASH_REPORT", "1")
        .env("UNITY_NO_CLI_INVOKED_TELEMETRY", "1")
        .env("UNITY_NO_AGENT_HINTS", "1")
        .env("DO_NOT_TRACK", "1");

    let cert = pfx.join("etc/tls/cert.pem");
    if cert.is_file() {
        cmd.env("SSL_CERT_FILE", &cert);
        cmd.env("CURL_CA_BUNDLE", &cert);
    }
    let cert_dir = pfx.join("etc/tls/certs");
    if cert_dir.is_dir() {
        cmd.env("SSL_CERT_DIR", &cert_dir);
    }
    Ok(cmd)
}

pub fn cli_probe_quick() -> Value {
    let bin = unity_bin_path();
    if !bin.is_file() {
        return json!({
            "installed": false,
            "binary_path": bin.to_string_lossy()
        });
    }

    let mut version_json = Value::Null;
    if let Ok(mut cmd) = build_unity_command() {
        if let Ok(out) = cmd.args(["version", "--format", "json"]).output() {
            if let Ok(v) = serde_json::from_slice::<Value>(&out.stdout) {
                version_json = v.get("data").cloned().unwrap_or(v);
            }
        }
    }

    let mut auth_json = Value::Null;
    if let Ok(mut cmd) = build_unity_command() {
        if let Ok(out) = cmd.args(["auth", "status", "--format", "json"]).output() {
            if let Ok(v) = serde_json::from_slice::<Value>(&out.stdout) {
                auth_json = v.get("data").cloned().unwrap_or(v);
            }
        }
    }

    json!({
        "installed": true,
        "binary_path": bin.to_string_lossy(),
        "glibc_patched_lib_dir": unity_opt_dir().join("lib").to_string_lossy(),
        "version_info": version_json,
        "auth_status": auth_json
    })
}

/// Execute any official `unity` CLI command safely, keeping stdout and stderr strictly separated.
pub fn cli_exec(args: &Value) -> Result<Value, String> {
    let mut argv: Vec<String> = if let Some(arr) = args.get("args").and_then(|v| v.as_array()) {
        arr.iter()
            .filter_map(|x| x.as_str().map(|s| s.to_string()))
            .collect()
    } else {
        let raw = opt_str(args, "command", "");
        if raw.is_empty() {
            return Err("Provide `args` (array of strings, e.g. [\"releases\"]) or `command` string.".to_string());
        }
        split_shell_words(&raw)
    };

    if argv.first().map(|s| s == "unity").unwrap_or(false) {
        argv.remove(0);
    }
    if argv.is_empty() {
        return Err("Empty Unity CLI arguments.".to_string());
    }

    let json_mode = opt_bool(args, "json_output", true);
    let has_fmt = argv
        .iter()
        .any(|a| a == "--format" || a.starts_with("--format=") || a == "--json" || a == "--help" || a == "-h");
    if json_mode && !has_fmt {
        argv.push("--format".to_string());
        argv.push("json".to_string());
    }

    let proj_dir = opt_str(args, "project_dir", "");
    let _timeout_sec = opt_i64(args, "timeout_sec", 60).clamp(5, 300);

    let mut cmd = build_unity_command()?;
    if !proj_dir.is_empty() {
        let p = PathBuf::from(&proj_dir);
        if p.is_dir() {
            cmd.current_dir(&p);
        }
    }
    cmd.args(&argv);

    let out = cmd.output().map_err(|e| format!("Failed spawning unity-cli: {e}"))?;
    let code = out.status.code().unwrap_or(-1);
    let stdout_str = String::from_utf8_lossy(&out.stdout).trim().to_string();
    let stderr_str = String::from_utf8_lossy(&out.stderr).trim().to_string();

    let parsed_json = serde_json::from_str::<Value>(&stdout_str).ok();
    let success = if let Some(ref j) = parsed_json {
        j.get("success").and_then(|b| b.as_bool()).unwrap_or(code == 0)
    } else {
        code == 0
    };

    Ok(json!({
        "exit_code": code,
        "success": success,
        "invoked_args": argv,
        "envelope": parsed_json,
        "raw_stdout": if parsed_json.is_some() { Value::Null } else { Value::String(stdout_str) },
        "diagnostics_stderr": stderr_str
    }))
}

/// Pure-Rust self-healing installer & 31-byte Android glibc binary patcher for official `unity-linux-arm64`.
pub fn cli_setup(args: &Value) -> Result<Value, String> {
    let force_download = opt_bool(args, "force_download", false);
    let channel = opt_str(args, "channel", "stable");
    let pfx = prefix_dir();
    let opt = unity_opt_dir();
    let lib_dst = opt.join("lib");
    let orig_bin = opt.join("unity.orig");
    let patched_bin = unity_bin_path();

    fs::create_dir_all(&lib_dst).map_err(|e| e.to_string())?;

    // 1. Ensure glibc + patchelf + brotli exist via pkg if missing
    let glibc_ld = pfx.join("glibc/lib/ld-linux-aarch64.so.1");
    if !glibc_ld.exists() || find_bin("patchelf").is_none() || find_bin("brotli").is_none() {
        let pkg = find_bin("pkg").ok_or("`pkg` manager not found in $PREFIX/bin")?;
        let _ = Command::new(&pkg).args(["install", "patchelf", "brotli", "glibc-repo"]).status();
        let _ = Command::new(&pkg).arg("update").status();
        let st = Command::new(&pkg)
            .args([
                "install",
                "glibc",
                "gcc-libs-glibc",
                "openssl-glibc",
                "zlib-glibc",
                "libicu-glibc",
                "ca-certificates-glibc",
                "resolv-conf",
            ])
            .status()
            .map_err(|e| format!("pkg install glibc failed: {e}"))?;
        if !st.success() && !glibc_ld.exists() {
            return Err("Failed installing `glibc` runtime packages via `pkg`.".to_string());
        }
    }

    // 2. Ensure nsswitch.conf, resolv.conf (single-request-reopen to prevent 5s Android NAT A/AAAA UDP drop), and gai.conf exist in $PREFIX/glibc/etc
    let glibc_etc = pfx.join("glibc/etc");
    let _ = fs::create_dir_all(&glibc_etc);
    let nss_path = glibc_etc.join("nsswitch.conf");
    if !nss_path.exists() {
        let _ = fs::write(
            &nss_path,
            "hosts: files dns\nnetworks: files\nservices: files\nprotocols: files\n",
        );
    }
    let resolv_path = glibc_etc.join("resolv.conf");
    let resolv_cur = fs::read_to_string(&resolv_path).unwrap_or_default();
    if !resolv_cur.contains("single-request-reopen") {
        let _ = fs::write(
            &resolv_path,
            "options single-request-reopen timeout:1 attempts:2\nnameserver 1.1.1.1\nnameserver 8.8.8.8\n",
        );
    }
    let gai_path = glibc_etc.join("gai.conf");
    if let Ok(gai_cur) = fs::read_to_string(&gai_path) {
        if gai_cur.contains("#precedence ::ffff:0:0/96  100") {
            let _ = fs::write(
                &gai_path,
                gai_cur.replace("#precedence ::ffff:0:0/96  100", "precedence ::ffff:0:0/96  100"),
            );
        }
    }

    // 3. Patch 31-byte Termux prefix -> com.agy prefix inside essential glibc shared libraries
    let patched_count = patch_glibc_libs(&pfx.join("glibc/lib"), &lib_dst)?;

    // 4. Download unity-linux-arm64.br if missing or force_download=true
    let mut installed_ver = "existing".to_string();
    if force_download || !orig_bin.is_file() {
        let manifest_name = match channel.as_str() {
            "alpha" => "latest-alpha.json",
            "beta" => "latest-beta.json",
            _ => "latest.json",
        };
        let curl = find_bin("curl").ok_or("`curl` not found in $PREFIX/bin")?;
        let cert = pfx.join("etc/tls/cert.pem");
        let mut m_cmd = Command::new(&curl);
        if cert.is_file() {
            m_cmd.env("SSL_CERT_FILE", &cert);
        }
        let m_out = m_cmd
            .args(["-fsSL", &format!("{CDN_BASE}/{manifest_name}")])
            .output()
            .map_err(|e| format!("Failed fetching Unity CLI manifest: {e}"))?;
        if !m_out.status.success() {
            return Err(format!(
                "Failed fetching {CDN_BASE}/{manifest_name}: {}",
                String::from_utf8_lossy(&m_out.stderr)
            ));
        }
        let manifest: Value =
            serde_json::from_slice(&m_out.stdout).map_err(|e| format!("Invalid manifest JSON: {e}"))?;
        let ver = manifest
            .get("version")
            .and_then(|v| v.as_str())
            .ok_or("Missing `version` in Unity CLI manifest")?;
        installed_ver = ver.to_string();

        let br_file = manifest
            .pointer("/binaries/linux-arm64/brotli/filename")
            .and_then(|v| v.as_str())
            .unwrap_or("unity-linux-arm64.br");
        let br_url = format!("{CDN_BASE}/{ver}/{br_file}");
        let br_dest = opt.join("unity-linux-arm64.br");

        let mut d_cmd = Command::new(&curl);
        if cert.is_file() {
            d_cmd.env("SSL_CERT_FILE", &cert);
        }
        let d_out = d_cmd
            .args(["-fsSL", &br_url, "-o"])
            .arg(&br_dest)
            .output()
            .map_err(|e| e.to_string())?;
        if !d_out.status.success() {
            return Err(format!(
                "Download failed from {br_url}: {}",
                String::from_utf8_lossy(&d_out.stderr)
            ));
        }

        let brotli = find_bin("brotli").ok_or("`brotli` binary missing")?;
        let b_out = Command::new(brotli)
            .args(["-d", "-f"])
            .arg(&br_dest)
            .arg("-o")
            .arg(&orig_bin)
            .output()
            .map_err(|e| e.to_string())?;
        let _ = fs::remove_file(&br_dest);
        if !b_out.status.success() {
            return Err(format!(
                "Brotli decompression failed: {}",
                String::from_utf8_lossy(&b_out.stderr)
            ));
        }
        let _ = fs::set_permissions(&orig_bin, fs::Permissions::from_mode(0o755));
    }

    // 5. Build libunity_android_compat.so (returns ENOSYS for desktop Linux keyutils syscalls 217/218/219 not present on Android)
    build_android_compat_so(&opt, &lib_dst)?;

    // 6. Copy unity.orig -> unity-bin and run patchelf
    fs::copy(&orig_bin, &patched_bin).map_err(|e| format!("Failed copying unity.orig: {e}"))?;
    let _ = fs::set_permissions(&patched_bin, fs::Permissions::from_mode(0o755));

    let patchelf = find_bin("patchelf").ok_or("`patchelf` binary missing")?;
    let interp = lib_dst.join("ld-linux-aarch64.so.1");
    let rpath = format!("{}:{}", lib_dst.display(), pfx.join("glibc/lib").display());
    let pe_out = Command::new(patchelf)
        .args(["--set-interpreter"])
        .arg(&interp)
        .args(["--set-rpath", &rpath, "--add-needed", "libunity_android_compat.so"])
        .arg(&patched_bin)
        .output()
        .map_err(|e| e.to_string())?;
    if !pe_out.status.success() {
        return Err(format!(
            "patchelf failed: {}",
            String::from_utf8_lossy(&pe_out.stderr)
        ));
    }

    crate::ensure_wrappers_installed();

    Ok(json!({
        "status": "ready",
        "requested_version": installed_ver,
        "patched_glibc_libs": patched_count,
        "wrappers_installed": [
            pfx.join("bin/unity").to_string_lossy(),
            pfx.join("bin/agy-unity").to_string_lossy()
        ],
        "probe": cli_probe_quick()
    }))
}

fn patch_glibc_libs(src_dir: &Path, dst_dir: &Path) -> Result<usize, String> {
    let skip_prefixes = [
        "libasan",
        "libtsan",
        "libubsan",
        "liblsan",
        "libgfortran",
        "libbfd",
        "libopcodes",
        "libgprofng",
        "libdb",
    ];
    let mut patched_real = HashSet::new();
    let entries = fs::read_dir(src_dir).map_err(|e| format!("Cannot read {}: {e}", src_dir.display()))?;

    let mut all_names = Vec::new();
    for entry in entries.flatten() {
        let name = entry.file_name().to_string_lossy().to_string();
        if !name.contains(".so") || skip_prefixes.iter().any(|p| name.starts_with(p)) {
            continue;
        }
        all_names.push(name);
    }

    for name in &all_names {
        let sp = src_dir.join(name);
        let meta = match fs::symlink_metadata(&sp) {
            Ok(m) => m,
            Err(_) => continue,
        };
        if meta.file_type().is_file() {
            let mut bytes = fs::read(&sp).map_err(|e| e.to_string())?;
            if replace_31byte_slices(&mut bytes, OLD_TERMUX_PFX, NEW_AGY_PFX) > 0 {
                let dp = dst_dir.join(name);
                fs::write(&dp, &bytes).map_err(|e| e.to_string())?;
                let _ = fs::set_permissions(&dp, fs::Permissions::from_mode(0o755));
                patched_real.insert(name.clone());
            }
        }
    }

    for name in &all_names {
        let sp = src_dir.join(name);
        let meta = match fs::symlink_metadata(&sp) {
            Ok(m) => m,
            Err(_) => continue,
        };
        if meta.file_type().is_symlink() {
            if let Ok(target) = fs::read_link(&sp) {
                let base = target
                    .file_name()
                    .map(|s| s.to_string_lossy().to_string())
                    .unwrap_or_default();
                if patched_real.contains(&base) {
                    let dp = dst_dir.join(name);
                    let _ = fs::remove_file(&dp);
                    let _ = symlink(&base, &dp);
                }
            }
        }
    }

    Ok(patched_real.len())
}

fn replace_31byte_slices(buf: &mut [u8], needle: &[u8; 31], replacement: &[u8; 31]) -> usize {
    let mut count = 0usize;
    let mut i = 0usize;
    while i + 31 <= buf.len() {
        if &buf[i..i + 31] == needle {
            buf[i..i + 31].copy_from_slice(replacement);
            count += 1;
            i += 31;
        } else {
            i += 1;
        }
    }
    count
}

fn split_shell_words(input: &str) -> Vec<String> {
    let mut words = Vec::new();
    let mut cur = String::new();
    let mut in_single = false;
    let mut in_double = false;
    let mut chars = input.chars().peekable();

    while let Some(c) = chars.next() {
        match c {
            '\'' if !in_double => in_single = !in_single,
            '"' if !in_single => in_double = !in_double,
            '\\' if !in_single => {
                if let Some(nc) = chars.next() {
                    cur.push(nc);
                }
            }
            c if c.is_whitespace() && !in_single && !in_double => {
                if !cur.is_empty() {
                    words.push(std::mem::take(&mut cur));
                }
            }
            _ => cur.push(c),
        }
    }
    if !cur.is_empty() {
        words.push(cur);
    }
    words
}

const PREBUILT_COMPAT_SO: &[u8] = include_bytes!("../../bin/libunity_android_compat.so");

fn build_android_compat_so(opt_dir: &Path, lib_dst: &Path) -> Result<(), String> {
    let so_path = lib_dst.join("libunity_android_compat.so");
    if so_path.is_file() {
        return Ok(());
    }
    if !PREBUILT_COMPAT_SO.is_empty() {
        fs::write(&so_path, PREBUILT_COMPAT_SO).map_err(|e| e.to_string())?;
        let _ = fs::set_permissions(&so_path, fs::Permissions::from_mode(0o755));
        return Ok(());
    }
    let clang = match find_bin("clang").or_else(|| find_bin("gcc")) {
        Some(c) => c,
        None => return Ok(()),
    };
    let c_src = opt_dir.join("compat.c");
    let ver_src = opt_dir.join("compat.ver");
    let code = r#"extern int *__errno_location(void);

long syscall(long nr, long a0, long a1, long a2, long a3, long a4, long a5) {
    if (nr == 217 || nr == 218 || nr == 219) {
        *__errno_location() = 38;
        return -1L;
    }
    register long x8 __asm__("x8") = nr;
    register long x0 __asm__("x0") = a0;
    register long x1 __asm__("x1") = a1;
    register long x2 __asm__("x2") = a2;
    register long x3 __asm__("x3") = a3;
    register long x4 __asm__("x4") = a4;
    register long x5 __asm__("x5") = a5;
    __asm__ volatile(
        "svc #0"
        : "+r"(x0)
        : "r"(x1), "r"(x2), "r"(x3), "r"(x4), "r"(x5), "r"(x8)
        : "memory", "cc"
    );
    if ((unsigned long)x0 >= (unsigned long)-4095L) {
        *__errno_location() = (int)(-x0);
        return -1L;
    }
    return x0;
}
"#;
    let ver = "GLIBC_2.17 {\n  global:\n    syscall;\n  local:\n    *;\n};\n";
    fs::write(&c_src, code).map_err(|e| e.to_string())?;
    fs::write(&ver_src, ver).map_err(|e| e.to_string())?;

    let out = Command::new(clang)
        .args([
            "--target=aarch64-linux-gnu",
            "-nostdlib",
            "-shared",
            "-fPIC",
            "-O2",
            "-Wl,--soname,libunity_android_compat.so",
            &format!("-Wl,--version-script,{}", ver_src.display()),
        ])
        .arg(&c_src)
        .arg(lib_dst.join("libc.so.6"))
        .arg("-o")
        .arg(&so_path)
        .output()
        .map_err(|e| e.to_string())?;

    if !out.status.success() {
        return Err(format!(
            "Failed compiling libunity_android_compat.so: {}",
            String::from_utf8_lossy(&out.stderr)
        ));
    }
    Ok(())
}
