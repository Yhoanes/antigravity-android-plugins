use serde_json::Value;
use std::env;
use std::fs;
use std::path::{Path, PathBuf};

pub fn home_dir() -> PathBuf {
    env::var("HOME")
        .map(PathBuf::from)
        .unwrap_or_else(|_| PathBuf::from("/data/user/0/com.agy/files"))
}

pub fn prefix_dir() -> PathBuf {
    env::var("PREFIX")
        .map(PathBuf::from)
        .unwrap_or_else(|_| home_dir().join("usr"))
}

pub fn req_str(args: &Value, key: &str) -> Result<String, String> {
    args.get(key)
        .and_then(|v| v.as_str())
        .map(|s| s.trim().to_string())
        .filter(|s| !s.is_empty())
        .ok_or_else(|| format!("Missing required string parameter: '{key}'"))
}

pub fn opt_str(args: &Value, key: &str, default: &str) -> String {
    args.get(key)
        .and_then(|v| v.as_str())
        .map(|s| s.trim().to_string())
        .filter(|s| !s.is_empty())
        .unwrap_or_else(|| default.to_string())
}

pub fn opt_bool(args: &Value, key: &str, default: bool) -> bool {
    args.get(key).and_then(|v| v.as_bool()).unwrap_or(default)
}

pub fn opt_i64(args: &Value, key: &str, default: i64) -> i64 {
    args.get(key).and_then(|v| v.as_i64()).unwrap_or(default)
}

pub fn opt_f64(args: &Value, key: &str, default: f64) -> f64 {
    args.get(key).and_then(|v| v.as_f64()).unwrap_or(default)
}

pub fn round2(v: f64) -> f64 {
    (v * 100.0).round() / 100.0
}

pub fn find_bin(name: &str) -> Option<PathBuf> {
    let pfx_bin = prefix_dir().join("bin").join(name);
    if fs::metadata(&pfx_bin).map(|m| m.is_file()).unwrap_or(false) {
        return Some(pfx_bin);
    }
    if let Some(path_var) = env::var_os("PATH") {
        for dir in env::split_paths(&path_var) {
            let c = dir.join(name);
            if fs::metadata(&c).map(|m| m.is_file()).unwrap_or(false) {
                return Some(c);
            }
        }
    }
    let rt_bin = home_dir().join("runtime/bin").join(name);
    if fs::metadata(&rt_bin).map(|m| m.is_file()).unwrap_or(false) {
        return Some(rt_bin);
    }
    None
}

/// Pure-Rust RFC 1321 MD5 implementation for deterministic 32-hex Unity `.meta` GUIDs.
pub fn unity_guid_from_seed(seed: &str) -> String {
    let msg = seed.as_bytes();
    const K: [u32; 64] = [
        0xd76aa478, 0xe8c7b756, 0x242070db, 0xc1bdceee, 0xf57c0faf, 0x4787c62a, 0xa8304613, 0xfd469501,
        0x698098d8, 0x8b44f7af, 0xffff5bb1, 0x895cd7be, 0x6b901122, 0xfd987193, 0xa679438e, 0x49b40821,
        0xf61e2562, 0xc040b340, 0x265e5a51, 0xe9b6c7aa, 0xd62f105d, 0x02441453, 0xd8a1e681, 0xe7d3fbc8,
        0x21e1cde6, 0xc33707d6, 0xf4d50d87, 0x455a14ed, 0xa9e3e905, 0xfcefa3f8, 0x676f02d9, 0x8d2a4c8a,
        0xfffa3942, 0x8771f681, 0x6d9d6122, 0xfde5380c, 0xa4beea44, 0x4bdecfa9, 0xf6bb4b60, 0xbebfbc70,
        0x289b7ec6, 0xeaa127fa, 0xd4ef3085, 0x04881d05, 0xd9d4d039, 0xe6db99e5, 0x1fa27cf8, 0xc4ac5665,
        0xf4292244, 0x432aff97, 0xab9423a7, 0xfc93a039, 0x655b59c3, 0x8f0ccc92, 0xffeff47d, 0x85845dd1,
        0x6fa87e4f, 0xfe2ce6e0, 0xa3014314, 0x4e0811a1, 0xf7537e82, 0xbd3af235, 0x2ad7d2bb, 0xeb86d391,
    ];
    const S: [u32; 64] = [
        7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22,
        5, 9, 14, 20, 5, 9, 14, 20, 5, 9, 14, 20, 5, 9, 14, 20,
        4, 11, 16, 23, 4, 11, 16, 23, 4, 11, 16, 23, 4, 11, 16, 23,
        6, 10, 15, 21, 6, 10, 15, 21, 6, 10, 15, 21, 6, 10, 15, 21,
    ];

    let mut padded = msg.to_vec();
    padded.push(0x80);
    while (padded.len() % 64) != 56 {
        padded.push(0);
    }
    let bit_len = (msg.len() as u64).wrapping_mul(8);
    padded.extend_from_slice(&bit_len.to_le_bytes());

    let mut a0: u32 = 0x67452301;
    let mut b0: u32 = 0xefcdab89;
    let mut c0: u32 = 0x98badcfe;
    let mut d0: u32 = 0x10325476;

    for chunk in padded.chunks_exact(64) {
        let mut m = [0u32; 16];
        for (i, w) in chunk.chunks_exact(4).enumerate() {
            m[i] = u32::from_le_bytes([w[0], w[1], w[2], w[3]]);
        }
        let (mut a, mut b, mut c, mut d) = (a0, b0, c0, d0);
        for i in 0..64 {
            let (f, g) = match i {
                0..=15 => ((b & c) | ((!b) & d), i),
                16..=31 => ((d & b) | ((!d) & c), (5 * i + 1) % 16),
                32..=47 => (b ^ c ^ d, (3 * i + 5) % 16),
                _ => (c ^ (b | (!d)), (7 * i) % 16),
            };
            let tmp = d;
            d = c;
            c = b;
            let sum = a.wrapping_add(f).wrapping_add(K[i]).wrapping_add(m[g]);
            b = b.wrapping_add(sum.rotate_left(S[i]));
            a = tmp;
        }
        a0 = a0.wrapping_add(a);
        b0 = b0.wrapping_add(b);
        c0 = c0.wrapping_add(c);
        d0 = d0.wrapping_add(d);
    }

    let mut out = [0u8; 16];
    out[0..4].copy_from_slice(&a0.to_le_bytes());
    out[4..8].copy_from_slice(&b0.to_le_bytes());
    out[8..12].copy_from_slice(&c0.to_le_bytes());
    out[12..16].copy_from_slice(&d0.to_le_bytes());
    out.iter().map(|b| format!("{b:02x}")).collect()
}

/// Extract `guid: <32hex>` from an existing Unity `.meta` file if present.
pub fn read_meta_guid(meta_path: &Path) -> Option<String> {
    let txt = fs::read_to_string(meta_path).ok()?;
    for line in txt.lines() {
        let t = line.trim();
        if let Some(rest) = t.strip_prefix("guid:") {
            let g = rest.trim();
            if g.len() == 32 && g.chars().all(|c| c.is_ascii_hexdigit()) {
                return Some(g.to_ascii_lowercase());
            }
        }
    }
    None
}

/// Ensure a Unity `.meta` file exists for `asset_path` (relative to project root `rel_key` for deterministic GUID).
pub fn ensure_meta_for_path(asset_path: &Path, rel_key: &str) -> Result<String, String> {
    let meta_path = PathBuf::from(format!("{}.meta", asset_path.display()));
    if let Some(existing) = read_meta_guid(&meta_path) {
        return Ok(existing);
    }
    let normalized = rel_key.replace('\\', "/");
    let guid = unity_guid_from_seed(&format!("unity-android::{normalized}"));
    let is_dir = asset_path.is_dir();
    let ext = asset_path
        .extension()
        .and_then(|s| s.to_str())
        .unwrap_or("")
        .to_ascii_lowercase();

    let body = if is_dir {
        format!(
            "fileFormatVersion: 2\nguid: {guid}\nfolderAsset: yes\nDefaultImporter:\n  externalObjects: {{}}\n  userData: \n  assetBundleName: \n  assetBundleVariant: \n"
        )
    } else if ext == "cs" {
        format!(
            "fileFormatVersion: 2\nguid: {guid}\nMonoImporter:\n  externalObjects: {{}}\n  serializedVersion: 2\n  defaultReferences: []\n  executionOrder: 0\n  icon: {{instanceID: 0}}\n  userData: \n  assetBundleName: \n  assetBundleVariant: \n"
        )
    } else if matches!(ext.as_str(), "png" | "jpg" | "jpeg" | "tga" | "webp") {
        format!(
            "fileFormatVersion: 2\nguid: {guid}\nTextureImporter:\n  internalIDToNameTable: []\n  externalObjects: {{}}\n  serializedVersion: 13\n  mipmaps:\n    mipMapMode: 0\n    enableMipMap: 1\n  bumpmap:\n    convertToNormalMap: 0\n  textureType: 0\n  maxTextureSize: 2048\n  userData: \n  assetBundleName: \n  assetBundleVariant: \n"
        )
    } else if matches!(ext.as_str(), "wav" | "ogg" | "mp3") {
        format!(
            "fileFormatVersion: 2\nguid: {guid}\nAudioImporter:\n  externalObjects: {{}}\n  serializedVersion: 7\n  defaultSettings:\n    loadType: 0\n    sampleRateSetting: 0\n    compressionFormat: 1\n    quality: 1\n  userData: \n  assetBundleName: \n  assetBundleVariant: \n"
        )
    } else {
        format!(
            "fileFormatVersion: 2\nguid: {guid}\nDefaultImporter:\n  externalObjects: {{}}\n  userData: \n  assetBundleName: \n  assetBundleVariant: \n"
        )
    };

    fs::write(&meta_path, body).map_err(|e| format!("Failed writing {}: {e}", meta_path.display()))?;
    Ok(guid)
}
