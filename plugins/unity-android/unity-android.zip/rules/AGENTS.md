# Unity Studio Android Rules (Native Rust ARM64 + Ported Unity CLI v1.0.0)

When the `unity-android` plugin is enabled on Antigravity for Android:

1. **Prefer Native `unity-android` Rust MCP Tools for Unity 6 Workflows:**
   - Use `unity_project_create` (defaulting to `/storage/emulated/0/Documents/UnityProjects/`) to scaffold Android-optimized Unity 6.3 LTS (`6000.3.28f1`, free Unity Personal compatible — avoid `6000.0.85+` XLTS which requires Enterprise/Industry) URP 2D/3D projects with 120 FPS mobile bootstrap, touch input, deterministic `.meta` GUIDs, and `$0` GitHub Actions `GameCI` build pipelines.
   - Always create or update Unity C# scripts via `unity_script_create` (which enforces `MonoBehaviour` class-to-filename matching and maintains deterministic `.cs.meta` GUIDs) and build/modify `.unity` scenes or `.prefab` files via `unity_scene_build`.
   - Always run `unity_yaml_audit` before pushing to GitHub CI or Unity Cloud Build to auto-heal missing `.meta` files and catch broken `{fileID}` / GUID references locally in `<1s`.
   - Use `unity_package_io` (`inspect`, `import`, `export`) for offline `.unitypackage` management and `unity_asset_opt` (`glb_inspect`, `wav_master`) to optimize 3D `.glb` draw-call/triangle budgets and strip `0-ms` audio latency.

2. **Ported Official `unity-cli` (`v1.0.0`, `linux-arm64` via Patched `glibc`):**
   - Both `$PREFIX/bin/unity` in terminal and `unity_cli_exec` via MCP invoke Unity's official `unity-cli v1.0.0` natively on Android ARM64 (`LD_PRELOAD` and `LD_LIBRARY_PATH` stripped automatically so Bionic `.so` files never collide with `glibc`).
   - Use `unity_cli_exec` (or `unity <cmd> --format json`) for official Unity documentation (`docs toc`, `docs --content`), release catalogs (`releases`), semantic scene diffs/blame (`vcs diff`, `vcs blame`, `vcs guid`), authentication (`auth`), Personal license activation (`license`), and `pipeline cloud-build`.
   - Note that the desktop `Unity Editor` (`x86_64`) does not run locally on Android; compile `.apk`/`.aab` for `$0` via `unity_ci_workflow` (GitHub Actions `GameCI`: unlimited free minutes on public repos, 2,000 free min/month on private repos) or `unity pipeline cloud-build` (300 free min/month), then deploy and debug live on-device via `unity_apk_deploy` and `unity_live_debug` (`rish`).

3. **Android Sandbox Safety:**
   - Never modify, overwrite, or delete anything inside `/data/user/0/com.agy/files/runtime/bin/`. Wrappers live exclusively in `$PREFIX/bin/{unity,agy-unity}`.
