---
name: unity-android
description: Native Android ARM64 Unity 6 Studio & Ported Official Unity CLI v1.0.0 workflow guide. Use whenever creating, editing, auditing, building ($0 GitHub GameCI / Unity Cloud Build), installing, or live-debugging Unity 2D/3D Android games (`unity_project_create`, `unity_script_create`, `unity_scene_build`, `unity_yaml_audit`, `unity_package_io`, `unity_cli_exec`, `unity_ci_workflow`, `unity_apk_deploy`, `unity_live_debug`).
---

# Unity Studio Android (Native Rust ARM64 + Ported `unity-cli` v1.0.0)

This skill equips Antigravity on Android (`aarch64`) with a complete end-to-end **Unity 6 Mobile Studio** powered by:
1. **`unity-android-mcp` (Pure Native Rust ARM64 Bionic):** `<10 MB` RAM, instant `0 ms` startup, 13 MCP tools including deterministic `.meta` GUID engine, `%YAML 1.1` `.unity`/`.prefab` serializer & auditor, unstrippable `Resources/NeonLit.shader`, 120–144 Hz refresh unlock, offline `.unitypackage` engine, mobile `.glb` & `0-ms` WAV optimizer, `$0` GitHub `GameCI` orchestrator, and live on-device `rish` APK installer + `logcat -s Unity` / 144 Hz profiler.
2. **Ported Official `unity-cli` v1.0.0 (`$PREFIX/bin/unity`):** Unity Technologies' official `linux-arm64` CLI running at 100% native CPU speed on Android via an isolated 31-byte binary-patched `glibc` runtime (`$PREFIX/opt/unity-cli/lib`) + embedded `libunity_android_compat.so` (`ENOSYS` shim for desktop `keyutils` syscalls `217/218/219`) and fast DNS (`single-request-reopen`), unlocking `unity docs`, `unity releases`, `unity vcs`, `unity auth`, `unity projects`, `unity license`, and `unity pipeline cloud-build`.

---

## 1. End-to-End "$0 Cloud + Local Android Test" Workflow

1. **Create Project (`unity_project_create`):**
   Scaffolds a clean **Unity 6.3 LTS (`6000.3.28f1`, 100% compatible with free Unity Personal — avoid `6000.0.85+` XLTS)** 3D or 2D project in `/storage/emulated/0/Documents/UnityProjects/<GameName>` pre-configured for:
   - **Scripting Backend:** `IL2CPP` (`arm64-v8a`)
   - **High Refresh Unlock (120–144 Hz):** `Screen.SetResolution(..., maxRefreshRate)` + `Application.targetFrameRate = 144` (`MobileBootstrap.cs`) + `PlayerSettings.Android.optimizedFramePacing = false`
   - **Zero Pink-Screen Shaders:** Pre-bundled `Assets/Resources/NeonLit.shader` (`Shader.Find("Custom/NeonLit")` via `Resources.Load<Shader>("NeonLit")`) so runtime materials are never stripped into magenta `Hidden/InternalErrorShader` on Android Vulkan/GLES3
   - **Input:** Unity New Input System (`Touchscreen.current` + keyboard fallback)
   - **CI/CD:** `.github/workflows/unity-android-build.yml` + `Assets/Editor/AndroidAutoBuilder.cs`

2. **Author Scripts & Scenes Safely (`unity_script_create` + `unity_scene_build`):**
   - **Rule #1 of Headless Unity Authoring:** Every file and folder inside `Assets/` MUST have a `.meta` file with a unique 32-hex lowercase `guid`, and every `MonoBehaviour` / `ScriptableObject` file `<ClassName>.cs` MUST declare `class <ClassName>`.
   - `unity_script_create` enforces both automatically and returns the script's `guid`. Pass that `guid` into `unity_scene_build` (`script_guid`) to bind your `MonoBehaviour` and serialize custom inspector fields directly onto GameObjects.

3. **Pre-Flight Local Audit (`unity_yaml_audit`):**
   - Run `unity_yaml_audit` (`auto_fix_meta: true`) before pushing to GitHub or triggering Cloud Build. It heals any missing `.meta` files, detects duplicate GUIDs, verifies local `&fileID` links inside `.unity`/`.prefab` YAML files, and checks C# brace/class validity in `<1 second` so zero cloud minutes are wasted.

4. **Compile `.apk` / `.aab` for `$0` (`unity_ci_workflow` or `unity_cli_exec`):**
   - **Option A — GitHub Actions `GameCI` (`$0`, Unlimited Public / 2,000 Free Private Min/Mo):**
     Push the project with the `github` plugin, configure your free Unity Personal license (`UNITY_LICENSE` or OAuth activation in workflow), and call `unity_ci_workflow` (`action: "trigger"` -> `"status"` -> `"download_apk"`). If compilation fails, `action: "logs"` extracts exact `error CS...` lines.
   - **Option B — Unity Build Automation (`$0` Free Tier, ~300 Min/Mo):**
     Sign in via `unity auth login` (`xdg-open` for OAuth) and run `unity_cli_exec` with `["pipeline", "cloud-build", "builds", "start", ...]`.

5. **On-Device Install, Live `logcat -s Unity` & 120–144 FPS Profiling (`unity_apk_deploy` + `unity_live_debug`):**
   - Call `unity_apk_deploy` with the downloaded `.apk` path and `package_name`: stages in `/data/local/tmp`, runs `pm install -r -g` via `rish` (auto-handling `INSTALL_FAILED_UPDATE_INCOMPATIBLE` across ephemeral CI debug keystores), clears stale logs, and launches the game right on the phone screen.
   - Call `unity_live_debug` to inspect C#/IL2CPP exceptions (`NullReferenceException`, shader errors, `Debug.Log`) alongside `gfxinfo` frame times, `SurfaceFlinger` display Hz, PSS RAM MB, and battery temp.

---

## 2. High-Value Ported `unity-cli` Commands (`unity_cli_exec`)

- **Version-Matched Official Docs:**
  - `["docs", "toc", "--query", "CharacterController"]`
  - `["docs", "--url", "<doc-url>", "--content"]`
- **Semantic YAML Scene Diff, Blame & GUID Lookup:**
  - `["vcs", "diff", "Assets/Scenes/Main.unity"]`
  - `["vcs", "blame", "Assets/Scenes/Main.unity", "--object", "Player"]`
  - `["vcs", "guid", "<32-hex-guid>"]`
- **Cloud Org, Projects & Releases:**
  - `["auth", "status"]` / `["orgs", "list"]` / `["projects", "verify"]`
  - `["releases"]`
  - `["commands", "--grep", "cloud-build"]`
- **Repair / First-Time CLI Install:**
  - If `$PREFIX/opt/unity-cli/unity-bin` is not installed yet, call `unity_cli_setup` (or run `agy-unity setup` in terminal).
