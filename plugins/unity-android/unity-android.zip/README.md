# Unity Studio Android (`v1.0.0`) — Motor Nativo en Rust ARM64 + `unity-cli` v1.0.0 Oficial Porteado

Plugin oficial nativo **ARM64 (`aarch64` + `LSE`)** para **Antigravity for Android** que une un motor MCP ultrarrápido en **Rust puro (`<10 MB` RAM, arranque instantáneo)** con el **`unity-cli v1.0.0` oficial de Unity Technologies porteado a Android ARM64**, permitiéndote crear, auditar, compilar por **\$0 en la nube** (**Unity 6.3 LTS `6000.3.28f1` Personal**) y depurar en vivo videojuegos **2D y 3D a 120–144 FPS** directamente desde tu teléfono o tablet.

> [!TIP]
> **Flujo Completo Zero-PC Verificado en Dispositivo Real:**
> 1. **Autoría Local sin Roturas:** Genera proyectos **Unity 6.3 LTS (`6000.3.28f1`, 100 % compatible con licencia gratuita Unity Personal)** con controles táctiles, desbloqueo de pantalla **120–144 Hz** (`optimizedFramePacing = false`) y shader `Assets/Resources/NeonLit.shader` inmune al *stripping* de Vulkan/GLES3 (cero pantallas magenta `#FF00FF`).
> 2. **Compilación Cloud \$0 (`arm64-v8a` IL2CPP):** Compila el `.apk` o `.aab` gratis con **GitHub Actions (`GameCI`)** o **Unity Cloud Build** usando activación OAuth de un toque.
> 3. **Instalación y Telemetría en Vivo (`rish`):** Instala el `.apk` directo en tu Android, captura excepciones C#/IL2CPP en `logcat -s Unity` y mide FPS reales, hercios de pantalla (`SurfaceFlinger`), `PSS` RAM y temperatura.

---

## Las 13 Herramientas MCP Nativas en Rust

| Herramienta | Departamento | Función Nativa ARM64 |
| :--- | :--- | :--- |
| `unity_status` | Diagnóstico | Verifica el motor Rust ARM64, estado y sesión OAuth de `unity-cli v1.0.0`, conexión `rish`/ADB y herramientas Cloud (`gh`, `git`). |
| `unity_cli_exec` | CLI Oficial | Ejecuta cualquier subcomando oficial de **`unity-cli v1.0.0`** en Android (`releases`, `docs`, `auth`, `license`, `projects`, `vcs diff/blame/guid`, `pipeline cloud-build`) con salida JSON limpia. |
| `unity_cli_setup` | Auto-Instalador | Descarga desde el CDN de Unity y parchea automáticamente `unity-linux-arm64` + `glibc` de 31 bytes + shim `libunity_android_compat.so` (`ENOSYS` para syscalls `217/218/219`) y wrappers `$PREFIX/bin/{unity,agy-unity}`. |
| `unity_project_create` | Motor 2D/3D | Crea proyectos **Unity 6.3 LTS (`6000.3.28f1`)** 2D o 3D preconfigurados para Android `arm64-v8a` IL2CPP, 120–144 Hz, *New Input System* táctil, `Resources/NeonLit.shader`, `.meta` deterministas y workflow CI \$0. |
| `unity_script_create` | Scripting C# | Crea o actualiza scripts `.cs`, shaders o UI Toolkit validando coincidencia exacta `class == archivo` en `MonoBehaviour` y generando su `.meta` con GUID determinista. |
| `unity_scene_build` | Serializador YAML | Construye escenas `.unity` y `.prefab` (`%YAML 1.1`) puras en Rust con cámara, luz, primitivas 2D/3D, colisionadores, `Rigidbody` y enlace de scripts por `guid`. |
| `unity_yaml_audit` | QA Pre-Vuelo | Audita en `<1s` antes de compilar: repara `.meta` faltantes, detecta GUIDs duplicados, verifica enlaces `&fileID` en escenas/prefabs y valida llaves/clases C#. |
| `unity_package_io` | Paquetes Offline | Motor `.unitypackage` puro en Rust (`tar.gz`): inspecciona (`inspect`), importa (`import`) o exporta (`export`) carpetas `Assets/` conservando sus GUIDs. |
| `unity_asset_opt` | Arte 3D y Audio | Inspecciona presupuestos móviles de modelos `.glb` (triángulos, huesos, *draw calls*) y masteriza audio `.wav` sin latencia (`0 ms` attack, `-1.0 dBFS` y loops BGM). |
| `unity_ci_workflow` | Cloud Build \$0 | Orquesta compilaciones gratuitas en **GitHub Actions (`GameCI`)**: `scaffold` (con limpieza de ~35 GB de disco y activación Personal automática), `trigger`, `status`, `logs` de errores `CS...` y `download_apk`. |
| `unity_apk_deploy` | Despliegue APK | Instala tu `.apk` en el teléfono vía `rish` (auto-resolviendo cambios de firma `INSTALL_FAILED_UPDATE_INCOMPATIBLE`), limpia `logcat` y lanza el juego en pantalla. |
| `unity_live_debug` | Live Debugger | Captura en vivo `logcat -s Unity` (excepciones C#, shaders, `Debug.Log`) junto a FPS, `gfxinfo`, tasa de refresco real (`60/120/144 Hz`), RAM `PSS` y temperatura de batería. |
| `unity_remote_mcp` | Puente Remoto | Puente HTTP JSON-RPC opcional para controlar un Unity 6 Editor abierto en PC/Mac vía Wi-Fi local o Tailscale. |

---

## Activación Rápida del `unity-cli` Oficial

Las **13 herramientas MCP en Rust** arrancan en `<2 ms` apenas instalas el plugin desde el Marketplace. Para descargar y activar el binario oficial **`unity-cli v1.0.0`** en terminal (o al ejecutar `unity` por primera vez):

```bash
# Instala y parchea automaticamente unity-linux-arm64 v1.0.0 + glibc:
agy-unity setup

# Inicia sesion OAuth con tu cuenta gratuita de Unity Personal:
unity auth login
```
