#!/system/bin/sh
# install-plugin.sh - Installs and configures Unity Studio Android (v1.0.0, Native Rust ARM64 + Ported Unity CLI)
set -eu

SRC_DIR="$(CDPATH= cd -- "$(/system/bin/dirname -- "$0")" && pwd)"
case "$SRC_DIR" in
    */.gemini/*) HOME="${SRC_DIR%%/.gemini/*}" ;;
    *) HOME="${HOME:-/data/user/0/com.agy/files}" ;;
esac
PREFIX="${PREFIX:-$HOME/usr}"
CONFIG_DIR="$HOME/.gemini/config"
TARGET_DIR="$CONFIG_DIR/plugins/unity-android"

/system/bin/mkdir -p "$CONFIG_DIR/plugins" "$PREFIX/tmp" "$PREFIX/bin"

if [ "$SRC_DIR" != "$TARGET_DIR" ]; then
    /system/bin/rm -rf "$TARGET_DIR"
    /system/bin/mkdir -p "$TARGET_DIR"
    /system/bin/cp -Rf "$SRC_DIR"/. "$TARGET_DIR"/
fi

/system/bin/chmod 0755 \
    "$TARGET_DIR/install-plugin.sh" \
    "$TARGET_DIR/mcp/bin/start-mcp.sh" \
    "$TARGET_DIR/mcp/bin/unity-android-mcp"
[ -f "$TARGET_DIR/mcp/bin/libunity_android_compat.so" ] && /system/bin/chmod 0755 "$TARGET_DIR/mcp/bin/libunity_android_compat.so" || true

# Self-heal $PREFIX/bin/unity and $PREFIX/bin/agy-unity via Rust binary (never touch $HOME/runtime/bin)
"$TARGET_DIR/mcp/bin/unity-android-mcp" status >/dev/null 2>&1 || true

echo "================================================================="
echo " Plugin Unity Studio Android v1.0.0 (Native Rust ARM64) installed"
echo " Path: $TARGET_DIR"
echo "================================================================="
