# Skill Licenses and Terms of Use

Please note that you are responsible for ensuring your use of the skills file
complies with any terms applicable to the sources of data used by the skills
file at your request. To assist your compliance, relevant site references are
included in the table below; however, please note that site addresses may change
from time to time so the list below may be incomplete or may become outdated.



Skill                                | Reference Url(s)
------------------------------------ | ----------------
alphafold-database-fetch-and-analyze | https://alphafold.ebi.ac.uk/
alphagenome-single-variant-analysis  | https://deepmind.google.com/science/alphagenome/
chembl-database                      | https://chembl.gitbook.io/chembl-interface-documentation/about
cheminformatics-cofolding            | https://www.rdkit.org/, https://github.com/google-deepmind/alphafold3, and https://github.com/jwohlwend/boltz
cheminformatics-core                 | https://www.rdkit.org/, https://chembl.gitbook.io/chembl-interface-documentation/about, https://pubchem.ncbi.nlm.nih.gov/docs/citation-guidelines, https://webbook.nist.gov/chemistry/, and https://openbabel.org/
cheminformatics-doc2mol              | https://www.rdkit.org/, https://opsin.ch.cam.ac.uk, https://pubchem.ncbi.nlm.nih.gov/docs/citation-guidelines, https://patents.google.com/, and https://open-reaction-database.org/
cheminformatics-ml                   | https://www.rdkit.org/ and https://scikit-learn.org/
cheminformatics-physics              | https://www.rdkit.org/, https://github.com/ccsb-scripps/AutoDock-Vina, https://sourceforge.net/projects/smina/, https://openmm.org/, and https://openforcefield.org/
cheminformatics-reactions            | https://www.rdkit.org/ and https://github.com/rdkit/rdkit
clinical-trials-database             | https://clinicaltrials.gov/
clinvar-database                     | https://www.ncbi.nlm.nih.gov/clinvar/
dbsnp-database                       | https://www.ncbi.nlm.nih.gov/snp/
embl-ebi-ols                         | https://www.ebi.ac.uk/ols4/api-docs
encode-ccres-database                | https://www.encodeproject.org/help/rest-api/
ensembl-database                     | https://github.com/Ensembl/ensembl-rest/wiki and https://useast.ensembl.org/index.html
foldseek-structural-search           | https://search.foldseek.com/search and https://github.com/steineggerlab/foldseek
gnomad-database                      | https://gnomad.broadinstitute.org/policies and https://gnomad.broadinstitute.org/data#api
gtex-database                        | https://gtexportal.org/home/license and https://gtexportal.org/home/documentationPage#gtexApi
human-protein-atlas-database         | https://www.proteinatlas.org/about/licence
interpro-database                    | https://www.ebi.ac.uk/interpro/ and https://www.ebi.ac.uk/about/terms-of-use/
jaspar-database                      | https://jaspar.elixir.no/ and https://jaspar.elixir.no/api/
literature-search-arxiv              | https://info.arxiv.org/help/api/index.html
literature-search-biorxiv            | https://api.biorxiv.org/ and https://www.biorxiv.org/content/about-biorxiv
literature-search-europepmc          | https://europepmc.org/
literature-search-openalex           | https://help.openalex.org/
ncbi-sequence-fetch                  | https://www.ncbi.nlm.nih.gov/ and https://www.ncbi.nlm.nih.gov/home/about/policies/
openfda-database                     | https://open.fda.gov/apis/ and https://open.fda.gov/license
opentargets-database                 | https://platform-docs.opentargets.org/licence
pdb-database                         | https://www.rcsb.org/pages/usage-policy
protein-sequence-msa                 | https://www.ebi.ac.uk/about/terms-of-use/ and https://www.ebi.ac.uk/jdispatcher/msa/clustalo
protein-sequence-similarity-search   | https://www.ebi.ac.uk/jdispatcher/sss/ncbiblast and https://colabfold.com
pubchem-database                     | https://pubchem.ncbi.nlm.nih.gov/docs/citation-guidelines and https://pubchem.ncbi.nlm.nih.gov/docs/pug-rest
pubmed-database                      | https://pubmed.ncbi.nlm.nih.gov/disclaimer/ and https://www.ncbi.nlm.nih.gov/home/about/policies/
pymol                                | https://www.pymol.org/
quickgo-database                     | https://www.ebi.ac.uk/QuickGO/ and https://www.ebi.ac.uk/QuickGO/api/index.html
rdkit-general                        | https://www.rdkit.org/, https://opsin.ch.cam.ac.uk, and https://pubchem.ncbi.nlm.nih.gov/docs/citation-guidelines
reactome-database                    | https://reactome.org/license and https://reactome.org/cite
string-database                      | https://string-db.org/cgi/access
ucsc-conservation-and-tfbs           | https://genome.ucsc.edu/conditions.html and https://genome.ucsc.edu/goldenPath/help/api.html
unibind-database                     | https://unibind.uio.no/ and https://unibind.uio.no/api/overview
uniprot-database                     | https://www.uniprot.org/help/license and https://www.uniprot.org/help/api_queries


