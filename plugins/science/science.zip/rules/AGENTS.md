# Science Visualization Priority Rules (Android ARM64 & Cross-Platform)

For scientific and biomolecular visualization tasks:

1. **On Antigravity for Android (standalone mode without desktop Electron sidecars):**
   - Prefer **Generative UI** (`generative_ui` interactive HTML/SVG/3Dmol.js/Chart.js widgets rendered inline or as artifacts) and/or high-resolution Python plots (`matplotlib`, `seaborn`, `rdkit`, `pymol`) embedded in the response or artifacts.
   - Do **not** emit `sidecar://` links unless a science viewer sidecar MCP server is actively registered in `<mcp_servers>`.

2. **When a viewer sidecar MCP server IS registered (Desktop):**
   - Prefer the interactive sidecar viewer (e.g. Biomolecular Structure Viewer) and include its `sidecar://` pill link in the chat response.
