#!/system/bin/sh
# install-plugin.sh - Installs AGY ADB Bridge v1.0.1 (Native Rust ARM64) into Antigravity Android.
# STRICT RULE: Never writes, edits, or deletes anything inside $HOME/runtime/bin/.
set -eu

SRC_DIR="$(CDPATH= cd -- "$(/system/bin/dirname -- "$0")" && pwd)"
case "$SRC_DIR" in
    */.gemini/*) HOME="${SRC_DIR%%/.gemini/*}" ;;
    *) HOME="${HOME:-/data/user/0/com.agy/files}" ;;
esac
PREFIX="${PREFIX:-$HOME/usr}"
CONFIG_DIR="$HOME/.gemini/config"
TARGET_DIR="$CONFIG_DIR/plugins/agy-adb-bridge"

if [ -f "$PREFIX/lib/libandroid-support.so" ]; then
    export LD_LIBRARY_PATH="$PREFIX/lib${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
    export PATH="$PREFIX/bin:$HOME/runtime/bin:/system/bin"
else
    unset LD_PRELOAD 2>/dev/null || true
    unset LD_LIBRARY_PATH 2>/dev/null || true
    export PATH="/system/bin:$HOME/runtime/bin:$PREFIX/bin"
fi

/system/bin/mkdir -p "$CONFIG_DIR/plugins" "$PREFIX/bin" "$PREFIX/tmp" "$HOME/.android"
/system/bin/chmod 700 "$HOME/.android" 2>/dev/null || true

if [ "$SRC_DIR" != "$TARGET_DIR" ]; then
    /system/bin/rm -rf "$TARGET_DIR"
    /system/bin/mkdir -p "$TARGET_DIR"
    /system/bin/cp -Rf "$SRC_DIR"/. "$TARGET_DIR"/
fi

/system/bin/chmod 0755 \
    "$TARGET_DIR/install-plugin.sh" \
    "$TARGET_DIR/mcp/bin/start-mcp.sh" \
    "$TARGET_DIR/mcp/bin/agy-adb-mcp" \
    "$TARGET_DIR/mcp/bin/agy-adb-setup"

/system/bin/rm -f "$PREFIX/bin"/.rish.agy.*.tmp "$PREFIX/bin"/.agy-adb.*.tmp "$PREFIX/bin"/.agy-adb-setup.*.tmp 2>/dev/null || true

STOCK_RISH="$HOME/runtime/bin/rish"
MCP_BIN="$TARGET_DIR/mcp/bin/agy-adb-mcp"

TMP_RISH="$PREFIX/bin/.rish.agy.$$.tmp"
/system/bin/cat > "$TMP_RISH" <<EOF
#!/system/bin/sh
# AGY_ADB_BRIDGE_WRAPPER v1.0.1
export HOME="\${HOME:-$HOME}"
export PREFIX="\${PREFIX:-$PREFIX}"
if [ ! -f "\$PREFIX/lib/libandroid-support.so" ]; then
    unset LD_PRELOAD LD_LIBRARY_PATH 2>/dev/null || true
fi
MCP_BIN="\$HOME/.gemini/config/plugins/agy-adb-bridge/mcp/bin/agy-adb-mcp"
if [ -x "\$MCP_BIN" ]; then
    exec "\$MCP_BIN" __rish "\$@"
fi
if [ -x "$MCP_BIN" ]; then
    exec "$MCP_BIN" __rish "\$@"
fi
unset LD_PRELOAD LD_LIBRARY_PATH 2>/dev/null || true
export PATH="/system/bin:/system/xbin"
export RISH_APPLICATION_ID="\${RISH_APPLICATION_ID:-com.agy}"
exec /system/bin/sh "$STOCK_RISH" "\$@"
EOF
/system/bin/chmod 0755 "$TMP_RISH"
/system/bin/mv -f "$TMP_RISH" "$PREFIX/bin/rish"

TMP_CLI="$PREFIX/bin/.agy-adb.$$.tmp"
/system/bin/cat > "$TMP_CLI" <<EOF
#!/system/bin/sh
# AGY_ADB_BRIDGE_CLI v1.0.1
export HOME="\${HOME:-$HOME}"
export PREFIX="\${PREFIX:-$PREFIX}"
if [ ! -f "\$PREFIX/lib/libandroid-support.so" ]; then
    unset LD_PRELOAD LD_LIBRARY_PATH 2>/dev/null || true
fi
MCP_BIN="\$HOME/.gemini/config/plugins/agy-adb-bridge/mcp/bin/agy-adb-mcp"
if [ -x "\$MCP_BIN" ]; then
    exec "\$MCP_BIN" cli "\$@"
fi
exec "$MCP_BIN" cli "\$@"
EOF
/system/bin/chmod 0755 "$TMP_CLI"
/system/bin/mv -f "$TMP_CLI" "$PREFIX/bin/agy-adb"

TMP_SETUP="$PREFIX/bin/.agy-adb-setup.$$.tmp"
/system/bin/cat > "$TMP_SETUP" <<EOF
#!/system/bin/sh
# AGY_ADB_BRIDGE_SETUP v1.0.1
export HOME="\${HOME:-$HOME}"
export PREFIX="\${PREFIX:-$PREFIX}"
exec /system/bin/sh "$TARGET_DIR/mcp/bin/agy-adb-setup" "\$@"
EOF
/system/bin/chmod 0755 "$TMP_SETUP"
/system/bin/mv -f "$TMP_SETUP" "$PREFIX/bin/agy-adb-setup"

echo "============================================================"
echo " Plugin AGY ADB Bridge v1.0.1 (Native Rust ARM64) activo"
echo " Ruta: $TARGET_DIR"
echo " Wrappers en \$PREFIX/bin: rish, agy-adb, agy-adb-setup"
echo "============================================================"
