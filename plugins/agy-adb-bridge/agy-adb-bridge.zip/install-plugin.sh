#!/system/bin/sh
# install-plugin.sh - Installs AGY ADB Bridge v1.0.0 (Native Rust ARM64) into Antigravity Android.
# STRICT RULE: Never writes, edits, or deletes anything inside $HOME/runtime/bin/.
set -eu

SRC_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
case "$SRC_DIR" in
    */.gemini/*) HOME="${SRC_DIR%%/.gemini/*}" ;;
    *) HOME="${HOME:-/data/user/0/com.agy/files}" ;;
esac
PREFIX="${PREFIX:-$HOME/usr}"
CONFIG_DIR="$HOME/.gemini/config"
TARGET_DIR="$CONFIG_DIR/plugins/agy-adb-bridge"

mkdir -p "$CONFIG_DIR/plugins" "$PREFIX/bin" "$PREFIX/tmp" "$HOME/.android"
chmod 700 "$HOME/.android" 2>/dev/null || true

if [ "$SRC_DIR" != "$TARGET_DIR" ]; then
    rm -rf "$TARGET_DIR"
    mkdir -p "$TARGET_DIR"
    cp -Rf "$SRC_DIR"/. "$TARGET_DIR"/
fi

chmod 0755 \
    "$TARGET_DIR/install-plugin.sh" \
    "$TARGET_DIR/mcp/bin/start-mcp.sh" \
    "$TARGET_DIR/mcp/bin/agy-adb-mcp" \
    "$TARGET_DIR/mcp/bin/agy-adb-setup"

STOCK_RISH="$HOME/runtime/bin/rish"
MCP_BIN="$TARGET_DIR/mcp/bin/agy-adb-mcp"

TMP_RISH="$PREFIX/bin/.rish.agy.$$.tmp"
cat > "$TMP_RISH" <<EOF
#!/system/bin/sh
# AGY_ADB_BRIDGE_WRAPPER v1.0.0
export HOME="\${HOME:-$HOME}"
export PREFIX="\${PREFIX:-$PREFIX}"
MCP_BIN="\$HOME/.gemini/config/plugins/agy-adb-bridge/mcp/bin/agy-adb-mcp"
if [ -x "\$MCP_BIN" ]; then
    exec "\$MCP_BIN" __rish "\$@"
fi
if [ -x "$MCP_BIN" ]; then
    exec "$MCP_BIN" __rish "\$@"
fi
exec "$STOCK_RISH" "\$@"
EOF
chmod 0755 "$TMP_RISH"
mv -f "$TMP_RISH" "$PREFIX/bin/rish"

TMP_CLI="$PREFIX/bin/.agy-adb.$$.tmp"
cat > "$TMP_CLI" <<EOF
#!/system/bin/sh
# AGY_ADB_BRIDGE_CLI v1.0.0
export HOME="\${HOME:-$HOME}"
export PREFIX="\${PREFIX:-$PREFIX}"
MCP_BIN="\$HOME/.gemini/config/plugins/agy-adb-bridge/mcp/bin/agy-adb-mcp"
if [ -x "\$MCP_BIN" ]; then
    exec "\$MCP_BIN" cli "\$@"
fi
exec "$MCP_BIN" cli "\$@"
EOF
chmod 0755 "$TMP_CLI"
mv -f "$TMP_CLI" "$PREFIX/bin/agy-adb"

TMP_SETUP="$PREFIX/bin/.agy-adb-setup.$$.tmp"
cat > "$TMP_SETUP" <<EOF
#!/system/bin/sh
# AGY_ADB_BRIDGE_SETUP v1.0.0
export HOME="\${HOME:-$HOME}"
export PREFIX="\${PREFIX:-$PREFIX}"
exec /system/bin/sh "$TARGET_DIR/mcp/bin/agy-adb-setup" "\$@"
EOF
chmod 0755 "$TMP_SETUP"
mv -f "$TMP_SETUP" "$PREFIX/bin/agy-adb-setup"

echo "============================================================"
echo " Plugin AGY ADB Bridge v1.0.0 (Native Rust ARM64) activo"
echo " Ruta: $TARGET_DIR"
echo " Wrappers en \$PREFIX/bin: rish, agy-adb, agy-adb-setup"
echo "============================================================"
