# AGY ADB Bridge Rules (Android ARM64 — Native Rust)

When the `agy-adb-bridge` plugin is enabled on Antigravity for Android:

1. **Transparent `uid=2000(shell)` Execution via `$PREFIX/bin/rish`:**
   - Because `$PREFIX/bin` precedes `$HOME/runtime/bin` in `$PATH`, invoking `rish -c "<cmd>"` in `run_command` automatically uses `agy-adb-bridge`'s Rust wrapper:
     1. Fast path: local `adb` (`127.0.0.1:5555` or on-demand mDNS TLS endpoint using `$HOME/.android/adbkey`).
     2. Fallback: `/data/user/0/com.agy/files/runtime/bin/rish` (Shizuku) guarded by a hard `2s` watchdog so MIUI/HyperOS sleep never stalls a command.
   - You can also invoke `adb_bridge_shell`, `adb_bridge_status`, `adb_bridge_pair`, `adb_bridge_connect`, `adb_bridge_discover`, `adb_bridge_configure`, and `adb_bridge_setup` directly via MCP, or `agy-adb <subcommand>` in terminal.

2. **One-Time 6-Digit Pairing Guidance:**
   - If `adb_bridge_status` reports `adbkey_present: false` or neither ADB nor Shizuku is active, guide the user through the one-time setup:
     * Open **Ajustes → Opciones de desarrollador → Depuración inalámbrica → Vincular dispositivo con código de vinculación** (ideally in split-screen/floating window so the 6-digit code stays visible).
     * Ask the user for the 6-digit code (and optional port if mDNS is blocked on their network) and call `adb_bridge_pair` (or tell them to run `agy-adb pair <6-digitos>`).
   - Once paired, `adb tcpip 5555` keeps `127.0.0.1:5555` active offline (even with Wi-Fi turned off) until the next device reboot; after a reboot, call `adb_bridge_connect` once on Wi-Fi without re-pairing.

3. **Protect `$HOME/runtime/bin`:**
   - Never modify, overwrite, or delete `/data/user/0/com.agy/files/runtime/bin/rish`. Self-healing applies only to `$PREFIX/bin/rish` and `$PREFIX/bin/agy-adb`.
