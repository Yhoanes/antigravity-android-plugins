---
name: agy-adb-bridge
description: Native Android ARM64 Rust ADB & Shizuku bridge providing persistent uid=2000(shell) permissions via android-tools ($PREFIX/bin/adb + $HOME/.android/adbkey + adb tcpip 5555 on 127.0.0.1:5555), zero-polling mDNS discovery, and a self-healing rish wrapper with a 2s MIUI-safe Shizuku fallback. Use whenever checking, pairing, reconnecting, or troubleshooting elevated shell/rish permissions on Android.
---

# AGY ADB Bridge (Native Rust ARM64)

`agy-adb-bridge` replaces reliance on an external background Shizuku app with an in-sandbox native Rust engine backed by `android-tools` (`$PREFIX/bin/adb`) and a persistent RSA key in `$HOME/.android/adbkey`.

## Architecture

1. **Zero-Conflict Wrapper (`$PREFIX/bin/rish`):**
   - Lives solely in `$PREFIX/bin` (`/data/user/0/com.agy/files/usr/bin/rish`), leaving `/data/user/0/com.agy/files/runtime/bin/rish` completely untouched.
   - Auto-repairs itself silently whenever `start-mcp.sh` or `agy-adb` starts (so APK restarts that overwrite `$PREFIX/bin/rish` never break the bridge).
   - Inspects `stdin` (`isatty` + `poll`) so automated `rish -c "..."` calls never hang waiting for PTY EOF while genuine binary pipes (`cat`, file redirection) stream intact.
2. **Offline-Capable Loopback (`127.0.0.1:5555`):**
   - During pairing (`adb_bridge_pair` / `agy-adb pair <6-digitos>`), the bridge pairs over Wireless Debugging TLS, connects, and runs `adb tcpip 5555`.
   - From that moment on, commands route over loopback `127.0.0.1:5555` in `<25 ms`, surviving Wi-Fi off, mobile data switches, and MIUI/HyperOS aggressive background killing until the phone reboots.
3. **Zero-Polling On-Demand mDNS (`224.0.0.251:5353`):**
   - Discovers `_adb-tls-pairing._tcp` and `_adb-tls-connect._tcp` purely on demand (0% background battery drain).
   - After a phone reboot, turning Wireless Debugging back on lets `adb_bridge_connect` (or the next `rish` call when on Wi-Fi) auto-discover the new TLS port using the saved `$HOME/.android/adbkey` and re-promote `127.0.0.1:5555` without needing a new 6-digit pairing code.
4. **Hard 2s MIUI-Safe Fallback:**
   - If ADB is not yet paired or reachable, `$PREFIX/bin/rish` falls back to `/data/user/0/com.agy/files/runtime/bin/rish` inside a dedicated process group with a strict `2000 ms` SIGKILL watchdog (exit code `124` on timeout instead of hanging indefinitely).

## Quick Commands & MCP Tools

| Goal | MCP Tool | CLI Equivalent |
| :--- | :--- | :--- |
| Check bridge, key, `127.0.0.1:5555`, mDNS & Shizuku | `adb_bridge_status` | `agy-adb status` |
| Scan Wireless Debugging ports via mDNS | `adb_bridge_discover` | `agy-adb discover` |
| One-time 6-digit pairing + `tcpip 5555` | `adb_bridge_pair` | `agy-adb pair <6-digitos> [puerto]` |
| Reconnect after reboot/Wi-Fi change | `adb_bridge_connect` | `agy-adb connect [puerto]` |
| Run elevated `uid=2000(shell)` command | `adb_bridge_shell` | `agy-adb exec "<cmd>"` or `rish -c "<cmd>"` |
| Change mode (`tcpip`, `tls_only`, `shizuku_only`) or disconnect | `adb_bridge_configure` | `agy-adb mode <modo>` / `agy-adb disconnect` |
| Install `android-tools` & repair `$PREFIX/bin` wrappers | `adb_bridge_setup` | `agy-adb setup` / `agy-adb-setup` |

## Security Note (`tcpip` vs `tls_only`)

- `preferred_mode: "tcpip"` (default) keeps local `127.0.0.1:5555` active even when Wi-Fi is off, requiring only RSA key auth from `adbkey`.
- On untrusted public Wi-Fi networks, you can temporarily run `agy-adb disconnect` or switch to `agy-adb mode tls_only` so only TLS-encrypted Wireless Debugging is used.
