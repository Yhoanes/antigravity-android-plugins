use crate::adb::{
    adb_version, disconnect_adb, ensure_android_tools_installed, pair_and_activate,
    query_uid, reconnect_with_saved_key, resolve_active_adb_serial, tcp_port_open,
};
use crate::config::{
    adb_bin_path, adbkey_path, ensure_wrappers_installed, is_rish_wrapper_healthy,
    stock_rish_path, BridgeConfig, WRAPPER_VERSION,
};
use crate::mdns::discover_mdns_endpoints;
use crate::rish::execute_shell_captured;
use serde::Serialize;
use serde_json::{json, Value};
use std::io::{self, BufRead, BufReader, BufWriter, Write};

const SERVER_NAME: &str = "agy-adb-bridge";

#[derive(Debug, Serialize)]
pub struct BridgeStatus {
    pub version: &'static str,
    pub adb_installed: bool,
    pub adb_path: Option<String>,
    pub adb_version: Option<String>,
    pub adbkey_present: bool,
    pub adbkey_path: String,
    pub preferred_mode: String,
    pub tcpip_port: u16,
    pub fallback_timeout_ms: u64,
    pub last_tls_endpoint: Option<String>,
    pub loopback_5555_open: bool,
    pub active_backend: String,
    pub active_serial: Option<String>,
    pub uid_check: Option<String>,
    pub wlan_ip: Option<String>,
    pub mdns_connect_endpoints: Vec<crate::mdns::MdnsEndpoint>,
    pub mdns_pairing_endpoints: Vec<crate::mdns::MdnsEndpoint>,
    pub rish_wrapper_healthy: bool,
    pub shizuku_fallback_ready: bool,
}

/// Gather live status of ADB bridge, local `127.0.0.1:5555`, mDNS services, and Shizuku fallback.
pub fn collect_status(scan_mdns_ms: u64) -> BridgeStatus {
    let mut cfg = BridgeConfig::load();
    let adb = adb_bin_path();
    let adb_ver = adb.as_deref().and_then(adb_version);
    let key_ok = adbkey_path().is_file();
    let loopback = format!("127.0.0.1:{}", cfg.tcpip_port);
    let loopback_open = tcp_port_open(&loopback, 80);

    let disc = discover_mdns_endpoints(adb.as_deref(), scan_mdns_ms, false);

    let (active_serial, active_backend, uid_check) =
        if let (Some(ref abin), Some((serial, backend))) =
            (&adb, resolve_active_adb_serial(&mut cfg))
        {
            let uid = query_uid(abin, &serial);
            (Some(serial), backend.to_string(), Some(uid))
        } else if stock_rish_path().is_file() {
            let probe = execute_shell_captured("id", cfg.fallback_timeout_ms);
            match probe {
                Ok(res) if !res.timed_out && res.exit_code == 0 && res.stdout.contains("uid=") => (
                    Some("shizuku".to_string()),
                    "shizuku-fallback".to_string(),
                    Some(res.stdout.trim().to_string()),
                ),
                _ => (None, "none".to_string(), None),
            }
        } else {
            (None, "none".to_string(), None)
        };

    let shizuku_ready = active_backend == "shizuku-fallback"
        || (stock_rish_path().is_file() && active_backend != "none");

    BridgeStatus {
        version: WRAPPER_VERSION,
        adb_installed: adb.is_some(),
        adb_path: adb.map(|p| p.display().to_string()),
        adb_version: adb_ver,
        adbkey_present: key_ok,
        adbkey_path: adbkey_path().display().to_string(),
        preferred_mode: cfg.preferred_mode.clone(),
        tcpip_port: cfg.tcpip_port,
        fallback_timeout_ms: cfg.fallback_timeout_ms,
        last_tls_endpoint: cfg.last_tls_endpoint.clone(),
        loopback_5555_open: loopback_open,
        active_backend,
        active_serial,
        uid_check,
        wlan_ip: disc.wlan_ip,
        mdns_connect_endpoints: disc.connect_endpoints,
        mdns_pairing_endpoints: disc.pairing_endpoints,
        rish_wrapper_healthy: is_rish_wrapper_healthy(),
        shizuku_fallback_ready: shizuku_ready && stock_rish_path().is_file(),
    }
}

fn tool_definitions() -> Value {
    json!([
        {
            "name": "adb_bridge_status",
            "description": "Inspect the native ARM64 ADB bridge (`127.0.0.1:5555`, saved RSA key `$HOME/.android/adbkey`, mDNS Wireless Debugging endpoints, `$PREFIX/bin/rish` wrapper health, and 2s Shizuku fallback).",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "scan_ms": { "type": "integer", "description": "Optional on-demand mDNS scan window in ms (default 450)" }
                }
            }
        },
        {
            "name": "adb_bridge_discover",
            "description": "Run an on-demand zero-polling mDNS scan (`224.0.0.251:5353`) for `_adb-tls-pairing._tcp` and `_adb-tls-connect._tcp` Wireless Debugging ports on this device.",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "timeout_ms": { "type": "integer", "description": "Scan duration in milliseconds (default 1200)" }
                }
            }
        },
        {
            "name": "adb_bridge_pair",
            "description": "One-time Wireless Debugging pairing with the 6-digit code shown in Android Developer Options -> Wireless debugging -> Pair device with pairing code. Persists RSA key in `$HOME/.android/adbkey`, connects TLS, enables `adb tcpip 5555` (`127.0.0.1:5555`) so `uid=2000(shell)` stays alive even when Wi-Fi is turned off, and verifies `id`.",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "code": { "type": "string", "description": "6-digit Wireless Debugging pairing code" },
                    "pairing_port": { "type": "string", "description": "Optional pairing port (e.g. '38123') or 'host:port'; auto-discovered via mDNS if omitted" },
                    "connect_port": { "type": "string", "description": "Optional main Wireless Debugging connect port or 'host:port'; auto-discovered via mDNS if omitted" }
                },
                "required": ["code"]
            }
        },
        {
            "name": "adb_bridge_connect",
            "description": "Reconnect without re-pairing using the saved RSA key (`$HOME/.android/adbkey`), promoting the TLS session back to `127.0.0.1:5555` when preferred_mode='tcpip'.",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "endpoint": { "type": "string", "description": "Optional port or 'host:port'; auto-discovered via mDNS if omitted" },
                    "promote_tcpip": { "type": "boolean", "description": "Promote TLS connection to local 127.0.0.1:5555 (default true)" }
                }
            }
        },
        {
            "name": "adb_bridge_shell",
            "description": "Execute a shell command as `uid=2000(shell)` using the active local ADB bridge (`127.0.0.1:5555` or TLS) with 2s MIUI-safe Shizuku fallback.",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "command": { "type": "string", "description": "Shell command to execute under /system/bin/sh" },
                    "timeout_ms": { "type": "integer", "description": "Maximum execution time in ms (default 15000)" }
                },
                "required": ["command"]
            }
        },
        {
            "name": "adb_bridge_configure",
            "description": "Configure bridge mode (`tcpip`, `tls_only`, `shizuku_only`), loopback TCP/IP port (default 5555), fallback timeout (default 2000 ms), or disconnect the active TCP/IP session.",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "preferred_mode": { "type": "string", "enum": ["tcpip", "tls_only", "shizuku_only"] },
                    "tcpip_port": { "type": "integer", "description": "Local loopback port (1024-65535, default 5555)" },
                    "fallback_timeout_ms": { "type": "integer", "description": "Watchdog timeout for Shizuku fallback (500-10000 ms, default 2000)" },
                    "disconnect_now": { "type": "boolean", "description": "If true, disconnect ADB and disable tcpip listener" }
                }
            }
        },
        {
            "name": "adb_bridge_setup",
            "description": "Ensure `android-tools` (`$PREFIX/bin/adb`) is installed via `pkg` and repair `$PREFIX/bin/rish`, `$PREFIX/bin/agy-adb`, and `$PREFIX/bin/agy-adb-setup` without touching `runtime/bin`.",
            "inputSchema": {
                "type": "object",
                "properties": {}
            }
        }
    ])
}

fn handle_tool_call(name: &str, args: &Value) -> Result<Value, String> {
    match name {
        "adb_bridge_status" => {
            let scan_ms = args
                .get("scan_ms")
                .and_then(|v| v.as_u64())
                .unwrap_or(450)
                .clamp(150, 5000);
            let st = collect_status(scan_ms);
            serde_json::to_value(st).map_err(|e| e.to_string())
        }
        "adb_bridge_discover" => {
            let timeout_ms = args
                .get("timeout_ms")
                .and_then(|v| v.as_u64())
                .unwrap_or(1200)
                .clamp(200, 6000);
            let disc = discover_mdns_endpoints(adb_bin_path().as_deref(), timeout_ms, false);
            serde_json::to_value(disc).map_err(|e| e.to_string())
        }
        "adb_bridge_pair" => {
            let code = args
                .get("code")
                .and_then(|v| v.as_str())
                .ok_or_else(|| "Missing required 'code' parameter".to_string())?;
            let pairing_port = args.get("pairing_port").and_then(|v| {
                v.as_str()
                    .map(|s| s.to_string())
                    .or_else(|| v.as_u64().map(|n| n.to_string()))
            });
            let connect_port = args.get("connect_port").and_then(|v| {
                v.as_str()
                    .map(|s| s.to_string())
                    .or_else(|| v.as_u64().map(|n| n.to_string()))
            });
            let mut cfg = BridgeConfig::load();
            let res = pair_and_activate(
                &mut cfg,
                code,
                pairing_port.as_deref(),
                connect_port.as_deref(),
            )?;
            serde_json::to_value(res).map_err(|e| e.to_string())
        }
        "adb_bridge_connect" => {
            let endpoint = args.get("endpoint").and_then(|v| {
                v.as_str()
                    .map(|s| s.to_string())
                    .or_else(|| v.as_u64().map(|n| n.to_string()))
            });
            let promote = args
                .get("promote_tcpip")
                .and_then(|v| v.as_bool())
                .unwrap_or(true);
            let mut cfg = BridgeConfig::load();
            let res = reconnect_with_saved_key(&mut cfg, endpoint.as_deref(), promote)?;
            serde_json::to_value(res).map_err(|e| e.to_string())
        }
        "adb_bridge_shell" => {
            let command = args
                .get("command")
                .and_then(|v| v.as_str())
                .ok_or_else(|| "Missing required 'command' parameter".to_string())?;
            let timeout_ms = args
                .get("timeout_ms")
                .and_then(|v| v.as_u64())
                .unwrap_or(15000)
                .clamp(500, 120_000);
            let res = execute_shell_captured(command, timeout_ms)?;
            serde_json::to_value(res).map_err(|e| e.to_string())
        }
        "adb_bridge_configure" => {
            let mut cfg = BridgeConfig::load();
            if let Some(mode) = args.get("preferred_mode").and_then(|v| v.as_str()) {
                cfg.preferred_mode = mode.to_string();
            }
            if let Some(port) = args.get("tcpip_port").and_then(|v| v.as_u64()) {
                cfg.tcpip_port = port.clamp(1024, 65535) as u16;
            }
            if let Some(tout) = args.get("fallback_timeout_ms").and_then(|v| v.as_u64()) {
                cfg.fallback_timeout_ms = tout.clamp(500, 10000);
            }
            cfg.sanitize();
            cfg.save()?;
            let mut disc_msg = None;
            if args
                .get("disconnect_now")
                .and_then(|v| v.as_bool())
                .unwrap_or(false)
            {
                disc_msg = Some(disconnect_adb(&cfg).unwrap_or_else(|e| e));
            }
            Ok(json!({
                "config": cfg,
                "disconnected": disc_msg,
            }))
        }
        "adb_bridge_setup" => {
            let pkg_msg = ensure_android_tools_installed()?;
            ensure_wrappers_installed()?;
            let st = collect_status(350);
            Ok(json!({
                "setup_result": pkg_msg,
                "wrappers_repaired": st.rish_wrapper_healthy,
                "status": st,
            }))
        }
        _ => Err(format!("Unknown tool: {name}")),
    }
}

fn send_json(out: &mut impl Write, use_content_length: bool, val: &Value) {
    if let Ok(bytes) = serde_json::to_vec(val) {
        if use_content_length {
            let _ = write!(out, "Content-Length: {}\r\n\r\n", bytes.len());
            let _ = out.write_all(&bytes);
        } else {
            let _ = out.write_all(&bytes);
            let _ = out.write_all(b"\n");
        }
        let _ = out.flush();
    }
}

fn read_next_message<R: BufRead>(
    reader: &mut R,
    use_content_length: &mut bool,
) -> io::Result<Option<String>> {
    loop {
        let mut line = String::new();
        let n = reader.read_line(&mut line)?;
        if n == 0 {
            return Ok(None);
        }
        let t = line.trim();
        if t.is_empty() {
            continue;
        }
        if t.len() >= 15 && t[..15].eq_ignore_ascii_case("content-length:") {
            *use_content_length = true;
            let len: usize = t[15..].trim().parse().unwrap_or(0);
            loop {
                let mut hdr = String::new();
                if reader.read_line(&mut hdr)? == 0 || hdr.trim().is_empty() {
                    break;
                }
            }
            let mut body = vec![0u8; len];
            reader.read_exact(&mut body)?;
            return Ok(Some(String::from_utf8_lossy(&body).to_string()));
        }
        return Ok(Some(t.to_string()));
    }
}

/// Run the silent stdio JSON-RPC 2.0 MCP server loop (supports both newline and Content-Length framing).
pub fn run_mcp_server() -> i32 {
    // Self-heal `$PREFIX/bin/rish` silently on startup without writing anything to stdout.
    let _ = ensure_wrappers_installed();

    let stdin = io::stdin();
    let stdout = io::stdout();
    let mut reader = BufReader::new(stdin.lock());
    let mut out = BufWriter::new(stdout.lock());
    let mut use_content_length = false;

    loop {
        let payload = match read_next_message(&mut reader, &mut use_content_length) {
            Ok(Some(msg)) => msg,
            Ok(None) | Err(_) => break,
        };
        let trimmed = payload.trim();
        if trimmed.is_empty() {
            continue;
        }
        let req: Value = match serde_json::from_str(trimmed) {
            Ok(v) => v,
            Err(_) => {
                send_json(
                    &mut out,
                    use_content_length,
                    &json!({
                        "jsonrpc": "2.0",
                        "id": Value::Null,
                        "error": { "code": -32700, "message": "Parse error" }
                    }),
                );
                continue;
            }
        };

        let method = req.get("method").and_then(|v| v.as_str()).unwrap_or("");
        let msg_id = req.get("id").cloned();

        if method == "notifications/initialized" || msg_id.is_none() {
            continue;
        }
        let id = msg_id.unwrap();

        match method {
            "initialize" => {
                let proto = req
                    .get("params")
                    .and_then(|p| p.get("protocolVersion"))
                    .and_then(|v| v.as_str())
                    .filter(|s| !s.is_empty())
                    .unwrap_or("2024-11-05");
                send_json(
                    &mut out,
                    use_content_length,
                    &json!({
                        "jsonrpc": "2.0",
                        "id": id,
                        "result": {
                            "protocolVersion": proto,
                            "capabilities": { "tools": {} },
                            "serverInfo": {
                                "name": SERVER_NAME,
                                "version": WRAPPER_VERSION
                            }
                        }
                    }),
                );
            }
            "tools/list" => {
                send_json(
                    &mut out,
                    use_content_length,
                    &json!({
                        "jsonrpc": "2.0",
                        "id": id,
                        "result": { "tools": tool_definitions() }
                    }),
                );
            }
            "resources/list" => {
                send_json(
                    &mut out,
                    use_content_length,
                    &json!({
                        "jsonrpc": "2.0",
                        "id": id,
                        "result": { "resources": [] }
                    }),
                );
            }
            "prompts/list" => {
                send_json(
                    &mut out,
                    use_content_length,
                    &json!({
                        "jsonrpc": "2.0",
                        "id": id,
                        "result": { "prompts": [] }
                    }),
                );
            }
            "tools/call" => {
                let params = req.get("params").cloned().unwrap_or_else(|| json!({}));
                let t_name = params.get("name").and_then(|v| v.as_str()).unwrap_or("");
                let t_args = params.get("arguments").cloned().unwrap_or_else(|| json!({}));
                match handle_tool_call(t_name, &t_args) {
                    Ok(res) => {
                        let text = serde_json::to_string_pretty(&res).unwrap_or_default();
                        send_json(
                            &mut out,
                            use_content_length,
                            &json!({
                                "jsonrpc": "2.0",
                                "id": id,
                                "result": {
                                    "content": [{ "type": "text", "text": text }]
                                }
                            }),
                        );
                    }
                    Err(err) => {
                        send_json(
                            &mut out,
                            use_content_length,
                            &json!({
                                "jsonrpc": "2.0",
                                "id": id,
                                "result": {
                                    "isError": true,
                                    "content": [{ "type": "text", "text": format!("Error: {err}") }]
                                }
                            }),
                        );
                    }
                }
            }
            "ping" => {
                send_json(
                    &mut out,
                    use_content_length,
                    &json!({
                        "jsonrpc": "2.0",
                        "id": id,
                        "result": {}
                    }),
                );
            }
            _ => {
                send_json(
                    &mut out,
                    use_content_length,
                    &json!({
                        "jsonrpc": "2.0",
                        "id": id,
                        "error": { "code": -32601, "message": format!("Method not found: {method}") }
                    }),
                );
            }
        }
    }

    0
}
