use crate::adb::{adb_command, resolve_active_adb_serial, run_with_timeout};
use crate::config::{adb_bin_path, stock_rish_path, BridgeConfig};
use serde::Serialize;
use std::os::unix::process::{CommandExt, ExitStatusExt};
use std::process::{Command, Stdio};
use std::thread;
use std::time::{Duration, Instant};

#[derive(Debug, Clone, Serialize)]
pub struct ShellExecResult {
    pub backend: String,
    pub exit_code: i32,
    pub stdout: String,
    pub stderr: String,
    pub elapsed_ms: u64,
    pub timed_out: bool,
}

/// POSIX single-quote escaping safe for `/system/bin/sh`.
pub fn shell_quote(arg: &str) -> String {
    let mut out = String::with_capacity(arg.len() + 2);
    out.push('\'');
    for ch in arg.chars() {
        if ch == '\'' {
            out.push_str("'\\''");
        } else {
            out.push(ch);
        }
    }
    out.push('\'');
    out
}

fn is_tty(fd: libc::c_int) -> bool {
    unsafe { libc::isatty(fd) == 1 }
}

/// Inspect fd 0 so automated `rish -c` calls never block on an open PTY or idle runner pipe,
/// while genuine piped data (`printf ... | rish -c "cat"`) or file redirects stream cleanly.
fn stdin_has_payload(is_command_mode: bool) -> bool {
    if !is_command_mode {
        return true;
    }
    if is_tty(0) {
        return false;
    }
    unsafe {
        let mut st: libc::stat = std::mem::zeroed();
        if libc::fstat(0, &mut st) != 0 {
            return false;
        }
        let kind = st.st_mode & libc::S_IFMT;
        if kind == libc::S_IFREG {
            return true;
        }
        if kind == libc::S_IFCHR {
            return false;
        }
        if kind == libc::S_IFIFO || kind == libc::S_IFSOCK {
            let mut pfd = libc::pollfd {
                fd: 0,
                events: libc::POLLIN,
                revents: 0,
            };
            let rc = libc::poll(&mut pfd as *mut libc::pollfd, 1, 15);
            return rc > 0 && (pfd.revents & libc::POLLIN) != 0;
        }
        false
    }
}

fn build_remote_shell_command(args: &[String]) -> Option<String> {
    if args.is_empty() {
        return None;
    }
    if args[0] == "-c" {
        if args.len() < 2 {
            return Some("exec /system/bin/sh -c ''".to_string());
        }
        let mut parts = vec![
            "exec".to_string(),
            "/system/bin/sh".to_string(),
            "-c".to_string(),
            shell_quote(&args[1]),
        ];
        for extra in &args[2..] {
            parts.push(shell_quote(extra));
        }
        return Some(parts.join(" "));
    }
    Some(
        args.iter()
            .map(|a| shell_quote(a))
            .collect::<Vec<_>>()
            .join(" "),
    )
}

/// Drop-in smart `rish` entrypoint: executes via local `adb` (`127.0.0.1:5555` or TLS) first,
/// falling back to stock `runtime/bin/rish` with a hard 2s MIUI-safe timeout.
pub fn run_smart_rish(args: &[String]) -> i32 {
    let mut cfg = BridgeConfig::load();
    let is_cmd = !args.is_empty();
    let pass_stdin = stdin_has_payload(is_cmd);

    if let (Some(adb_bin), Some((serial, _backend))) =
        (adb_bin_path(), resolve_active_adb_serial(&mut cfg))
    {
        let mut cmd = adb_command(&adb_bin);
        cmd.args(["-s", &serial, "shell"]);

        match build_remote_shell_command(args) {
            Some(remote_cmd) => {
                if !pass_stdin {
                    cmd.arg("-n");
                }
                cmd.arg("-T");
                cmd.arg(remote_cmd);
            }
            None => {
                if !(is_tty(0) && is_tty(1)) {
                    cmd.args(["-T", "/system/bin/sh"]);
                }
            }
        }

        cmd.stdin(if pass_stdin {
            Stdio::inherit()
        } else {
            Stdio::null()
        });
        cmd.stdout(Stdio::inherit()).stderr(Stdio::inherit());

        match cmd.status() {
            Ok(status) => {
                return status
                    .code()
                    .unwrap_or_else(|| 128 + status.signal().unwrap_or(1));
            }
            Err(e) => {
                eprintln!("[agy-adb-bridge] adb shell error ({e}); intentando fallback Shizuku...");
            }
        }
    }

    run_stock_rish_fallback(args, pass_stdin, cfg.fallback_timeout_ms)
}

fn run_stock_rish_fallback(args: &[String], pass_stdin: bool, timeout_ms: u64) -> i32 {
    let stock = stock_rish_path();
    if !stock.is_file() {
        eprintln!(
            "[agy-adb-bridge] Ni el puente ADB ni {} estan activos. Empareja una vez con: agy-adb pair <6-digitos>",
            stock.display()
        );
        return 127;
    }

    let interactive_tty = args.is_empty() && is_tty(0) && is_tty(1);

    let mut cmd = Command::new("/system/bin/sh");
    cmd.arg(&stock);
    cmd.args(args);
    cmd.env_remove("LD_PRELOAD")
        .env_remove("LD_LIBRARY_PATH")
        .env("RISH_APPLICATION_ID", "com.agy")
        .stdin(if pass_stdin {
            Stdio::inherit()
        } else {
            Stdio::null()
        })
        .stdout(Stdio::inherit())
        .stderr(Stdio::inherit());

    if !interactive_tty {
        cmd.process_group(0);
    }

    let mut child = match cmd.spawn() {
        Ok(c) => c,
        Err(e) => {
            eprintln!("[agy-adb-bridge] Error lanzando fallback Shizuku: {e}");
            return 126;
        }
    };

    if interactive_tty {
        return match child.wait() {
            Ok(s) => s.code().unwrap_or(0),
            Err(_) => 1,
        };
    }

    let pid = child.id() as libc::pid_t;
    let started = Instant::now();
    let deadline = Duration::from_millis(timeout_ms.max(500));

    loop {
        match child.try_wait() {
            Ok(Some(status)) => {
                return status
                    .code()
                    .unwrap_or_else(|| 128 + status.signal().unwrap_or(1));
            }
            Ok(None) => {
                if started.elapsed() >= deadline {
                    unsafe {
                        libc::kill(-pid, libc::SIGKILL);
                    }
                    let _ = child.kill();
                    let _ = child.wait();
                    eprintln!(
                        "[agy-adb-bridge] Shizuku fallback agoto {} ms (MIUI bloqueado o servicio apagado) y el puente ADB no esta vinculado. Vincula una vez con: agy-adb pair <6-digitos>",
                        timeout_ms
                    );
                    return 124;
                }
                thread::sleep(Duration::from_millis(20));
            }
            Err(e) => {
                unsafe {
                    libc::kill(-pid, libc::SIGKILL);
                }
                let _ = child.kill();
                let _ = child.wait();
                eprintln!("[agy-adb-bridge] Error esperando Shizuku: {e}");
                return 1;
            }
        }
    }
}

/// Execute a shell command with captured stdout/stderr for MCP and `agy-adb exec`.
pub fn execute_shell_captured(command: &str, timeout_ms: u64) -> Result<ShellExecResult, String> {
    let mut cfg = BridgeConfig::load();
    let started = Instant::now();

    if let (Some(adb_bin), Some((serial, backend))) =
        (adb_bin_path(), resolve_active_adb_serial(&mut cfg))
    {
        let remote = format!("exec /system/bin/sh -c {}", shell_quote(command));
        let mut cmd = adb_command(&adb_bin);
        cmd.args(["-s", &serial, "shell", "-n", "-T", &remote]);
        let out = run_with_timeout(cmd, timeout_ms.max(500))?;
        return Ok(ShellExecResult {
            backend: format!("{backend}:{serial}"),
            exit_code: out.exit_code,
            stdout: out.stdout,
            stderr: out.stderr,
            elapsed_ms: started.elapsed().as_millis() as u64,
            timed_out: out.timed_out,
        });
    }

    let stock = stock_rish_path();
    if !stock.is_file() {
        return Err(
            "No hay puente ADB activo ni Shizuku disponible. Vincula una vez con 'agy-adb pair <6-digitos>'."
                .to_string(),
        );
    }
    let mut cmd = Command::new("/system/bin/sh");
    cmd.arg(&stock)
        .args(["-c", command])
        .env_remove("LD_PRELOAD")
        .env_remove("LD_LIBRARY_PATH")
        .env("RISH_APPLICATION_ID", "com.agy");

    let cap_timeout = timeout_ms.min(cfg.fallback_timeout_ms).max(500);
    let out = run_with_timeout(cmd, cap_timeout)?;
    let mut stderr = out.stderr;
    if out.timed_out && stderr.is_empty() {
        stderr = format!(
            "Shizuku fallback timed out after {cap_timeout} ms and ADB bridge is not connected."
        );
    }

    Ok(ShellExecResult {
        backend: "shizuku-fallback".to_string(),
        exit_code: out.exit_code,
        stdout: out.stdout,
        stderr,
        elapsed_ms: started.elapsed().as_millis() as u64,
        timed_out: out.timed_out,
    })
}
