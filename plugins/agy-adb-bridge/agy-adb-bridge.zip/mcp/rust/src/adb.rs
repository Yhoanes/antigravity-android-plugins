use crate::config::{
    adb_bin_path, adbkey_path, android_home_dir, home_dir, prefix_bin_dir, prefix_lib_dir,
    prefix_tmp_dir, BridgeConfig,
};
use crate::mdns::{detect_local_wlan_ip, discover_mdns_endpoints};
use serde::Serialize;
use std::fs;
use std::net::{SocketAddr, TcpStream};
use std::os::unix::fs::PermissionsExt;
use std::os::unix::process::CommandExt;
use std::path::Path;
use std::process::{Command, Stdio};
use std::thread;
use std::time::{Duration, Instant};

#[derive(Debug, Clone)]
pub struct CmdOutput {
    pub exit_code: i32,
    pub stdout: String,
    pub stderr: String,
    pub timed_out: bool,
}

#[derive(Debug, Clone, Serialize)]
pub struct PairResult {
    pub paired: bool,
    pub pairing_endpoint: String,
    pub tls_endpoint: Option<String>,
    pub active_serial: String,
    pub active_backend: String,
    pub tcpip_port: Option<u16>,
    pub uid_check: String,
    pub adbkey_path: String,
    pub write_secure_settings_granted: bool,
}

#[derive(Debug, Clone, Serialize)]
pub struct ConnectResult {
    pub connected: bool,
    pub active_serial: String,
    pub active_backend: String,
    pub tls_endpoint: Option<String>,
    pub tcpip_port: Option<u16>,
    pub uid_check: String,
}

/// Build an `adb` command configured for Antigravity Bionic `$HOME/.android` and `$PREFIX/lib`.
pub fn adb_command(adb_bin: &Path) -> Command {
    let home = home_dir();
    let android_home = android_home_dir();
    let tmp_dir = prefix_tmp_dir();
    let _ = fs::create_dir_all(&android_home);
    let _ = fs::set_permissions(&android_home, fs::Permissions::from_mode(0o700));
    let _ = fs::create_dir_all(&tmp_dir);

    let lib_dir = prefix_lib_dir();
    let ld_path = match std::env::var("LD_LIBRARY_PATH") {
        Ok(existing) if !existing.is_empty() => format!("{}:{existing}", lib_dir.display()),
        _ => lib_dir.display().to_string(),
    };

    let mut cmd = Command::new(adb_bin);
    cmd.env("HOME", &home)
        .env("ANDROID_USER_HOME", &android_home)
        .env("TMPDIR", &tmp_dir)
        .env("LD_LIBRARY_PATH", ld_path)
        .env(
            "PATH",
            format!("{}:/system/bin", prefix_bin_dir().display()),
        );
    cmd
}

/// Run a command in its own process group with deadlock-free piped output and hard SIGKILL timeout.
pub fn run_with_timeout(mut cmd: Command, timeout_ms: u64) -> Result<CmdOutput, String> {
    cmd.stdin(Stdio::null())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .process_group(0);

    let mut child = cmd
        .spawn()
        .map_err(|e| format!("Failed spawning process: {e}"))?;
    let pid = child.id() as libc::pid_t;

    let out_pipe = child.stdout.take();
    let err_pipe = child.stderr.take();

    let out_handle = thread::spawn(move || -> Vec<u8> {
        let mut buf = Vec::new();
        if let Some(mut r) = out_pipe {
            let _ = std::io::Read::read_to_end(&mut r, &mut buf);
        }
        buf
    });
    let err_handle = thread::spawn(move || -> Vec<u8> {
        let mut buf = Vec::new();
        if let Some(mut r) = err_pipe {
            let _ = std::io::Read::read_to_end(&mut r, &mut buf);
        }
        buf
    });

    let started = Instant::now();
    let deadline = Duration::from_millis(timeout_ms.max(100));
    let mut timed_out = false;
    let exit_code: i32;

    loop {
        match child.try_wait() {
            Ok(Some(status)) => {
                exit_code = status.code().unwrap_or(1);
                break;
            }
            Ok(None) => {
                if started.elapsed() >= deadline {
                    timed_out = true;
                    unsafe {
                        libc::kill(-pid, libc::SIGKILL);
                    }
                    let _ = child.kill();
                    let _ = child.wait();
                    exit_code = 124;
                    break;
                }
                thread::sleep(Duration::from_millis(15));
            }
            Err(e) => {
                unsafe {
                    libc::kill(-pid, libc::SIGKILL);
                }
                return Err(format!("Wait error: {e}"));
            }
        }
    }

    let stdout_bytes = out_handle.join().unwrap_or_default();
    let stderr_bytes = err_handle.join().unwrap_or_default();

    Ok(CmdOutput {
        exit_code,
        stdout: String::from_utf8_lossy(&stdout_bytes).into_owned(),
        stderr: String::from_utf8_lossy(&stderr_bytes).into_owned(),
        timed_out,
    })
}

/// Fast non-blocking-style TCP probe to verify if an endpoint is listening before spawning `adb`.
pub fn tcp_port_open(endpoint: &str, timeout_ms: u64) -> bool {
    let Ok(addr) = endpoint.parse::<SocketAddr>() else {
        return false;
    };
    TcpStream::connect_timeout(&addr, Duration::from_millis(timeout_ms)).is_ok()
}

pub fn adb_version(adb_bin: &Path) -> Option<String> {
    let mut cmd = adb_command(adb_bin);
    cmd.arg("version");
    let out = run_with_timeout(cmd, 1500).ok()?;
    if out.exit_code != 0 {
        return None;
    }
    Some(
        out.stdout
            .lines()
            .take(2)
            .collect::<Vec<_>>()
            .join(" / "),
    )
}

pub fn adb_get_state(adb_bin: &Path, serial: &str) -> bool {
    let mut cmd = adb_command(adb_bin);
    cmd.args(["-s", serial, "get-state"]);
    match run_with_timeout(cmd, 1200) {
        Ok(out) => !out.timed_out && out.exit_code == 0 && out.stdout.trim() == "device",
        Err(_) => false,
    }
}

pub fn adb_connect_endpoint(adb_bin: &Path, endpoint: &str) -> Result<bool, String> {
    let mut cmd = adb_command(adb_bin);
    cmd.args(["connect", endpoint]);
    let out = run_with_timeout(cmd, 2500)?;
    let combined = format!("{}\n{}", out.stdout, out.stderr);
    if out.timed_out {
        return Ok(false);
    }
    if adb_get_state(adb_bin, endpoint) {
        return Ok(true);
    }
    Ok(combined.to_ascii_lowercase().contains("connected to") && adb_get_state(adb_bin, endpoint))
}

/// Promote an active Wireless Debugging TLS session to persistent local `127.0.0.1:<port>`.
pub fn promote_to_loopback_tcpip(
    adb_bin: &Path,
    tls_serial: &str,
    tcpip_port: u16,
) -> Option<String> {
    let port_str = tcpip_port.to_string();
    let mut cmd = adb_command(adb_bin);
    cmd.args(["-s", tls_serial, "tcpip", &port_str]);
    let out = run_with_timeout(cmd, 3500).ok()?;
    if out.timed_out || out.exit_code != 0 {
        return None;
    }

    let loopback = format!("127.0.0.1:{tcpip_port}");
    let deadline = Instant::now() + Duration::from_millis(2400);
    while Instant::now() < deadline {
        if tcp_port_open(&loopback, 100) {
            if adb_connect_endpoint(adb_bin, &loopback).unwrap_or(false) {
                return Some(loopback);
            }
        }
        thread::sleep(Duration::from_millis(100));
    }
    None
}

/// Resolve an active `adb` serial (`127.0.0.1:5555` preferred, then cached/mDNS TLS) with zero background polling.
pub fn resolve_active_adb_serial(cfg: &mut BridgeConfig) -> Option<(String, &'static str)> {
    if cfg.preferred_mode == "shizuku_only" {
        return None;
    }
    let adb_bin = adb_bin_path()?;
    if !adbkey_path().is_file() {
        return None;
    }

    // Fast Path 1: persistent loopback tcpip (survives Wi-Fi off & port rotations until reboot)
    let loopback = format!("127.0.0.1:{}", cfg.tcpip_port);
    if cfg.preferred_mode == "tcpip" && tcp_port_open(&loopback, 80) {
        if adb_get_state(&adb_bin, &loopback)
            || adb_connect_endpoint(&adb_bin, &loopback).unwrap_or(false)
        {
            return Some((loopback, "adb-tcpip"));
        }
    }

    // Fast Path 2: cached TLS endpoint or rapid on-demand mDNS lookup
    let mut candidates: Vec<String> = Vec::new();
    if let Some(ref cached) = cfg.last_tls_endpoint {
        if tcp_port_open(cached, 80) {
            candidates.push(cached.clone());
        }
    }
    if candidates.is_empty() {
        let disc = discover_mdns_endpoints(Some(&adb_bin), 450, true);
        for ep in disc.connect_endpoints {
            let addr = ep.addr();
            if !candidates.contains(&addr) && tcp_port_open(&addr, 120) {
                candidates.push(addr);
            }
        }
    }

    for ep in candidates {
        if adb_connect_endpoint(&adb_bin, &ep).unwrap_or(false) {
            cfg.last_tls_endpoint = Some(ep.clone());
            let _ = cfg.save();

            if cfg.preferred_mode == "tcpip" {
                if let Some(lb) = promote_to_loopback_tcpip(&adb_bin, &ep, cfg.tcpip_port) {
                    return Some((lb, "adb-tcpip"));
                }
            }
            return Some((ep, "adb-tls"));
        }
    }

    None
}

fn normalize_endpoint_input(raw: &str, wlan_ip: Option<&str>) -> Vec<String> {
    let s = raw.trim();
    if s.is_empty() {
        return Vec::new();
    }
    if s.contains(':') {
        return vec![s.to_string()];
    }
    let mut out = Vec::new();
    if s.chars().all(|c| c.is_ascii_digit()) {
        if let Some(ip) = wlan_ip {
            out.push(format!("{ip}:{s}"));
        }
        out.push(format!("127.0.0.1:{s}"));
    }
    out
}

/// Ensure persistent RSA key exists before pairing.
fn ensure_adb_key_initialized(adb_bin: &Path) {
    if adbkey_path().is_file() {
        return;
    }
    let mut cmd = adb_command(adb_bin);
    cmd.arg("start-server");
    let _ = run_with_timeout(cmd, 3000);
}

/// Return `$PREFIX/bin/adb`, automatically installing `android-tools` if it is missing.
fn resolve_or_install_adb_bin() -> Result<std::path::PathBuf, String> {
    if let Some(p) = adb_bin_path() {
        return Ok(p);
    }
    ensure_android_tools_installed()?;
    adb_bin_path().ok_or_else(|| {
        "No se encontro '$PREFIX/bin/adb' tras instalar android-tools.".to_string()
    })
}

/// One-time Wireless Debugging pairing (`adb pair`) followed by TLS connect and `tcpip 5555` promotion.
pub fn pair_and_activate(
    cfg: &mut BridgeConfig,
    code: &str,
    pairing_endpoint_opt: Option<&str>,
    connect_endpoint_opt: Option<&str>,
) -> Result<PairResult, String> {
    let clean_code: String = code.trim().chars().filter(|c| !c.is_whitespace()).collect();
    if clean_code.len() != 6 || !clean_code.chars().all(|c| c.is_ascii_digit()) {
        return Err(
            "El codigo de vinculacion debe tener exactamente 6 digitos (ej. '482910').".to_string(),
        );
    }

    let adb_bin = resolve_or_install_adb_bin()?;
    ensure_adb_key_initialized(&adb_bin);

    let wlan_ip = detect_local_wlan_ip().map(|ip| ip.to_string());
    let mut pair_candidates: Vec<String> = Vec::new();
    if let Some(raw_ep) = pairing_endpoint_opt {
        pair_candidates = normalize_endpoint_input(raw_ep, wlan_ip.as_deref());
    }
    if pair_candidates.is_empty() {
        let disc = discover_mdns_endpoints(Some(&adb_bin), 1800, false);
        for ep in disc.pairing_endpoints {
            let addr = ep.addr();
            if !pair_candidates.contains(&addr) {
                pair_candidates.push(addr);
            }
        }
    }

    if pair_candidates.is_empty() {
        return Err(
            "No se detecto ningun puerto mDNS de emparejamiento (_adb-tls-pairing._tcp). \
            Abre Ajustes -> Opciones de desarrollador -> Depuracion inalambrica -> 'Vincular dispositivo con codigo de vinculacion' \
            en pantalla dividida/ventana flotante y pasa el codigo (o especifica pairing_port)."
                .to_string(),
        );
    }

    let mut paired_ep: Option<String> = None;
    let mut last_pair_err = String::new();
    for target in &pair_candidates {
        let mut cmd = adb_command(&adb_bin);
        cmd.args(["pair", target, &clean_code]);
        let out = run_with_timeout(cmd, 10000)?;
        let combined = format!("{} {}", out.stdout.trim(), out.stderr.trim());
        if !out.timed_out
            && out.exit_code == 0
            && (combined.to_ascii_lowercase().contains("successfully paired")
                || !combined.to_ascii_lowercase().contains("failed"))
        {
            paired_ep = Some(target.clone());
            break;
        }
        last_pair_err = combined;
    }

    let pairing_endpoint = paired_ep.ok_or_else(|| {
        format!(
            "Fallo 'adb pair' en {:?}: {}. Verifica que el dialogo de 6 digitos siga abierto y el codigo no haya cambiado.",
            pair_candidates, last_pair_err
        )
    })?;

    // Wait briefly for Android adbd to expose _adb-tls-connect after pairing finishes
    let mut connect_candidates: Vec<String> = Vec::new();
    if let Some(raw_conn) = connect_endpoint_opt {
        connect_candidates = normalize_endpoint_input(raw_conn, wlan_ip.as_deref());
    }
    if connect_candidates.is_empty() {
        for attempt in 0..3 {
            let disc = discover_mdns_endpoints(Some(&adb_bin), 1400, true);
            for ep in disc.connect_endpoints {
                let addr = ep.addr();
                if !connect_candidates.contains(&addr) {
                    connect_candidates.push(addr);
                }
            }
            if !connect_candidates.is_empty() || attempt == 2 {
                break;
            }
            thread::sleep(Duration::from_millis(350));
        }
    }

    let mut tls_connected: Option<String> = None;
    for target in &connect_candidates {
        if adb_connect_endpoint(&adb_bin, target).unwrap_or(false) {
            tls_connected = Some(target.clone());
            break;
        }
    }

    let tls_ep = tls_connected.ok_or_else(|| {
        format!(
            "Vinculacion RSA exitosa en {pairing_endpoint}, pero no se pudo conectar al puerto TLS de Depuracion Inalambrica ({:?}). \
            Asegurate de que 'Depuracion inalambrica' siga activada y ejecuta 'agy-adb connect [puerto]'.",
            connect_candidates
        )
    })?;

    cfg.last_tls_endpoint = Some(tls_ep.clone());
    let mut active_serial = tls_ep.clone();
    let mut active_backend = "adb-tls".to_string();
    let mut active_tcpip_port: Option<u16> = None;

    if cfg.preferred_mode == "tcpip" {
        if let Some(lb) = promote_to_loopback_tcpip(&adb_bin, &tls_ep, cfg.tcpip_port) {
            active_serial = lb;
            active_backend = "adb-tcpip".to_string();
            active_tcpip_port = Some(cfg.tcpip_port);
        }
    }
    let _ = cfg.save();

    // Best-effort permission grant + uid=2000 verification
    let mut grant_cmd = adb_command(&adb_bin);
    grant_cmd.args([
        "-s",
        &active_serial,
        "shell",
        "-n",
        "-T",
        "pm grant com.agy android.permission.WRITE_SECURE_SETTINGS >/dev/null 2>&1; echo GRANT:$?; id",
    ]);
    let verify_out = run_with_timeout(grant_cmd, 4000)?;
    let write_secure = verify_out.stdout.contains("GRANT:0");
    let uid_line = verify_out
        .stdout
        .lines()
        .find(|l| l.contains("uid="))
        .unwrap_or(verify_out.stdout.trim())
        .to_string();

    Ok(PairResult {
        paired: true,
        pairing_endpoint,
        tls_endpoint: Some(tls_ep),
        active_serial,
        active_backend,
        tcpip_port: active_tcpip_port,
        uid_check: uid_line,
        adbkey_path: adbkey_path().display().to_string(),
        write_secure_settings_granted: write_secure,
    })
}

/// Reconnect using the persisted `$HOME/.android/adbkey` (after Wi-Fi change or reboot) without re-pairing.
pub fn reconnect_with_saved_key(
    cfg: &mut BridgeConfig,
    explicit_endpoint: Option<&str>,
    promote_tcpip: bool,
) -> Result<ConnectResult, String> {
    let adb_bin = resolve_or_install_adb_bin()?;
    if !adbkey_path().is_file() {
        return Err(
            "Aun no existe la llave '$HOME/.android/adbkey'. Vincula una vez con 'agy-adb pair <codigo-6-digitos>'."
                .to_string(),
        );
    }

    if let Some(raw_ep) = explicit_endpoint {
        let wlan_ip = detect_local_wlan_ip().map(|ip| ip.to_string());
        let candidates = normalize_endpoint_input(raw_ep, wlan_ip.as_deref());
        let mut connected_ep: Option<String> = None;
        for c in &candidates {
            if adb_connect_endpoint(&adb_bin, c).unwrap_or(false) {
                connected_ep = Some(c.clone());
                break;
            }
        }
        let ep = connected_ep.ok_or_else(|| {
            format!("No se pudo conectar a {:?}. Verifica Depuracion inalambrica.", candidates)
        })?;
        cfg.last_tls_endpoint = Some(ep.clone());
        let mut serial = ep.clone();
        let mut backend = "adb-tls".to_string();
        let mut tcpip_port = None;
        if promote_tcpip && cfg.preferred_mode == "tcpip" && !ep.starts_with("127.0.0.1:") {
            if let Some(lb) = promote_to_loopback_tcpip(&adb_bin, &ep, cfg.tcpip_port) {
                serial = lb;
                backend = "adb-tcpip".to_string();
                tcpip_port = Some(cfg.tcpip_port);
            }
        }
        let _ = cfg.save();
        let uid_check = query_uid(&adb_bin, &serial);
        return Ok(ConnectResult {
            connected: true,
            active_serial: serial,
            active_backend: backend,
            tls_endpoint: Some(ep),
            tcpip_port,
            uid_check,
        });
    }

    if let Some((serial, backend)) = resolve_active_adb_serial(cfg) {
        let uid_check = query_uid(&adb_bin, &serial);
        return Ok(ConnectResult {
            connected: true,
            active_serial: serial.clone(),
            active_backend: backend.to_string(),
            tls_endpoint: cfg.last_tls_endpoint.clone(),
            tcpip_port: if backend == "adb-tcpip" {
                Some(cfg.tcpip_port)
            } else {
                None
            },
            uid_check,
        });
    }

    Err(
        "No se encontro '127.0.0.1:5555' ni un endpoint mDNS '_adb-tls-connect._tcp' activo. \
        Activa Depuracion inalambrica en Ajustes (sin volver a emparejar si ya usaste la misma app/llave) e intenta 'agy-adb connect'."
            .to_string(),
    )
}

pub fn query_uid(adb_bin: &Path, serial: &str) -> String {
    let mut cmd = adb_command(adb_bin);
    cmd.args(["-s", serial, "shell", "-n", "-T", "id"]);
    run_with_timeout(cmd, 2500)
        .map(|o| o.stdout.trim().to_string())
        .unwrap_or_default()
}

/// Disconnect ADB sessions and optionally close TCP/IP listener.
pub fn disconnect_adb(cfg: &BridgeConfig) -> Result<String, String> {
    let adb_bin = adb_bin_path().ok_or_else(|| "adb not installed".to_string())?;
    let loopback = format!("127.0.0.1:{}", cfg.tcpip_port);
    if tcp_port_open(&loopback, 80) && adb_get_state(&adb_bin, &loopback) {
        let mut usb = adb_command(&adb_bin);
        usb.args(["-s", &loopback, "usb"]);
        let _ = run_with_timeout(usb, 1500);
    }
    let mut disc = adb_command(&adb_bin);
    disc.arg("disconnect");
    let out = run_with_timeout(disc, 2000)?;
    Ok(out.stdout.trim().to_string())
}

/// Check `pkg` and install `android-tools` if `$PREFIX/bin/adb` is absent.
pub fn ensure_android_tools_installed() -> Result<String, String> {
    if let Some(adb) = adb_bin_path() {
        return Ok(format!(
            "android-tools already installed at {}",
            adb.display()
        ));
    }
    let pkg_bin = prefix_bin_dir().join("pkg");
    if !pkg_bin.is_file() {
        return Err("No se encontro 'pkg' en $PREFIX/bin para instalar android-tools.".to_string());
    }
    let mut upd = Command::new(&pkg_bin);
    upd.arg("update")
        .env("HOME", home_dir())
        .env("PREFIX", crate::config::prefix_dir())
        .env(
            "PATH",
            format!("{}:/system/bin", prefix_bin_dir().display()),
        );
    let _ = run_with_timeout(upd, 60000);

    let mut inst = Command::new(&pkg_bin);
    inst.args(["install", "android-tools"])
        .env("HOME", home_dir())
        .env("PREFIX", crate::config::prefix_dir())
        .env(
            "PATH",
            format!("{}:/system/bin", prefix_bin_dir().display()),
        );
    let res = run_with_timeout(inst, 120000)?;
    if res.timed_out || res.exit_code != 0 {
        return Err(format!(
            "Fallo 'pkg install android-tools' (code {}): {}\n{}",
            res.exit_code, res.stdout, res.stderr
        ));
    }
    let adb = adb_bin_path()
        .ok_or_else(|| "android-tools se instalo pero no aparece '$PREFIX/bin/adb'.".to_string())?;
    Ok(format!("Installed {}", adb.display()))
}
