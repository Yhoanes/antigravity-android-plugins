mod adb;
mod config;
mod mcp;
mod mdns;
mod rish;

use crate::adb::{
    disconnect_adb, ensure_android_tools_installed, pair_and_activate, reconnect_with_saved_key,
};
use crate::config::{ensure_wrappers_installed, BridgeConfig, WRAPPER_VERSION};
use crate::mcp::{collect_status, run_mcp_server};
use crate::mdns::discover_mdns_endpoints;
use crate::rish::{execute_shell_captured, run_smart_rish};
use std::env;
use std::path::Path;
use std::process;

fn print_help() {
    println!(
        "AGY ADB Bridge v{WRAPPER_VERSION} — Puente nativo ARM64 de permisos uid=2000(shell)\n\n\
        Uso:\n\
          agy-adb status [--json]              Muestra el estado de ADB local (127.0.0.1:5555), mDNS y fallback Shizuku\n\
          agy-adb discover [--ms N]            Escanea servicios Wireless Debugging via mDNS (0% bateria)\n\
          agy-adb pair <6-digitos> [puerto]    Vincula Depuracion Inalambrica, guarda llave RSA y activa tcpip 5555\n\
          agy-adb connect [puerto|host:puerto] Reconecta usando la llave guardada sin volver a emparejar\n\
          agy-adb exec \"<comando>\"             Ejecuta un comando como uid=2000(shell)\n\
          agy-adb mode <tcpip|tls_only|shizuku_only>\n\
          agy-adb disconnect                   Cierra la sesion ADB TCP/IP actual\n\
          agy-adb setup                        Instala android-tools (si falta) y repara wrappers en $PREFIX/bin\n"
    );
}

fn looks_like_six_digits(s: &str) -> bool {
    let clean: String = s.trim().chars().filter(|c| !c.is_whitespace()).collect();
    clean.len() == 6 && clean.chars().all(|c| c.is_ascii_digit())
}

fn run_cli(args: &[String]) -> i32 {
    let _ = ensure_wrappers_installed();
    if args.is_empty() || matches!(args[0].as_str(), "help" | "-h" | "--help") {
        print_help();
        return 0;
    }

    match args[0].as_str() {
        "status" => {
            let as_json = args.iter().any(|a| a == "--json");
            let st = collect_status(450);
            if as_json {
                println!(
                    "{}",
                    serde_json::to_string_pretty(&st).unwrap_or_else(|_| "{}".to_string())
                );
                return 0;
            }
            println!("AGY ADB Bridge v{}", st.version);
            println!(
                "  Backend activo       : {} ({})",
                st.active_backend,
                st.active_serial.as_deref().unwrap_or("ninguno")
            );
            println!(
                "  UID verificado       : {}",
                st.uid_check.as_deref().unwrap_or("sin respuesta")
            );
            println!(
                "  ADB instalado        : {} ({})",
                st.adb_installed,
                st.adb_version.as_deref().unwrap_or("-")
            );
            println!(
                "  Llave RSA            : {} ({})",
                st.adbkey_present, st.adbkey_path
            );
            println!(
                "  Modo / Loopback      : {} | 127.0.0.1:{} abierto={}",
                st.preferred_mode, st.tcpip_port, st.loopback_5555_open
            );
            println!(
                "  Wrapper $PREFIX/rish : {} | Fallback Shizuku: {} ({} ms)",
                if st.rish_wrapper_healthy { "OK" } else { "DESACTUALIZADO" },
                if st.shizuku_fallback_ready { "listo" } else { "no encontrado" },
                st.fallback_timeout_ms
            );
            println!("  IP WLAN local        : {}", st.wlan_ip.as_deref().unwrap_or("-"));
            if !st.mdns_connect_endpoints.is_empty() {
                let eps: Vec<String> = st.mdns_connect_endpoints.iter().map(|e| e.addr()).collect();
                println!("  mDNS Connect         : {}", eps.join(", "));
            }
            if !st.mdns_pairing_endpoints.is_empty() {
                let eps: Vec<String> = st.mdns_pairing_endpoints.iter().map(|e| e.addr()).collect();
                println!("  mDNS Pairing         : {}", eps.join(", "));
            }
            0
        }
        "discover" => {
            let ms = args
                .windows(2)
                .find(|w| w[0] == "--ms")
                .and_then(|w| w[1].parse::<u64>().ok())
                .unwrap_or(1200)
                .clamp(200, 6000);
            let disc = discover_mdns_endpoints(crate::config::adb_bin_path().as_deref(), ms, false);
            println!(
                "{}",
                serde_json::to_string_pretty(&disc).unwrap_or_else(|_| "{}".to_string())
            );
            0
        }
        "pair" => {
            if args.len() < 2 {
                eprintln!("Uso: agy-adb pair <codigo-6-digitos> [puerto_pairing] [puerto_conexion]");
                return 2;
            }
            let mut code_arg = args[1].as_str();
            let mut pair_port_arg = args.get(2).map(|s| s.as_str());
            let conn_port_arg = args.get(3).map(|s| s.as_str());

            // Gracefully accept swapped order: `agy-adb pair <host:port> <6-digits>`
            if !looks_like_six_digits(code_arg) {
                if let Some(p2) = pair_port_arg {
                    if looks_like_six_digits(p2) {
                        pair_port_arg = Some(code_arg);
                        code_arg = p2;
                    }
                }
            }

            let mut cfg = BridgeConfig::load();
            match pair_and_activate(&mut cfg, code_arg, pair_port_arg, conn_port_arg) {
                Ok(res) => {
                    println!(
                        "{}",
                        serde_json::to_string_pretty(&res).unwrap_or_else(|_| "{}".to_string())
                    );
                    0
                }
                Err(e) => {
                    eprintln!("Error: {e}");
                    1
                }
            }
        }
        "connect" => {
            let mut promote = true;
            let mut endpoint: Option<&str> = None;
            for a in &args[1..] {
                if a == "--no-tcpip" {
                    promote = false;
                } else if endpoint.is_none() {
                    endpoint = Some(a.as_str());
                }
            }
            let mut cfg = BridgeConfig::load();
            match reconnect_with_saved_key(&mut cfg, endpoint, promote) {
                Ok(res) => {
                    println!(
                        "{}",
                        serde_json::to_string_pretty(&res).unwrap_or_else(|_| "{}".to_string())
                    );
                    0
                }
                Err(e) => {
                    eprintln!("Error: {e}");
                    1
                }
            }
        }
        "exec" | "shell" => {
            if args.len() < 2 {
                eprintln!("Uso: agy-adb exec \"<comando>\"");
                return 2;
            }
            let cmd = args[1..].join(" ");
            match execute_shell_captured(&cmd, 20000) {
                Ok(res) => {
                    if !res.stdout.is_empty() {
                        print!("{}", res.stdout);
                    }
                    if !res.stderr.is_empty() {
                        eprint!("{}", res.stderr);
                    }
                    res.exit_code
                }
                Err(e) => {
                    eprintln!("Error: {e}");
                    1
                }
            }
        }
        "mode" => {
            if args.len() < 2 {
                eprintln!("Uso: agy-adb mode <tcpip|tls_only|shizuku_only>");
                return 2;
            }
            let m = args[1].as_str();
            if !matches!(m, "tcpip" | "tls_only" | "shizuku_only") {
                eprintln!("Modo invalido '{m}'. Usa: tcpip | tls_only | shizuku_only");
                return 2;
            }
            let mut cfg = BridgeConfig::load();
            cfg.preferred_mode = m.to_string();
            if let Err(e) = cfg.save() {
                eprintln!("Error guardando configuracion: {e}");
                return 1;
            }
            println!("Modo actualizado a: {m}");
            0
        }
        "disconnect" => {
            let cfg = BridgeConfig::load();
            match disconnect_adb(&cfg) {
                Ok(msg) => {
                    println!("{}", if msg.is_empty() { "disconnected" } else { &msg });
                    0
                }
                Err(e) => {
                    eprintln!("Error: {e}");
                    1
                }
            }
        }
        "setup" => {
            match ensure_android_tools_installed() {
                Ok(msg) => println!("{msg}"),
                Err(e) => {
                    eprintln!("Error: {e}");
                    return 1;
                }
            }
            if let Err(e) = ensure_wrappers_installed() {
                eprintln!("Error reparando wrappers: {e}");
                return 1;
            }
            println!("Wrappers activos en $PREFIX/bin/rish y $PREFIX/bin/agy-adb");
            0
        }
        other => {
            eprintln!("Subcomando desconocido: '{other}'");
            print_help();
            2
        }
    }
}

fn main() {
    let raw_args: Vec<String> = env::args().collect();
    let argv0 = raw_args
        .first()
        .and_then(|s| Path::new(s).file_name())
        .and_then(|n| n.to_str())
        .unwrap_or("agy-adb-mcp");

    let exit_code = if argv0 == "rish" {
        run_smart_rish(&raw_args[1..])
    } else if argv0 == "agy-adb" {
        run_cli(&raw_args[1..])
    } else {
        match raw_args.get(1).map(|s| s.as_str()) {
            Some("__rish") => run_smart_rish(&raw_args[2..]),
            Some("cli") => run_cli(&raw_args[2..]),
            Some("mcp") | None => run_mcp_server(),
            Some(other) => {
                eprintln!("Uso: {argv0} [mcp | cli ... | __rish ...]");
                eprintln!("Subcomando no reconocido: {other}");
                2
            }
        }
    };

    process::exit(exit_code);
}
