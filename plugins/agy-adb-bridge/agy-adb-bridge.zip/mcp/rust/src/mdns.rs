use serde::Serialize;
use std::collections::{BTreeMap, HashMap};
use std::net::{Ipv4Addr, SocketAddr, SocketAddrV4, UdpSocket};
use std::os::unix::io::FromRawFd;
use std::path::Path;
use std::process::{Command, Stdio};
use std::time::{Duration, Instant};

pub const PAIRING_SERVICE: &str = "_adb-tls-pairing._tcp.local.";
pub const CONNECT_SERVICE: &str = "_adb-tls-connect._tcp.local.";
const MDNS_ADDR: Ipv4Addr = Ipv4Addr::new(224, 0, 0, 251);
const MDNS_PORT: u16 = 5353;

#[derive(Debug, Clone, Serialize, PartialEq, Eq)]
pub struct MdnsEndpoint {
    pub ip: String,
    pub port: u16,
    pub service_name: String,
    pub source: String,
}

impl MdnsEndpoint {
    pub fn addr(&self) -> String {
        format!("{}:{}", self.ip, self.port)
    }
}

#[derive(Debug, Clone, Serialize)]
pub struct DiscoverResult {
    pub wlan_ip: Option<String>,
    pub connect_endpoints: Vec<MdnsEndpoint>,
    pub pairing_endpoints: Vec<MdnsEndpoint>,
}

/// Determine the active non-loopback local IPv4 address via a kernel routing lookup (sends 0 packets).
pub fn detect_local_wlan_ip() -> Option<Ipv4Addr> {
    let sock = UdpSocket::bind("0.0.0.0:0").ok()?;
    if sock.connect("8.8.8.8:53").is_err() {
        return None;
    }
    match sock.local_addr().ok()? {
        SocketAddr::V4(v4) => {
            let ip = *v4.ip();
            if !ip.is_loopback() && !ip.is_unspecified() {
                Some(ip)
            } else {
                None
            }
        }
        _ => None,
    }
}

/// Bind a reusable UDP socket on `0.0.0.0:5353` using `SO_REUSEADDR` and `SO_REUSEPORT`.
fn bind_reusable_mdns_socket() -> Option<UdpSocket> {
    unsafe {
        let fd = libc::socket(libc::AF_INET, libc::SOCK_DGRAM, libc::IPPROTO_UDP);
        if fd < 0 {
            return None;
        }
        let one: libc::c_int = 1;
        let _ = libc::setsockopt(
            fd,
            libc::SOL_SOCKET,
            libc::SO_REUSEADDR,
            (&one as *const libc::c_int).cast(),
            std::mem::size_of::<libc::c_int>() as libc::socklen_t,
        );
        let _ = libc::setsockopt(
            fd,
            libc::SOL_SOCKET,
            libc::SO_REUSEPORT,
            (&one as *const libc::c_int).cast(),
            std::mem::size_of::<libc::c_int>() as libc::socklen_t,
        );

        let sin = libc::sockaddr_in {
            sin_family: libc::AF_INET as libc::sa_family_t,
            sin_port: MDNS_PORT.to_be(),
            sin_addr: libc::in_addr { s_addr: 0 },
            sin_zero: [0; 8],
        };
        if libc::bind(
            fd,
            (&sin as *const libc::sockaddr_in).cast(),
            std::mem::size_of::<libc::sockaddr_in>() as libc::socklen_t,
        ) < 0
        {
            libc::close(fd);
            return None;
        }
        Some(UdpSocket::from_raw_fd(fd))
    }
}

fn configure_multicast_socket(sock: &UdpSocket, wlan_ip: Option<Ipv4Addr>) {
    let _ = sock.set_nonblocking(true);
    let _ = sock.set_multicast_loop_v4(true);
    let _ = sock.set_multicast_ttl_v4(255);
    let _ = sock.join_multicast_v4(&MDNS_ADDR, &Ipv4Addr::UNSPECIFIED);
    if let Some(ip) = wlan_ip {
        let _ = sock.join_multicast_v4(&MDNS_ADDR, &ip);
    }
}

fn encode_dns_name(fqdn: &str) -> Vec<u8> {
    let mut out = Vec::with_capacity(fqdn.len() + 2);
    for label in fqdn.trim_end_matches('.').split('.') {
        if label.is_empty() || label.len() > 63 {
            continue;
        }
        out.push(label.len() as u8);
        out.extend_from_slice(label.as_bytes());
    }
    out.push(0);
    out
}

fn build_mdns_query(services: &[&str], qclass: u16) -> Vec<u8> {
    let mut pkt = Vec::with_capacity(128);
    let qcount = (services.len() * 2) as u16;
    pkt.extend_from_slice(&[0x00, 0x00, 0x00, 0x00]); // ID=0, Flags=0
    pkt.extend_from_slice(&qcount.to_be_bytes());
    pkt.extend_from_slice(&[0x00, 0x00, 0x00, 0x00, 0x00, 0x00]); // AN, NS, AR = 0
    for svc in services {
        let qname = encode_dns_name(svc);
        // PTR (12)
        pkt.extend_from_slice(&qname);
        pkt.extend_from_slice(&12u16.to_be_bytes());
        pkt.extend_from_slice(&qclass.to_be_bytes());
        // ANY (255)
        pkt.extend_from_slice(&qname);
        pkt.extend_from_slice(&255u16.to_be_bytes());
        pkt.extend_from_slice(&qclass.to_be_bytes());
    }
    pkt
}

/// Safely decode a DNS name with pointer compression hop limit <= 16.
fn parse_dns_name(pkt: &[u8], start: usize) -> Option<(String, usize)> {
    let mut labels: Vec<String> = Vec::new();
    let mut pos = start;
    let mut end_pos: Option<usize> = None;
    let mut jumps = 0u8;

    loop {
        if pos >= pkt.len() {
            return None;
        }
        let len = pkt[pos];
        if len == 0 {
            let next = end_pos.unwrap_or(pos + 1);
            return Some((labels.join("."), next));
        }
        if (len & 0xC0) == 0xC0 {
            if pos + 1 >= pkt.len() || jumps >= 16 {
                return None;
            }
            let ptr = (((len & 0x3F) as usize) << 8) | (pkt[pos + 1] as usize);
            if ptr >= pkt.len() {
                return None;
            }
            if end_pos.is_none() {
                end_pos = Some(pos + 2);
            }
            pos = ptr;
            jumps += 1;
            continue;
        }
        if (len & 0xC0) != 0 {
            return None;
        }
        let seg_len = len as usize;
        pos += 1;
        if pos + seg_len > pkt.len() {
            return None;
        }
        labels.push(String::from_utf8_lossy(&pkt[pos..pos + seg_len]).into_owned());
        pos += seg_len;
    }
}

#[derive(Debug)]
struct ParsedSrv {
    instance: String,
    target: String,
    port: u16,
}

fn parse_mdns_packet(
    pkt: &[u8],
    src_ip: Ipv4Addr,
    srvs: &mut Vec<ParsedSrv>,
    a_records: &mut HashMap<String, String>,
) {
    if pkt.len() < 12 {
        return;
    }
    let flags = u16::from_be_bytes([pkt[2], pkt[3]]);
    if (flags & 0x8000) == 0 {
        return; // Not a DNS response
    }
    let qdcount = u16::from_be_bytes([pkt[4], pkt[5]]) as usize;
    let ancount = u16::from_be_bytes([pkt[6], pkt[7]]) as usize;
    let nscount = u16::from_be_bytes([pkt[8], pkt[9]]) as usize;
    let arcount = u16::from_be_bytes([pkt[10], pkt[11]]) as usize;

    let mut pos = 12usize;
    for _ in 0..qdcount {
        match parse_dns_name(pkt, pos) {
            Some((_, next)) if next + 4 <= pkt.len() => pos = next + 4,
            _ => return,
        }
    }

    let total_rr = ancount.saturating_add(nscount).saturating_add(arcount);
    for _ in 0..total_rr {
        let (name, next) = match parse_dns_name(pkt, pos) {
            Some(v) => v,
            None => return,
        };
        if next + 10 > pkt.len() {
            return;
        }
        let rtype = u16::from_be_bytes([pkt[next], pkt[next + 1]]);
        let rdlength = u16::from_be_bytes([pkt[next + 8], pkt[next + 9]]) as usize;
        let rdata_start = next + 10;
        let rdata_end = rdata_start + rdlength;
        if rdata_end > pkt.len() {
            return;
        }

        match rtype {
            // A record
            1 if rdlength == 4 => {
                let ip = Ipv4Addr::new(
                    pkt[rdata_start],
                    pkt[rdata_start + 1],
                    pkt[rdata_start + 2],
                    pkt[rdata_start + 3],
                );
                if !ip.is_unspecified() {
                    a_records.insert(name.to_ascii_lowercase(), ip.to_string());
                }
            }
            // SRV record: priority(2), weight(2), port(2), target
            33 if rdlength >= 7 => {
                let port = u16::from_be_bytes([pkt[rdata_start + 4], pkt[rdata_start + 5]]);
                if port > 0 {
                    if let Some((target, _)) = parse_dns_name(pkt, rdata_start + 6) {
                        srvs.push(ParsedSrv {
                            instance: name,
                            target: target.to_ascii_lowercase(),
                            port,
                        });
                    }
                }
            }
            _ => {}
        }
        pos = rdata_end;
    }

    // Fallback: record responder IP if valid and host lacks explicit A record later
    let _ = src_ip;
}

/// On-demand, zero-polling mDNS discovery for ADB TLS services (`_adb-tls-connect._tcp` & `_adb-tls-pairing._tcp`).
pub fn discover_mdns_endpoints(
    adb_bin: Option<&Path>,
    timeout_ms: u64,
    early_return_on_connect: bool,
) -> DiscoverResult {
    let wlan_ip = detect_local_wlan_ip();
    let mut sockets: Vec<UdpSocket> = Vec::new();
    if let Some(s5353) = bind_reusable_mdns_socket() {
        configure_multicast_socket(&s5353, wlan_ip);
        sockets.push(s5353);
    }
    if let Ok(ephem) = UdpSocket::bind("0.0.0.0:0") {
        configure_multicast_socket(&ephem, wlan_ip);
        sockets.push(ephem);
    }

    let services = [CONNECT_SERVICE, PAIRING_SERVICE];
    let q_qu = build_mdns_query(&services, 0x8001); // Request unicast reply
    let q_qm = build_mdns_query(&services, 0x0001); // Request multicast reply
    let dest = SocketAddr::V4(SocketAddrV4::new(MDNS_ADDR, MDNS_PORT));

    for sock in &sockets {
        let _ = sock.send_to(&q_qu, dest);
        let _ = sock.send_to(&q_qm, dest);
    }

    let mut connect_map: BTreeMap<String, MdnsEndpoint> = BTreeMap::new();
    let mut pairing_map: BTreeMap<String, MdnsEndpoint> = BTreeMap::new();
    let mut global_a: HashMap<String, String> = HashMap::new();
    let mut pending_srvs: Vec<(ParsedSrv, Ipv4Addr)> = Vec::new();

    let started = Instant::now();
    let deadline = started + Duration::from_millis(timeout_ms.max(150));
    let mut first_connect_seen: Option<Instant> = None;
    let mut resent = false;
    let mut buf = [0u8; 4096];

    while Instant::now() < deadline {
        if !resent && started.elapsed() >= Duration::from_millis(160) {
            for sock in &sockets {
                let _ = sock.send_to(&q_qu, dest);
            }
            resent = true;
        }

        let mut received_any = false;
        for sock in &sockets {
            loop {
                match sock.recv_from(&mut buf) {
                    Ok((len, src)) => {
                        received_any = true;
                        let src_ip = match src {
                            SocketAddr::V4(v4) => *v4.ip(),
                            _ => Ipv4Addr::UNSPECIFIED,
                        };
                        let mut local_srvs = Vec::new();
                        parse_mdns_packet(&buf[..len], src_ip, &mut local_srvs, &mut global_a);
                        for srv in local_srvs {
                            if srv.instance.to_ascii_lowercase().contains("_adb-tls-connect._tcp")
                                && first_connect_seen.is_none()
                            {
                                first_connect_seen = Some(Instant::now());
                            }
                            pending_srvs.push((srv, src_ip));
                        }
                    }
                    Err(ref e) if e.kind() == std::io::ErrorKind::WouldBlock => break,
                    Err(_) => break,
                }
            }
        }

        if early_return_on_connect {
            if let Some(seen_at) = first_connect_seen {
                if seen_at.elapsed() >= Duration::from_millis(120) {
                    break;
                }
            }
        }

        if !received_any {
            std::thread::sleep(Duration::from_millis(15));
        }
    }

    for (srv, src_ip) in pending_srvs {
        let lower_inst = srv.instance.to_ascii_lowercase();
        let ip = global_a
            .get(&srv.target)
            .cloned()
            .or_else(|| wlan_ip.map(|w| w.to_string()))
            .or_else(|| {
                if !src_ip.is_unspecified() && !src_ip.is_loopback() {
                    Some(src_ip.to_string())
                } else {
                    None
                }
            })
            .unwrap_or_else(|| "127.0.0.1".to_string());

        let ep = MdnsEndpoint {
            ip,
            port: srv.port,
            service_name: srv.instance.trim_end_matches('.').to_string(),
            source: "mdns-udp".to_string(),
        };
        let key = ep.addr();
        if lower_inst.contains("_adb-tls-connect._tcp") {
            connect_map.entry(key).or_insert(ep);
        } else if lower_inst.contains("_adb-tls-pairing._tcp") {
            pairing_map.entry(key).or_insert(ep);
        }
    }

    // Complementary check via `adb mdns services` (gracefully ignored when unsupported)
    if let Some(adb) = adb_bin {
        for ep in discover_via_adb_mdns(adb) {
            let key = ep.addr();
            let lower = ep.service_name.to_ascii_lowercase();
            if lower.contains("_adb-tls-connect") {
                connect_map.entry(key).or_insert(ep);
            } else if lower.contains("_adb-tls-pairing") {
                pairing_map.entry(key).or_insert(ep);
            }
        }
    }

    DiscoverResult {
        wlan_ip: wlan_ip.map(|ip| ip.to_string()),
        connect_endpoints: connect_map.into_values().collect(),
        pairing_endpoints: pairing_map.into_values().collect(),
    }
}

/// Fallback parser for `adb mdns services` when compiled with OpenScreen mDNS support.
pub fn discover_via_adb_mdns(adb_bin: &Path) -> Vec<MdnsEndpoint> {
    let mut cmd = Command::new(adb_bin);
    cmd.args(["mdns", "services"])
        .stdin(Stdio::null())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped());

    let prefix_lib = adb_bin
        .parent()
        .and_then(|p| p.parent())
        .map(|p| p.join("lib"));
    if let Some(lib_dir) = prefix_lib {
        if lib_dir.is_dir() {
            cmd.env("LD_LIBRARY_PATH", lib_dir);
        }
    }

    let Ok(mut child) = cmd.spawn() else {
        return Vec::new();
    };
    let start = Instant::now();
    loop {
        match child.try_wait() {
            Ok(Some(_)) => break,
            Ok(None) if start.elapsed() >= Duration::from_millis(650) => {
                let _ = child.kill();
                let _ = child.wait();
                return Vec::new();
            }
            Ok(None) => std::thread::sleep(Duration::from_millis(20)),
            Err(_) => return Vec::new(),
        }
    }

    let Ok(out) = child.wait_with_output() else {
        return Vec::new();
    };
    if !out.status.success() {
        return Vec::new();
    }
    let text = String::from_utf8_lossy(&out.stdout);
    let mut results = Vec::new();
    for line in text.lines() {
        let trimmed = line.trim();
        if trimmed.is_empty()
            || trimmed.starts_with("List of")
            || trimmed.contains("not supported")
        {
            continue;
        }
        let parts: Vec<&str> = trimmed.split_whitespace().collect();
        if parts.len() >= 3 {
            let endpoint_str = parts[parts.len() - 1];
            if let Some((ip, port_s)) = endpoint_str.rsplit_once(':') {
                if let Ok(port) = port_s.parse::<u16>() {
                    results.push(MdnsEndpoint {
                        ip: ip.to_string(),
                        port,
                        service_name: parts[..parts.len() - 1].join(" "),
                        source: "adb-mdns".to_string(),
                    });
                }
            }
        }
    }
    results
}
