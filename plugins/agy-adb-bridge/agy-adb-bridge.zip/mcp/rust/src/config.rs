use serde::{Deserialize, Serialize};
use std::env;
use std::fs;
use std::os::unix::fs::PermissionsExt;
use std::path::{Path, PathBuf};
use std::time::{SystemTime, UNIX_EPOCH};

pub const WRAPPER_VERSION: &str = "1.0.0";
pub const RISH_MARKER: &str = "# AGY_ADB_BRIDGE_WRAPPER v1.0.0";
pub const CLI_MARKER: &str = "# AGY_ADB_BRIDGE_CLI v1.0.0";
pub const SETUP_MARKER: &str = "# AGY_ADB_BRIDGE_SETUP v1.0.0";

/// Persistent configuration for `agy-adb-bridge`.
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(default)]
pub struct BridgeConfig {
    pub preferred_mode: String,
    pub tcpip_port: u16,
    pub last_tls_endpoint: Option<String>,
    pub fallback_timeout_ms: u64,
}

impl Default for BridgeConfig {
    fn default() -> Self {
        Self {
            preferred_mode: "tcpip".to_string(),
            tcpip_port: 5555,
            last_tls_endpoint: None,
            fallback_timeout_ms: 2000,
        }
    }
}

impl BridgeConfig {
    /// Load configuration from `$HOME/.gemini/config/agy-adb-bridge.json`, falling back to defaults.
    pub fn load() -> Self {
        let path = config_file();
        if let Ok(raw) = fs::read_to_string(&path) {
            if let Ok(mut cfg) = serde_json::from_str::<BridgeConfig>(&raw) {
                cfg.sanitize();
                return cfg;
            }
        }
        Self::default()
    }

    /// Normalize out-of-range configuration fields.
    pub fn sanitize(&mut self) {
        match self.preferred_mode.as_str() {
            "tcpip" | "tls_only" | "shizuku_only" => {}
            _ => self.preferred_mode = "tcpip".to_string(),
        }
        if self.tcpip_port < 1024 {
            self.tcpip_port = 5555;
        }
        if self.fallback_timeout_ms < 500 || self.fallback_timeout_ms > 15000 {
            self.fallback_timeout_ms = 2000;
        }
    }

    /// Atomically persist configuration to `$HOME/.gemini/config/agy-adb-bridge.json` (mode 0600).
    pub fn save(&self) -> Result<(), String> {
        let path = config_file();
        if let Some(parent) = path.parent() {
            fs::create_dir_all(parent).map_err(|e| format!("Failed to create config dir: {e}"))?;
        }
        let body = serde_json::to_string_pretty(self)
            .map_err(|e| format!("Failed to serialize bridge config: {e}"))?;
        atomic_write(&path, format!("{body}\n").as_bytes(), 0o600)
    }
}

/// Resolve Antigravity `$HOME` (`/data/user/0/com.agy/files`).
pub fn home_dir() -> PathBuf {
    if let Some(h) = env::var_os("HOME") {
        let p = PathBuf::from(h);
        if !p.as_os_str().is_empty() {
            return p;
        }
    }
    if let Ok(exe) = env::current_exe() {
        let s = exe.to_string_lossy();
        if let Some(idx) = s.find("/.gemini/") {
            return PathBuf::from(&s[..idx]);
        }
    }
    PathBuf::from("/data/user/0/com.agy/files")
}

/// Resolve `$PREFIX` (`$HOME/usr`).
pub fn prefix_dir() -> PathBuf {
    if let Some(p) = env::var_os("PREFIX") {
        let pb = PathBuf::from(p);
        if !pb.as_os_str().is_empty() {
            return pb;
        }
    }
    home_dir().join("usr")
}

pub fn prefix_bin_dir() -> PathBuf {
    prefix_dir().join("bin")
}

pub fn prefix_lib_dir() -> PathBuf {
    prefix_dir().join("lib")
}

pub fn prefix_tmp_dir() -> PathBuf {
    prefix_dir().join("tmp")
}

pub fn plugin_dir() -> PathBuf {
    home_dir().join(".gemini/config/plugins/agy-adb-bridge")
}

pub fn mcp_bin_path() -> PathBuf {
    let preferred = plugin_dir().join("mcp/bin/agy-adb-mcp");
    if preferred.is_file() {
        return preferred;
    }
    env::current_exe().unwrap_or(preferred)
}

pub fn adb_bin_path() -> Option<PathBuf> {
    let candidate = prefix_bin_dir().join("adb");
    if is_executable(&candidate) {
        return Some(candidate);
    }
    if let Some(path_var) = env::var_os("PATH") {
        for dir in env::split_paths(&path_var) {
            if dir.to_string_lossy().contains("runtime/bin") {
                continue;
            }
            let p = dir.join("adb");
            if is_executable(&p) {
                return Some(p);
            }
        }
    }
    None
}

pub fn android_home_dir() -> PathBuf {
    home_dir().join(".android")
}

pub fn adbkey_path() -> PathBuf {
    android_home_dir().join("adbkey")
}

pub fn stock_rish_path() -> PathBuf {
    home_dir().join("runtime/bin/rish")
}

pub fn config_file() -> PathBuf {
    home_dir().join(".gemini/config/agy-adb-bridge.json")
}

pub fn is_executable(path: &Path) -> bool {
    if let Ok(meta) = fs::metadata(path) {
        if meta.is_file() {
            return (meta.permissions().mode() & 0o111) != 0;
        }
    }
    false
}

/// Atomically write a file via a sibling temporary file + `fs::rename`.
pub fn atomic_write(dest: &Path, content: &[u8], mode: u32) -> Result<(), String> {
    let parent = dest
        .parent()
        .ok_or_else(|| format!("Invalid target path without parent: {}", dest.display()))?;
    fs::create_dir_all(parent)
        .map_err(|e| format!("Failed to create dir {}: {e}", parent.display()))?;

    let nonce = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_nanos())
        .unwrap_or(0);
    let fname = dest
        .file_name()
        .and_then(|n| n.to_str())
        .unwrap_or("tmp");
    let tmp = parent.join(format!(".{fname}.agy.{}.{nonce}.tmp", std::process::id()));

    fs::write(&tmp, content).map_err(|e| format!("Failed writing temp file {}: {e}", tmp.display()))?;
    fs::set_permissions(&tmp, fs::Permissions::from_mode(mode))
        .map_err(|e| format!("Failed chmod on {}: {e}", tmp.display()))?;
    if let Err(e) = fs::rename(&tmp, dest) {
        let _ = fs::remove_file(&tmp);
        return Err(format!("Failed rename to {}: {e}", dest.display()));
    }
    Ok(())
}

/// Ensure `$PREFIX/bin/{rish,agy-adb,agy-adb-setup}` exist and match our self-healing wrappers.
/// Never reads or modifies `$HOME/runtime/bin`.
pub fn ensure_wrappers_installed() -> Result<(), String> {
    let bin_dir = prefix_bin_dir();
    fs::create_dir_all(&bin_dir)
        .map_err(|e| format!("Failed creating {}: {e}", bin_dir.display()))?;

    let home_str = home_dir().to_string_lossy().into_owned();
    let prefix_str = prefix_dir().to_string_lossy().into_owned();
    let stock_rish = stock_rish_path().to_string_lossy().into_owned();
    let mcp_bin = mcp_bin_path().to_string_lossy().into_owned();
    let setup_script = plugin_dir()
        .join("mcp/bin/agy-adb-setup")
        .to_string_lossy()
        .into_owned();

    let rish_dst = bin_dir.join("rish");
    let rish_script = format!(
        "#!/system/bin/sh\n\
        {RISH_MARKER}\n\
        export HOME=\"${{HOME:-{home_str}}}\"\n\
        export PREFIX=\"${{PREFIX:-{prefix_str}}}\"\n\
        MCP_BIN=\"$HOME/.gemini/config/plugins/agy-adb-bridge/mcp/bin/agy-adb-mcp\"\n\
        if [ -x \"$MCP_BIN\" ]; then\n\
            exec \"$MCP_BIN\" __rish \"$@\"\n\
        fi\n\
        if [ -x \"{mcp_bin}\" ]; then\n\
            exec \"{mcp_bin}\" __rish \"$@\"\n\
        fi\n\
        exec \"{stock_rish}\" \"$@\"\n"
    );
    ensure_wrapper_file(&rish_dst, RISH_MARKER, &rish_script)?;

    let cli_dst = bin_dir.join("agy-adb");
    let cli_script = format!(
        "#!/system/bin/sh\n\
        {CLI_MARKER}\n\
        export HOME=\"${{HOME:-{home_str}}}\"\n\
        export PREFIX=\"${{PREFIX:-{prefix_str}}}\"\n\
        MCP_BIN=\"$HOME/.gemini/config/plugins/agy-adb-bridge/mcp/bin/agy-adb-mcp\"\n\
        if [ -x \"$MCP_BIN\" ]; then\n\
            exec \"$MCP_BIN\" cli \"$@\"\n\
        fi\n\
        exec \"{mcp_bin}\" cli \"$@\"\n"
    );
    ensure_wrapper_file(&cli_dst, CLI_MARKER, &cli_script)?;

    let setup_dst = bin_dir.join("agy-adb-setup");
    let setup_script_body = format!(
        "#!/system/bin/sh\n\
        {SETUP_MARKER}\n\
        export HOME=\"${{HOME:-{home_str}}}\"\n\
        export PREFIX=\"${{PREFIX:-{prefix_str}}}\"\n\
        exec /system/bin/sh \"{setup_script}\" \"$@\"\n"
    );
    ensure_wrapper_file(&setup_dst, SETUP_MARKER, &setup_script_body)?;

    Ok(())
}

fn ensure_wrapper_file(dest: &Path, marker: &str, body: &str) -> Result<(), String> {
    if is_executable(dest) {
        if let Ok(existing) = fs::read_to_string(dest) {
            if existing.contains(marker) {
                return Ok(());
            }
        }
    }
    atomic_write(dest, body.as_bytes(), 0o755)
}

/// Check whether `$PREFIX/bin/rish` currently holds our active self-healing wrapper.
pub fn is_rish_wrapper_healthy() -> bool {
    let rish_dst = prefix_bin_dir().join("rish");
    if !is_executable(&rish_dst) {
        return false;
    }
    fs::read_to_string(&rish_dst)
        .map(|s| s.contains(RISH_MARKER))
        .unwrap_or(false)
}
