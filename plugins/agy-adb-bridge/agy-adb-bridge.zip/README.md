# AGY ADB Bridge v1.0.0 — Puente Nativo `uid=2000(shell)` en Rust ARM64

**`agy-adb-bridge` (`v1.0.0`)** es un plugin MCP + CLI compilado en **Rust ARM64 nativo (`aarch64`)** para **Antigravity for Android** que elimina la dependencia de una app externa de Shizuku en segundo plano, evitando desconexiones y bloqueos de batería en Xiaomi MIUI / HyperOS.

---

## ¿Qué resuelve?

1. **Llave RSA persistente (`$HOME/.android/adbkey`) + `adb tcpip 5555`:**
   * Vinculas **una sola vez** con el código de 6 dígitos de *Depuración inalámbrica*.
   * El puente activa `127.0.0.1:5555` en local para que `uid=2000(shell)` siga funcionando **incluso si apagas el Wi-Fi o sales con datos móviles** (hasta el próximo reinicio del equipo).
2. **Wrapper inteligente auto-reparable en `$PREFIX/bin/rish`:**
   * No toca `/data/user/0/com.agy/files/runtime/bin/rish`.
   * Se auto-repara al instante si una actualización o reinicio de `com.agy` sobreescribe `$PREFIX/bin/rish`.
   * Si `adb` aún no está vinculado, cae en *fallback* limpio a Shizuku con un **watchdog estricto de 2 segundos** para no quedarse colgado nunca.
3. **Auto-descubrimiento mDNS bajo demanda (`224.0.0.251:5353`):**
   * 0% consumo de batería en reposo (cero procesos o *polling* en segundo plano).
   * Detecta automáticamente los puertos dinámicos `_adb-tls-pairing._tcp` y `_adb-tls-connect._tcp`.

---

## Las 7 Herramientas MCP Incluidas

1. `adb_bridge_status`: Diagnóstico completo (`127.0.0.1:5555`, llave RSA, backend activo, mDNS, salud de `$PREFIX/bin/rish` y fallback Shizuku).
2. `adb_bridge_discover`: Escaneo mDNS bajo demanda de puertos activos de Depuración Inalámbrica.
3. `adb_bridge_pair`: Emparejamiento único con código de 6 dígitos (`adb pair`), conexión TLS, promoción automática a `tcpip 5555` y verificación de `uid=2000(shell)`.
4. `adb_bridge_connect`: Reconexión rápida tras un reinicio usando tu llave `$HOME/.android/adbkey` sin volver a emparejar.
5. `adb_bridge_shell`: Ejecuta cualquier comando como `uid=2000(shell)`.
6. `adb_bridge_configure`: Cambia entre modo `tcpip`, `tls_only` o `shizuku_only`, puerto local o desconexión rápida.
7. `adb_bridge_setup`: Instala `android-tools` (`adb`) vía `pkg` y repara wrappers en `$PREFIX/bin`.

---

## Uso Rápido

```sh
# 1. Ver estado del puente:
agy-adb status

# 2. Vincular una sola vez (con Depuración inalámbrica -> código de 6 dígitos abierto):
agy-adb pair 123456

# 3. Ejecutar cualquier comando elevado con rish o agy-adb:
rish -c "id"
agy-adb exec "pm list packages -3"
```
