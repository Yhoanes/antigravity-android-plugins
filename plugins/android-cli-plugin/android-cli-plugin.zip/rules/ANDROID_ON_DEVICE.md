# Android On-Device CLI & Shizuku Note

You are running natively ON an Android ARM64 device (`aarch64`).
- Do NOT download or execute desktop `linux_x86_64/install.sh` binaries.
- For live device inspection, package installs, UI layout dumps (`uiautomator dump`), screenshots (`screencap -p`), and intent launches on this Android device, use `rish -c "<cmd>"` (Shizuku ADB shell) directly!
