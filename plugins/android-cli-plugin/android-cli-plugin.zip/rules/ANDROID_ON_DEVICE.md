# Android On-Device CLI & Shizuku Note

You are running natively ON an Android ARM64 device (`aarch64`).
- The on-device `android` CLI is **already installed** at `$HOME/runtime/bin/android` (`android --version`, `android status`, `android devices`, `android layout`, `android screen capture --output /sdcard/Download/screen.png`, `android install <apk>`, `android shell "<cmd>"`).
- **NEVER** download or execute desktop `dl.google.com/android/cli/.../install.sh` binaries (those are desktop glibc binaries and cannot run on Android Bionic).
- Live device UI/ADB actions use **Shizuku (`rish`)** under the hood; if `android status` reports `shizuku:inactive`, simply let the user know they can start the Shizuku app whenever they want live UI control.
