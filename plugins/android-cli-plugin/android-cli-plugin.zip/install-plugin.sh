#!/system/bin/sh
# install-plugin.sh - Installs on-device `android` CLI wrapper into $HOME/runtime/bin/android
set -eu
SRC_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
case "$SRC_DIR" in
    */.gemini/*) HOME="${SRC_DIR%%/.gemini/*}" ;;
    *) HOME="${HOME:-/data/user/0/com.agy/files}" ;;
esac
PREFIX="${PREFIX:-$HOME/usr}"
TARGET_DIR="$HOME/.gemini/config/plugins/android-cli-plugin"
chmod 0755 "$TARGET_DIR/mcp/bin/android" 2>/dev/null || true
mkdir -p "$HOME/runtime/bin" 2>/dev/null || true
rm -f "$HOME/runtime/bin/android" 2>/dev/null || true
cat > "$HOME/runtime/bin/android" <<EOF
#!/system/bin/sh
export HOME="$HOME"
export PREFIX="$PREFIX"
exec "$TARGET_DIR/mcp/bin/android" "\$@"
EOF
chmod 0755 "$HOME/runtime/bin/android"
