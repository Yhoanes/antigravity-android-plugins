<p align="center">
  <img src="assets/logo.png" alt="Android CLI Logo" width="180" />
</p>

# Android CLI

**Android CLI** is the official command-line interface that standardizes core Android development competencies for agent-first workflows. It gives coding agents and developers an entry point to the official tools, skills, and documentation needed to build for Android efficiently.

Whether you are scaffolding a new app, launching virtual devices, running fast incremental builds, inspecting live device layouts, or evaluating user journeys, the Android CLI streamlines development directly from your workspace.

---

## 🚀 Key Capabilities

### 🛠️ Project Scaffolding
- Initialize modern Android projects from official templates using `android create`.
- Pre-configured with the latest Android Gradle Plugin (AGP), Jetpack Compose, and best practices.
- Print environment information including SDK location, connected devices, and configuration variables using `android info` (use specific fields to narrow the output).

### 📱 Device & Emulator Management
- Inspect, create, and launch Android Virtual Devices (AVDs) directly from the terminal with `android emulator`.
- Deploy and launch applications with fast delta installs using `android run`.

### 🧠 Agent Skills Management
- The `android skills` command provides an official way to discover, install, update, and manage recommended skills.
- Skills installed using this command aren't removed if the Android plugin for Antigravity is uninstalled.

### 🔍 UI Layout Inspection & Screen Analysis
- Extract the live application layout tree in structured JSON using `android layout`.
- Inspect UI hierarchies, interactive bounds, accessibility attributes, and focus states.
- Capture device screenshots and resolve visual coordinates for automated interactions using `android screen`.

### 🧪 Journey Testing
- Test end-to-end user flows with Journey tests defined using natural language, using `android layout` and visual verification.
- Output structured Markdown reports detailing pass/fail statuses, ADB interaction commands, and verification screenshots.

### 📚 Official Android Knowledge Base
- Search authoritative, up-to-date Android developer documentation directly from the CLI via `android docs search "<query>"`.
- Fetch full articles and migration guides using `android docs fetch kb://...`.

### 🖥️ Device Hub & Compose Preview Panes
- **Android Device Hub**: list, start, stop, create, and remove Android Virtual Devices, and mirror and control emulators and physical devices connected to adb, in a side pane.
- **Android Compose Preview**: render Jetpack Compose `@Preview` functions with `android preview` and review the results in a side pane.
- Both panes are served by the Android CLI (`android sidecar run <name>`), which downloads their implementation on first use.

---

## 📦 On-Device Android ARM64 Setup (Antigravity for Android)

On **Antigravity for Android (`aarch64`)**, the native on-device `android` CLI bridge is **bundled and pre-installed automatically** at `$HOME/runtime/bin/android` — no external desktop installer is needed.

1. Enable **Shizuku** on your Android device (via Wireless Debugging) whenever you want live UI inspection, screenshots, or silent APK installs.
2. Verify connection status from the Antigravity terminal or chat:
   ```bash
   android --version
   android status
   ```

> [!IMPORTANT]
> Do **not** run desktop `linux_x86_64/install.sh` scripts on Android Bionic ARM64 devices; use the bundled `android` bridge + `rish` directly.

---

## 💡 Starter Prompts

Once enabled, try asking your agent:

1. **Creating a new Android project**:
   > *"Create a new Android project called MyFirstApp using the empty-activity template"*

2. **Running on a device**:
   > *"Run my app on a Samsung Galaxy Ultra device."*

3. **Testing & Play readiness**:
   > *"Test my app and make sure that it's ready to publish to Google Play."*

---

## 📖 Command Reference

| Command | Description |
| :--- | :--- |
| `android create` | Initialize a new Android project from available templates. |
| `android describe` | Generate descriptive build target and artifact metadata for a project. |
| `android run` | Build, deploy, and launch an application on a connected device or emulator. |
| `android layout` | Returns the active UI layout tree in JSON format (supports `--pretty` and `--diff`). |
| `android screen` | Commands to view, capture, and target UI elements visually on device. |
| `android emulator` | Create, start, stop, and list Android Virtual Devices (AVDs). |
| `android sdk` | Manage Android SDK packages, platforms, and build tools. |
| `android docs` | Search and fetch documentation from the official Android Knowledge Base. |
| `android info` | Print environment information including SDK location, connected devices, and configuration variables. Use specific fields to narrow the output. |
| `android init` | Initialize the environment and install default Android CLI agent skills (skills that are installed aren't removed if the Android plugin for Antigravity is uninstalled). |
| `android skills` | Manage Android CLI skills (search, add, remove, list, update). Skills that are installed aren't removed if the Android plugin for Antigravity is uninstalled. |
| `android update` | Update the Android CLI to the latest version. |

---

For more documentation, visit [developer.android.com/tools/agents/android-cli](https://developer.android.com/tools/agents/android-cli).
